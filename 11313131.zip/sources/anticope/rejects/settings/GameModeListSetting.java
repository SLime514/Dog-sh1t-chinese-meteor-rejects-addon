package anticope.rejects.settings;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.function.Consumer;
import meteordevelopment.meteorclient.settings.IVisible;
import meteordevelopment.meteorclient.settings.Setting;
import net.minecraft.class_1934;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2519;
import net.minecraft.class_2520;

public class GameModeListSetting extends Setting<List<class_1934>> {
    public GameModeListSetting(String name, String description, List<class_1934> defaultValue, Consumer<List<class_1934>> onChanged, Consumer<Setting<List<class_1934>>> onModuleActivated, IVisible visible) {
        super(name, description, defaultValue, onChanged, onModuleActivated, visible);
    }

    public List<class_1934> m184parseImpl(String str) {
        String[] values = str.split(",");
        List<class_1934> modes = new ArrayList<>(values.length);
        for (String s : values) {
            class_1934 mode = class_1934.method_8385(s);
            if (mode != null) {
                modes.add(mode);
            }
        }
        return modes;
    }

    public boolean isValueValid(List<class_1934> value) {
        return true;
    }

    protected void resetImpl() {
        this.value = new ArrayList();
    }

    public class_2487 save(class_2487 tag) {
        class_2499 valueTag = new class_2499();
        for (class_1934 mode : (List) get()) {
            valueTag.add(class_2519.method_23256(mode.method_8381()));
        }
        tag.method_10566("value", valueTag);
        return tag;
    }

    public List<class_1934> m183load(class_2487 tag) {
        ((List) get()).clear();
        class_2499 valueTag = tag.method_10554("value", 8);
        Iterator it = valueTag.iterator();
        while (it.hasNext()) {
            class_2520 tagI = (class_2520) it.next();
            class_1934 mode = class_1934.method_8385(tagI.method_10714());
            if (mode != null) {
                ((List) get()).add(mode);
            }
        }
        return (List) get();
    }

    public static class Builder extends Setting.SettingBuilder<Builder, List<class_1934>, GameModeListSetting> {
        public Builder() {
            super(new ArrayList(0));
        }

        public Builder defaultValue(List<class_1934> map) {
            this.defaultValue = map;
            return this;
        }

        public GameModeListSetting m185build() {
            return new GameModeListSetting(this.name, this.description, (List) this.defaultValue, this.onChanged, this.onModuleActivated, this.visible);
        }
    }
}
