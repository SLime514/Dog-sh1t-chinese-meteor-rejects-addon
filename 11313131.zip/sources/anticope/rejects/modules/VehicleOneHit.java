package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1688;
import net.minecraft.class_1690;
import net.minecraft.class_2824;
import net.minecraft.class_3966;
import net.minecraft.class_7648;

public class VehicleOneHit extends Module {
    private final SettingGroup sgGeneral;

    private final Setting<Integer> f198;

    public VehicleOneHit() {
        super(MeteorRejectsAddon.CATEGORY, "车辆摧毁", "通过发送多个攻击数据包，实现一击摧毁矿车和船。");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.f198 = this.sgGeneral.add(((IntSetting.Builder) ((IntSetting.Builder) ((IntSetting.Builder) new IntSetting.Builder().name("数据包数量")).description("每次攻击发送的交互数据包数量。")).defaultValue(16)).range(1, 100).sliderRange(1, 20).build());
    }

    @EventHandler
    private void onPacketSend(PacketEvent.Send event) {
        if (event.packet instanceof class_2824) {
            class_3966 class_3966Var = this.mc.field_1765;
            if (class_3966Var instanceof class_3966) {
                class_3966 class_3966Var2 = class_3966Var;
                if (!(class_3966Var2.method_17782() instanceof class_1688) && !(class_3966Var2.method_17782() instanceof class_1690)) {
                    return;
                }
                for (int i = 0; i < ((Integer) this.f198.get()).intValue() - 1; i++) {
                    this.mc.field_1724.field_3944.method_48296().method_10752(event.packet, (class_7648) null);
                }
            }
        }
    }
}
