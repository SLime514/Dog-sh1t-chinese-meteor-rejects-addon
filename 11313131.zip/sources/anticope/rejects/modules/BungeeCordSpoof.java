package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import anticope.rejects.mixin.HandshakeC2SPacketAccessor;
import com.google.gson.Gson;
import java.util.List;
import java.util.Objects;
import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.StringListSetting;
import meteordevelopment.meteorclient.settings.StringSetting;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_2889;
import net.minecraft.class_8592;

public class BungeeCordSpoof extends Module {
    private final SettingGroup sgGeneral;
    private static final Gson GSON = new Gson();
    private final Setting<Boolean> whitelist;
    private final Setting<List<String>> whitelistedServers;
    private final Setting<Boolean> spoofProfile;
    private final Setting<String> forwardedIP;

    public BungeeCordSpoof() {
        super(MeteorRejectsAddon.CATEGORY, "BungeeCord伪造", "允许你加入BungeeCord代理服务器，在绕过代理检测时有用。");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.whitelist = this.sgGeneral.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("启用白名单")).description("仅对指定服务器生效。")).defaultValue(false)).build());
        SettingGroup settingGroup = this.sgGeneral;
        StringListSetting.Builder builder = (StringListSetting.Builder) ((StringListSetting.Builder) new StringListSetting.Builder().name("白名单服务器")).description("仅当你加入以上服务器时，模块才会工作。");
        Setting<Boolean> setting = this.whitelist;
        Objects.requireNonNull(setting);
        this.whitelistedServers = settingGroup.add(((StringListSetting.Builder) builder.visible(setting::get)).build());
        this.spoofProfile = this.sgGeneral.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("伪造账号档案")).description("伪造账号的属性档案信息。")).defaultValue(false)).build());
        this.forwardedIP = this.sgGeneral.add(((StringSetting.Builder) ((StringSetting.Builder) ((StringSetting.Builder) new StringSetting.Builder().name("转发IP地址")).description("用于BungeeCord转发的IP地址。")).defaultValue("127.0.0.1")).build());
        this.runInMainMenu = true;
    }

    @EventHandler
    private void onPacketSend(PacketEvent.Send event) {
        HandshakeC2SPacketAccessor handshakeC2SPacketAccessor = event.packet;
        if (handshakeC2SPacketAccessor instanceof class_2889) {
            HandshakeC2SPacketAccessor handshakeC2SPacketAccessor2 = (class_2889) handshakeC2SPacketAccessor;
            if (handshakeC2SPacketAccessor2.comp_1566() == class_8592.field_44975) {
                if (((Boolean) this.whitelist.get()).booleanValue() && !((List) this.whitelistedServers.get()).contains(Utils.getWorldName())) {
                    return;
                }
                handshakeC2SPacketAccessor2.setAddress(handshakeC2SPacketAccessor2.comp_1564() + "��" + ((String) this.forwardedIP.get()) + "��" + this.mc.method_1548().method_44717().toString().replace("-", "") + (((Boolean) this.spoofProfile.get()).booleanValue() ? m110getAccount() : ""));
            }
        }
    }

    private String m110getAccount() {
        return "��" + GSON.toJson(this.mc.method_53462().getProperties().values().toArray());
    }
}
