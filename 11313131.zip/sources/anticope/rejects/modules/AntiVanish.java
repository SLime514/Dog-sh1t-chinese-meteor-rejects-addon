package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Random;
import java.util.UUID;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import meteordevelopment.meteorclient.events.game.ReceiveMessageEvent;
import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.gui.GuiTheme;
import meteordevelopment.meteorclient.gui.widgets.WWidget;
import meteordevelopment.meteorclient.gui.widgets.containers.WVerticalList;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.StringSetting;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_2639;
import net.minecraft.class_2805;

public class AntiVanish extends Module {
    private final SettingGroup sgGeneral;
    private final Setting<Integer> interval;
    private final Setting<Mode> mode;
    private final Setting<String> command;

    private Map<UUID, String> f78player;

    private final List<String> f79;

    private final Random f5;

    private List<Integer> f80ID;

    private List<String> f81;

    private int f82;

    public enum Mode {
        f83,
        f84
    }

    public AntiVanish() {
        super(MeteorRejectsAddon.CATEGORY, "防隐身", "当管理员使用/vanish时通知用户。");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.interval = this.sgGeneral.add(((IntSetting.Builder) ((IntSetting.Builder) ((IntSetting.Builder) new IntSetting.Builder().name("检测间隔")).description("隐身检测的间隔时间。")).defaultValue(100)).min(0).sliderMax(300).build());
        this.mode = this.sgGeneral.add(((EnumSetting.Builder) ((EnumSetting.Builder) new EnumSetting.Builder().name("模式")).defaultValue(Mode.f83)).build());
        this.command = this.sgGeneral.add(((StringSetting.Builder) ((StringSetting.Builder) ((StringSetting.Builder) ((StringSetting.Builder) new StringSetting.Builder().name("命令")).description("用于检测玩家名称的补全命令。")).defaultValue("minecraft:msg")).visible(() -> {
            return this.mode.get() == Mode.f84;
        })).build());
        this.f78player = new HashMap();
        this.f79 = new ArrayList();
        this.f5 = new Random();
        this.f80ID = new ArrayList();
        this.f81 = new ArrayList();
        this.f82 = 0;
    }

    public void onActivate() {
        this.f82 = 0;
        this.f80ID.clear();
        this.f79.clear();
    }

    public WWidget getWidget(GuiTheme theme) {
        WVerticalList l = theme.verticalList();
        l.add(theme.label("离开消息：如果客户端没有收到退出游戏的消息（如Essentials插件的情况）。"));
        l.add(theme.label("真实加入消息：通过玩家名称补全来判断玩家是否真的离开。"));
        return l;
    }

    @EventHandler
    private void onPacket(PacketEvent.Receive event) {
        if (this.mode.get() == Mode.f84) {
            class_2639 class_2639Var = event.packet;
            if (class_2639Var instanceof class_2639) {
                class_2639 class_2639Var2 = class_2639Var;
                if (this.f80ID.contains(Integer.valueOf(class_2639Var2.comp_2262()))) {
                    List<String> list = this.f81.stream().toList();
                    this.f81 = class_2639Var2.method_11397().getList().stream().map((v0) -> {
                        return v0.getText();
                    }).toList();
                    if (list.isEmpty()) {
                        return;
                    }
                    Predicate<String> predicate = str -> {
                        return list.contains(str) != this.f81.contains(str);
                    };
                    for (String str2 : this.f81) {
                        if (!Objects.equals(str2, this.mc.field_1724.method_5477().getString()) && !str2.contains(" ") && str2.length() >= 3 && str2.length() <= 16 && predicate.test(str2)) {
                            info("玩家加入：" + str2, new Object[0]);
                        }
                    }
                    for (String str3 : list) {
                        if (!Objects.equals(str3, this.mc.field_1724.method_5477().getString()) && !str3.contains(" ") && str3.length() >= 3 && str3.length() <= 16 && predicate.test(str3)) {
                            info("玩家离开：" + str3, new Object[0]);
                        }
                    }
                    this.f80ID.remove(Integer.valueOf(class_2639Var2.comp_2262()));
                    event.cancel();
                }
            }
        }
    }

    @EventHandler
    private void onReceiveMessage(ReceiveMessageEvent event) {
        this.f79.add(event.getMessage().getString());
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        this.f82++;
        if (this.f82 < ((Integer) this.interval.get()).intValue()) {
            return;
        }
        switch ((Mode) this.mode.get()) {
            case f83:
                Map<UUID, String> mapCopyOf = Map.copyOf(this.f78player);
                this.f78player = (Map) this.mc.method_1562().method_2880().stream().collect(Collectors.toMap(e -> {
                    return e.method_2966().getId();
                }, e2 -> {
                    return e2.method_2966().getName();
                }));
                for (UUID uuid : mapCopyOf.keySet()) {
                    if (!this.f78player.containsKey(uuid)) {
                        String str = mapCopyOf.get(uuid);
                        if (!str.contains(" ") && str.length() >= 3 && str.length() <= 16 && this.f79.stream().noneMatch(s -> {
                            return s.contains(str);
                        })) {
                            warning(str + " 进入隐身状态。", new Object[0]);
                        }
                    }
                }
                break;
            case f84:
                int id = this.f5.nextInt(200);
                this.f80ID.add(Integer.valueOf(id));
                this.mc.method_1562().method_52787(new class_2805(id, ((String) this.command.get()) + " "));
                break;
        }
        this.f82 = 0;
        this.f79.clear();
    }
}
