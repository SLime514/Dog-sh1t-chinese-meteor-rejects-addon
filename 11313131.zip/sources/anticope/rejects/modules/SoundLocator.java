package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.PlaySoundEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.ColorSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.SoundEventListSetting;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1113;
import net.minecraft.class_1146;
import net.minecraft.class_124;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_3414;
import net.minecraft.class_5250;

public class SoundLocator extends Module {
    private final SettingGroup sgGeneral;
    private final SettingGroup sgRender;

    private final Setting<Boolean> f178;

    private final Setting<List<class_3414>> f179;

    private final Setting<Boolean> f180;

    private final Setting<Integer> f181;

    private final Setting<Boolean> f182;

    private final Setting<ShapeMode> f183;

    private final Setting<SettingColor> f184;

    private final Setting<SettingColor> f185;

    private List<class_243> f186;

    private List<Integer> f187;

    public SoundLocator() {
        super(MeteorRejectsAddon.CATEGORY, "声音定位器", "追踪并显示游戏中声音事件的位置。");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.sgRender = this.settings.createGroup("渲染");
        this.f178 = this.sgGeneral.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("白名单模式")).description("启用声音过滤白名单（仅追踪指定声音）。")).defaultValue(false)).build());
        SettingGroup settingGroup = this.sgGeneral;
        SoundEventListSetting.Builder builder = (SoundEventListSetting.Builder) ((SoundEventListSetting.Builder) ((SoundEventListSetting.Builder) new SoundEventListSetting.Builder().name("目标声音")).description("需要追踪的声音列表。")).defaultValue(new ArrayList(0));
        Setting<Boolean> setting = this.f178;
        Objects.requireNonNull(setting);
        this.f179 = settingGroup.add(((SoundEventListSetting.Builder) builder.visible(setting::get)).build());
        this.f180 = this.sgGeneral.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("聊天日志")).description("在聊天中发送声音的位置信息。")).defaultValue(false)).build());
        this.f181 = this.sgGeneral.add(((IntSetting.Builder) ((IntSetting.Builder) ((IntSetting.Builder) new IntSetting.Builder().name("显示时间")).description("声音位置标记的显示时间（游戏刻）。")).defaultValue(60)).build());
        this.f182 = this.sgRender.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("渲染位置")).description("在声音发出的位置渲染标记框。")).defaultValue(true)).build());
        this.f183 = this.sgRender.add(((EnumSetting.Builder) ((EnumSetting.Builder) ((EnumSetting.Builder) new EnumSetting.Builder().name("形状模式")).description("标记框的渲染方式。")).defaultValue(ShapeMode.Both)).build());
        this.f184 = this.sgRender.add(((ColorSetting.Builder) ((ColorSetting.Builder) new ColorSetting.Builder().name("面颜色")).description("标记框的填充颜色。")).defaultValue(new SettingColor(255, 0, 0, 70)).build());
        this.f185 = this.sgRender.add(((ColorSetting.Builder) ((ColorSetting.Builder) new ColorSetting.Builder().name("线颜色")).description("标记框的边框颜色。")).defaultValue(new SettingColor(255, 0, 0)).build());
        this.f186 = new ArrayList();
        this.f187 = new ArrayList();
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        Iterator<Integer> it = this.f187.iterator();
        while (it.hasNext()) {
            int iIntValue = it.next().intValue();
            if (iIntValue <= 0) {
                it.remove();
                this.f186.remove(0);
            } else {
                this.f187.set(this.f187.indexOf(Integer.valueOf(iIntValue)), Integer.valueOf(iIntValue - 1));
            }
        }
    }

    @EventHandler
    private void onPlaySound(PlaySoundEvent event) {
        if (((Boolean) this.f178.get()).booleanValue()) {
            Iterator it = ((List) this.f179.get()).iterator();
            while (it.hasNext()) {
                if (((class_3414) it.next()).comp_3319().equals(event.sound.method_4775())) {
                    m166(event.sound);
                    return;
                }
            }
            return;
        }
        m166(event.sound);
    }

    private void m166(class_1113 class_1113Var) {
        class_5250 class_5250VarMethod_43470;
        class_1146 class_1146VarMethod_4869 = this.mc.method_1483().method_4869(class_1113Var.method_4775());
        class_243 class_243Var = new class_243(class_1113Var.method_4784() - 0.5d, class_1113Var.method_4779() - 0.5d, class_1113Var.method_4778() - 0.5d);
        if (!this.f186.contains(class_243Var)) {
            this.f186.add(class_243Var);
            this.f187.add((Integer) this.f181.get());
            if (((Boolean) this.f180.get()).booleanValue()) {
                if (class_1146VarMethod_4869 == null || class_1146VarMethod_4869.method_4886() == null) {
                    class_5250VarMethod_43470 = class_2561.method_43470(class_1113Var.method_4775().toString());
                } else {
                    class_5250VarMethod_43470 = class_1146VarMethod_4869.method_4886().method_27661();
                }
                class_5250VarMethod_43470.method_27693(String.format("%s 在 ", class_124.field_1070));
                class_5250VarMethod_43470.method_10852(ChatUtils.formatCoords(class_243Var));
                class_5250VarMethod_43470.method_27693(String.format("%s。", class_124.field_1070));
                info(class_5250VarMethod_43470);
            }
        }
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        if (((Boolean) this.f182.get()).booleanValue()) {
            this.f186.forEach(class_243Var -> {
                event.renderer.box(class_238.method_29968(class_243Var), (Color) this.f184.get(), (Color) this.f185.get(), (ShapeMode) this.f183.get(), 0);
            });
        }
    }
}
