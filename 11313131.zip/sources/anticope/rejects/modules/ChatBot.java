package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import anticope.rejects.settings.StringMapSetting;
import java.util.LinkedHashMap;
import java.util.Map;
import meteordevelopment.meteorclient.events.game.ReceiveMessageEvent;
import meteordevelopment.meteorclient.gui.utils.StarscriptTextBoxRenderer;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.StringSetting;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.misc.MeteorStarscript;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import meteordevelopment.orbit.EventHandler;
import meteordevelopment.starscript.Script;
import meteordevelopment.starscript.compiler.Compiler;
import meteordevelopment.starscript.compiler.Parser;
import meteordevelopment.starscript.utils.Error;
import meteordevelopment.starscript.utils.StarscriptError;

public class ChatBot extends Module {
    private final SettingGroup sgGeneral;
    private final Setting<String> prefix;
    private final Setting<Boolean> help;
    private final Setting<Map<String, String>> commands;

    public ChatBot() {
        super(MeteorRejectsAddon.CATEGORY, "聊天机器人", "自动响应聊天消息的机器人，支持自定义命令与变量解析。");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.prefix = this.sgGeneral.add(((StringSetting.Builder) ((StringSetting.Builder) ((StringSetting.Builder) new StringSetting.Builder().name("命令前缀")).description("聊天机器人的命令触发前缀。")).defaultValue("!")).build());
        this.help = this.sgGeneral.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("启用帮助命令")).description("添加help命令，用于查看所有可用指令。")).defaultValue(true)).build());
        this.commands = this.sgGeneral.add(((StringMapSetting.Builder) ((StringMapSetting.Builder) new StringMapSetting.Builder().name("自定义命令")).description("设置聊天机器人的触发命令与对应回复。")).renderer(StarscriptTextBoxRenderer.class).defaultValue((Map<String, String>) new LinkedHashMap<String, String>() {
            {
                put("ping", "Pong!");
                put("tps", "当前服务器TPS：{server.tps}");
                put("time", "当前游戏时间：{server.time}");
                put("pos", "我的当前位置：{player.pos}");
            }
        }).m188build());
    }

    @EventHandler
    private void onMessageRecieve(ReceiveMessageEvent event) {
        String string = event.getMessage().getString();
        if (((Boolean) this.help.get()).booleanValue() && string.endsWith(((String) this.prefix.get()) + "help")) {
            ChatUtils.sendPlayerMsg("可用命令：" + String.join("、", ((Map) this.commands.get()).keySet()));
            return;
        }
        for (String str : ((Map) this.commands.get()).keySet()) {
            if (string.endsWith(((String) this.prefix.get()) + str)) {
                Script scriptM112 = m112((String) ((Map) this.commands.get()).get(str));
                if (scriptM112 == null) {
                    ChatUtils.sendPlayerMsg("命令执行出错：脚本编译失败");
                    return;
                }
                try {
                    ChatUtils.sendPlayerMsg(MeteorStarscript.ss.run(scriptM112).text);
                    return;
                } catch (StarscriptError e) {
                    MeteorStarscript.printChatError(e);
                    ChatUtils.sendPlayerMsg("命令执行出错：变量解析失败");
                    return;
                }
            }
        }
    }

    private static Script m112(String str) {
        if (str == null) {
            return null;
        }
        Parser.Result result = Parser.parse(str);
        if (result.hasErrors()) {
            MeteorStarscript.printChatError((Error) result.errors.get(0));
            return null;
        }
        return Compiler.compile(result);
    }
}
