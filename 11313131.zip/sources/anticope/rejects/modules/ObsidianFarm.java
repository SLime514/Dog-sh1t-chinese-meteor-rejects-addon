package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.systems.modules.player.AutoEat;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_9334;

public class ObsidianFarm extends Module {

    private boolean f159;

    public ObsidianFarm() {
        super(MeteorRejectsAddon.CATEGORY, "黑曜石农场", "自动开采黑曜石（适用于黑曜石农场/传送门结构），支持自动切换镐子。");
    }

    public void onActivate() {
        this.f159 = true;
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (this.mc.field_1724 == null || this.mc.field_1687 == null || this.mc.field_1761 == null) {
            return;
        }
        if (this.mc.field_1687.method_8597().comp_649()) {
            this.f159 = true;
            return;
        }
        if (this.f159) {
            if ((this.mc.field_1724.method_6115() || Modules.get().get(AutoEat.class).isActive()) && (this.mc.field_1724.method_6079().method_57826(class_9334.field_50075) || this.mc.field_1724.method_6047().method_57826(class_9334.field_50075))) {
                return;
            }
            if (this.mc.field_1724.method_6047().method_7909() != class_1802.field_22024 && this.mc.field_1724.method_6047().method_7909() != class_1802.field_8377) {
                int iM147 = m147();
                if (iM147 == -1 && isActive()) {
                    toggle();
                    return;
                }
                this.mc.field_1724.method_31548().field_7545 = iM147;
            }
            class_2338 class_2338VarM146 = m146();
            if (class_2338VarM146 == null) {
                return;
            }
            this.mc.field_1761.method_2902(class_2338VarM146, class_2350.field_11036);
            this.mc.field_1724.method_6104(class_1268.field_5808);
            if (this.mc.field_1724.method_24515().method_10074().equals(class_2338VarM146) && this.mc.field_1687.method_8320(class_2338VarM146).method_26204() != class_2246.field_10540) {
                this.f159 = false;
            }
        }
    }

    private class_2338 m146() {
        List<class_2338> arrayList = new ArrayList<>();
        for (int x = -2; x < 3; x++) {
            for (int z = -2; z < 3; z++) {
                arrayList.add(new class_2338(this.mc.field_1724.method_24515().method_10263() + x, this.mc.field_1724.method_24515().method_10264() + 2, this.mc.field_1724.method_24515().method_10260() + z));
            }
        }
        Optional<class_2338> optionalMin = ((Stream) arrayList.stream().parallel()).filter(class_2338Var -> {
            return this.mc.field_1687.method_8320(class_2338Var).method_26204() == class_2246.field_10540;
        }).min(Comparator.comparingDouble(class_2338Var2 -> {
            return this.mc.field_1724.method_5649(class_2338Var2.method_10263(), class_2338Var2.method_10264(), class_2338Var2.method_10260());
        }));
        if (optionalMin.isPresent()) {
            return optionalMin.get();
        }
        arrayList.clear();
        for (int x2 = -2; x2 < 3; x2++) {
            for (int z2 = -2; z2 < 3; z2++) {
                for (int y = 3; y > -2; y--) {
                    arrayList.add(new class_2338(this.mc.field_1724.method_24515().method_10263() + x2, this.mc.field_1724.method_24515().method_10264() + y, this.mc.field_1724.method_24515().method_10260() + z2));
                }
            }
        }
        Optional<class_2338> optionalMin2 = ((Stream) arrayList.stream().parallel()).filter(class_2338Var3 -> {
            return !this.mc.field_1724.method_24515().method_10074().equals(class_2338Var3);
        }).filter(class_2338Var4 -> {
            return this.mc.field_1687.method_8320(class_2338Var4).method_26204() == class_2246.field_10540;
        }).min(Comparator.comparingDouble(class_2338Var5 -> {
            return this.mc.field_1724.method_5649(class_2338Var5.method_10263(), class_2338Var5.method_10264(), class_2338Var5.method_10260());
        }));
        if (optionalMin2.isPresent()) {
            return optionalMin2.get();
        }
        if (this.mc.field_1687.method_8320(this.mc.field_1724.method_24515().method_10074()).method_26204() == class_2246.field_10540) {
            return this.mc.field_1724.method_24515().method_10074();
        }
        return null;
    }

    private int m147() {
        for (int i = 0; i < 9; i++) {
            if (this.mc.field_1724.method_31548().method_5438(i).method_7909() == class_1802.field_22024) {
                return i;
            }
            if (this.mc.field_1724.method_31548().method_5438(i).method_7909() == class_1802.field_8377) {
                return i;
            }
        }
        return -1;
    }
}
