package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import java.util.ArrayList;
import java.util.List;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BlockListSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1713;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_3965;

public class LawnBot extends Module {

    private final ArrayList<class_2338> f153;
    private final SettingGroup sgGeneral;
    private final Setting<List<class_2248>> blockWhitelist;

    public LawnBot() {
        super(MeteorRejectsAddon.CATEGORY, "草坪机器人", "自动将多种泥土类方块（如菌丝、灰化土）替换为草方块，快速打造平整草坪。");
        this.f153 = new ArrayList<>();
        this.sgGeneral = this.settings.getDefaultGroup();
        this.blockWhitelist = this.sgGeneral.add(((BlockListSetting.Builder) ((BlockListSetting.Builder) new BlockListSetting.Builder().name("方块白名单")).description("需要替换为草方块的泥土类方块（默认包含菌丝、灰化土等）。")).defaultValue(new class_2248[]{class_2246.field_10402, class_2246.field_10520, class_2246.field_10194, class_2246.field_10253, class_2246.field_28685}).filter(this::grassFilter).build());
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        class_1792 class_1792Var = class_1802.field_8270;
        if (InvUtils.find(new class_1792[]{class_1792Var}).count() == 0) {
            return;
        }
        int iSlot = InvUtils.findInHotbar(itemStack -> {
            return itemStack.method_7909() == class_1792Var;
        }).slot();
        if (iSlot == -1) {
            int iSlot2 = InvUtils.find(itemStack2 -> {
                return itemStack2.method_7909() == class_1792Var;
            }).slot();
            if (iSlot2 == -1) {
                return;
            }
            this.mc.field_1761.method_2906(this.mc.field_1724.field_7512.field_7763, iSlot2 < 9 ? iSlot2 + 36 : iSlot2, 8, class_1713.field_7791, this.mc.field_1724);
            return;
        }
        for (int i = 0; i < this.f153.size(); i++) {
            class_2338 class_2338Var = this.f153.get(i);
            class_2248 class_2248VarMethod_26204 = this.mc.field_1687.method_8320(class_2338Var).method_26204();
            double dMethod_1022 = this.mc.field_1724.method_19538().method_1022(new class_243(class_2338Var.method_10263(), class_2338Var.method_10264(), class_2338Var.method_10260()));
            if (class_2248VarMethod_26204 == class_2246.field_10124 && dMethod_1022 <= 5.0d) {
                this.mc.field_1724.method_31548().field_7545 = iSlot;
                this.mc.field_1761.method_2896(this.mc.field_1724, class_1268.field_5808, new class_3965(new class_243(class_2338Var.method_10263(), class_2338Var.method_10264(), class_2338Var.method_10260()), class_2350.field_11036, class_2338Var, false));
                return;
            } else {
                if (!((List) this.blockWhitelist.get()).contains(class_2248VarMethod_26204)) {
                    this.f153.remove(i);
                }
            }
        }
        for (int i2 = 0; i2 < this.f153.size(); i2++) {
            class_2338 class_2338Var2 = this.f153.get(i2);
            class_2248 class_2248VarMethod_262042 = this.mc.field_1687.method_8320(class_2338Var2).method_26204();
            double dMethod_10222 = this.mc.field_1724.method_19538().method_1022(new class_243(class_2338Var2.method_10263(), class_2338Var2.method_10264(), class_2338Var2.method_10260()));
            if (((List) this.blockWhitelist.get()).contains(class_2248VarMethod_262042) && dMethod_10222 <= 5.0d) {
                this.mc.field_1761.method_2902(class_2338Var2, class_2350.field_11036);
                return;
            }
        }
        this.f153.clear();
        for (int x = -5; x < 5; x++) {
            for (int y = -3; y < 3; y++) {
                for (int z = -5; z < 5; z++) {
                    class_2338 class_2338VarMethod_10069 = this.mc.field_1724.method_24515().method_10069(x, y, z);
                    if (((List) this.blockWhitelist.get()).contains(this.mc.field_1687.method_8320(class_2338VarMethod_10069).method_26204())) {
                        this.f153.add(class_2338VarMethod_10069);
                    }
                }
            }
        }
    }

    private boolean grassFilter(class_2248 block) {
        return block == class_2246.field_10402 || block == class_2246.field_10520 || block == class_2246.field_10194 || block == class_2246.field_10253 || block == class_2246.field_28685;
    }
}
