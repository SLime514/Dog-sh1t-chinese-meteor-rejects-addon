package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import meteordevelopment.meteorclient.events.Cancellable;
import meteordevelopment.meteorclient.events.meteor.MouseButtonEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.systems.modules.combat.KillAura;
import meteordevelopment.meteorclient.utils.misc.input.KeyAction;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1743;
import net.minecraft.class_243;
import net.minecraft.class_2824;
import net.minecraft.class_2828;
import net.minecraft.class_2879;
import net.minecraft.class_3966;

public class ShieldBypass extends Module {
    private final SettingGroup sgGeneral;
    private final Setting<Boolean> ignoreAxe;

    public ShieldBypass() {
        super(MeteorRejectsAddon.CATEGORY, "盾牌绕过", "通过短暂传送至敌人身后的方式，绕过敌方盾牌防御进行攻击。");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.ignoreAxe = this.sgGeneral.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("忽略斧头")).description("手持斧头时，不触发盾牌绕过逻辑（斧头本身可破盾，无需额外绕过）。")).defaultValue(true)).build());
    }

    @EventHandler
    private void onMouseButton(MouseButtonEvent event) {
        if (!Modules.get().isActive(KillAura.class) && this.mc.field_1755 == null && !this.mc.field_1724.method_6115() && event.action == KeyAction.Press && event.button == 0) {
            class_3966 class_3966Var = this.mc.field_1765;
            if (class_3966Var instanceof class_3966) {
                bypass(class_3966Var.method_17782(), event);
            }
        }
    }

    private boolean m162(class_243 class_243Var, class_1309 class_1309Var) {
        class_243 class_243VarMethod_1029 = class_243Var.method_1035(class_1309Var.method_19538()).method_1029();
        return new class_243(class_243VarMethod_1029.field_1352, 0.0d, class_243VarMethod_1029.field_1350).method_1026(class_1309Var.method_5828(1.0f)) >= 0.0d;
    }

    public void bypass(class_1297 class_1297Var, Cancellable cancellable) {
        if (class_1297Var instanceof class_1309) {
            class_1309 class_1309Var = (class_1309) class_1297Var;
            if (class_1309Var.method_6039()) {
                if ((((Boolean) this.ignoreAxe.get()).booleanValue() && InvUtils.testInMainHand(class_1799Var -> {
                    return class_1799Var.method_7909() instanceof class_1743;
                })) || m162(this.mc.field_1724.method_19538(), class_1309Var)) {
                    return;
                }
                class_243 class_243VarMethod_1021 = class_243.method_1030(0.0f, this.mc.field_1724.method_36454()).method_1029().method_1021(2.0d);
                class_243 class_243VarMethod_1019 = class_1309Var.method_19538().method_1019(class_243VarMethod_1021);
                boolean z = false;
                float f = 0.0f;
                while (true) {
                    float f2 = f;
                    if (f2 >= 4.0f) {
                        break;
                    }
                    class_243 class_243VarMethod_1031 = class_243VarMethod_1019.method_1031(0.0d, f2, 0.0d);
                    boolean z2 = !this.mc.field_1687.method_8587((class_1297) null, class_1309Var.method_5829().method_997(class_243VarMethod_1021).method_997(class_243VarMethod_1031.method_1020(class_243VarMethod_1019)));
                    if (!z && z2) {
                        z = true;
                    } else if (z && !z2) {
                        class_243VarMethod_1019 = class_243VarMethod_1031;
                        break;
                    }
                    f = (float) (f2 + 0.25d);
                }
                if (m162(class_243VarMethod_1019, class_1309Var)) {
                    cancellable.cancel();
                    this.mc.method_1562().method_52787(new class_2828.class_2829(class_243VarMethod_1019.method_10216(), class_243VarMethod_1019.method_10214(), class_243VarMethod_1019.method_10215(), true, false));
                    this.mc.method_1562().method_52787(class_2824.method_34206(class_1309Var, this.mc.field_1724.method_5715()));
                    this.mc.method_1562().method_52787(new class_2879(this.mc.field_1724.method_6058()));
                    this.mc.field_1724.method_7350();
                    this.mc.method_1562().method_52787(new class_2828.class_2829(this.mc.field_1724.method_23317(), this.mc.field_1724.method_23318(), this.mc.field_1724.method_23321(), true, this.mc.field_1724.field_5976));
                }
            }
        }
    }
}
