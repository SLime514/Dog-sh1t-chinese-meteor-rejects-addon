package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import com.seedfinding.mccore.nbt.NBTType;
import java.util.Objects;
import java.util.Random;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.ColorSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.entity.SortPriority;
import meteordevelopment.meteorclient.utils.entity.TargetUtils;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1297;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_3959;
import net.minecraft.class_3965;

public class Confuse extends Module {
    private final SettingGroup sgGeneral;
    private final Setting<Mode> mode;
    private final Setting<Integer> delay;
    private final Setting<Integer> range;
    private final Setting<SortPriority> priority;
    private final Setting<Integer> circleSpeed;
    private final Setting<Boolean> moveThroughBlocks;
    private final Setting<Boolean> budgetGraphics;
    private final Setting<SettingColor> circleColor;

    int f139;

    double f140;

    double f141;

    class_1297 f142;

    public enum Mode {
        RandomTP("随机传送"),
        Switch("相对位移"),
        Circle("环形环绕");

        public final String chineseName;

        Mode(String chineseName) {
            this.chineseName = chineseName;
        }

        @Override
        public String toString() {
            return this.chineseName;
        }
    }

    public Confuse() {
        super(MeteorRejectsAddon.CATEGORY, "敌人混淆", "通过不规则移动干扰敌人的瞄准与判断。");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.mode = this.sgGeneral.add(((EnumSetting.Builder) ((EnumSetting.Builder) ((EnumSetting.Builder) new EnumSetting.Builder().name("混淆模式")).description("混淆敌人的移动模式。")).defaultValue(Mode.RandomTP)).build());
        this.delay = this.sgGeneral.add(((IntSetting.Builder) ((IntSetting.Builder) ((IntSetting.Builder) new IntSetting.Builder().name("移动间隔")).description("每次移动之间的tick间隔（1秒=20tick）。")).defaultValue(3)).min(0).sliderMax(20).build());
        this.range = this.sgGeneral.add(((IntSetting.Builder) ((IntSetting.Builder) ((IntSetting.Builder) new IntSetting.Builder().name("作用半径")).description("围绕目标混淆的最大半径（单位：方块）。")).defaultValue(6)).min(0).sliderMax(10).build());
        this.priority = this.sgGeneral.add(((EnumSetting.Builder) ((EnumSetting.Builder) ((EnumSetting.Builder) new EnumSetting.Builder().name("目标优先级")).description("选择目标时的优先级排序方式。")).defaultValue(SortPriority.LowestHealth)).build());
        this.circleSpeed = this.sgGeneral.add(((IntSetting.Builder) ((IntSetting.Builder) ((IntSetting.Builder) new IntSetting.Builder().name("环形速度")).description("环形环绕模式下的旋转速度（单位：度/tick）。")).defaultValue(10)).min(1).sliderMax(180).build());
        this.moveThroughBlocks = this.sgGeneral.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("穿透方块")).description("是否允许穿过方块进行移动。")).defaultValue(false)).build());
        this.budgetGraphics = this.sgGeneral.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("简化渲染")).description("启用后使用单色简化渲染（提升性能）。")).defaultValue(false)).build());
        SettingGroup settingGroup = this.sgGeneral;
        ColorSetting.Builder builderDefaultValue = ((ColorSetting.Builder) ((ColorSetting.Builder) new ColorSetting.Builder().name("环形颜色")).description("简化渲染模式下环形效果的颜色。")).defaultValue(new SettingColor(0, 255, 0));
        Setting<Boolean> setting = this.budgetGraphics;
        Objects.requireNonNull(setting);
        this.circleColor = settingGroup.add(((ColorSetting.Builder) builderDefaultValue.visible(setting::get)).build());
        this.f139 = 0;
        this.f140 = 0.0d;
        this.f141 = 0.0d;
        this.f142 = null;
    }

    public void onActivate() {
        this.f139 = 0;
        this.f140 = 0.0d;
        this.f141 = 0.0d;
        this.f142 = null;
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        this.f139++;
        if (this.f139 < ((Integer) this.delay.get()).intValue()) {
        }
        this.f139 = 0;
        this.f142 = TargetUtils.getPlayerTarget(((Integer) this.range.get()).intValue(), (SortPriority) this.priority.get());
        if (this.f142 == null) {
            return;
        }
        class_243 class_243VarMethod_19538 = this.f142.method_19538();
        class_243 class_243VarMethod_195382 = this.mc.field_1724.method_19538();
        Random random = new Random();
        int iIntValue = ((Integer) this.range.get()).intValue() / 2;
        switch (((Mode) this.mode.get()).ordinal()) {
            case 0:
                double dNextDouble = (random.nextDouble() * ((Integer) this.range.get()).intValue()) - iIntValue;
                double dNextDouble2 = (random.nextDouble() * ((Integer) this.range.get()).intValue()) - iIntValue;
                class_243 class_243VarMethod_1019 = class_243VarMethod_19538.method_1019(new class_243(dNextDouble, 0.0d, dNextDouble2));
                if (this.mc.field_1687.method_8320(class_2338.method_49637(class_243VarMethod_1019.field_1352, class_243VarMethod_1019.field_1351, class_243VarMethod_1019.field_1350)).method_26204() != class_2246.field_10124) {
                    class_243VarMethod_1019 = new class_243(dNextDouble, class_243VarMethod_195382.field_1351, dNextDouble2);
                }
                if (this.mc.field_1687.method_8320(class_2338.method_49637(class_243VarMethod_1019.field_1352, class_243VarMethod_1019.field_1351, class_243VarMethod_1019.field_1350)).method_26204() == class_2246.field_10124) {
                    class_3965 class_3965VarMethod_17742 = this.mc.field_1687.method_17742(new class_3959(class_243VarMethod_195382, class_243VarMethod_1019, class_3959.class_3960.field_17558, class_3959.class_242.field_1347, this.mc.field_1724));
                    if (!((Boolean) this.moveThroughBlocks.get()).booleanValue() && class_3965VarMethod_17742.method_17781()) {
                        this.f139 = ((Integer) this.delay.get()).intValue() - 1;
                        break;
                    } else {
                        this.mc.field_1724.method_30634(class_243VarMethod_1019.field_1352, class_243VarMethod_1019.field_1351, class_243VarMethod_1019.field_1350);
                        break;
                    }
                } else {
                    this.f139 = ((Integer) this.delay.get()).intValue() - 1;
                    break;
                }
                break;
            case 1:
                class_243 class_243VarMethod_1020 = class_243VarMethod_19538.method_1020(class_243VarMethod_195382);
                class_243 class_243VarMethod_10192 = class_243VarMethod_19538.method_1019(new class_243(class_3532.method_15350(class_243VarMethod_1020.field_1352, -iIntValue, iIntValue), class_3532.method_15350(class_243VarMethod_1020.field_1351, -iIntValue, iIntValue), class_3532.method_15350(class_243VarMethod_1020.field_1350, -iIntValue, iIntValue)));
                class_3965 class_3965VarMethod_177422 = this.mc.field_1687.method_17742(new class_3959(class_243VarMethod_195382, class_243VarMethod_10192, class_3959.class_3960.field_17558, class_3959.class_242.field_1347, this.mc.field_1724));
                if (!((Boolean) this.moveThroughBlocks.get()).booleanValue() && class_3965VarMethod_177422.method_17781()) {
                    this.f139 = ((Integer) this.delay.get()).intValue() - 1;
                    break;
                } else {
                    this.mc.field_1724.method_30634(class_243VarMethod_10192.field_1352, class_243VarMethod_10192.field_1351, class_243VarMethod_10192.field_1350);
                    break;
                }
                break;
            case NBTType.SHORT:
                this.delay.set(0);
                this.f140 += ((Integer) this.circleSpeed.get()).intValue();
                if (this.f140 > 360.0d) {
                    this.f140 -= 360.0d;
                }
                double radians = Math.toRadians(this.f140);
                class_243 class_243Var = new class_243(class_243VarMethod_19538.field_1352 + (Math.sin(radians) * 3.0d), class_243VarMethod_195382.field_1351, class_243VarMethod_19538.field_1350 + (Math.cos(radians) * 3.0d));
                class_3965 class_3965VarMethod_177423 = this.mc.field_1687.method_17742(new class_3959(class_243VarMethod_195382, class_243Var, class_3959.class_3960.field_17558, class_3959.class_242.field_1347, this.mc.field_1724));
                if (((Boolean) this.moveThroughBlocks.get()).booleanValue() || !class_3965VarMethod_177423.method_17781()) {
                    this.mc.field_1724.method_30634(class_243Var.field_1352, class_243Var.field_1351, class_243Var.field_1350);
                    break;
                }
                break;
        }
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        Color color;
        if (this.f142 == null) {
            return;
        }
        boolean zBooleanValue = ((Boolean) this.budgetGraphics.get()).booleanValue();
        class_243 class_243Var = null;
        this.f141 += zBooleanValue ? 0.0d : 1.0d;
        if (this.f141 > 360.0d) {
            this.f141 = 0.0d;
        }
        int i = 0;
        while (true) {
            int i2 = i;
            if (i2 < 360) {
                if (zBooleanValue) {
                    color = (Color) this.circleColor.get();
                } else {
                    double d = (765.0d * ((i2 + this.f141) % 360.0d)) / 360.0d;
                    int iFloor = (int) Math.floor(d / 255.0d);
                    double d2 = d % 255.0d;
                    color = new Color((int) (iFloor == 0 ? d2 : iFloor == 1 ? Math.abs(d2 - 255.0d) : 0.0d), (int) (iFloor == 1 ? d2 : iFloor == 2 ? Math.abs(d2 - 255.0d) : 0.0d), (int) (iFloor == 2 ? d2 : iFloor == 0 ? Math.abs(d2 - 255.0d) : 0.0d));
                }
                class_243 class_243VarMethod_19538 = this.f142.method_19538();
                double radians = Math.toRadians(i2);
                class_243 class_243Var2 = new class_243(class_243VarMethod_19538.field_1352 + (Math.sin(radians) * 3.0d), class_243VarMethod_19538.field_1351 + (this.f142.method_17682() / 2.0f), class_243VarMethod_19538.field_1350 + (Math.cos(radians) * 3.0d));
                if (class_243Var != null) {
                    event.renderer.line(class_243Var.field_1352, class_243Var.field_1351, class_243Var.field_1350, class_243Var2.field_1352, class_243Var2.field_1351, class_243Var2.field_1350, color);
                }
                class_243Var = class_243Var2;
                i = i2 + (zBooleanValue ? 7 : 1);
            } else {
                return;
            }
        }
    }
}
