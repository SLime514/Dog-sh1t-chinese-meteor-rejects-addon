package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import anticope.rejects.utils.WorldUtils;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import org.apache.commons.lang3.tuple.Pair;

public class MossBot extends Module {
    private final SettingGroup sgGeneral;
    private final Setting<Integer> range;
    private final Setting<Boolean> rotate;

    private final Map<class_2338, Integer> f154;

    public MossBot() {
        super(MeteorRejectsAddon.CATEGORY, "苔藓机器人", "自动对苔藓方块使用骨粉，以最高效率扩散苔藓覆盖范围。");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.range = this.sgGeneral.add(((IntSetting.Builder) ((IntSetting.Builder) ((IntSetting.Builder) new IntSetting.Builder().name("作用范围")).description("骨粉可作用的最大范围（单位：方块）。")).defaultValue(4)).min(0).build());
        this.rotate = this.sgGeneral.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("自动旋转")).description("使用骨粉时是否自动朝向目标方块。")).defaultValue(true)).build());
        this.f154 = new HashMap();
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        class_2338 class_2338Var;
        this.f154.entrySet().removeIf(e -> {
            return ((Integer) e.setValue(Integer.valueOf(((Integer) e.getValue()).intValue() - 1))).intValue() <= 0;
        });
        FindItemResult findItemResultFindInHotbar = InvUtils.findInHotbar(new class_1792[]{class_1802.field_8324});
        if (findItemResultFindInHotbar.found() && (class_2338Var = (class_2338) class_2338.method_25998(class_2338.method_49638(this.mc.field_1724.method_33571()), ((Integer) this.range.get()).intValue(), ((Integer) this.range.get()).intValue(), ((Integer) this.range.get()).intValue()).filter(class_2338Var2 -> {
            return this.mc.field_1724.method_33571().method_1022(class_243.method_24953(class_2338Var2)) <= ((double) ((Integer) this.range.get()).intValue()) && !this.f154.containsKey(class_2338Var2);
        }).map(class_2338Var3 -> {
            return Pair.of(class_2338Var3.method_10062(), Integer.valueOf(m141(class_2338Var3)));
        }).filter(pair -> {
            return ((Integer) pair.getRight()).intValue() > 10;
        }).map((v0) -> {
            return v0.getLeft();
        }).max(Comparator.naturalOrder()).orElse(null)) != null) {
            if (!this.mc.field_1687.method_22347(class_2338Var.method_10084())) {
                this.mc.field_1761.method_2902(class_2338Var.method_10084(), class_2350.field_11036);
            }
            WorldUtils.interact(class_2338Var, findItemResultFindInHotbar, ((Boolean) this.rotate.get()).booleanValue());
            this.f154.put(class_2338Var, 100);
        }
    }

    private int m141(class_2338 class_2338Var) {
        if (this.mc.field_1687.method_8320(class_2338Var).method_26204() != class_2246.field_28681 || this.mc.field_1687.method_8320(class_2338Var.method_10084()).method_26214(this.mc.field_1687, class_2338Var) != 0.0f) {
            return 0;
        }
        return (int) class_2338.method_25998(class_2338Var, 3, 4, 3).filter(class_2338Var2 -> {
            return m142(this.mc.field_1687.method_8320(class_2338Var2).method_26204()) && this.mc.field_1687.method_22347(class_2338Var2.method_10084());
        }).count();
    }

    private boolean m142(class_2248 class_2248Var) {
        return class_2248Var == class_2246.field_10340 || class_2248Var == class_2246.field_10474 || class_2248Var == class_2246.field_10115 || class_2248Var == class_2246.field_10508 || class_2248Var == class_2246.field_10566 || class_2248Var == class_2246.field_10253 || class_2248Var == class_2246.field_10402 || class_2248Var == class_2246.field_10219 || class_2248Var == class_2246.field_10520 || class_2248Var == class_2246.field_28685;
    }
}
