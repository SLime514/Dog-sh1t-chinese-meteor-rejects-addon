package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import anticope.rejects.events.OffGroundSpeedEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_746;

public class Glide extends Module {
    private final SettingGroup sgGeneral;
    public final Setting<Double> fallSpeed;
    public final Setting<Double> moveSpeed;
    public final Setting<Double> minHeight;

    public Glide() {
        super(MeteorRejectsAddon.CATEGORY, "滑行模式", "实现类似“缓降”的滑行效果，可控制下落与移动速度（原注释：Yeehaw!，拟声词，表兴奋语气）。");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.fallSpeed = this.sgGeneral.add(((DoubleSetting.Builder) ((DoubleSetting.Builder) new DoubleSetting.Builder().name("下落速度")).description("滑行时的垂直下落速度（数值越小，下落越缓慢）。")).defaultValue(0.125d).min(0.005d).sliderRange(0.005d, 0.25d).build());
        this.moveSpeed = this.sgGeneral.add(((DoubleSetting.Builder) ((DoubleSetting.Builder) new DoubleSetting.Builder().name("移动速度系数")).description("滑行时水平移动速度的倍数（基于玩家基础移动速度，数值越大，水平移动越快）。")).defaultValue(1.2d).min(1.0d).sliderRange(1.0d, 5.0d).build());
        this.minHeight = this.sgGeneral.add(((DoubleSetting.Builder) ((DoubleSetting.Builder) new DoubleSetting.Builder().name("最低触发高度")).description("距离地面低于该高度时，不触发滑行效果（避免贴近地面时仍缓慢下落）。")).defaultValue(0.0d).min(0.0d).sliderRange(0.0d, 2.0d).build());
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        class_746 class_746Var = this.mc.field_1724;
        class_243 class_243VarMethod_18798 = class_746Var.method_18798();
        if (class_746Var.method_24828() || class_746Var.method_5799() || class_746Var.method_5771() || class_746Var.method_6101() || class_243VarMethod_18798.field_1351 >= 0.0d) {
            return;
        }
        if (((Double) this.minHeight.get()).doubleValue() > 0.0d) {
            class_238 class_238VarMethod_5829 = class_746Var.method_5829();
            if (!this.mc.field_1687.method_18026(class_238VarMethod_5829.method_991(class_238VarMethod_5829.method_989(0.0d, -((Double) this.minHeight.get()).doubleValue(), 0.0d)))) {
                return;
            }
        }
        class_746Var.method_18800(class_243VarMethod_18798.field_1352, Math.max(class_243VarMethod_18798.field_1351, -((Double) this.fallSpeed.get()).doubleValue()), class_243VarMethod_18798.field_1350);
    }

    @EventHandler
    private void onOffGroundSpeed(OffGroundSpeedEvent event) {
        event.speed *= ((Double) this.moveSpeed.get()).floatValue();
    }
}
