package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import net.minecraft.class_279;
import net.minecraft.class_2960;
import net.minecraft.class_9960;

public class Rendering extends Module {
    private final SettingGroup sgInvisible;
    private final SettingGroup sgFun;
    private final Setting<Boolean> structureVoid;
    private final Setting<Shader> shaderEnum;
    private final Setting<Boolean> dinnerbone;
    private final Setting<Boolean> deadmau5Ears;
    private final Setting<Boolean> christmas;

    private class_279 f173;

    public enum Shader {
        None,
        Blur,
        Creeper,
        Invert,
        Spider
    }

    public Rendering() {
        super(MeteorRejectsAddon.CATEGORY, "渲染调整", "提供各种渲染相关的 tweak，如显示隐藏元素或添加趣味视觉效果。");
        this.sgInvisible = this.settings.createGroup("不可见元素");
        this.sgFun = this.settings.createGroup("趣味效果");
        this.structureVoid = this.sgInvisible.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("结构空位")).description("是否渲染结构空位方块（原版中默认不可见）。")).defaultValue(true)).onChanged(onChanged -> {
            if (isActive()) {
                this.mc.field_1769.method_3279();
            }
        })).build());
        this.shaderEnum = this.sgFun.add(((EnumSetting.Builder) ((EnumSetting.Builder) ((EnumSetting.Builder) ((EnumSetting.Builder) new EnumSetting.Builder().name("着色器效果")).description("选择要应用的视觉着色器效果。")).defaultValue(Shader.None)).onChanged(this::onShaderChanged)).build());
        this.dinnerbone = this.sgFun.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("上下颠倒")).description("让所有实体（包括玩家）上下颠倒显示（类似Dinnerbone命名效果）。")).defaultValue(false)).build());
        this.deadmau5Ears = this.sgFun.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("猫耳头饰")).description("给所有玩家添加类似Deadmau5的猫耳头饰。")).defaultValue(false)).build());
        this.christmas = this.sgFun.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("圣诞箱子")).description("让所有箱子显示圣诞礼盒纹理，随时体验圣诞氛围。")).defaultValue(false)).build());
        this.f173 = null;
    }

    public void onActivate() {
        this.mc.field_1769.method_3279();
    }

    public void onDeactivate() {
        this.mc.field_1769.method_3279();
    }

    private void onShaderChanged(Shader shader) {
        if (this.mc.field_1687 == null) {
            return;
        }
        String lowerCase = shader.toString().toLowerCase();
        if (lowerCase.equals("none")) {
            this.f173 = null;
        } else {
            this.f173 = this.mc.method_62887().method_62941(class_2960.method_60656(lowerCase), class_9960.field_53902);
        }
    }

    public boolean renderStructureVoid() {
        return isActive() && ((Boolean) this.structureVoid.get()).booleanValue();
    }

    public class_279 getShaderEffect() {
        if (isActive()) {
            return this.f173;
        }
        return null;
    }

    public boolean dinnerboneEnabled() {
        if (isActive()) {
            return ((Boolean) this.dinnerbone.get()).booleanValue();
        }
        return false;
    }

    public boolean deadmau5EarsEnabled() {
        if (isActive()) {
            return ((Boolean) this.deadmau5Ears.get()).booleanValue();
        }
        return false;
    }

    public boolean chistmas() {
        if (isActive()) {
            return ((Boolean) this.christmas.get()).booleanValue();
        }
        return false;
    }
}
