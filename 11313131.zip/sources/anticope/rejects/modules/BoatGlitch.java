package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import meteordevelopment.meteorclient.events.entity.BoatMoveEvent;
import meteordevelopment.meteorclient.events.meteor.KeyEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.utils.misc.input.KeyAction;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1690;
import net.minecraft.class_2824;

public class BoatGlitch extends Module {
    private final SettingGroup sgGeneral;
    private final Setting<Boolean> toggleAfter;
    private final Setting<Boolean> remount;

    private class_1297 f9;

    private int f117;

    private int f118;

    private boolean f119;

    private boolean f120;

    public BoatGlitch() {
        super(MeteorRejectsAddon.CATEGORY, "船只卡块", "将你的船只卡进下方方块中，按下潜行键触发。");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.toggleAfter = this.sgGeneral.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("完成后关闭")).description("执行完卡船操作后自动禁用模块。")).defaultValue(true)).build());
        this.remount = this.sgGeneral.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("自动重新上船")).description("执行完卡船操作后自动重新登上船只。")).defaultValue(true)).build());
        this.f9 = null;
        this.f117 = 0;
        this.f118 = 0;
        this.f119 = true;
    }

    public void onActivate() {
        this.f119 = true;
        this.f117 = 0;
        this.f118 = 0;
        this.f9 = null;
        if (Modules.get().isActive(BoatPhase.class)) {
            this.f120 = true;
            ((BoatPhase) Modules.get().get(BoatPhase.class)).toggle();
        } else {
            this.f120 = false;
        }
    }

    public void onDeactivate() {
        if (this.f9 != null) {
            this.f9.field_5960 = false;
            this.f9 = null;
        }
        if (this.f120 && !Modules.get().isActive(BoatPhase.class)) {
            ((BoatPhase) Modules.get().get(BoatPhase.class)).toggle();
        }
    }

    @EventHandler
    private void onBoatMove(BoatMoveEvent event) {
        if (this.f117 == 0 && !this.f119) {
            if (this.f9 != event.boat) {
                if (this.f9 != null) {
                    this.f9.field_5960 = false;
                }
                if (this.mc.field_1724.method_5854() != null && event.boat == this.mc.field_1724.method_5854()) {
                    this.f9 = event.boat;
                } else {
                    this.f9 = null;
                }
            }
            if (this.f9 != null) {
                this.f9.field_5960 = true;
                this.f117 = 5;
            }
        }
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (this.f117 > 0) {
            this.f117--;
            if (this.f117 == 0) {
                if (this.f9 != null) {
                    this.f9.field_5960 = false;
                    if (((Boolean) this.toggleAfter.get()).booleanValue() && !((Boolean) this.remount.get()).booleanValue()) {
                        toggle();
                    } else if (((Boolean) this.remount.get()).booleanValue()) {
                        this.f118 = 5;
                    }
                }
                this.f119 = true;
            }
        }
        if (this.f118 > 0) {
            this.f118--;
            if (this.f118 == 0 && this.f9 != null) {
                this.mc.method_1562().method_52787(class_2824.method_34207(this.f9, false, class_1268.field_5808));
                if (((Boolean) this.toggleAfter.get()).booleanValue()) {
                    toggle();
                }
            }
        }
    }

    @EventHandler
    private void onKey(KeyEvent event) {
        if (event.key == this.mc.field_1690.field_1832.method_1429().method_1444() && event.action == KeyAction.Press && this.mc.field_1724.method_5854() != null && (this.mc.field_1724.method_5854() instanceof class_1690)) {
            this.f119 = false;
            this.f9 = null;
        }
    }
}
