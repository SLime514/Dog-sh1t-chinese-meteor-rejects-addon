package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import java.util.List;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.ItemListSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.StringSetting;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1703;
import net.minecraft.class_1706;
import net.minecraft.class_1735;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2480;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_342;
import net.minecraft.class_471;
import net.minecraft.class_9279;
import net.minecraft.class_9334;

public class AutoRename extends Module {
    private final SettingGroup sgGeneral;
    private final Setting<List<class_1792>> items;
    private final Setting<Integer> delay;
    private final Setting<String> name;
    private final Setting<Boolean> firstItemInContainer;
    private final Setting<List<class_1792>> containerItems;

    private int f103;

    public AutoRename() {
        super(MeteorRejectsAddon.CATEGORY, "自动重命名", "自动为物品重命名。");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.items = this.sgGeneral.add(((ItemListSetting.Builder) ((ItemListSetting.Builder) ((ItemListSetting.Builder) new ItemListSetting.Builder().name("目标物品")).description("你想要自动重命名的物品。")).defaultValue(List.of())).build());
        this.delay = this.sgGeneral.add(((IntSetting.Builder) ((IntSetting.Builder) ((IntSetting.Builder) new IntSetting.Builder().name("延迟")).description("每次操作之间等待的tick数。")).defaultValue(2)).min(0).sliderMax(40).build());
        this.name = this.sgGeneral.add(((StringSetting.Builder) ((StringSetting.Builder) ((StringSetting.Builder) new StringSetting.Builder().name("重命名内容")).description("物品的新名称，留空则恢复为默认名称。")).defaultValue("")).build());
        this.firstItemInContainer = this.sgGeneral.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("容器内首个物品命名")).description("根据容器内首个物品的名称来重命名容器（如潜影盒）。")).defaultValue(false)).build());
        this.containerItems = this.sgGeneral.add(((ItemListSetting.Builder) ((ItemListSetting.Builder) ((ItemListSetting.Builder) new ItemListSetting.Builder().name("容器物品")).description("视为容器并应用上述命名规则的物品。")).defaultValue(List.of())).build());
        this.f103 = 0;
    }

    @EventHandler
    private void onTick(TickEvent.Post ignoredEvent) {
        if (this.mc.field_1761 == null || ((List) this.items.get()).isEmpty() || !(this.mc.field_1724.field_7512 instanceof class_1706)) {
            return;
        }
        if (this.f103 > 0) {
            this.f103--;
            return;
        }
        this.f103 = ((Integer) this.delay.get()).intValue();
        class_1735 class_1735VarMethod_7611 = this.mc.field_1724.field_7512.method_7611(0);
        class_1735 class_1735VarMethod_76112 = this.mc.field_1724.field_7512.method_7611(1);
        class_1735 class_1735VarMethod_76113 = this.mc.field_1724.field_7512.method_7611(2);
        if (class_1735VarMethod_76112.method_7681()) {
            return;
        }
        if (class_1735VarMethod_76113.method_7681()) {
            if (this.mc.field_1724.field_7520 >= 1) {
                m97();
            }
        } else if (class_1735VarMethod_7611.method_7681()) {
            m95(class_1735VarMethod_7611.method_7677());
        } else {
            m98();
        }
    }

    private void m95(class_1799 class_1799Var) {
        String strM96;
        if (((Boolean) this.firstItemInContainer.get()).booleanValue() && ((List) this.containerItems.get()).contains(class_1799Var.method_7909())) {
            strM96 = m96(class_1799Var);
        } else {
            strM96 = (String) this.name.get();
        }
        if (this.mc.field_1755 == null || !(this.mc.field_1755 instanceof class_471)) {
            error("当前非铁砧界面", new Object[0]);
            toggle();
        } else {
            ((class_342) this.mc.field_1755.method_25396().get(0)).method_1852(strM96);
        }
    }

    private String m96(class_1799 class_1799Var) {
        class_2487 class_2487VarMethod_57461;
        class_2487 class_2487VarMethod_10562;
        class_2499 class_2499VarMethod_10554;
        class_1747 class_1747VarMethod_7909 = class_1799Var.method_7909();
        if (!(class_1747VarMethod_7909 instanceof class_1747) || !(class_1747VarMethod_7909.method_7711() instanceof class_2480) || (class_2487VarMethod_57461 = ((class_9279) class_1799Var.method_57825(class_9334.field_49628, class_9279.field_49302)).method_57461()) == null || (class_2487VarMethod_10562 = class_2487VarMethod_57461.method_10562("BlockEntityTag")) == null || (class_2499VarMethod_10554 = class_2487VarMethod_10562.method_10554("Items", 10)) == null) {
            return "";
        }
        byte b = 127;
        String strMethod_10558 = "";
        for (int i = 0; i < class_2499VarMethod_10554.size(); i++) {
            class_2487 class_2487VarMethod_10602 = class_2499VarMethod_10554.method_10602(i);
            byte bMethod_10571 = class_2487VarMethod_10602.method_10571("Slot");
            if (b >= bMethod_10571 && class_2487VarMethod_10602.method_10558("id") != null) {
                strMethod_10558 = class_2487VarMethod_10602.method_10545("Name") ? class_2487VarMethod_10602.method_10562("Name").method_10558("Name") : "";
                b = bMethod_10571;
            }
        }
        return strMethod_10558;
    }

    private void m97() {
        int i = -1;
        class_1703 class_1703Var = this.mc.field_1724.field_7512;
        int i2 = 3;
        while (true) {
            if (i2 >= 38) {
                break;
            }
            if (!class_1703Var.method_7611(i2).method_7681()) {
                i2++;
            } else {
                i = i2;
                break;
            }
        }
        if (i == -1) {
            return;
        }
        InvUtils.shiftClick().fromId(2).toId(i);
    }

    private void m98() {
        List<class_1792> list = (List) this.items.get();
        int i = -1;
        class_1703 class_1703Var = this.mc.field_1724.field_7512;
        int i2 = 3;
        while (true) {
            if (i2 >= 38) {
                break;
            }
            class_1735 class_1735VarMethod_7611 = class_1703Var.method_7611(i2);
            if (class_1735VarMethod_7611.method_7681()) {
                class_1799 class_1799VarMethod_7677 = class_1735VarMethod_7611.method_7677();
                if (list.contains(class_1799VarMethod_7677.method_7909()) && !class_1799VarMethod_7677.method_57353().method_57832(class_9334.field_49631)) {
                    i = i2;
                    break;
                }
            }
            i2++;
        }
        if (i == -1) {
            return;
        }
        InvUtils.shiftClick().fromId(i).toId(0);
    }
}
