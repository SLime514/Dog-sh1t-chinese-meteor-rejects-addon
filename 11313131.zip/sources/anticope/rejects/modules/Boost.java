package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import java.util.Objects;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_243;

public class Boost extends Module {
    private final SettingGroup sgGeneral;
    private final Setting<Double> strength;
    private final Setting<Boolean> autoBoost;
    private final Setting<Integer> interval;

    private int f121;

    public Boost() {
        super(MeteorRejectsAddon.CATEGORY, "推进冲刺", "类似冲刺位移的功能，向面向方向推进。");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.strength = this.sgGeneral.add(((DoubleSetting.Builder) ((DoubleSetting.Builder) new DoubleSetting.Builder().name("推进强度")).description("推动你的力度大小。")).defaultValue(4.0d).sliderMax(10.0d).build());
        this.autoBoost = this.sgGeneral.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("自动推进")).description("自动对你进行推进。")).defaultValue(false)).build());
        SettingGroup settingGroup = this.sgGeneral;
        IntSetting.Builder builder = (IntSetting.Builder) ((IntSetting.Builder) new IntSetting.Builder().name("推进间隔")).description("自动推进的tick间隔（1秒=20tick）。");
        Setting<Boolean> setting = this.autoBoost;
        Objects.requireNonNull(setting);
        this.interval = settingGroup.add(((IntSetting.Builder) ((IntSetting.Builder) builder.visible(setting::get)).defaultValue(20)).sliderMax(120).build());
        this.f121 = 0;
    }

    public void onActivate() {
        this.f121 = ((Integer) this.interval.get()).intValue();
        if (!((Boolean) this.autoBoost.get()).booleanValue()) {
            if (this.mc.field_1724 != null) {
                m109();
            }
            toggle();
        }
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (((Boolean) this.autoBoost.get()).booleanValue()) {
            if (this.f121 < 1) {
                m109();
                this.f121 = ((Integer) this.interval.get()).intValue();
            } else {
                this.f121--;
            }
        }
    }

    private void m109() {
        class_243 class_243VarMethod_1021 = this.mc.field_1724.method_5663().method_1021(((Double) this.strength.get()).doubleValue());
        this.mc.field_1724.method_5762(class_243VarMethod_1021.method_10216(), class_243VarMethod_1021.method_10214(), class_243VarMethod_1021.method_10215());
    }
}
