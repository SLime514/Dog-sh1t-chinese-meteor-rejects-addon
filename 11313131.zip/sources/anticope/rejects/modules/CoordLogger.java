package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_124;
import net.minecraft.class_1299;
import net.minecraft.class_1321;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2673;
import net.minecraft.class_2777;
import net.minecraft.class_5250;

public class CoordLogger extends Module {
    private final SettingGroup sgGeneral;
    private final SettingGroup sgTeleports;
    private final SettingGroup sgWorldEvents;
    private final Setting<Double> minDistance;
    private final Setting<Boolean> players;
    private final Setting<Boolean> wolves;
    private final Setting<Boolean> enderDragons;
    private final Setting<Boolean> endPortals;
    private final Setting<Boolean> withers;
    private final Setting<Boolean> otherEvents;

    public CoordLogger() {
        super(MeteorRejectsAddon.CATEGORY, "坐标记录器", "记录各类事件的坐标（在Spigot/Paper服务器上可能无法正常工作）。");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.sgTeleports = this.settings.createGroup("传送记录");
        this.sgWorldEvents = this.settings.createGroup("世界事件记录");
        this.minDistance = this.sgGeneral.add(((DoubleSetting.Builder) ((DoubleSetting.Builder) new DoubleSetting.Builder().name("最小记录距离")).description("记录事件所需的最小距离（过近的事件不记录）。")).min(5.0d).max(100.0d).sliderMin(5.0d).sliderMax(100.0d).defaultValue(10.0d).build());
        this.players = this.sgTeleports.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("玩家传送")).description("记录玩家的远距离传送坐标。")).defaultValue(true)).build());
        this.wolves = this.sgTeleports.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("狼传送")).description("记录狼（宠物）的远距离传送坐标。")).defaultValue(false)).build());
        this.enderDragons = this.sgWorldEvents.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("末影龙死亡")).description("记录末影龙被击杀的坐标。")).defaultValue(false)).build());
        this.endPortals = this.sgWorldEvents.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("末地传送门开启")).description("记录末地传送门被开启的坐标。")).defaultValue(false)).build());
        this.withers = this.sgWorldEvents.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("凋零生成")).description("记录凋零被生成的坐标。")).defaultValue(false)).build());
        this.otherEvents = this.sgWorldEvents.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("其他全局事件")).description("记录其他未分类的全局世界事件坐标。")).defaultValue(false)).build());
    }

    @EventHandler
    private void onPacketReceive(PacketEvent.Receive event) {
        class_2777 class_2777Var = event.packet;
        if (class_2777Var instanceof class_2777) {
            class_2777 class_2777Var2 = class_2777Var;
            try {
                class_1321 class_1321VarMethod_8469 = this.mc.field_1687.method_8469(class_2777Var2.comp_3237());
                if (class_1321VarMethod_8469 == null) {
                }
                class_243 class_243VarComp_3148 = class_2777Var2.comp_3238().comp_3148();
                double dMethod_1022 = class_1321VarMethod_8469.method_19538().method_1022(class_243VarComp_3148);
                if (class_1321VarMethod_8469.method_5864().equals(class_1299.field_6097) && ((Boolean) this.players.get()).booleanValue()) {
                    if (dMethod_1022 >= ((Double) this.minDistance.get()).doubleValue()) {
                        info(m120("玩家 '" + class_1321VarMethod_8469.method_5820() + "' 已传送到 ", class_243VarComp_3148));
                    }
                } else if (class_1321VarMethod_8469.method_5864().equals(class_1299.field_6055) && ((Boolean) this.wolves.get()).booleanValue() && class_1321VarMethod_8469.method_6139() != null && dMethod_1022 >= ((Double) this.minDistance.get()).doubleValue()) {
                    info(m120("狼已传送到 ", class_243VarComp_3148));
                }
                return;
            } catch (NullPointerException e) {
                return;
            }
        }
        class_2673 class_2673Var = event.packet;
        if (class_2673Var instanceof class_2673) {
            class_2673 class_2673Var2 = class_2673Var;
            if (!class_2673Var2.method_11533() || PlayerUtils.distanceTo(class_2673Var2.method_11531()) <= ((Double) this.minDistance.get()).doubleValue()) {
                return;
            }
            switch (class_2673Var2.method_11532()) {
                case 1023:
                    if (((Boolean) this.withers.get()).booleanValue()) {
                        info(m121("凋零生成于 ", class_2673Var2.method_11531()));
                        break;
                    }
                    break;
                case 1028:
                    if (((Boolean) this.enderDragons.get()).booleanValue()) {
                        info(m121("末影龙被击杀于 ", class_2673Var2.method_11531()));
                        break;
                    }
                    break;
                case 1038:
                    if (((Boolean) this.endPortals.get()).booleanValue()) {
                        info(m121("末地传送门开启于 ", class_2673Var2.method_11531()));
                        break;
                    }
                    break;
                default:
                    if (((Boolean) this.otherEvents.get()).booleanValue()) {
                        info(m121("未知全局事件发生于 ", class_2673Var2.method_11531()));
                        break;
                    }
                    break;
            }
        }
    }

    public class_5250 m120(String str, class_243 class_243Var) {
        class_5250 class_5250VarMethod_43470 = class_2561.method_43470(str);
        class_5250VarMethod_43470.method_10852(ChatUtils.formatCoords(class_243Var));
        class_5250VarMethod_43470.method_27693(String.valueOf(class_124.field_1080) + ".");
        return class_5250VarMethod_43470;
    }

    public class_5250 m121(String str, class_2338 class_2338Var) {
        return m120(str, new class_243(class_2338Var.method_10263(), class_2338Var.method_10264(), class_2338Var.method_10260()));
    }
}
