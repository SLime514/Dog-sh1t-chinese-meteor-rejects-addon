package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import java.util.concurrent.atomic.AtomicInteger;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import meteordevelopment.meteorclient.utils.player.Rotations;
import meteordevelopment.meteorclient.utils.world.BlockIterator;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1291;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2846;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class AutoExtinguish extends Module {
    private final SettingGroup sgGeneral;
    private final SettingGroup sgBucket;
    private final Setting<Boolean> extinguish;
    private final Setting<Integer> horizontalRadius;
    private final Setting<Integer> verticalRadius;
    private final Setting<Integer> maxBlockPerTick;
    private final Setting<Boolean> waterBucket;
    private final Setting<Boolean> center;
    private final Setting<Boolean> onGround;
    private boolean hasPlacedWater;
    private class_2338 blockPos;
    private boolean doesWaterBucketWork;
    private static final class_1291 FIRE_RESISTANCE = (class_1291) class_7923.field_41174.method_63535(class_2960.method_60654("fire_resistance"));

    public AutoExtinguish() {
        super(MeteorRejectsAddon.CATEGORY, "自动灭火", "自动熄灭你周围的火焰。");
        this.sgGeneral = this.settings.createGroup("熄灭周围火焰");
        this.sgBucket = this.settings.createGroup("熄灭自身火焰");
        this.extinguish = this.sgGeneral.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("自动灭火")).description("自动熄灭你周围的火焰。")).defaultValue(false)).build());
        this.horizontalRadius = this.sgGeneral.add(((IntSetting.Builder) ((IntSetting.Builder) ((IntSetting.Builder) new IntSetting.Builder().name("水平范围")).description("搜索火焰的水平范围。")).defaultValue(4)).min(0).sliderMax(6).build());
        this.verticalRadius = this.sgGeneral.add(((IntSetting.Builder) ((IntSetting.Builder) ((IntSetting.Builder) new IntSetting.Builder().name("垂直范围")).description("搜索火焰的垂直范围。")).defaultValue(4)).min(0).sliderMax(6).build());
        this.maxBlockPerTick = this.sgGeneral.add(((IntSetting.Builder) ((IntSetting.Builder) ((IntSetting.Builder) new IntSetting.Builder().name("每tick最大灭火数")).description("每游戏tick最多熄灭的火焰方块数量。")).defaultValue(5)).min(1).sliderMax(50).build());
        this.waterBucket = this.sgBucket.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("水桶灭火")).description("当你着火且没有防火效果时，自动放置水桶灭火。")).defaultValue(false)).build());
        this.center = this.sgBucket.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("自动居中")).description("放置水桶时自动将玩家位置居中到方块中心。")).defaultValue(false)).build());
        this.onGround = this.sgBucket.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("仅地面生效")).description("仅当你站在地面上时才放置水桶。")).defaultValue(false)).build());
        this.hasPlacedWater = false;
        this.blockPos = null;
        this.doesWaterBucketWork = true;
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (this.mc.field_1687.method_8597().comp_649()) {
            if (this.doesWaterBucketWork) {
                warning("当前维度无法使用水桶！", new Object[0]);
                this.doesWaterBucketWork = false;
            }
        } else if (!this.doesWaterBucketWork) {
            warning("已启用水桶功能！", new Object[0]);
            this.doesWaterBucketWork = true;
        }
        if (((Boolean) this.onGround.get()).booleanValue() && !this.mc.field_1724.method_24828()) {
            return;
        }
        if (((Boolean) this.waterBucket.get()).booleanValue() && this.doesWaterBucketWork) {
            if (this.hasPlacedWater) {
                int iFindSlot = findSlot(class_1802.field_8550);
                this.blockPos = this.mc.field_1724.method_24515();
                place(iFindSlot);
                this.hasPlacedWater = false;
            } else if (!this.mc.field_1724.method_6059(class_7923.field_41174.method_47983(FIRE_RESISTANCE)) && this.mc.field_1724.method_5809()) {
                this.blockPos = this.mc.field_1724.method_24515();
                int iFindSlot2 = findSlot(class_1802.field_8705);
                if (this.mc.field_1687.method_8320(this.blockPos).method_26204() == class_2246.field_10036 || this.mc.field_1687.method_8320(this.blockPos).method_26204() == class_2246.field_22089) {
                    float fMethod_19330 = this.mc.field_1773.method_19418().method_19330() % 360.0f;
                    float fMethod_19329 = this.mc.field_1773.method_19418().method_19329() % 360.0f;
                    if (((Boolean) this.center.get()).booleanValue()) {
                        PlayerUtils.centerPlayer();
                    }
                    Rotations.rotate(fMethod_19330, 90.0d);
                    this.mc.method_1562().method_52787(new class_2846(class_2846.class_2847.field_12968, this.blockPos, class_2350.field_11036));
                    this.mc.field_1724.method_6104(class_1268.field_5808);
                    this.mc.method_1562().method_52787(new class_2846(class_2846.class_2847.field_12973, this.blockPos, class_2350.field_11036));
                    Rotations.rotate(fMethod_19330, fMethod_19329);
                }
                place(iFindSlot2);
                this.hasPlacedWater = true;
            }
        }
        if (((Boolean) this.extinguish.get()).booleanValue()) {
            AtomicInteger atomicInteger = new AtomicInteger();
            BlockIterator.register(((Integer) this.horizontalRadius.get()).intValue(), ((Integer) this.verticalRadius.get()).intValue(), (blockPos, blockState) -> {
                if (atomicInteger.get() <= ((Integer) this.maxBlockPerTick.get()).intValue()) {
                    if (blockState.method_26204() == class_2246.field_10036 || this.mc.field_1687.method_8320(blockPos).method_26204() == class_2246.field_22089) {
                        extinguishFire(blockPos);
                        atomicInteger.getAndIncrement();
                    }
                }
            });
        }
    }

    private void place(int slot) {
        if (slot != -1) {
            int i = this.mc.field_1724.method_31548().field_7545;
            if (((Boolean) this.center.get()).booleanValue()) {
                PlayerUtils.centerPlayer();
            }
            this.mc.field_1724.method_31548().field_7545 = slot;
            float fMethod_19330 = this.mc.field_1773.method_19418().method_19330() % 360.0f;
            float fMethod_19329 = this.mc.field_1773.method_19418().method_19329() % 360.0f;
            Rotations.rotate(fMethod_19330, 90.0d);
            this.mc.field_1761.method_2919(this.mc.field_1724, class_1268.field_5808);
            this.mc.field_1724.method_31548().field_7545 = i;
            Rotations.rotate(fMethod_19330, fMethod_19329);
        }
    }

    private void extinguishFire(class_2338 blockPos) {
        this.mc.method_1562().method_52787(new class_2846(class_2846.class_2847.field_12968, blockPos, class_2350.field_11036));
        this.mc.field_1724.method_6104(class_1268.field_5808);
        this.mc.method_1562().method_52787(new class_2846(class_2846.class_2847.field_12973, blockPos, class_2350.field_11036));
    }

    private int findSlot(class_1792 item) {
        int i = -1;
        int i2 = 0;
        while (true) {
            if (i2 >= 9) {
                break;
            }
            if (this.mc.field_1724.method_31548().method_5438(i2).method_7909() != item) {
                i2++;
            } else {
                i = i2;
                break;
            }
        }
        return i;
    }
}
