package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import anticope.rejects.utils.WorldUtils;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import meteordevelopment.meteorclient.events.entity.player.BreakBlockEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BlockListSetting;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.ItemListSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.misc.Pool;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.world.BlockIterator;
import meteordevelopment.meteorclient.utils.world.BlockUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1792;
import net.minecraft.class_1794;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2282;
import net.minecraft.class_2302;
import net.minecraft.class_2338;
import net.minecraft.class_2344;
import net.minecraft.class_2350;
import net.minecraft.class_2420;
import net.minecraft.class_2421;
import net.minecraft.class_243;
import net.minecraft.class_2473;
import net.minecraft.class_2492;
import net.minecraft.class_2513;
import net.minecraft.class_2680;
import net.minecraft.class_3486;
import net.minecraft.class_3830;
import net.minecraft.class_3965;
import net.minecraft.class_4538;
import net.minecraft.class_5800;
import net.minecraft.class_8237;

public class AutoFarm extends Module {
    private final SettingGroup sgGeneral;
    private final SettingGroup sgTill;
    private final SettingGroup sgHarvest;
    private final SettingGroup sgPlant;
    private final SettingGroup sgBonemeal;

    private final Map<class_2338, class_1792> f86;
    private final Setting<Integer> range;
    private final Setting<Integer> bpt;
    private final Setting<Boolean> rotate;
    private final Setting<Boolean> till;
    private final Setting<Boolean> moist;
    private final Setting<Boolean> harvest;
    private final Setting<List<class_2248>> harvestBlocks;
    private final Setting<Boolean> plant;
    private final Setting<List<class_1792>> plantItems;
    private final Setting<Boolean> onlyReplant;
    private final Setting<Boolean> bonemeal;
    private final Setting<List<class_2248>> bonemealBlocks;

    private final Pool<class_2338.class_2339> f87;

    private final List<class_2338.class_2339> f88;

    int f89;

    public AutoFarm() {
        super(MeteorRejectsAddon.CATEGORY, "自动农场", "一体化的耕种辅助工具。");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.sgTill = this.settings.createGroup("耕地设置");
        this.sgHarvest = this.settings.createGroup("收获设置");
        this.sgPlant = this.settings.createGroup("种植设置");
        this.sgBonemeal = this.settings.createGroup("骨粉设置");
        this.f86 = new HashMap();
        this.range = this.sgGeneral.add(((IntSetting.Builder) ((IntSetting.Builder) ((IntSetting.Builder) new IntSetting.Builder().name("范围")).description("自动 farming 的范围。")).defaultValue(4)).min(1).build());
        this.bpt = this.sgGeneral.add(((IntSetting.Builder) ((IntSetting.Builder) ((IntSetting.Builder) new IntSetting.Builder().name("每tick操作数")).description("每游戏tick可以执行的操作数量。")).min(1).defaultValue(1)).build());
        this.rotate = this.sgGeneral.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("自动转向")).description("是否在操作方块时自动转向。")).defaultValue(true)).build());
        this.till = this.sgTill.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("自动耕地")).description("将附近的泥土变成耕地。")).defaultValue(true)).build());
        this.moist = this.sgTill.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("仅湿润耕地")).description("只在有水源附近的泥土上耕地。")).defaultValue(true)).build());
        this.harvest = this.sgHarvest.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("自动收获")).description("收获成熟的作物。")).defaultValue(true)).build());
        this.harvestBlocks = this.sgHarvest.add(((BlockListSetting.Builder) ((BlockListSetting.Builder) new BlockListSetting.Builder().name("收获作物")).description("指定要收获的作物类型。")).defaultValue(new class_2248[0]).filter(this::m82).build());
        this.plant = this.sgPlant.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("自动种植")).description("种植作物。")).defaultValue(true)).build());
        this.plantItems = this.sgPlant.add(((ItemListSetting.Builder) ((ItemListSetting.Builder) new ItemListSetting.Builder().name("种植物品")).description("指定要种植的作物种子。")).defaultValue(new class_1792[0]).filter(this::m83).build());
        this.onlyReplant = this.sgPlant.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("只补种")).description("只补种刚刚收获的作物。")).defaultValue(true)).onChanged(b -> {
            this.f86.clear();
        })).build());
        this.bonemeal = this.sgBonemeal.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("自动骨粉")).description("使用骨粉加速作物生长。")).defaultValue(true)).build());
        this.bonemealBlocks = this.sgBonemeal.add(((BlockListSetting.Builder) ((BlockListSetting.Builder) new BlockListSetting.Builder().name("骨粉作物")).description("指定要使用骨粉的作物类型。")).defaultValue(new class_2248[0]).filter(this::m81).build());
        this.f87 = new Pool<>(class_2338.class_2339::new);
        this.f88 = new ArrayList();
        this.f89 = 0;
    }

    public void onDeactivate() {
        this.f86.clear();
    }

    @EventHandler
    private void onBreakBlock(BreakBlockEvent event) {
        class_2248 class_2248VarMethod_26204 = this.mc.field_1687.method_8320(event.blockPos).method_26204();
        if (((Boolean) this.onlyReplant.get()).booleanValue()) {
            class_1792 class_1792Var = null;
            if (class_2248VarMethod_26204 == class_2246.field_10293) {
                class_1792Var = class_1802.field_8317;
            } else if (class_2248VarMethod_26204 == class_2246.field_10609) {
                class_1792Var = class_1802.field_8179;
            } else if (class_2248VarMethod_26204 == class_2246.field_10247) {
                class_1792Var = class_1802.field_8567;
            } else if (class_2248VarMethod_26204 == class_2246.field_10341) {
                class_1792Var = class_1802.field_8309;
            } else if (class_2248VarMethod_26204 == class_2246.field_9974) {
                class_1792Var = class_1802.field_8790;
            } else if (class_2248VarMethod_26204 == class_2246.field_43228) {
                class_1792Var = class_1802.field_43195;
            } else if (class_2248VarMethod_26204 == class_2246.field_42734) {
                class_1792Var = class_1802.field_42711;
            }
            if (class_1792Var != null) {
                this.f86.put(event.blockPos, class_1792Var);
            }
        }
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        this.f89 = 0;
        BlockIterator.register(((Integer) this.range.get()).intValue(), ((Integer) this.range.get()).intValue(), (pos, state) -> {
            if (this.mc.field_1724.method_33571().method_1022(class_243.method_24953(pos)) <= ((Integer) this.range.get()).intValue()) {
                this.f88.add(((class_2338.class_2339) this.f87.get()).method_10101(pos));
            }
        });
        BlockIterator.after(() -> {
            this.f88.sort(Comparator.comparingDouble(value -> {
                return this.mc.field_1724.method_33571().method_1022(class_243.method_24953(value));
            }));
            Iterator<class_2338.class_2339> it = this.f88.iterator();
            while (it.hasNext()) {
                class_2338 pos2 = (class_2338) it.next();
                class_2680 class_2680VarMethod_8320 = this.mc.field_1687.method_8320(pos2);
                class_2248 class_2248VarMethod_26204 = class_2680VarMethod_8320.method_26204();
                if (m0(pos2, class_2248VarMethod_26204) || m1(pos2, class_2680VarMethod_8320, class_2248VarMethod_26204) || m2(pos2, class_2248VarMethod_26204) || m3(pos2, class_2680VarMethod_8320, class_2248VarMethod_26204)) {
                    this.f89++;
                }
                if (this.f89 >= ((Integer) this.bpt.get()).intValue()) {
                    break;
                }
            }
            Iterator<class_2338.class_2339> it2 = this.f88.iterator();
            while (it2.hasNext()) {
                this.f87.free(it2.next());
            }
            this.f88.clear();
        });
    }

    private boolean m0(class_2338 pos, class_2248 class_2248Var) {
        if (!((Boolean) this.till.get()).booleanValue()) {
            return false;
        }
        boolean z = !((Boolean) this.moist.get()).booleanValue() || m80(this.mc.field_1687, pos);
        boolean z2 = class_2248Var == class_2246.field_10219 || class_2248Var == class_2246.field_10194 || class_2248Var == class_2246.field_10566 || class_2248Var == class_2246.field_10253 || class_2248Var == class_2246.field_28685;
        if (z && z2 && this.mc.field_1687.method_8320(pos.method_10084()).method_26215()) {
            return WorldUtils.interact(pos, InvUtils.findInHotbar(itemStack -> {
                return itemStack.method_7909() instanceof class_1794;
            }), ((Boolean) this.rotate.get()).booleanValue());
        }
        return false;
    }

    private boolean m1(class_2338 pos, class_2680 class_2680Var, class_2248 class_2248Var) {
        if (!((Boolean) this.harvest.get()).booleanValue() || !((List) this.harvestBlocks.get()).contains(class_2248Var) || !isMature(class_2680Var, class_2248Var)) {
            return false;
        }
        if (class_2248Var instanceof class_3830) {
            this.mc.field_1761.method_2896(this.mc.field_1724, class_1268.field_5808, new class_3965(Utils.vec3d(pos), class_2350.field_11036, pos, false));
            return true;
        }
        this.mc.field_1761.method_2902(pos, class_2350.field_11036);
        return true;
    }

    private boolean m2(class_2338 pos, class_2248 class_2248Var) {
        if (!((Boolean) this.plant.get()).booleanValue() || !this.mc.field_1687.method_22347(pos.method_10084())) {
            return false;
        }
        FindItemResult findItemResultFind = null;
        if (((Boolean) this.onlyReplant.get()).booleanValue()) {
            Iterator<class_2338> it = this.f86.keySet().iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                class_2338 next = it.next();
                if (next.equals(pos.method_10084())) {
                    findItemResultFind = InvUtils.find(new class_1792[]{this.f86.get(next)});
                    this.f86.remove(next);
                    break;
                }
            }
        } else if (class_2248Var instanceof class_2344) {
            findItemResultFind = InvUtils.find(itemStack -> {
                class_1792 class_1792VarMethod_7909 = itemStack.method_7909();
                return class_1792VarMethod_7909 != class_1802.field_8790 && ((List) this.plantItems.get()).contains(class_1792VarMethod_7909);
            });
        } else if (class_2248Var instanceof class_2492) {
            findItemResultFind = InvUtils.find(itemStack2 -> {
                return itemStack2.method_7909() == class_1802.field_8790 && ((List) this.plantItems.get()).contains(class_1802.field_8790);
            });
        }
        if (findItemResultFind != null && findItemResultFind.found()) {
            BlockUtils.place(pos.method_10084(), findItemResultFind, ((Boolean) this.rotate.get()).booleanValue(), -100, false);
            return true;
        }
        return false;
    }

    private boolean m3(class_2338 pos, class_2680 class_2680Var, class_2248 class_2248Var) {
        if (((Boolean) this.bonemeal.get()).booleanValue() && ((List) this.bonemealBlocks.get()).contains(class_2248Var) && !isMature(class_2680Var, class_2248Var)) {
            return WorldUtils.interact(pos, InvUtils.findInHotbar(new class_1792[]{class_1802.field_8324}), ((Boolean) this.rotate.get()).booleanValue());
        }
        return false;
    }

    private boolean m80(class_4538 world, class_2338 pos) {
        Iterator it = class_2338.method_10097(pos.method_10069(-4, 0, -4), pos.method_10069(4, 1, 4)).iterator();
        while (it.hasNext()) {
            if (world.method_8316((class_2338) it.next()).method_15767(class_3486.field_15517)) {
                return true;
            }
        }
        return false;
    }

    private boolean isMature(class_2680 class_2680Var, class_2248 class_2248Var) {
        if (class_2248Var instanceof class_2302) {
            return ((class_2302) class_2248Var).method_9825(class_2680Var);
        }
        if (class_2248Var instanceof class_2282) {
            return ((Integer) class_2680Var.method_11654(class_2282.field_10779)).intValue() >= 2;
        }
        if (class_2248Var instanceof class_2513) {
            return ((Integer) class_2680Var.method_11654(class_2513.field_11584)).intValue() == 7;
        }
        if (class_2248Var instanceof class_3830) {
            return ((Integer) class_2680Var.method_11654(class_3830.field_17000)).intValue() >= 2;
        }
        if (class_2248Var instanceof class_2421) {
            return ((Integer) class_2680Var.method_11654(class_2421.field_11306)).intValue() >= 3;
        }
        if (!(class_2248Var instanceof class_8237)) {
            return true;
        }
        return ((Integer) class_2680Var.method_11654(class_8237.field_43239)).intValue() >= 4;
    }

    private boolean m81(class_2248 class_2248Var) {
        return (class_2248Var instanceof class_2302) || (class_2248Var instanceof class_2513) || (class_2248Var instanceof class_2420) || (class_2248Var instanceof class_5800) || (class_2248Var instanceof class_2473) || class_2248Var == class_2246.field_10302 || class_2248Var == class_2246.field_16999 || class_2248Var == class_2246.field_43228 || class_2248Var == class_2246.field_42734;
    }

    private boolean m82(class_2248 class_2248Var) {
        return (class_2248Var instanceof class_2302) || class_2248Var == class_2246.field_46282 || class_2248Var == class_2246.field_46283 || class_2248Var == class_2246.field_9974 || class_2248Var == class_2246.field_16999 || class_2248Var == class_2246.field_10302 || class_2248Var == class_2246.field_43228 || class_2248Var == class_2246.field_42734;
    }

    private boolean m83(class_1792 class_1792Var) {
        return class_1792Var == class_1802.field_8317 || class_1792Var == class_1802.field_8179 || class_1792Var == class_1802.field_8567 || class_1792Var == class_1802.field_8309 || class_1792Var == class_1802.field_46249 || class_1792Var == class_1802.field_46250 || class_1792Var == class_1802.field_8790 || class_1792Var == class_1802.field_43195 || class_1792Var == class_1802.field_42711;
    }
}
