package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.entity.EntityUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1297;
import net.minecraft.class_1657;

public class AntiBot extends Module {
    private final SettingGroup sgGeneral;
    private final SettingGroup sgFilters;
    private final Setting<Boolean> removeInvisible;
    private final Setting<Boolean> gameMode;
    private final Setting<Boolean> api;
    private final Setting<Boolean> profile;
    private final Setting<Boolean> latency;
    private final Setting<Boolean> nullException;

    public AntiBot() {
        super(MeteorRejectsAddon.CATEGORY, "机器人检测", "检测并移除机器人。");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.sgFilters = this.settings.createGroup("过滤器");
        this.removeInvisible = this.sgGeneral.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("只移除隐身的")).description("仅当机器人处于隐身状态时才移除它们。")).defaultValue(true)).build());
        this.gameMode = this.sgFilters.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("无效游戏模式")).description("移除没有游戏模式的玩家")).defaultValue(true)).build());
        this.api = this.sgFilters.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("无效玩家条目")).description("移除没有玩家条目的玩家")).defaultValue(true)).build());
        this.profile = this.sgFilters.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("无效游戏档案")).description("移除没有游戏档案的玩家")).defaultValue(true)).build());
        this.latency = this.sgFilters.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("延迟检测")).description("使用延迟检测移除玩家")).defaultValue(false)).build());
        this.nullException = this.sgFilters.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("空指针异常")).description("如果发生空指针异常则移除玩家")).defaultValue(false)).build());
    }

    @EventHandler
    public void onTick(TickEvent.Post tickEvent) {
        for (class_1297 entity : this.mc.field_1687.method_18112()) {
            if (entity instanceof class_1657) {
                class_1657 playerEntity = (class_1657) entity;
                if (!((Boolean) this.removeInvisible.get()).booleanValue() || entity.method_5767()) {
                    if (isBot(playerEntity)) {
                        entity.method_5650(class_1297.class_5529.field_26999);
                    }
                }
            }
        }
    }

    private boolean isBot(class_1657 entity) {
        try {
            if (((Boolean) this.gameMode.get()).booleanValue() && EntityUtils.getGameMode(entity) == null) {
                return true;
            }
            if (((Boolean) this.api.get()).booleanValue() && this.mc.method_1562().method_2871(entity.method_5667()) == null) {
                return true;
            }
            if (((Boolean) this.profile.get()).booleanValue() && this.mc.method_1562().method_2871(entity.method_5667()).method_2966() == null) {
                return true;
            }
            if (((Boolean) this.latency.get()).booleanValue()) {
                return this.mc.method_1562().method_2871(entity.method_5667()).method_2959() > 1;
            }
            return false;
        } catch (NullPointerException e) {
            return ((Boolean) this.nullException.get()).booleanValue();
        }
    }
}
