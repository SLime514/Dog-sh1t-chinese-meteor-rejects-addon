package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import baritone.api.BaritoneAPI;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import meteordevelopment.meteorclient.events.entity.player.ItemUseCrosshairTargetEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.StatusEffectListSetting;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.systems.modules.combat.AnchorAura;
import meteordevelopment.meteorclient.systems.modules.combat.BedAura;
import meteordevelopment.meteorclient.systems.modules.combat.CrystalAura;
import meteordevelopment.meteorclient.systems.modules.combat.KillAura;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.player.Rotations;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1844;
import net.minecraft.class_6880;
import net.minecraft.class_7923;
import net.minecraft.class_9334;

public class AutoPot extends Module {

    private static final Class<? extends Module>[] f90;
    private final SettingGroup sgGeneral;

    private final Setting<List<class_1291>> f91;

    private final Setting<Boolean> f92;

    private final Setting<Integer> f93;

    private final Setting<Boolean> f94;

    private final Setting<Boolean> f95Baritone;

    private final Setting<Boolean> f96;

    private int f97;

    private int f98;

    private boolean f99;

    private boolean f100;

    private final List<Class<? extends Module>> f101;

    private boolean f102Baritone;
    static final boolean $assertionsDisabled;

    static {
        $assertionsDisabled = !AutoPot.class.desiredAssertionStatus();
        f90 = new Class[]{KillAura.class, CrystalAura.class, AnchorAura.class, BedAura.class};
    }

    public AutoPot() {
        super(MeteorRejectsAddon.CATEGORY, "自动药水", "自动饮用或投掷药水。");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.f91 = this.sgGeneral.add(((StatusEffectListSetting.Builder) ((StatusEffectListSetting.Builder) new StatusEffectListSetting.Builder().name("使用的药水")).description("需要自动使用的药水效果。")).defaultValue(new class_1291[]{(class_1291) class_1294.field_5915.comp_349(), (class_1291) class_1294.field_5910.comp_349()}).build());
        this.f92 = this.sgGeneral.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("喷溅药水")).description("允许使用喷溅药水")).defaultValue(true)).build());
        this.f93 = this.sgGeneral.add(((IntSetting.Builder) ((IntSetting.Builder) ((IntSetting.Builder) new IntSetting.Builder().name("生命值阈值")).description("当生命值低于此数值时，触发治疗药水使用。")).defaultValue(15)).min(0).sliderMax(20).build());
        this.f94 = this.sgGeneral.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("暂停攻击光环")).description("使用药水时暂停所有攻击光环。")).defaultValue(true)).build());
        this.f95Baritone = this.sgGeneral.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("暂停Baritone")).description("使用药水时暂停Baritone路径导航。")).defaultValue(true)).build());
        this.f96 = this.sgGeneral.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("自动转向")).description("投掷喷溅药水时强制向下瞄准。")).defaultValue(true)).build());
        this.f101 = new ArrayList();
    }

    public void onDeactivate() {
        m88();
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (this.mc.field_1724.method_6115()) {
            return;
        }
        for (class_1291 class_1291Var : (List) this.f91.get()) {
            class_6880<class_1291> class_6880VarMethod_47983 = class_7923.field_41174.method_47983(class_1291Var);
            if (!this.mc.field_1724.method_6059(class_6880VarMethod_47983)) {
                this.f97 = m91(class_1291Var);
                if (this.f97 == -1) {
                    continue;
                } else if (class_6880VarMethod_47983 == class_1294.field_5915 && m93()) {
                    m92();
                    return;
                } else if (class_6880VarMethod_47983 == class_1294.field_5915) {
                    return;
                } else {
                    m92();
                }
            }
        }
    }

    @EventHandler
    private void onItemUseCrosshairTarget(ItemUseCrosshairTargetEvent event) {
        if (this.f99) {
            event.target = null;
        }
    }

    private void m87(boolean z) {
        this.mc.field_1690.field_1904.method_23481(z);
    }

    private void m4() {
        m90(this.f97);
        m87(true);
        if (!this.mc.field_1724.method_6115()) {
            Utils.rightClick();
        }
        this.f99 = true;
    }

    private void m5() {
        m90(this.f97);
        m87(true);
        this.f100 = true;
    }

    private void m88() {
        m90(this.f98);
        m87(false);
        this.f99 = false;
        this.f100 = false;
        if (((Boolean) this.f94.get()).booleanValue()) {
            for (Class<? extends Module> cls : f90) {
                Module module = Modules.get().get(cls);
                if (this.f101.contains(cls) && !module.isActive()) {
                    module.toggle();
                }
            }
        }
        if (((Boolean) this.f95Baritone.get()).booleanValue() && this.f102Baritone) {
            BaritoneAPI.getProvider().getPrimaryBaritone().getCommandManager().execute("resume");
        }
    }

    private double m89() {
        if ($assertionsDisabled || this.mc.field_1724 != null) {
            return this.mc.field_1724.method_6032();
        }
        throw new AssertionError();
    }

    private void m90(int i) {
        this.mc.field_1724.method_31548().field_7545 = i;
        this.f97 = i;
    }

    private int m91(class_1291 class_1291Var) {
        int i = -1;
        for (int i2 = 0; i2 < 9; i2++) {
            class_1799 class_1799VarMethod_5438 = this.mc.field_1724.method_31548().method_5438(i2);
            if (!class_1799VarMethod_5438.method_7960() && (class_1799VarMethod_5438.method_7909() == class_1802.field_8574 || (class_1799VarMethod_5438.method_7909() == class_1802.field_8436 && ((Boolean) this.f92.get()).booleanValue()))) {
                Iterator it = ((class_1844) class_1799VarMethod_5438.method_57353().method_57830(class_9334.field_49651, class_1844.field_49274)).method_57397().iterator();
                while (true) {
                    if (!it.hasNext()) {
                        break;
                    }
                    if (((class_1293) it.next()).method_5586().equals(class_1291Var.method_5567())) {
                        i = i2;
                        break;
                    }
                }
            }
        }
        return i;
    }

    private void m92() {
        this.f98 = this.mc.field_1724.method_31548().field_7545;
        if (((Boolean) this.f92.get()).booleanValue()) {
            if (((Boolean) this.f96.get()).booleanValue()) {
                Rotations.rotate(this.mc.field_1724.method_36454(), 90.0d);
                m5();
            } else {
                m5();
            }
        } else {
            m4();
        }
        this.f101.clear();
        if (((Boolean) this.f94.get()).booleanValue()) {
            for (Class<? extends Module> cls : f90) {
                Module module = Modules.get().get(cls);
                if (module.isActive()) {
                    this.f101.add(cls);
                    module.toggle();
                }
            }
        }
        this.f102Baritone = false;
        if (((Boolean) this.f95Baritone.get()).booleanValue() && BaritoneAPI.getProvider().getPrimaryBaritone().getPathingBehavior().isPathing()) {
            this.f102Baritone = true;
            BaritoneAPI.getProvider().getPrimaryBaritone().getCommandManager().execute("pause");
        }
    }

    private boolean m93() {
        return m89() < ((double) ((Integer) this.f93.get()).intValue());
    }
}
