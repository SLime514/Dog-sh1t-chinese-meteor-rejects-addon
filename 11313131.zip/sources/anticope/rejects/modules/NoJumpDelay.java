package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;

public class NoJumpDelay extends Module {
    public NoJumpDelay() {
        super(MeteorRejectsAddon.CATEGORY, "无跳跃延迟", "移除玩家跳跃后的冷却时间，实现无间隔连续跳跃。");
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        this.mc.field_1724.setJumpCooldown(0);
    }
}
