package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import meteordevelopment.meteorclient.utils.world.BlockUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1313;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2346;
import net.minecraft.class_243;

public class BlockIn extends Module {
    private final SettingGroup sgGeneral;
    private final Setting<Boolean> multiPlace;
    private final Setting<Boolean> center;
    private final Setting<Boolean> rotate;
    private final Setting<Boolean> turnOff;
    private final Setting<Boolean> onlyOnGround;

    private final class_2338.class_2339 f114;

    private boolean f115;

    private double f116Y;

    public BlockIn() {
        super(MeteorRejectsAddon.CATEGORY, "方块包围", "用方块将自己围起来。");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.multiPlace = this.sgGeneral.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("多格放置")).description("是否在一tick内放置所有方块")).defaultValue(false)).build());
        this.center = this.sgGeneral.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("自动居中")).description("是否自动居中以避免阻碍放置")).defaultValue(true)).build());
        this.rotate = this.sgGeneral.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("自动转向")).description("放置方块时是否自动转向")).defaultValue(true)).build());
        this.turnOff = this.sgGeneral.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("自动关闭")).description("放置完成后是否自动关闭模块")).defaultValue(true)).build());
        this.onlyOnGround = this.sgGeneral.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("仅地面放置")).description("仅当站在方块上时才放置（不在半空中）")).defaultValue(true)).build());
        this.f114 = new class_2338.class_2339();
    }

    public void onActivate() {
        this.f116Y = this.mc.field_1724.method_19538().method_10214();
    }

    @EventHandler
    private void onPreTick(TickEvent.Pre event) {
        if (this.mc.field_1724.method_24828() && this.mc.field_1724.method_23318() > Math.floor(this.mc.field_1724.method_23318() + 0.2d)) {
            this.mc.field_1690.field_1832.method_23481(true);
        }
        if (this.f115 && this.mc.field_1690.field_1832.method_1434()) {
            this.mc.field_1690.field_1832.method_23481(false);
        }
        if (((Boolean) this.center.get()).booleanValue()) {
            if (!((Boolean) this.onlyOnGround.get()).booleanValue()) {
                this.mc.field_1724.method_18800(0.0d, 0.0d, 0.0d);
                this.mc.field_1724.method_5784(class_1313.field_6308, new class_243(0.0d, -(this.f116Y - Math.floor(this.f116Y)), 0.0d));
            }
            PlayerUtils.centerPlayer();
        }
        if (!((Boolean) this.onlyOnGround.get()).booleanValue() || this.mc.field_1724.method_24828()) {
            this.f115 = false;
            if (((Boolean) this.multiPlace.get()).booleanValue()) {
                boolean zM105 = m105(0, -1, 0);
                boolean zM1052 = m105(1, 0, 0);
                boolean zM1053 = m105(-1, 0, 0);
                boolean zM1054 = m105(0, 0, 1);
                boolean zM1055 = m105(0, 0, -1);
                boolean zM1056 = m105(1, 1, 0);
                boolean zM1057 = m105(-1, 1, 0);
                boolean zM1058 = m105(0, 1, 1);
                boolean zM1059 = m105(0, 1, -1);
                boolean zM10510 = m105(0, 2, 0);
                if (((Boolean) this.turnOff.get()).booleanValue() && zM105 && zM1052 && zM1053 && zM1054 && zM1055 && zM1056 && zM1057 && zM1058 && zM1059 && zM10510) {
                    toggle();
                    return;
                }
                return;
            }
            boolean zM10511 = m105(0, -1, 0);
            if (this.f115) {
                return;
            }
            boolean zM10512 = m105(1, 0, 0);
            if (this.f115) {
                return;
            }
            boolean zM10513 = m105(-1, 0, 0);
            if (this.f115) {
                return;
            }
            boolean zM10514 = m105(0, 0, 1);
            if (this.f115) {
                return;
            }
            boolean zM10515 = m105(0, 0, -1);
            if (this.f115) {
                return;
            }
            boolean zM10516 = m105(1, 1, 0);
            if (this.f115) {
                return;
            }
            boolean zM10517 = m105(-1, 1, 0);
            if (this.f115) {
                return;
            }
            boolean zM10518 = m105(0, 1, 1);
            if (this.f115) {
                return;
            }
            boolean zM10519 = m105(0, 1, -1);
            if (this.f115) {
                return;
            }
            boolean zM10520 = m105(0, 2, 0);
            if (((Boolean) this.turnOff.get()).booleanValue() && zM10511 && zM10512 && zM10513 && zM10514 && zM10515 && zM10516 && zM10517 && zM10518 && zM10519 && zM10520) {
                toggle();
            }
        }
    }

    private boolean m105(int x, int y, int z) {
        m106(x, y, z);
        FindItemResult findItemResultFindInHotbar = InvUtils.findInHotbar(class_1799Var -> {
            return m107(class_1799Var, this.f114);
        });
        if (!BlockUtils.canPlace(this.f114)) {
            return true;
        }
        if (BlockUtils.place(this.f114, findItemResultFindInHotbar, ((Boolean) this.rotate.get()).booleanValue(), 100, true)) {
            this.f115 = true;
            return false;
        }
        return false;
    }

    private void m106(int x, int y, int z) {
        this.f114.method_10102(this.mc.field_1724.method_23317() + x, this.mc.field_1724.method_23318() + y, this.mc.field_1724.method_23321() + z);
    }

    private boolean m107(class_1799 class_1799Var, class_2338 class_2338Var) {
        if (!(class_1799Var.method_7909() instanceof class_1747)) {
            return false;
        }
        class_2248 class_2248VarMethod_7711 = class_1799Var.method_7909().method_7711();
        if (class_2248.method_9614(class_2248VarMethod_7711.method_9564().method_26220(this.mc.field_1687, class_2338Var))) {
            return ((class_2248VarMethod_7711 instanceof class_2346) && class_2346.method_10128(this.mc.field_1687.method_8320(class_2338Var))) ? false : true;
        }
        return false;
    }
}
