package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.misc.Pool;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import meteordevelopment.meteorclient.utils.world.BlockIterator;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1778;
import net.minecraft.class_1786;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2530;
import net.minecraft.class_3965;

public class AutoTNT extends Module {
    private final SettingGroup sgGeneral;
    private final Setting<Boolean> ignite;
    private final Setting<Integer> igniteDelay;
    private final Setting<Integer> horizontalRange;
    private final Setting<Integer> verticalRange;
    private final Setting<Boolean> antiBreak;
    private final Setting<Boolean> fireCharge;
    private final Setting<Boolean> rotate;

    private final List<class_2338.class_2339> f105TNT;

    private final Pool<class_2338.class_2339> f106TNT;

    private int f107;

    public AutoTNT() {
        super(MeteorRejectsAddon.CATEGORY, "自动点燃TNT", "自动点燃范围内的TNT，适用于破坏场景。");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.ignite = this.sgGeneral.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("自动点燃")).description("是否自动点燃TNT。")).defaultValue(true)).build());
        SettingGroup settingGroup = this.sgGeneral;
        IntSetting.Builder builder = (IntSetting.Builder) ((IntSetting.Builder) ((IntSetting.Builder) new IntSetting.Builder().name("点燃延迟")).description("两次点燃操作之间的tick延迟。")).defaultValue(1);
        Setting<Boolean> setting = this.ignite;
        Objects.requireNonNull(setting);
        this.igniteDelay = settingGroup.add(((IntSetting.Builder) builder.visible(setting::get)).build());
        this.horizontalRange = this.sgGeneral.add(((IntSetting.Builder) ((IntSetting.Builder) ((IntSetting.Builder) new IntSetting.Builder().name("水平范围")).description("点燃TNT的水平搜索范围。")).defaultValue(4)).build());
        this.verticalRange = this.sgGeneral.add(((IntSetting.Builder) ((IntSetting.Builder) ((IntSetting.Builder) new IntSetting.Builder().name("垂直范围")).description("点燃TNT的垂直搜索范围。")).defaultValue(4)).build());
        SettingGroup settingGroup2 = this.sgGeneral;
        BoolSetting.Builder builder2 = (BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("防止损坏")).description("避免打火石因耐久耗尽而损坏（保留10点耐久）。")).defaultValue(true);
        Setting<Boolean> setting2 = this.ignite;
        Objects.requireNonNull(setting2);
        this.antiBreak = settingGroup2.add(((BoolSetting.Builder) builder2.visible(setting2::get)).build());
        SettingGroup settingGroup3 = this.sgGeneral;
        BoolSetting.Builder builder3 = (BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("允许火弹")).description("是否同时使用火焰弹点燃TNT。")).defaultValue(true);
        Setting<Boolean> setting3 = this.ignite;
        Objects.requireNonNull(setting3);
        this.fireCharge = settingGroup3.add(((BoolSetting.Builder) builder3.visible(setting3::get)).build());
        this.rotate = this.sgGeneral.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("自动转向")).description("执行点燃操作时是否自动转向TNT方向。")).defaultValue(true)).build());
        this.f105TNT = new ArrayList();
        this.f106TNT = new Pool<>(class_2338.class_2339::new);
        this.f107 = 0;
    }

    public void onDeactivate() {
        this.f107 = 0;
    }

    @EventHandler
    private void onPreTick(TickEvent.Pre event) {
        if (((Boolean) this.ignite.get()).booleanValue() && this.f107 > ((Integer) this.igniteDelay.get()).intValue()) {
            Iterator<class_2338.class_2339> it = this.f105TNT.iterator();
            while (it.hasNext()) {
                this.f106TNT.free(it.next());
            }
            this.f105TNT.clear();
            BlockIterator.register(((Integer) this.horizontalRange.get()).intValue(), ((Integer) this.verticalRange.get()).intValue(), (class_2338Var, class_2680Var) -> {
                if (class_2680Var.method_26204() instanceof class_2530) {
                    this.f105TNT.add(((class_2338.class_2339) this.f106TNT.get()).method_10101(class_2338Var));
                }
            });
        }
    }

    @EventHandler
    private void onPostTick(TickEvent.Post event) {
        if (((Boolean) this.ignite.get()).booleanValue() && !this.f105TNT.isEmpty() && this.f107 > ((Integer) this.igniteDelay.get()).intValue()) {
            this.f105TNT.sort(Comparator.comparingDouble((v0) -> {
                return PlayerUtils.distanceTo(v0);
            }));
            FindItemResult findItemResultFindInHotbar = InvUtils.findInHotbar(class_1799Var -> {
                if (class_1799Var.method_7909() instanceof class_1786) {
                    return !((Boolean) this.antiBreak.get()).booleanValue() || class_1799Var.method_7936() - class_1799Var.method_7919() > 10;
                }
                if (class_1799Var.method_7909() instanceof class_1778) {
                    return ((Boolean) this.fireCharge.get()).booleanValue();
                }
                return false;
            });
            if (!findItemResultFindInHotbar.found()) {
                error("快捷栏中没有打火石或火焰弹", new Object[0]);
                toggle();
                return;
            } else {
                m103TNT((class_2338) this.f105TNT.get(0), findItemResultFindInHotbar);
                this.f107 = 0;
            }
        }
        this.f107++;
    }

    private void m103TNT(class_2338 class_2338Var, FindItemResult findItemResult) {
        InvUtils.swap(findItemResult.slot(), true);
        this.mc.field_1761.method_2896(this.mc.field_1724, class_1268.field_5808, new class_3965(new class_243(class_2338Var.method_10263() + 0.5d, class_2338Var.method_10264() + 0.5d, class_2338Var.method_10260() + 0.5d), class_2350.field_11036, class_2338Var, true));
        InvUtils.swapBack();
    }
}
