package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import anticope.rejects.settings.GameModeListSetting;
import java.util.List;
import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1934;
import net.minecraft.class_2703;
import net.minecraft.class_640;

public class GamemodeNotifier extends Module {
    private final SettingGroup sgGeneral;

    private final Setting<List<class_1934>> f147;

    public GamemodeNotifier() {
        super(MeteorRejectsAddon.CATEGORY, "游戏模式通知器", "当玩家的游戏模式发生变更时，向你发送通知。");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.f147 = this.sgGeneral.add(((GameModeListSetting.Builder) ((GameModeListSetting.Builder) new GameModeListSetting.Builder().name("目标游戏模式")).description("选择需要接收通知的游戏模式变更。")).m185build());
    }

    @EventHandler
    public void onPacket(PacketEvent.Receive event) {
        class_640 class_640VarMethod_2871;
        class_1934 class_1934VarComp_1110;
        class_2703 class_2703Var = event.packet;
        if (class_2703Var instanceof class_2703) {
            class_2703 class_2703Var2 = class_2703Var;
            for (class_2703.class_2705 class_2705Var : class_2703Var2.method_46329()) {
                if (class_2703Var2.method_46327().contains(class_2703.class_5893.field_29137) && (class_640VarMethod_2871 = this.mc.method_1562().method_2871(class_2705Var.comp_1106())) != null && class_640VarMethod_2871.method_2958() != (class_1934VarComp_1110 = class_2705Var.comp_1110()) && ((List) this.f147.get()).contains(class_1934VarComp_1110)) {
                    info("玩家 %s 将游戏模式更改为 %s", new Object[]{class_640VarMethod_2871.method_2966().getName(), class_1934VarComp_1110.method_8381()});
                }
            }
        }
    }
}
