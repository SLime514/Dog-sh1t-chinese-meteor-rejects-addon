package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import anticope.rejects.utils.RejectsUtils;
import com.google.common.collect.Streams;
import meteordevelopment.meteorclient.events.entity.player.PlayerMoveEvent;
import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.mixin.PlayerMoveC2SPacketAccessor;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1297;
import net.minecraft.class_2596;
import net.minecraft.class_2828;

public class FullFlight extends Module {
    private final SettingGroup sgGeneral;
    private final SettingGroup sgAntiKick;
    private final Setting<Double> speed;
    private final Setting<Boolean> verticalSpeedMatch;
    private final Setting<AntiKickMode> antiKickMode;

    private int f144;

    private double f145Y;

    private int f146;

    public FullFlight() {
        super(MeteorRejectsAddon.CATEGORY, "完全飞行", "提供无限制的飞行功能，支持多种防踢模式规避服务器检测。");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.sgAntiKick = this.settings.createGroup("防踢设置");
        this.speed = this.sgGeneral.add(((DoubleSetting.Builder) ((DoubleSetting.Builder) new DoubleSetting.Builder().name("飞行速度")).description("飞行时的移动速度。")).defaultValue(0.3d).min(0.0d).sliderMax(10.0d).build());
        this.verticalSpeedMatch = this.sgGeneral.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("垂直速度匹配")).description("使垂直飞行速度与水平速度保持一致，禁用则使用原版速度比例。")).defaultValue(false)).build());
        this.antiKickMode = this.sgAntiKick.add(((EnumSetting.Builder) ((EnumSetting.Builder) ((EnumSetting.Builder) new EnumSetting.Builder().name("防踢模式")).description("用于规避服务器飞行检测的防踢模式。")).defaultValue(AntiKickMode.PaperNew)).build());
        this.f144 = 20;
        this.f145Y = Double.MAX_VALUE;
        this.f146 = 0;
    }

    private double calculateGround() {
        double dMethod_23318 = this.mc.field_1724.method_23318();
        while (true) {
            double d = dMethod_23318;
            if (d > 0.0d) {
                if (!Streams.stream(this.mc.field_1687.method_20812(this.mc.field_1724, this.mc.field_1724.method_5829().method_989(0.0d, d - this.mc.field_1724.method_23318(), 0.0d))).findAny().isPresent()) {
                    dMethod_23318 = d - 0.05d;
                } else {
                    return d + 0.05d;
                }
            } else {
                return 0.0d;
            }
        }
    }

    private boolean isEntityOnAir(class_1297 entity) {
        return entity.method_37908().method_29546(entity.method_5829().method_1014(0.0625d).method_1012(0.0d, -0.55d, 0.0d)).allMatch((v0) -> {
            return v0.method_26215();
        });
    }

    private boolean shouldFlyDown(double currentY, double lastY) {
        return currentY >= lastY || lastY - currentY < 0.0313d;
    }

    private void antiKickPacket(class_2828 packet, double currentY) {
        if (this.f144 <= 0 && this.f145Y != Double.MAX_VALUE && shouldFlyDown(currentY, this.f145Y) && isEntityOnAir(this.mc.field_1724)) {
            ((PlayerMoveC2SPacketAccessor) packet).setY(this.f145Y - 0.0313d);
            this.f145Y -= 0.0313d;
            this.f144 = 20;
        } else {
            this.f145Y = currentY;
            if (!isEntityOnAir(this.mc.field_1724)) {
                this.f144 = 20;
            }
        }
        if (this.f144 > 0) {
            this.f144--;
        }
    }

    @EventHandler
    private void onSendPacket(PacketEvent.Send event) {
        class_2828.class_2830 class_2829Var;
        if (this.mc.field_1724.method_5854() == null) {
            class_2596 class_2596Var = event.packet;
            if (class_2596Var instanceof class_2828) {
                class_2828 class_2828Var = (class_2828) class_2596Var;
                if (this.antiKickMode.get() != AntiKickMode.PaperNew) {
                    return;
                }
                double dMethod_12268 = class_2828Var.method_12268(Double.MAX_VALUE);
                if (dMethod_12268 != Double.MAX_VALUE) {
                    antiKickPacket(class_2828Var, dMethod_12268);
                    return;
                }
                if (class_2828Var.method_36172()) {
                    class_2829Var = new class_2828.class_2830(this.mc.field_1724.method_23317(), this.mc.field_1724.method_23318(), this.mc.field_1724.method_23321(), class_2828Var.method_12271(0.0f), class_2828Var.method_12270(0.0f), class_2828Var.method_12273(), class_2828Var.method_61225());
                } else {
                    class_2829Var = new class_2828.class_2829(this.mc.field_1724.method_23317(), this.mc.field_1724.method_23318(), this.mc.field_1724.method_23321(), class_2828Var.method_12273(), class_2828Var.method_61225());
                }
                event.cancel();
                antiKickPacket(class_2829Var, this.mc.field_1724.method_23318());
                this.mc.method_1562().method_52787(class_2829Var);
            }
        }
    }

    @EventHandler
    private void onPlayerMove(PlayerMoveEvent event) {
        if (this.antiKickMode.get() == AntiKickMode.PaperNew) {
            this.mc.field_1724.setTicksSinceLastPositionPacketSent(20);
        }
        if (this.f146 >= 20) {
            switch ((AntiKickMode) this.antiKickMode.get()) {
                case Old:
                    if (!Streams.stream(this.mc.field_1687.method_20812(this.mc.field_1724, this.mc.field_1724.method_5829().method_989(0.0d, -0.4d, 0.0d))).findAny().isPresent()) {
                        double dCalculateGround = calculateGround() + 0.1d;
                        double dMethod_23318 = this.mc.field_1724.method_23318();
                        while (true) {
                            double d = dMethod_23318;
                            if (d > dCalculateGround) {
                                this.mc.method_1562().method_52787(new class_2828.class_2829(this.mc.field_1724.method_23317(), d, this.mc.field_1724.method_23321(), true, this.mc.field_1724.field_5976));
                                if (d - 4.0d >= dCalculateGround) {
                                    dMethod_23318 = d - 4.0d;
                                }
                            }
                        }
                        this.mc.method_1562().method_52787(new class_2828.class_2829(this.mc.field_1724.method_23317(), dCalculateGround, this.mc.field_1724.method_23321(), true, this.mc.field_1724.field_5976));
                        double d2 = dCalculateGround;
                        while (true) {
                            double d3 = d2;
                            if (d3 < this.mc.field_1724.method_23318()) {
                                this.mc.method_1562().method_52787(new class_2828.class_2829(this.mc.field_1724.method_23317(), d3, this.mc.field_1724.method_23321(), this.mc.field_1724.method_24828(), this.mc.field_1724.field_5976));
                                if (d3 + 4.0d <= this.mc.field_1724.method_23318()) {
                                    d2 = d3 + 4.0d;
                                }
                            }
                        }
                        this.mc.method_1562().method_52787(new class_2828.class_2829(this.mc.field_1724.method_23317(), this.mc.field_1724.method_23318(), this.mc.field_1724.method_23321(), this.mc.field_1724.method_24828(), this.mc.field_1724.field_5976));
                        break;
                    }
                    break;
                case New:
                    if (!Streams.stream(this.mc.field_1687.method_20812(this.mc.field_1724, this.mc.field_1724.method_5829().method_989(0.0d, -0.4d, 0.0d))).findAny().isPresent()) {
                        this.mc.method_1562().method_52787(new class_2828.class_2829(this.mc.field_1724.method_23317(), this.mc.field_1724.method_23318() - 0.4d, this.mc.field_1724.method_23321(), this.mc.field_1724.method_24828(), this.mc.field_1724.field_5976));
                        this.mc.method_1562().method_52787(new class_2828.class_2829(this.mc.field_1724.method_23317(), this.mc.field_1724.method_23318(), this.mc.field_1724.method_23321(), this.mc.field_1724.method_24828(), this.mc.field_1724.field_5976));
                        break;
                    }
                    break;
            }
            this.f146 = 0;
        }
        float fFullFlightMove = RejectsUtils.fullFlightMove(event, ((Double) this.speed.get()).doubleValue(), ((Boolean) this.verticalSpeedMatch.get()).booleanValue());
        if (this.f146 < 20) {
            if (fFullFlightMove >= -0.1d) {
                this.f146++;
            } else if (this.antiKickMode.get() == AntiKickMode.New) {
                this.f146 = 0;
            }
        }
    }

    public enum AntiKickMode {
        Old("旧模式"),
        New("新模式"),
        PaperNew("Paper新模式"),
        None("无防踢");

        public final String chineseName;

        AntiKickMode(String chineseName) {
            this.chineseName = chineseName;
        }

        @Override
        public String toString() {
            return this.chineseName;
        }
    }
}
