package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import anticope.rejects.settings.StringMapSetting;
import anticope.rejects.utils.RejectsUtils;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;
import meteordevelopment.meteorclient.events.game.GameJoinedEvent;
import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.gui.GuiTheme;
import meteordevelopment.meteorclient.gui.widgets.WWidget;
import meteordevelopment.meteorclient.gui.widgets.containers.WHorizontalList;
import meteordevelopment.meteorclient.gui.widgets.pressable.WButton;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_124;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_5250;
import net.minecraft.class_7472;

public class AutoLogin extends Module {
    private final SettingGroup sgGeneral;
    private final Setting<Integer> delay;
    private final Setting<Boolean> smart;
    private final Setting<Map<String, String>> commands;
    private final Timer timer;

    public AutoLogin() {
        super(MeteorRejectsAddon.CATEGORY, "自动登录", "加入指定服务器时自动执行登录命令。");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.delay = this.sgGeneral.add(((IntSetting.Builder) ((IntSetting.Builder) ((IntSetting.Builder) new IntSetting.Builder().name("延迟")).description("执行命令前的毫秒延迟。")).defaultValue(1000)).min(0).sliderMax(10000).build());
        this.smart = this.sgGeneral.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("智能模式")).description("自动添加登录条目。")).defaultValue(false)).build());
        this.commands = this.sgGeneral.add(((StringMapSetting.Builder) ((StringMapSetting.Builder) new StringMapSetting.Builder().name("命令设置")).description("服务器与对应登录命令。(* 表示通用)")).defaultValue((Map<String, String>) new LinkedHashMap<String, String>() {
            {
                put("localhost", "/login 123456");
            }
        }).m188build());
        this.timer = new Timer();
        this.runInMainMenu = true;
    }

    public WWidget getWidget(GuiTheme theme) {
        WHorizontalList l = theme.horizontalList();
        WButton btn = l.add(theme.button("随机生成密码")).widget();
        btn.action = () -> {
            String password = RejectsUtils.getRandomPassword(16);
            class_5250 text = class_2561.method_43470(String.valueOf(class_124.field_1067) + "点击此处安全注册账号。");
            text.method_10862(text.method_10866().method_10958(new class_2558(class_2558.class_2559.field_11750, String.format("/register %s %s", password, password))));
            info(text);
        };
        return l;
    }

    @EventHandler
    private void onGameJoined(GameJoinedEvent event) {
        final String command;
        if (isActive() && (command = (String) ((Map) this.commands.get()).getOrDefault(Utils.getWorldName(), (String) ((Map) this.commands.get()).get("*"))) != null) {
            this.timer.schedule(new TimerTask() {
                @Override
                public void run() {
                    if (AutoLogin.this.mc.field_1724 != null) {
                        ChatUtils.sendPlayerMsg(command);
                    }
                }
            }, ((Integer) this.delay.get()).intValue());
        }
    }

    @EventHandler
    private void onPacketSent(PacketEvent.Send event) {
        if (((Boolean) this.smart.get()).booleanValue()) {
            class_7472 class_7472Var = event.packet;
            if (class_7472Var instanceof class_7472) {
                class_7472 packet = class_7472Var;
                String command = packet.comp_808();
                List<String> listAsList = Arrays.asList("reg", "register", "l", "login", "log");
                String[] strArrSplit = command.split(" ");
                if (strArrSplit.length >= 2 && listAsList.contains(strArrSplit[0])) {
                    ((Map) this.commands.get()).put(Utils.getWorldName(), "/login " + strArrSplit[1]);
                }
            }
        }
    }
}
