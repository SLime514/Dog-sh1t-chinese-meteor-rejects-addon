package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import meteordevelopment.meteorclient.events.entity.BoatMoveEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1690;
import net.minecraft.class_243;

public class BoatPhase extends Module {
    private final SettingGroup sgGeneral;
    private final SettingGroup sgSpeeds;
    private final Setting<Boolean> lockYaw;
    private final Setting<Boolean> verticalControl;
    private final Setting<Boolean> adjustHorizontalSpeed;
    private final Setting<Boolean> fall;
    private final Setting<Double> horizontalSpeed;
    private final Setting<Double> verticalSpeed;
    private final Setting<Double> fallSpeed;

    private class_1690 f10;

    public BoatPhase() {
        super(MeteorRejectsAddon.CATEGORY, "船只穿模", "使用船只穿过方块。");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.sgSpeeds = this.settings.createGroup("速度设置");
        this.lockYaw = this.sgGeneral.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("锁定船只朝向")).description("将船只朝向锁定为你面向的方向。")).defaultValue(true)).build());
        this.verticalControl = this.sgGeneral.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("垂直控制")).description("是否可以使用空格/ctrl进行垂直移动。")).defaultValue(true)).build());
        this.adjustHorizontalSpeed = this.sgGeneral.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("调整水平速度")).description("是否修改水平移动速度。")).defaultValue(false)).build());
        this.fall = this.sgGeneral.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("自动下落")).description("开启垂直滑行模式。")).defaultValue(false)).build());
        this.horizontalSpeed = this.sgSpeeds.add(((DoubleSetting.Builder) ((DoubleSetting.Builder) new DoubleSetting.Builder().name("水平速度")).description("水平移动速度（方块/秒）。")).defaultValue(10.0d).min(0.0d).sliderMax(50.0d).build());
        this.verticalSpeed = this.sgSpeeds.add(((DoubleSetting.Builder) ((DoubleSetting.Builder) new DoubleSetting.Builder().name("垂直速度")).description("垂直移动速度（方块/秒）。")).defaultValue(5.0d).min(0.0d).sliderMax(20.0d).build());
        this.fallSpeed = this.sgSpeeds.add(((DoubleSetting.Builder) ((DoubleSetting.Builder) new DoubleSetting.Builder().name("下落速度")).description("下落速度（方块/秒）。")).defaultValue(0.625d).min(0.0d).sliderMax(10.0d).build());
        this.f10 = null;
    }

    public void onActivate() {
        this.f10 = null;
        if (Modules.get().isActive(BoatGlitch.class)) {
            ((BoatGlitch) Modules.get().get(BoatGlitch.class)).toggle();
        }
    }

    public void onDeactivate() {
        if (this.f10 != null) {
            this.f10.field_5960 = false;
        }
    }

    @EventHandler
    private void onBoatMove(BoatMoveEvent event) {
        class_243 class_243VarMethod_18798;
        if (this.mc.field_1724.method_5854() != null && (this.mc.field_1724.method_5854() instanceof class_1690)) {
            if (this.f10 != this.mc.field_1724.method_5854()) {
                if (this.f10 != null) {
                    this.f10.field_5960 = false;
                }
                this.f10 = this.mc.field_1724.method_5854();
            }
        } else {
            this.f10 = null;
        }
        if (this.f10 != null) {
            this.f10.field_5960 = true;
            if (((Boolean) this.lockYaw.get()).booleanValue()) {
                this.f10.method_36456(this.mc.field_1724.method_36454());
            }
            if (((Boolean) this.adjustHorizontalSpeed.get()).booleanValue()) {
                class_243VarMethod_18798 = PlayerUtils.getHorizontalVelocity(((Double) this.horizontalSpeed.get()).doubleValue());
            } else {
                class_243VarMethod_18798 = this.f10.method_18798();
            }
            double d = class_243VarMethod_18798.field_1352;
            double dDoubleValue = 0.0d;
            double d2 = class_243VarMethod_18798.field_1350;
            if (((Boolean) this.verticalControl.get()).booleanValue()) {
                if (this.mc.field_1690.field_1903.method_1434()) {
                    dDoubleValue = 0.0d + (((Double) this.verticalSpeed.get()).doubleValue() / 20.0d);
                }
                if (this.mc.field_1690.field_1867.method_1434()) {
                    dDoubleValue -= ((Double) this.verticalSpeed.get()).doubleValue() / 20.0d;
                } else if (((Boolean) this.fall.get()).booleanValue()) {
                    dDoubleValue -= ((Double) this.fallSpeed.get()).doubleValue() / 20.0d;
                }
            } else if (((Boolean) this.fall.get()).booleanValue()) {
                dDoubleValue = 0.0d - (((Double) this.fallSpeed.get()).doubleValue() / 20.0d);
            }
            this.f10.method_18798().meteor$set(d, dDoubleValue, d2);
        }
    }
}
