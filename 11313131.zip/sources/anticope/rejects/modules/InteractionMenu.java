package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import anticope.rejects.gui.screens.InteractionScreen;
import anticope.rejects.settings.StringMapSetting;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import meteordevelopment.meteorclient.gui.utils.StarscriptTextBoxRenderer;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.ColorSetting;
import meteordevelopment.meteorclient.settings.EntityTypeListSetting;
import meteordevelopment.meteorclient.settings.KeybindSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.misc.Keybind;
import meteordevelopment.meteorclient.utils.misc.MeteorStarscript;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.starscript.value.Value;
import meteordevelopment.starscript.value.ValueMap;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_863;

public class InteractionMenu extends Module {
    private final SettingGroup sgGeneral;
    private final SettingGroup sgStyle;
    private final Setting<Set<class_1299<?>>> entities;
    public final Setting<Keybind> keybind;
    public final Setting<Boolean> useCrosshairTarget;
    public final Setting<SettingColor> selectedDotColor;
    public final Setting<SettingColor> dotColor;
    public final Setting<SettingColor> backgroundColor;
    public final Setting<SettingColor> borderColor;
    public final Setting<SettingColor> textColor;
    public final Setting<Map<String, String>> messages;

    public InteractionMenu() {
        super(MeteorRejectsAddon.CATEGORY, "交互菜单", "当看向实体时显示的交互界面");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.sgStyle = this.settings.createGroup("样式");
        this.entities = this.sgGeneral.add(((EntityTypeListSetting.Builder) ((EntityTypeListSetting.Builder) new EntityTypeListSetting.Builder().name("实体类型")).description("要交互的实体类型")).defaultValue(new class_1299[]{class_1299.field_6097}).build());
        this.keybind = this.sgGeneral.add(((KeybindSetting.Builder) ((KeybindSetting.Builder) new KeybindSetting.Builder().name("按键绑定")).description("用于打开交互菜单的按键绑定")).action(this::onKey).build());
        this.useCrosshairTarget = this.sgGeneral.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("使用准星瞄准目标")).description("是否使用准星所瞄准的目标")).defaultValue(false)).build());
        this.selectedDotColor = this.sgStyle.add(((ColorSetting.Builder) ((ColorSetting.Builder) new ColorSetting.Builder().name("选中点颜色")).description("选中时的点颜色")).defaultValue(new SettingColor(76, 255, 0)).build());
        this.dotColor = this.sgStyle.add(((ColorSetting.Builder) ((ColorSetting.Builder) new ColorSetting.Builder().name("点颜色")).description("普通状态下的点颜色")).defaultValue(new SettingColor(0, 148, 255)).build());
        this.backgroundColor = this.sgStyle.add(((ColorSetting.Builder) ((ColorSetting.Builder) new ColorSetting.Builder().name("背景颜色")).description("背景的颜色")).defaultValue(new SettingColor(128, 128, 128, 128)).build());
        this.borderColor = this.sgStyle.add(((ColorSetting.Builder) ((ColorSetting.Builder) new ColorSetting.Builder().name("边框颜色")).description("边框的颜色")).defaultValue(new SettingColor(0, 0, 0)).build());
        this.textColor = this.sgStyle.add(((ColorSetting.Builder) ((ColorSetting.Builder) new ColorSetting.Builder().name("文字颜色")).description("文字的颜色")).defaultValue(new SettingColor(255, 255, 255)).build());
        this.messages = this.sgGeneral.add(((StringMapSetting.Builder) ((StringMapSetting.Builder) new StringMapSetting.Builder().name("消息")).description("交互时的消息内容")).renderer(StarscriptTextBoxRenderer.class).m188build());
        MeteorStarscript.ss.set("entity", () -> {
            return wrap(InteractionScreen.interactionMenuEntity);
        });
    }

    public void onKey() {
        if (this.mc.field_1724 == null || this.mc.field_1755 != null) {
            return;
        }
        class_1297 e = null;
        if (((Boolean) this.useCrosshairTarget.get()).booleanValue()) {
            e = this.mc.field_1692;
        } else {
            Optional<class_1297> lookingAt = class_863.method_23101(this.mc.field_1724, 20);
            if (lookingAt.isPresent()) {
                e = lookingAt.get();
            }
        }
        if (e != null && ((Set) this.entities.get()).contains(e.method_5864())) {
            this.mc.method_1507(new InteractionScreen(e, this));
        }
    }

    public static Value wrap(class_1297 entity) {
        double dMethod_6032;
        if (entity == null) {
            return Value.map(new ValueMap().set("_toString", Value.null_()).set("health", Value.null_()).set("pos", Value.map(new ValueMap().set("_toString", Value.null_()).set("x", Value.null_()).set("y", Value.null_()).set("z", Value.null_()))).set("uuid", Value.null_()));
        }
        ValueMap valueMap = new ValueMap().set("_toString", Value.string(entity.method_5477().getString()));
        if (entity instanceof class_1309) {
            class_1309 e = (class_1309) entity;
            dMethod_6032 = e.method_6032();
        } else {
            dMethod_6032 = 0.0d;
        }
        return Value.map(valueMap.set("health", Value.number(dMethod_6032)).set("pos", Value.map(new ValueMap().set("_toString", posString(entity.method_23317(), entity.method_23318(), entity.method_23321())).set("x", Value.number(entity.method_23317())).set("y", Value.number(entity.method_23318())).set("z", Value.number(entity.method_23321())))).set("uuid", Value.string(entity.method_5845())));
    }

    private static Value posString(double x, double y, double z) {
        return Value.string(String.format("X: %.0f Y: %.0f Z: %.0f", Double.valueOf(x), Double.valueOf(y), Double.valueOf(z)));
    }
}
