package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import anticope.rejects.utils.WorldUtils;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.stream.IntStream;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import meteordevelopment.meteorclient.utils.player.Rotations;
import meteordevelopment.meteorclient.utils.world.CardinalDirection;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2473;
import net.minecraft.class_2885;
import net.minecraft.class_3532;
import net.minecraft.class_3965;

public class TreeAura extends Module {
    private final SettingGroup sgGeneral;

    private final Setting<Boolean> f188;

    private final Setting<Integer> f189;

    private final Setting<Integer> f190;

    private final Setting<Integer> f191;

    private final Setting<Integer> f192;

    private final Setting<SortMode> f193;

    private int f194;

    private int f195;

    public enum SortMode {
        f196,
        f197
    }

    public TreeAura() {
        super(MeteorRejectsAddon.CATEGORY, "树木光环", "自动在玩家周围种植树苗并使用骨粉催熟。");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.f188 = this.sgGeneral.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("自动旋转")).description("为方块交互（种植/骨粉）自动旋转视角。")).defaultValue(false)).build());
        this.f189 = this.sgGeneral.add(((IntSetting.Builder) ((IntSetting.Builder) ((IntSetting.Builder) new IntSetting.Builder().name("种植延迟")).description("两次种植树苗之间的间隔时间（游戏刻）。")).defaultValue(6)).min(0).sliderMax(25).build());
        this.f190 = this.sgGeneral.add(((IntSetting.Builder) ((IntSetting.Builder) ((IntSetting.Builder) new IntSetting.Builder().name("骨粉延迟")).description("两次对树苗使用骨粉之间的间隔时间（游戏刻）。")).defaultValue(3)).min(0).sliderMax(25).build());
        this.f191 = this.sgGeneral.add(((IntSetting.Builder) ((IntSetting.Builder) ((IntSetting.Builder) new IntSetting.Builder().name("水平范围")).description("可种植树苗的最大水平距离。")).defaultValue(4)).min(1).sliderMax(5).build());
        this.f192 = this.sgGeneral.add(((IntSetting.Builder) ((IntSetting.Builder) ((IntSetting.Builder) new IntSetting.Builder().name("垂直范围")).description("可种植树苗的最大垂直距离。")).defaultValue(3)).min(1).sliderMax(5).build());
        this.f193 = this.sgGeneral.add(((EnumSetting.Builder) ((EnumSetting.Builder) ((EnumSetting.Builder) new EnumSetting.Builder().name("排序模式")).description("附近树苗/种植位置的优先处理顺序。")).defaultValue(SortMode.f197)).build());
    }

    public void onActivate() {
        this.f194 = 0;
        this.f195 = 0;
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        class_2338 class_2338VarM174;
        class_2338 class_2338VarM176;
        this.f195--;
        this.f194--;
        if (this.f195 <= 0 && (class_2338VarM176 = m176()) != null) {
            m170(class_2338VarM176);
            this.f195 = ((Integer) this.f189.get()).intValue();
        }
        if (this.f194 <= 0 && (class_2338VarM174 = m174()) != null) {
            m171(class_2338VarM174);
            this.f194 = ((Integer) this.f190.get()).intValue();
        }
    }

    private FindItemResult m167() {
        return InvUtils.findInHotbar(new class_1792[]{class_1802.field_8324});
    }

    private FindItemResult m168() {
        return InvUtils.findInHotbar(itemStack -> {
            return class_2248.method_9503(itemStack.method_7909()) instanceof class_2473;
        });
    }

    private boolean m169(class_2338 class_2338Var) {
        return this.mc.field_1687.method_8320(class_2338Var).method_26204() instanceof class_2473;
    }

    private void m170(class_2338 class_2338Var) {
        FindItemResult findItemResultM168 = m168();
        if (!findItemResultM168.found()) {
            error("快捷栏中没有树苗！", new Object[0]);
            toggle();
            return;
        }
        InvUtils.swap(findItemResultM168.slot(), false);
        class_3965 class_3965Var = new class_3965(Utils.vec3d(class_2338Var), class_2350.field_11036, class_2338Var, false);
        if (((Boolean) this.f188.get()).booleanValue()) {
            Rotations.rotate(Rotations.getYaw(class_2338Var), Rotations.getPitch(class_2338Var), () -> {
                this.mc.field_1724.field_3944.method_52787(new class_2885(class_1268.field_5808, class_3965Var, 0));
            });
        } else {
            this.mc.field_1724.field_3944.method_52787(new class_2885(class_1268.field_5808, class_3965Var, 0));
        }
    }

    private void m171(class_2338 class_2338Var) {
        FindItemResult findItemResultM167 = m167();
        if (!findItemResultM167.found()) {
            error("快捷栏中没有骨粉！", new Object[0]);
            toggle();
            return;
        }
        InvUtils.swap(findItemResultM167.slot(), false);
        class_3965 class_3965Var = new class_3965(Utils.vec3d(class_2338Var), class_2350.field_11036, class_2338Var, false);
        if (((Boolean) this.f188.get()).booleanValue()) {
            Rotations.rotate(Rotations.getYaw(class_2338Var), Rotations.getPitch(class_2338Var), () -> {
                this.mc.field_1724.field_3944.method_52787(new class_2885(class_1268.field_5808, class_3965Var, 0));
            });
        } else {
            this.mc.field_1724.field_3944.method_52787(new class_2885(class_1268.field_5808, class_3965Var, 0));
        }
    }

    private boolean m172(class_2338 class_2338Var) {
        class_2248 class_2248VarMethod_26204 = this.mc.field_1687.method_8320(class_2338Var).method_26204();
        if (class_2248VarMethod_26204 == class_2246.field_10479 || class_2248VarMethod_26204 == class_2246.field_10219 || class_2248VarMethod_26204 == class_2246.field_10566 || class_2248VarMethod_26204 == class_2246.field_10253) {
            AtomicBoolean atomicBoolean = new AtomicBoolean(true);
            IntStream.rangeClosed(1, 5).forEach(i -> {
                class_2338 class_2338VarMethod_10086 = class_2338Var.method_10086(i);
                if (!this.mc.field_1687.method_8320(class_2338VarMethod_10086).method_26204().equals(class_2246.field_10124)) {
                    atomicBoolean.set(false);
                    return;
                }
                for (CardinalDirection cardinalDirection : CardinalDirection.values()) {
                    if (!this.mc.field_1687.method_8320(class_2338VarMethod_10086.method_10079(cardinalDirection.toDirection(), i)).method_26204().equals(class_2246.field_10124)) {
                        atomicBoolean.set(false);
                        return;
                    }
                }
            });
            return atomicBoolean.get();
        }
        return false;
    }

    private List<class_2338> m173(class_2338 class_2338Var, int i, int i2) {
        ArrayList<class_2338> arrayList = new ArrayList<>();
        for (class_2338 class_2338Var2 : WorldUtils.getSphere(class_2338Var, i, i2)) {
            if (m169(class_2338Var2)) {
                arrayList.add(class_2338Var2);
            }
        }
        return arrayList;
    }

    private class_2338 m174() {
        List<class_2338> listM173 = m173(this.mc.field_1724.method_24515(), ((Integer) this.f191.get()).intValue(), ((Integer) this.f192.get()).intValue());
        if (listM173.isEmpty()) {
            return null;
        }
        listM173.sort(Comparator.comparingDouble(PlayerUtils::distanceTo));
        if (this.f193.get() == SortMode.f197) {
            Collections.reverse(listM173);
        }
        return listM173.get(0);
    }

    private List<class_2338> m175(class_2338 class_2338Var, int i, int i2) {
        ArrayList<class_2338> arrayList = new ArrayList<>();
        for (class_2338 class_2338Var2 : WorldUtils.getSphere(class_2338Var, i, i2)) {
            if (m172(class_2338Var2)) {
                arrayList.add(class_2338Var2);
            }
        }
        return arrayList;
    }

    private class_2338 m176() {
        List<class_2338> listM175 = m175(this.mc.field_1724.method_24515(), ((Integer) this.f191.get()).intValue(), ((Integer) this.f192.get()).intValue());
        if (listM175.isEmpty()) {
            return null;
        }
        listM175.sort(Comparator.comparingDouble(PlayerUtils::distanceTo));
        if (this.f193.get() == SortMode.f197) {
            Collections.reverse(listM175);
        }
        return listM175.get(0);
    }

    private double m177(class_2338 class_2338Var, class_2338 class_2338Var2) {
        double dMethod_10263 = class_2338Var.method_10263() - class_2338Var2.method_10263();
        double dMethod_10264 = class_2338Var.method_10264() - class_2338Var2.method_10264();
        double dMethod_10260 = class_2338Var.method_10260() - class_2338Var2.method_10260();
        return class_3532.method_15355((float) ((dMethod_10263 * dMethod_10263) + (dMethod_10264 * dMethod_10264) + (dMethod_10260 * dMethod_10260)));
    }
}
