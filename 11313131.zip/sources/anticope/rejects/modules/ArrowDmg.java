package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import anticope.rejects.events.StopUsingItemEvent;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2828;
import net.minecraft.class_2848;
import net.minecraft.class_310;
import net.minecraft.class_746;

public class ArrowDmg extends Module {
    private final SettingGroup sgGeneral;
    public final Setting<Integer> packets;
    public final Setting<Integer> delayMs;
    public final Setting<Boolean> tridents;

    public ArrowDmg() {
        super(MeteorRejectsAddon.CATEGORY, "箭矢增伤", "大幅提升箭矢伤害，但会消耗大量饥饿值且降低精准度。不适用于弩，且在Paper服务器上似乎已被修复。");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.packets = this.sgGeneral.add(((IntSetting.Builder) ((IntSetting.Builder) ((IntSetting.Builder) new IntSetting.Builder().name("数据包数量")).description("发送的数据包数量。数据包越多，伤害越高。")).defaultValue(200)).min(2).sliderMax(2000).build());
        this.delayMs = this.sgGeneral.add(((IntSetting.Builder) ((IntSetting.Builder) ((IntSetting.Builder) new IntSetting.Builder().name("发送延迟(毫秒)")).description("每个数据包之间的延迟，避免瞬间发送过多导致卡死。")).defaultValue(5)).min(1).sliderMax(100).build());
        this.tridents = this.sgGeneral.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("三叉戟")).description("启用后，三叉戟飞行距离会大幅增加。似乎不影响伤害或激流效果。警告：启用此选项可能会导致三叉戟轻易丢失！")).defaultValue(false)).build());
    }

    @EventHandler
    private void onStopUsingItem(StopUsingItemEvent event) {
        class_746 player;
        if (isValidItem(event.itemStack.method_7909()) && (player = this.mc.field_1724) != null) {
            player.field_3944.method_52787(new class_2848(player, class_2848.class_2849.field_12981));
            double x = player.method_23317();
            double y = player.method_23318();
            double z = player.method_23321();
            CompletableFuture.runAsync(() -> {
                for (int i = 0; i < ((Integer) this.packets.get()).intValue(); i++) {
                    try {
                        TimeUnit.MILLISECONDS.sleep(((Integer) this.delayMs.get()).intValue());
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    class_310.method_1551().execute(() -> {
                        if (this.mc.field_1724 != null) {
                            this.mc.field_1724.field_3944.method_52787(new class_2828.class_2829(x, y - 1.0E-10d, z, true, this.mc.field_1724.field_5976));
                            this.mc.field_1724.field_3944.method_52787(new class_2828.class_2829(x, y + 1.0E-10d, z, false, this.mc.field_1724.field_5976));
                        }
                    });
                }
            });
        }
    }

    private boolean isValidItem(class_1792 item) {
        return (((Boolean) this.tridents.get()).booleanValue() && item == class_1802.field_8547) || item == class_1802.field_8102;
    }
}
