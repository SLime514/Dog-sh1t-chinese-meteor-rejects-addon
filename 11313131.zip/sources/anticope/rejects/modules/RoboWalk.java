package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import anticope.rejects.mixin.PlayerMoveC2SPacketAccessor;
import anticope.rejects.mixin.VehicleMoveC2SPacketAccessor;
import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_243;
import net.minecraft.class_2828;
import net.minecraft.class_2833;

public class RoboWalk extends Module {
    public RoboWalk() {
        super(MeteorRejectsAddon.CATEGORY, "机械行走", "绕过LiveOverflow的移动检测（通过平滑移动数据包）。");
    }

    private double m161(double d) {
        double dRound = Math.round(d * 100.0d) / 100.0d;
        return Math.nextAfter(dRound, dRound + Math.signum(d));
    }

    @EventHandler
    private void onPacketSend(PacketEvent.Send event) {
        PlayerMoveC2SPacketAccessor playerMoveC2SPacketAccessor = event.packet;
        if (playerMoveC2SPacketAccessor instanceof class_2828) {
            PlayerMoveC2SPacketAccessor playerMoveC2SPacketAccessor2 = (class_2828) playerMoveC2SPacketAccessor;
            if (playerMoveC2SPacketAccessor2.method_36171()) {
                double dM161 = m161(playerMoveC2SPacketAccessor2.method_12269(0.0d));
                double dM1612 = m161(playerMoveC2SPacketAccessor2.method_12274(0.0d));
                playerMoveC2SPacketAccessor2.setX(dM161);
                playerMoveC2SPacketAccessor2.setZ(dM1612);
                return;
            }
            return;
        }
        VehicleMoveC2SPacketAccessor vehicleMoveC2SPacketAccessor = event.packet;
        if (vehicleMoveC2SPacketAccessor instanceof class_2833) {
            VehicleMoveC2SPacketAccessor vehicleMoveC2SPacketAccessor2 = (class_2833) vehicleMoveC2SPacketAccessor;
            class_243 position = vehicleMoveC2SPacketAccessor2.getPosition();
            event.packet = VehicleMoveC2SPacketAccessor.create(new class_243(m161(position.method_10216()), position.method_10214(), m161(position.method_10215())), vehicleMoveC2SPacketAccessor2.comp_3351(), vehicleMoveC2SPacketAccessor2.comp_3352(), vehicleMoveC2SPacketAccessor2.comp_3353());
        }
    }
}
