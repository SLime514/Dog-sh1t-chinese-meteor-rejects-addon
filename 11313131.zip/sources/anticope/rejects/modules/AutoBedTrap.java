package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BlockListSetting;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.misc.Pool;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.world.BlockIterator;
import meteordevelopment.meteorclient.utils.world.BlockUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1747;
import net.minecraft.class_2244;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;

public class AutoBedTrap extends Module {
    private final SettingGroup sgGeneral;
    private final Setting<Integer> bpt;
    private final Setting<Boolean> rotate;
    private final Setting<Double> range;
    private final Setting<List<class_2248>> blockTypes;
    private final Pool<class_2338.class_2339> blockPosPool;
    private final List<class_2338.class_2339> blocks;

    int f85;

    public AutoBedTrap() {
        super(MeteorRejectsAddon.CATEGORY, "自动床陷阱", "自动在床的周围放置黑曜石（或指定方块）制作陷阱");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.bpt = this.sgGeneral.add(((IntSetting.Builder) ((IntSetting.Builder) ((IntSetting.Builder) new IntSetting.Builder().name("每tick放置数量")).description("每游戏tick放置的方块数量")).defaultValue(2)).min(1).sliderMax(8).build());
        this.rotate = this.sgGeneral.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("自动转向")).description("放置方块时自动转向目标位置")).defaultValue(true)).build());
        this.range = this.sgGeneral.add(((DoubleSetting.Builder) ((DoubleSetting.Builder) new DoubleSetting.Builder().name("检测范围")).description("检测床的范围")).defaultValue(4.0d).min(0.0d).build());
        this.blockTypes = this.sgGeneral.add(((BlockListSetting.Builder) ((BlockListSetting.Builder) ((BlockListSetting.Builder) new BlockListSetting.Builder().name("陷阱方块")).description("用于制作床陷阱的方块")).defaultValue(Arrays.asList(class_2246.field_10540))).build());
        this.blockPosPool = new Pool<>(class_2338.class_2339::new);
        this.blocks = new ArrayList();
        this.f85 = 0;
    }

    public void onDeactivate() {
        for (class_2338.class_2339 blockPos : this.blocks) {
            this.blockPosPool.free(blockPos);
        }
        this.blocks.clear();
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        BlockIterator.register((int) Math.ceil(((Double) this.range.get()).doubleValue()), (int) Math.ceil(((Double) this.range.get()).doubleValue()), (blockPos, blockState) -> {
            if (BlockUtils.canBreak(blockPos, blockState) && (blockState.method_26204() instanceof class_2244)) {
                this.blocks.add(((class_2338.class_2339) this.blockPosPool.get()).method_10101(blockPos));
            }
        });
    }

    @EventHandler
    private void onTickPost(TickEvent.Post event) {
        boolean z = false;
        Iterator<class_2338.class_2339> it = this.blocks.iterator();
        while (true) {
            if (!it.hasNext()) {
                break;
            }
            class_2338 blockPos = (class_2338) it.next();
            if (!m71(blockPos)) {
                z = true;
                break;
            }
        }
        if (!z || !isActive()) {
            return;
        }
        toggle();
    }

    public boolean m71(class_2338 block) {
        for (class_2338 b : new class_2338[]{block.method_10084(), block.method_10067(), block.method_10095(), block.method_10072(), block.method_10078(), block.method_10074()}) {
            if (this.f85 >= ((Integer) this.bpt.get()).intValue()) {
                this.f85 = 0;
                return true;
            }
            if (((List) this.blockTypes.get()).contains(this.mc.field_1687.method_8320(b).method_26204())) {
                return true;
            }
            FindItemResult findItemResultFindInHotbar = InvUtils.findInHotbar(item -> {
                if (!(item.method_7909() instanceof class_1747)) {
                    return false;
                }
                return ((List) this.blockTypes.get()).contains(item.method_7909().method_7711());
            });
            if (!findItemResultFindInHotbar.found()) {
                error("未找到指定的方块。正在禁用模块。", new Object[0]);
                return false;
            }
            if (BlockUtils.place(b, findItemResultFindInHotbar, ((Boolean) this.rotate.get()).booleanValue(), 10, false)) {
                this.f85++;
                if (this.f85 >= ((Integer) this.bpt.get()).intValue()) {
                    return true;
                }
            }
        }
        this.f85 = 0;
        return true;
    }
}
