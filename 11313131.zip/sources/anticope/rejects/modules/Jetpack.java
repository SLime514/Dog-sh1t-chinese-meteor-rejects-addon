package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import anticope.rejects.events.OffGroundSpeedEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;

public class Jetpack extends Module {
    private final SettingGroup sgGeneral;
    private final Setting<Double> jetpackSpeed;

    public Jetpack() {
        super(MeteorRejectsAddon.CATEGORY, "喷气背包", "模拟喷气背包的飞行效果，按下跳跃键即可上升。");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.jetpackSpeed = this.sgGeneral.add(((DoubleSetting.Builder) ((DoubleSetting.Builder) new DoubleSetting.Builder().name("喷气速度")).description("上升时的垂直速度（值越大，上升越快）。")).defaultValue(0.42d).min(0.0d).sliderMax(1.0d).build());
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (this.mc.field_1690.field_1903.method_1434()) {
            this.mc.field_1724.method_18798().meteor$setY(((Double) this.jetpackSpeed.get()).doubleValue());
        }
    }

    @EventHandler
    private void onOffGroundSpeed(OffGroundSpeedEvent event) {
        event.speed = this.mc.field_1724.method_6029() * ((Double) this.jetpackSpeed.get()).floatValue();
    }
}
