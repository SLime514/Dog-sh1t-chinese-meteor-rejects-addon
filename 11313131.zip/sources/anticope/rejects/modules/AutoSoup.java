package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.runtime.SwitchBootstraps;
import java.util.List;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1321;
import net.minecraft.class_1646;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2304;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_3965;
import net.minecraft.class_3966;

public class AutoSoup extends Module {
    private static final String desc = "在部分服务器中，当你的生命值较低时自动喝羹汤。";
    private final SettingGroup sgGeneral;
    public final Setting<Double> health;

    private int f104;

    public AutoSoup() {
        super(MeteorRejectsAddon.CATEGORY, "自动喝羹汤", desc);
        this.sgGeneral = this.settings.getDefaultGroup();
        this.health = this.sgGeneral.add(((DoubleSetting.Builder) ((DoubleSetting.Builder) new DoubleSetting.Builder().name("生命值阈值")).description("当你的生命值达到或低于此数值时，自动喝羹汤。")).defaultValue(6.5d).min(0.5d).sliderMin(0.5d).sliderMax(9.5d).build());
        this.f104 = -1;
    }

    public void onDeactivate() {
        m102();
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        int i = 0;
        while (i < 36) {
            class_1799 class_1799VarMethod_5438 = this.mc.field_1724.method_31548().method_5438(i);
            if (class_1799VarMethod_5438 != null && class_1799VarMethod_5438.method_7909() == class_1802.field_8428 && i != 9) {
                class_1799 class_1799VarMethod_54382 = this.mc.field_1724.method_31548().method_5438(9);
                boolean z = (class_1799VarMethod_54382.method_7960() || class_1799VarMethod_54382.method_7909() == class_1802.field_8428) ? false : true;
                InvUtils.click().slot(i < 9 ? 36 + i : i);
                InvUtils.click().slot(9);
                if (z) {
                    InvUtils.click().slot(i < 9 ? 36 + i : i);
                }
            }
            i++;
        }
        int iM99 = m99(0, 9);
        if (iM99 != -1) {
            if (!m100()) {
                m102();
                return;
            }
            if (this.f104 == -1) {
                this.f104 = this.mc.field_1724.method_31548().field_7545;
            }
            this.mc.field_1724.method_31548().field_7545 = iM99;
            this.mc.field_1690.field_1904.method_23481(true);
            this.mc.field_1761.method_2919(this.mc.field_1724, class_1268.field_5808);
            return;
        }
        m102();
        int iM992 = m99(9, 36);
        if (iM992 != -1) {
            InvUtils.quickSwap().slot(iM992);
        }
    }

    private int m99(int startSlot, int endSlot) {
        List<class_1792> listOf = List.of(class_1802.field_8308, class_1802.field_8208, class_1802.field_8515);
        for (int i = startSlot; i < endSlot; i++) {
            class_1799 class_1799VarMethod_5438 = this.mc.field_1724.method_31548().method_5438(i);
            if (class_1799VarMethod_5438 != null && listOf.contains(class_1799VarMethod_5438.method_7909())) {
                return i;
            }
        }
        return -1;
    }

    private boolean m100() {
        return ((double) this.mc.field_1724.method_6032()) <= ((Double) this.health.get()).doubleValue() * 2.0d && !m101(this.mc.field_1765);
    }

    private boolean m101(class_239 hitResult) {
        switch ((int) SwitchBootstraps.typeSwitch(MethodHandles.lookup(), "typeSwitch", MethodType.methodType(Integer.TYPE, Object.class, Integer.TYPE), class_3966.class, class_3965.class).dynamicInvoker().invoke(hitResult, 0) /* invoke-custom */) {
            case 0:
                class_1297 class_1297VarMethod_17782 = this.mc.field_1765.method_17782();
                if ((class_1297VarMethod_17782 instanceof class_1646) || (class_1297VarMethod_17782 instanceof class_1321)) {
                }
                break;
            case 1:
                class_2338 class_2338VarMethod_17777 = this.mc.field_1765.method_17777();
                if (class_2338VarMethod_17777 != null) {
                    class_2248 class_2248VarMethod_26204 = this.mc.field_1687.method_8320(class_2338VarMethod_17777).method_26204();
                    if ((class_2248VarMethod_26204 instanceof class_2237) || (class_2248VarMethod_26204 instanceof class_2304)) {
                    }
                }
                break;
        }
        return false;
    }

    private void m102() {
        if (this.f104 == -1) {
            return;
        }
        this.mc.field_1690.field_1904.method_23481(false);
        this.mc.field_1724.method_31548().field_7545 = this.f104;
        this.f104 = -1;
    }
}
