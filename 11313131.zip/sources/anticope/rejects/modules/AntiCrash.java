package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_243;
import net.minecraft.class_2664;
import net.minecraft.class_2675;
import net.minecraft.class_2708;
import net.minecraft.class_2743;

public class AntiCrash extends Module {
    private final SettingGroup sgGeneral;
    private final Setting<Boolean> log;

    public AntiCrash() {
        super(MeteorRejectsAddon.CATEGORY, "防崩溃", "尝试拦截可能导致客户端崩溃的数据包。");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.log = this.sgGeneral.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("日志记录")).description("当检测到崩溃数据包时记录日志。")).defaultValue(false)).build());
    }

    @EventHandler
    private void onPacketReceive(PacketEvent.Receive event) {
        class_2664 class_2664Var = event.packet;
        if (class_2664Var instanceof class_2664) {
            class_2664 packet = class_2664Var;
            class_243 explodePos = packet.comp_2883();
            class_243 playerKnockback = new class_243(0.0d, 0.0d, 0.0d);
            if (packet.comp_2884().isPresent()) {
                playerKnockback = (class_243) packet.comp_2884().get();
            }
            if (explodePos.method_10216() > 3.0E7d || explodePos.method_10214() > 3.0E7d || explodePos.method_10215() > 3.0E7d || explodePos.method_10216() < -3.0E7d || explodePos.method_10214() < -3.0E7d || explodePos.method_10215() < -3.0E7d || playerKnockback.field_1352 > 3.0E7d || playerKnockback.field_1351 > 3.0E7d || playerKnockback.field_1350 > 3.0E7d || playerKnockback.field_1352 < -3.0E7d || playerKnockback.field_1351 < -3.0E7d || playerKnockback.field_1350 < -3.0E7d) {
                cancel(event);
                return;
            }
            return;
        }
        class_2675 packet2 = event.packet;
        if (packet2 instanceof class_2675) {
            if (packet2.method_11545() > 100000) {
                cancel(event);
                return;
            }
            return;
        }
        class_2708 packet3 = event.packet;
        if (packet3 instanceof class_2708) {
            class_243 playerPos = packet3.comp_3228().comp_3148();
            if (playerPos.field_1352 > 3.0E7d || playerPos.field_1351 > 3.0E7d || playerPos.field_1350 > 3.0E7d || playerPos.field_1352 < -3.0E7d || playerPos.field_1351 < -3.0E7d || playerPos.field_1350 < -3.0E7d) {
                cancel(event);
                return;
            }
            return;
        }
        class_2743 class_2743Var = event.packet;
        if (class_2743Var instanceof class_2743) {
            class_2743 packet4 = class_2743Var;
            if (packet4.method_11815() > 3.0E7d || packet4.method_11816() > 3.0E7d || packet4.method_11819() > 3.0E7d || packet4.method_11815() < -3.0E7d || packet4.method_11816() < -3.0E7d || packet4.method_11819() < -3.0E7d) {
                cancel(event);
            }
        }
    }

    private void cancel(PacketEvent.Receive event) {
        if (((Boolean) this.log.get()).booleanValue()) {
            warning("服务器尝试让你崩溃", new Object[0]);
        }
        event.cancel();
    }
}
