package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.reflect.TypeToken;
import io.netty.buffer.Unpooled;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_124;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_2568;
import net.minecraft.class_2596;
import net.minecraft.class_2658;
import net.minecraft.class_5250;

public class CustomPackets extends Module {
    private static final Gson GSON_NON_PRETTY = new GsonBuilder().enableComplexMapKeySerialization().disableHtmlEscaping().create();
    private static final Type BADLION_MODS_TYPE = new TypeToken<Map<String, BadlionMod>>() {
    }.getType();
    private final SettingGroup sgGeneral;
    private final SettingGroup sgBadlion;
    private final Setting<Boolean> unknownPackets;
    private final Setting<Boolean> mods;

    private final class_2540 f143;

    public CustomPackets() {
        super(MeteorRejectsAddon.CATEGORY, "自定义数据包处理", "处理各种非原版的自定义协议数据包。");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.sgBadlion = this.settings.createGroup("BadLion");
        this.unknownPackets = this.sgGeneral.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("未知数据包")).description("是否显示未知的自定义数据包信息。")).defaultValue(false)).build());
        this.mods = this.sgBadlion.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("不允许的模组")).description("是否显示Badlion服务器禁用的模组信息。")).defaultValue(true)).build());
        this.f143 = new class_2540(Unpooled.buffer());
    }

    @EventHandler
    private void onCustomPayloadPacket(PacketEvent.Receive event) {
        class_2596 class_2596Var = event.packet;
        if (class_2596Var instanceof class_2658) {
            class_2658 class_2658Var = (class_2658) class_2596Var;
            if (class_2658Var.comp_1646().method_56479().toString().equals("badlion:mods")) {
                event.setCancelled(onBadlionModsPacket(class_2658Var));
            } else {
                onUnknownPacket(class_2658Var);
            }
        }
    }

    private void onUnknownPacket(class_2658 class_2658Var) {
        if (((Boolean) this.unknownPackets.get()).booleanValue()) {
            class_5250 class_5250VarMethod_43470 = class_2561.method_43470(class_2658Var.comp_1646().method_56479().toString());
            this.f143.method_52931();
            class_5250VarMethod_43470.method_10862(class_5250VarMethod_43470.method_10866().method_10949(new class_2568(class_2568.class_5247.field_24342, class_2561.method_43470(m123(this.f143)))));
            info(class_5250VarMethod_43470);
        }
    }

    private boolean onBadlionModsPacket(class_2658 class_2658Var) {
        if (!((Boolean) this.mods.get()).booleanValue()) {
            return false;
        }
        this.f143.method_52931();
        ChatUtils.sendMsg("Badlion", m122("模组信息", m124((Map) GSON_NON_PRETTY.fromJson(m123(this.f143), BADLION_MODS_TYPE))));
        return true;
    }

    private class_5250 m122(String str, class_5250 class_5250Var) {
        class_5250 class_5250VarMethod_43470 = class_2561.method_43470(String.format("[%s%s%s]", class_124.field_1075, str, class_124.field_1080));
        class_5250VarMethod_43470.method_27693(" ");
        class_5250VarMethod_43470.method_10852(class_5250Var);
        return class_5250VarMethod_43470;
    }

    private String m123(class_2540 class_2540Var) {
        return class_2540Var.readCharSequence(class_2540Var.readableBytes(), StandardCharsets.UTF_8).toString();
    }

    private class_5250 m124(Map<String, BadlionMod> map) {
        class_5250 class_5250VarMethod_43470 = class_2561.method_43470("禁用的模组：\n");
        map.forEach((str, badlionMod) -> {
            class_5250 class_5250VarMethod_434702 = class_2561.method_43470(String.format("- %s%s%s ", class_124.field_1054, str, class_124.field_1080));
            class_5250VarMethod_434702.method_27693(badlionMod.disabled ? "已禁用" : "已启用");
            class_5250VarMethod_434702.method_27693("\n");
            if (badlionMod.extra_data != null) {
                class_5250VarMethod_434702.method_10862(class_5250VarMethod_434702.method_10866().method_10949(new class_2568(class_2568.class_5247.field_24342, class_2561.method_43470(badlionMod.extra_data.toString()))));
            }
            class_5250VarMethod_43470.method_10852(class_5250VarMethod_434702);
        });
        return class_5250VarMethod_43470;
    }

    private static class BadlionMod {
        private boolean disabled;
        private JsonObject extra_data;
        private JsonObject settings;

        private BadlionMod() {
        }
    }
}
