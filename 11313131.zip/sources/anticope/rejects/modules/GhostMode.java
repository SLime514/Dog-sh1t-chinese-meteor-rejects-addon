package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import meteordevelopment.meteorclient.events.game.GameJoinedEvent;
import meteordevelopment.meteorclient.events.game.OpenScreenEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_418;

public class GhostMode extends Module {
    private final SettingGroup sgGeneral;
    private final Setting<Boolean> fullFood;
    private boolean active;

    public GhostMode() {
        super(MeteorRejectsAddon.CATEGORY, "幽灵模式", "允许你在死亡后继续游戏，适用于Forge、Fabric和原版服务器。");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.fullFood = this.sgGeneral.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("满饥饿值")).description("在客户端将饥饿值强制设置为最大值。")).defaultValue(true)).build());
        this.active = false;
    }

    public void onDeactivate() {
        super.onDeactivate();
        this.active = false;
        warning("你已退出幽灵模式！", new Object[0]);
        if (this.mc.field_1724 != null && this.mc.field_1724.field_3944 != null) {
            this.mc.field_1724.method_7331();
            info("已向服务器发送重生请求。", new Object[0]);
        }
    }

    @EventHandler
    private void onGameJoin(GameJoinedEvent event) {
        this.active = false;
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (this.active) {
            if (this.mc.field_1724.method_6032() < 1.0f) {
                this.mc.field_1724.method_6033(20.0f);
            }
            if (((Boolean) this.fullFood.get()).booleanValue() && this.mc.field_1724.method_7344().method_7586() < 20) {
                this.mc.field_1724.method_7344().method_7580(20);
            }
        }
    }

    @EventHandler
    private void onOpenScreen(OpenScreenEvent event) {
        if (event.screen instanceof class_418) {
            event.cancel();
            if (!this.active) {
                this.active = true;
                info("你已进入幽灵模式。", new Object[0]);
            }
        }
    }
}
