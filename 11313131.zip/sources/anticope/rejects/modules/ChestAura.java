package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import com.mojang.blaze3d.systems.RenderSystem;
import com.seedfinding.mccore.nbt.NBTType;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.IntStream;
import java.util.stream.Stream;
import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.events.packets.InventoryEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.StorageBlockListSetting;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.systems.modules.misc.InventoryTweaks;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.player.Rotations;
import meteordevelopment.meteorclient.utils.player.SlotUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1703;
import net.minecraft.class_1799;
import net.minecraft.class_2281;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2371;
import net.minecraft.class_243;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_2745;
import net.minecraft.class_3965;

public class ChestAura extends Module {
    private final SettingGroup sgGeneral;
    private final Setting<Boolean> rotate;
    private final Setting<Double> range;
    private final Setting<List<class_2591<?>>> blocks;
    private final Setting<Integer> delay;
    private final Setting<Integer> forget;
    private final Setting<CloseCondition> closeCondition;

    private final Map<class_2338, Integer> f122;

    private final CloseListener f123;

    private int f124;

    public ChestAura() {
        super(MeteorRejectsAddon.CATEGORY, "容器光环", "自动打开范围内的容器（箱子、潜影盒等）。");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.rotate = this.sgGeneral.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("自动转向")).description("打开容器时自动转向容器方向。")).defaultValue(true)).build());
        this.range = this.sgGeneral.add(((DoubleSetting.Builder) ((DoubleSetting.Builder) new DoubleSetting.Builder().name("作用范围")).description("可交互的最大距离。")).defaultValue(4.0d).min(0.0d).build());
        this.blocks = this.sgGeneral.add(((StorageBlockListSetting.Builder) ((StorageBlockListSetting.Builder) new StorageBlockListSetting.Builder().name("目标容器")).description("自动打开的容器类型。")).defaultValue(new class_2591[]{class_2591.field_11914}).build());
        this.delay = this.sgGeneral.add(((IntSetting.Builder) ((IntSetting.Builder) ((IntSetting.Builder) new IntSetting.Builder().name("打开延迟")).description("打开不同容器之间的tick间隔（1秒=20tick）。")).defaultValue(10)).sliderMax(20).build());
        this.forget = this.sgGeneral.add(((IntSetting.Builder) ((IntSetting.Builder) ((IntSetting.Builder) new IntSetting.Builder().name("遗忘时间")).description("间隔多少tick后忘记已打开的容器（重新检测），0为永久记忆。")).defaultValue(0)).min(0).sliderMax(1000).build());
        this.closeCondition = this.sgGeneral.add(((EnumSetting.Builder) ((EnumSetting.Builder) ((EnumSetting.Builder) new EnumSetting.Builder().name("关闭条件")).description("何时关闭容器界面。")).defaultValue(CloseCondition.IfEmpty)).build());
        this.f122 = new HashMap();
        this.f123 = new CloseListener();
        this.f124 = 0;
    }

    public void onActivate() {
        this.f124 = 0;
        this.f122.clear();
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (((Integer) this.forget.get()).intValue() != 0) {
            for (Map.Entry<class_2338, Integer> entry : new HashMap(this.f122).entrySet()) {
                int iIntValue = entry.getValue().intValue();
                if (iIntValue > ((Integer) this.forget.get()).intValue()) {
                    this.f122.remove(entry.getKey());
                } else {
                    this.f122.replace(entry.getKey(), Integer.valueOf(iIntValue + 1));
                }
            }
        }
        if (this.f124 <= 0 || this.mc.field_1755 == null) {
            Iterator it = Utils.blockEntities().iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                class_2586 class_2586Var = (class_2586) it.next();
                if (((List) this.blocks.get()).contains(class_2586Var.method_11017())) {
                    class_2338 class_2338VarMethod_11016 = class_2586Var.method_11016();
                    if (this.mc.field_1724.method_33571().method_1022(class_243.method_24953(class_2338VarMethod_11016)) < ((Double) this.range.get()).doubleValue() && !this.f122.containsKey(class_2338VarMethod_11016)) {
                        Runnable runnable = () -> {
                            this.mc.field_1761.method_2896(this.mc.field_1724, class_1268.field_5808, new class_3965(new class_243(class_2338VarMethod_11016.method_10263(), class_2338VarMethod_11016.method_10264(), class_2338VarMethod_11016.method_10260()), class_2350.field_11036, class_2338VarMethod_11016, false));
                        };
                        if (((Boolean) this.rotate.get()).booleanValue()) {
                            Rotations.rotate(Rotations.getYaw(class_2338VarMethod_11016), Rotations.getPitch(class_2338VarMethod_11016), runnable);
                        } else {
                            runnable.run();
                        }
                        class_2680 class_2680VarMethod_11010 = class_2586Var.method_11010();
                        if (class_2680VarMethod_11010.method_28498(class_2281.field_10770)) {
                            class_2350 class_2350VarMethod_11654 = class_2680VarMethod_11010.method_11654(class_2281.field_10768);
                            switch (C00071.$SwitchMap$net$minecraft$block$enums$ChestType[class_2680VarMethod_11010.method_11654(class_2281.field_10770).ordinal()]) {
                                case 1:
                                    this.f122.put(class_2338VarMethod_11016.method_10093(class_2350VarMethod_11654.method_10170()), 0);
                                    break;
                                case NBTType.SHORT:
                                    this.f122.put(class_2338VarMethod_11016.method_10093(class_2350VarMethod_11654.method_10160()), 0);
                                    break;
                            }
                        }
                        this.f122.put(class_2338VarMethod_11016, 0);
                        this.f124 = ((Integer) this.delay.get()).intValue();
                        MeteorClient.EVENT_BUS.subscribe(this.f123);
                    }
                }
            }
            this.f124--;
        }
    }

    static class C00071 {
        static final int[] $SwitchMap$net$minecraft$block$enums$ChestType = new int[class_2745.values().length];

        static {
            try {
                $SwitchMap$net$minecraft$block$enums$ChestType[class_2745.field_12574.ordinal()] = 1;
            } catch (NoSuchFieldError e) {
            }
            try {
                $SwitchMap$net$minecraft$block$enums$ChestType[class_2745.field_12571.ordinal()] = 2;
            } catch (NoSuchFieldError e2) {
            }
        }
    }

    public class CloseListener {
        public CloseListener() {
        }

        @EventHandler(priority = 100)
        private void onInventory(InventoryEvent event) {
            class_1703 class_1703Var = ChestAura.this.mc.field_1724.field_7512;
            if (event.packet.method_11440() == class_1703Var.field_7763) {
                switch (((CloseCondition) ChestAura.this.closeCondition.get()).ordinal()) {
                    case 0:
                        ChestAura.this.mc.field_1724.method_7346();
                        break;
                    case 1:
                        class_2371<class_1799> class_2371VarMethod_10211 = class_2371.method_10211();
                        IntStream intStreamRange = IntStream.range(0, SlotUtils.indexToId(9));
                        class_2371 class_2371Var = class_1703Var.field_7761;
                        Objects.requireNonNull(class_2371Var);
                        Stream map = intStreamRange.mapToObj(class_2371Var::get).map((v0) -> {
                            return v0.method_7677();
                        });
                        Objects.requireNonNull(class_2371VarMethod_10211);
                        map.forEach((v1) -> {
                            r1.add(v1);
                        });
                        if (class_2371VarMethod_10211.stream().allMatch((v0) -> {
                            return v0.method_7960();
                        })) {
                            ChestAura.this.mc.field_1724.method_7346();
                            break;
                        }
                        break;
                    case NBTType.SHORT:
                        ((InventoryTweaks) Modules.get().get(InventoryTweaks.class)).stealCallback(() -> {
                            RenderSystem.recordRenderCall(() -> {
                                ChestAura.this.mc.field_1724.method_7346();
                            });
                        });
                        break;
                }
            }
            MeteorClient.EVENT_BUS.unsubscribe(this);
        }
    }

    public enum CloseCondition {
        Always("总是关闭"),
        IfEmpty("为空时关闭"),
        AfterSteal("偷取后关闭"),
        Never("永不关闭");


        private final String f125;

        CloseCondition(String str) {
            this.f125 = str;
        }

        @Override
        public String toString() {
            return this.f125;
        }
    }
}
