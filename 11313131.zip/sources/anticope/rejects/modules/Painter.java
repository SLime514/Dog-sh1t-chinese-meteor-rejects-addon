package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import anticope.rejects.utils.WorldUtils;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BlockSetting;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.world.BlockUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;

public class Painter extends Module {
    private final SettingGroup sgGeneral;

    private final Setting<class_2248> f163;

    private final Setting<Integer> f164;

    private final Setting<Integer> f165;

    private final Setting<Integer> f166;

    private final Setting<Boolean> f167;

    private final Setting<Boolean> f168;

    private final Setting<Boolean> f169;

    private final Setting<Boolean> f170;

    private final Setting<Boolean> f171;

    private int f172;

    public Painter() {
        super(MeteorRejectsAddon.CATEGORY, "表面绘画", "自动在周围方块的表面放置指定方块（适合恶作剧或装饰）。");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.f163 = this.sgGeneral.add(((BlockSetting.Builder) ((BlockSetting.Builder) ((BlockSetting.Builder) new BlockSetting.Builder().name("绘画方块")).description("用于覆盖表面的方块类型。")).defaultValue(class_2246.field_10494)).build());
        this.f164 = this.sgGeneral.add(((IntSetting.Builder) ((IntSetting.Builder) ((IntSetting.Builder) new IntSetting.Builder().name("放置范围")).description("方块可以被放置的最大范围（以玩家为中心的球体半径）。")).min(0).defaultValue(0)).build());
        this.f165 = this.sgGeneral.add(((IntSetting.Builder) ((IntSetting.Builder) ((IntSetting.Builder) new IntSetting.Builder().name("放置延迟")).description("两次方块放置之间的间隔（单位：游戏刻，20刻=1秒）。")).min(0).defaultValue(0)).build());
        this.f166 = this.sgGeneral.add(((IntSetting.Builder) ((IntSetting.Builder) ((IntSetting.Builder) new IntSetting.Builder().name("每刻放置数量")).description("每游戏刻最多可以放置的方块数量。")).min(1).defaultValue(1)).build());
        this.f167 = this.sgGeneral.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("自动旋转")).description("放置方块时是否自动旋转玩家朝向目标位置。")).defaultValue(true)).build());
        this.f168 = this.sgGeneral.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("覆盖顶部")).description("是否在方块的顶部表面放置绘画方块。")).defaultValue(true)).build());
        this.f169 = this.sgGeneral.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("覆盖侧面")).description("是否在方块的侧面（东/南/西/北）放置绘画方块。")).defaultValue(true)).build());
        this.f170 = this.sgGeneral.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("覆盖底部")).description("是否在方块的底部表面放置绘画方块。")).defaultValue(true)).build());
        this.f171 = this.sgGeneral.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("单格高度模式")).description("是否只在1格高的空隙中放置方块（避免在高空或深坑中放置）。")).defaultValue(true)).build());
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (((Integer) this.f165.get()).intValue() != 0 && this.f172 < ((Integer) this.f165.get()).intValue() - 1) {
            this.f172++;
            return;
        }
        this.f172 = 0;
        FindItemResult findItemResultFindInHotbar = InvUtils.findInHotbar(class_1799Var -> {
            return this.f163.get() == class_2248.method_9503(class_1799Var.method_7909());
        });
        if (!findItemResultFindInHotbar.found()) {
            error("快捷栏中未找到指定方块！", new Object[0]);
            toggle();
            return;
        }
        int i = 0;
        for (class_2338 class_2338Var : WorldUtils.getSphere(this.mc.field_1724.method_24515(), ((Integer) this.f164.get()).intValue(), ((Integer) this.f164.get()).intValue())) {
            if (shouldPlace(class_2338Var, (class_2248) this.f163.get())) {
                BlockUtils.place(class_2338Var, findItemResultFindInHotbar, ((Boolean) this.f167.get()).booleanValue(), -100, false);
                i++;
                if (((Integer) this.f165.get()).intValue() != 0 && i >= ((Integer) this.f166.get()).intValue()) {
                    return;
                }
            }
        }
    }

    private boolean shouldPlace(class_2338 class_2338Var, class_2248 class_2248Var) {
        if (!this.mc.field_1687.method_8320(class_2338Var).method_45474()) {
            return false;
        }
        if (!((Boolean) this.f171.get()).booleanValue() && !this.mc.field_1687.method_8320(class_2338Var.method_10084()).method_45474() && !this.mc.field_1687.method_8320(class_2338Var.method_10074()).method_45474()) {
            return false;
        }
        boolean z = true;
        boolean z2 = true;
        boolean z3 = true;
        boolean z4 = true;
        boolean z5 = true;
        boolean z6 = true;
        class_2680 class_2680VarMethod_8320 = this.mc.field_1687.method_8320(class_2338Var.method_10095());
        class_2680 class_2680VarMethod_83202 = this.mc.field_1687.method_8320(class_2338Var.method_10072());
        class_2680 class_2680VarMethod_83203 = this.mc.field_1687.method_8320(class_2338Var.method_10078());
        class_2680 class_2680VarMethod_83204 = this.mc.field_1687.method_8320(class_2338Var.method_10067());
        class_2680 class_2680VarMethod_83205 = this.mc.field_1687.method_8320(class_2338Var.method_10084());
        class_2680 class_2680VarMethod_83206 = this.mc.field_1687.method_8320(class_2338Var.method_10074());
        if (((Boolean) this.f168.get()).booleanValue() && (class_2680VarMethod_83205.method_45474() || class_2680VarMethod_83205.method_26204() == class_2248Var)) {
            z5 = false;
        }
        if (((Boolean) this.f169.get()).booleanValue()) {
            if (class_2680VarMethod_8320.method_45474() || class_2680VarMethod_8320.method_26204() == class_2248Var) {
                z = false;
            }
            if (class_2680VarMethod_83202.method_45474() || class_2680VarMethod_83202.method_26204() == class_2248Var) {
                z2 = false;
            }
            if (class_2680VarMethod_83203.method_45474() || class_2680VarMethod_83203.method_26204() == class_2248Var) {
                z3 = false;
            }
            if (class_2680VarMethod_83204.method_45474() || class_2680VarMethod_83204.method_26204() == class_2248Var) {
                z4 = false;
            }
        }
        if (((Boolean) this.f170.get()).booleanValue() && (class_2680VarMethod_83206.method_45474() || class_2680VarMethod_83206.method_26204() == class_2248Var)) {
            z6 = false;
        }
        return z || z2 || z3 || z4 || z5 || z6;
    }
}
