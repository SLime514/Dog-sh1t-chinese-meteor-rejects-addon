package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import anticope.rejects.utils.RejectsUtils;
import com.seedfinding.mccore.nbt.NBTType;
import java.util.Set;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.EntityTypeListSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.friends.Friends;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.entity.EntityUtils;
import meteordevelopment.meteorclient.utils.entity.SortPriority;
import meteordevelopment.meteorclient.utils.entity.Target;
import meteordevelopment.meteorclient.utils.entity.TargetUtils;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1657;
import net.minecraft.class_3532;
import org.joml.Vector3d;

public class AimAssist extends Module {
    private final SettingGroup sgGeneral;
    private final SettingGroup sgSpeed;
    private final Setting<Set<class_1299<?>>> entities;
    private final Setting<Double> range;
    private final Setting<Double> fov;
    private final Setting<Boolean> ignoreWalls;
    private final Setting<SortPriority> priority;
    private final Setting<Target> bodyTarget;
    private final Setting<Boolean> instant;
    private final Setting<Double> speed;
    private final Vector3d vec3d1;
    private class_1297 target;

    public AimAssist() {
        super(MeteorRejectsAddon.CATEGORY, "自动瞄准", "自动瞄准实体。");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.sgSpeed = this.settings.createGroup("瞄准速度");
        this.entities = this.sgGeneral.add(((EntityTypeListSetting.Builder) ((EntityTypeListSetting.Builder) new EntityTypeListSetting.Builder().name("实体类型")).description("需要瞄准的实体类型。")).defaultValue(new class_1299[]{class_1299.field_6097}).build());
        this.range = this.sgGeneral.add(((DoubleSetting.Builder) ((DoubleSetting.Builder) new DoubleSetting.Builder().name("范围")).description("可瞄准实体的最大距离。")).defaultValue(5.0d).min(0.0d).build());
        this.fov = this.sgGeneral.add(((DoubleSetting.Builder) ((DoubleSetting.Builder) new DoubleSetting.Builder().name("视野范围")).description("只瞄准视野范围内的实体。")).defaultValue(360.0d).min(0.0d).max(360.0d).build());
        this.ignoreWalls = this.sgGeneral.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("穿透墙壁")).description("是否忽略墙壁进行瞄准。")).defaultValue(false)).build());
        this.priority = this.sgGeneral.add(((EnumSetting.Builder) ((EnumSetting.Builder) ((EnumSetting.Builder) new EnumSetting.Builder().name("优先级")).description("如何筛选范围内的目标。")).defaultValue(SortPriority.LowestHealth)).build());
        this.bodyTarget = this.sgGeneral.add(((EnumSetting.Builder) ((EnumSetting.Builder) ((EnumSetting.Builder) new EnumSetting.Builder().name("瞄准部位")).description("实体身上需要瞄准的部位。")).defaultValue(Target.Body)).build());
        this.instant = this.sgSpeed.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("瞬间瞄准")).description("立即看向实体。")).defaultValue(false)).build());
        this.speed = this.sgSpeed.add(((DoubleSetting.Builder) ((DoubleSetting.Builder) ((DoubleSetting.Builder) new DoubleSetting.Builder().name("速度")).description("瞄准实体的速度。")).defaultValue(5.0d).min(0.0d).visible(() -> {
            return !((Boolean) this.instant.get()).booleanValue();
        })).build());
        this.vec3d1 = new Vector3d();
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        this.target = TargetUtils.get(entity -> {
            if (!entity.method_5805() || !PlayerUtils.isWithin(entity, ((Double) this.range.get()).doubleValue())) {
                return false;
            }
            if ((!((Boolean) this.ignoreWalls.get()).booleanValue() && !PlayerUtils.canSeeEntity(entity)) || entity == this.mc.field_1724 || !((Set) this.entities.get()).contains(entity.method_5864())) {
                return false;
            }
            if (!(entity instanceof class_1657) || Friends.get().shouldAttack((class_1657) entity)) {
                return RejectsUtils.inFov(entity, ((Double) this.fov.get()).doubleValue());
            }
            return false;
        }, (SortPriority) this.priority.get());
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        if (this.target != null) {
            aim(this.target, event.tickDelta, ((Boolean) this.instant.get()).booleanValue());
        }
    }

    private void aim(class_1297 target, double delta, boolean instant) {
        Utils.set(this.vec3d1, target, delta);
        switch (C00031.$SwitchMap$meteordevelopment$meteorclient$utils$entity$Target[((Target) this.bodyTarget.get()).ordinal()]) {
            case 1:
                this.vec3d1.add(0.0d, target.method_18381(target.method_18376()), 0.0d);
                break;
            case NBTType.SHORT:
                this.vec3d1.add(0.0d, target.method_18381(target.method_18376()) / 2.0f, 0.0d);
                break;
        }
        double deltaX = this.vec3d1.x - this.mc.field_1724.method_23317();
        double deltaZ = this.vec3d1.z - this.mc.field_1724.method_23321();
        double deltaY = this.vec3d1.y - (this.mc.field_1724.method_23318() + this.mc.field_1724.method_18381(this.mc.field_1724.method_18376()));
        double angle = Math.toDegrees(Math.atan2(deltaZ, deltaX)) - 90.0d;
        if (instant) {
            this.mc.field_1724.method_36456((float) angle);
        } else {
            double deltaAngle = class_3532.method_15338(angle - this.mc.field_1724.method_36454());
            double toRotate = ((Double) this.speed.get()).doubleValue() * (deltaAngle >= 0.0d ? 1 : -1) * delta;
            if ((toRotate >= 0.0d && toRotate > deltaAngle) || (toRotate < 0.0d && toRotate < deltaAngle)) {
                toRotate = deltaAngle;
            }
            this.mc.field_1724.method_36456(this.mc.field_1724.method_36454() + ((float) toRotate));
        }
        double idk = Math.sqrt((deltaX * deltaX) + (deltaZ * deltaZ));
        double angle2 = -Math.toDegrees(Math.atan2(deltaY, idk));
        if (instant) {
            this.mc.field_1724.method_36457((float) angle2);
            return;
        }
        double deltaAngle2 = class_3532.method_15338(angle2 - this.mc.field_1724.method_36455());
        double toRotate2 = ((Double) this.speed.get()).doubleValue() * (deltaAngle2 >= 0.0d ? 1 : -1) * delta;
        if ((toRotate2 >= 0.0d && toRotate2 > deltaAngle2) || (toRotate2 < 0.0d && toRotate2 < deltaAngle2)) {
            toRotate2 = deltaAngle2;
        }
        this.mc.field_1724.method_36457(this.mc.field_1724.method_36455() + ((float) toRotate2));
    }

    static class C00031 {
        static final int[] $SwitchMap$meteordevelopment$meteorclient$utils$entity$Target = new int[Target.values().length];

        static {
            try {
                $SwitchMap$meteordevelopment$meteorclient$utils$entity$Target[Target.Head.ordinal()] = 1;
            } catch (NoSuchFieldError e) {
            }
            try {
                $SwitchMap$meteordevelopment$meteorclient$utils$entity$Target[Target.Body.ordinal()] = 2;
            } catch (NoSuchFieldError e2) {
            }
        }
    }

    public String getInfoString() {
        return EntityUtils.getName(this.target);
    }
}
