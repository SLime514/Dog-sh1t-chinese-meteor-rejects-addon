package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import com.mojang.blaze3d.systems.RenderSystem;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.ColorSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.config.Config;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.systems.modules.render.Freecam;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import meteordevelopment.meteorclient.utils.player.Rotations;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_10055;
import net.minecraft.class_10142;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_5498;
import net.minecraft.class_591;
import net.minecraft.class_630;
import net.minecraft.class_7833;
import net.minecraft.class_922;
import org.joml.Matrix4f;
import org.joml.Quaternionf;

public class SkeletonESP extends Module {
    private final SettingGroup sgGeneral;

    private final Color f174;

    private final Setting<SettingColor> f175;

    public final Setting<Boolean> f176;

    private final Freecam f177;

    public SkeletonESP() {
        super(MeteorRejectsAddon.CATEGORY, "骨骼透视", "以线框骨骼形式渲染玩家，视觉效果极具辨识度。");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.f174 = new Color();
        this.f175 = this.sgGeneral.add(((ColorSetting.Builder) ((ColorSetting.Builder) new ColorSetting.Builder().name("玩家骨骼颜色")).description("渲染其他玩家骨骼时使用的颜色。")).defaultValue(new SettingColor(255, 255, 255)).build());
        this.f176 = this.sgGeneral.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("距离变色")).description("根据与玩家的距离自动改变骨骼颜色（近绿远红）。")).defaultValue(false)).build());
        this.f177 = Modules.get().get(Freecam.class);
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        class_4587 class_4587Var = event.matrices;
        float f = event.tickDelta;
        RenderSystem.setShader(class_10142.field_53876);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableDepthTest();
        RenderSystem.depthMask(class_310.method_1517());
        RenderSystem.enableCull();
        this.mc.field_1687.method_18112().forEach(class_1297Var -> {
            if (class_1297Var instanceof class_1657) {
                if (this.mc.field_1690.method_31044() == class_5498.field_26664 && !this.f177.isActive() && this.mc.field_1724 == class_1297Var) {
                    return;
                }
                int iIntValue = ((Integer) Config.get().rotationHoldTicks.get()).intValue();
                class_1657 class_1657Var = (class_1657) class_1297Var;
                Color playerColor = PlayerUtils.getPlayerColor(class_1657Var, (Color) this.f175.get());
                if (((Boolean) this.f176.get()).booleanValue()) {
                    playerColor = m165(class_1657Var);
                }
                class_243 class_243VarM164 = m164(class_1657Var, f);
                class_591 class_591VarMethod_4038 = ((class_922) this.mc.method_1561().method_3953(class_1657Var)).method_4038();
                float fMethod_17821 = class_3532.method_17821(f, class_1657Var.field_6220, class_1657Var.field_6283);
                if (this.mc.field_1724 == class_1297Var && Rotations.rotationTimer < iIntValue) {
                    fMethod_17821 = Rotations.serverYaw;
                }
                float fMethod_178212 = class_3532.method_17821(f, class_1657Var.field_6259, class_1657Var.field_6241);
                if (this.mc.field_1724 == class_1297Var && Rotations.rotationTimer < iIntValue) {
                    fMethod_178212 = Rotations.serverYaw;
                }
                float fMethod_48569 = class_1657Var.field_42108.method_48569() - (class_1657Var.field_42108.method_48566() * (1.0f - f));
                float fMethod_48570 = class_1657Var.field_42108.method_48570(f);
                float f2 = class_1657Var.field_6012 + f;
                float f3 = fMethod_178212 - fMethod_17821;
                float fMethod_5695 = class_1657Var.method_5695(f);
                if (this.mc.field_1724 == class_1297Var && Rotations.rotationTimer < iIntValue) {
                    fMethod_5695 = Rotations.serverPitch;
                }
                class_10055 class_10055Var = new class_10055();
                class_10055Var.field_53450 = fMethod_48569;
                class_10055Var.field_53451 = fMethod_48570;
                class_10055Var.field_53328 = f2;
                class_10055Var.field_53447 = f3;
                class_10055Var.field_53448 = fMethod_5695;
                class_591VarMethod_4038.method_62110(class_10055Var);
                boolean zMethod_20232 = class_1657Var.method_20232();
                boolean zMethod_5715 = class_1657Var.method_5715();
                boolean zMethod_6128 = class_1657Var.method_6128();
                class_630 class_630Var = class_591VarMethod_4038.field_3398;
                class_630 class_630Var2 = class_591VarMethod_4038.field_27433;
                class_630 class_630Var3 = class_591VarMethod_4038.field_3401;
                class_630 class_630Var4 = class_591VarMethod_4038.field_3397;
                class_630 class_630Var5 = class_591VarMethod_4038.field_3392;
                class_4587Var.method_22904(class_243VarM164.field_1352, class_243VarM164.field_1351, class_243VarM164.field_1350);
                if (zMethod_20232) {
                    class_4587Var.method_46416(0.0f, 0.35f, 0.0f);
                }
                class_4587Var.method_22907(new Quaternionf().setAngleAxis(((fMethod_17821 + 180.0f) * 3.141592653589793d) / 180.0d, 0.0d, -1.0d, 0.0d));
                if (zMethod_20232 || zMethod_6128) {
                    class_4587Var.method_22907(new Quaternionf().setAngleAxis(((90.0f + fMethod_5695) * 3.141592653589793d) / 180.0d, -1.0d, 0.0d, 0.0d));
                }
                if (zMethod_20232) {
                    class_4587Var.method_46416(0.0f, -0.95f, 0.0f);
                }
                class_289 tessellator = class_289.method_1348();
                class_287 class_287VarMethod_60827 = tessellator.method_60827(class_293.class_5596.field_29344, class_290.field_1576);
                Matrix4f matrix4fMethod_23761 = class_4587Var.method_23760().method_23761();
                class_287VarMethod_60827.method_22918(matrix4fMethod_23761, 0.0f, zMethod_5715 ? 0.6f : 0.7f, zMethod_5715 ? 0.23f : 0.0f).method_1336(playerColor.r, playerColor.g, playerColor.b, playerColor.a);
                class_287VarMethod_60827.method_22918(matrix4fMethod_23761, 0.0f, zMethod_5715 ? 1.05f : 1.4f, 0.0f).method_1336(playerColor.r, playerColor.g, playerColor.b, playerColor.a);
                class_287VarMethod_60827.method_22918(matrix4fMethod_23761, -0.37f, zMethod_5715 ? 1.05f : 1.35f, 0.0f).method_1336(playerColor.r, playerColor.g, playerColor.b, playerColor.a);
                class_287VarMethod_60827.method_22918(matrix4fMethod_23761, 0.37f, zMethod_5715 ? 1.05f : 1.35f, 0.0f).method_1336(playerColor.r, playerColor.g, playerColor.b, playerColor.a);
                class_287VarMethod_60827.method_22918(matrix4fMethod_23761, -0.15f, zMethod_5715 ? 0.6f : 0.7f, zMethod_5715 ? 0.23f : 0.0f).method_1336(playerColor.r, playerColor.g, playerColor.b, playerColor.a);
                class_287VarMethod_60827.method_22918(matrix4fMethod_23761, 0.15f, zMethod_5715 ? 0.6f : 0.7f, zMethod_5715 ? 0.23f : 0.0f).method_1336(playerColor.r, playerColor.g, playerColor.b, playerColor.a);
                class_4587Var.method_22903();
                class_4587Var.method_46416(0.0f, zMethod_5715 ? 1.05f : 1.4f, 0.0f);
                m163(class_4587Var, class_630Var);
                Matrix4f matrix4fMethod_237612 = class_4587Var.method_23760().method_23761();
                class_287VarMethod_60827.method_22918(matrix4fMethod_237612, 0.0f, 0.0f, 0.0f).method_1336(playerColor.r, playerColor.g, playerColor.b, playerColor.a);
                class_287VarMethod_60827.method_22918(matrix4fMethod_237612, 0.0f, 0.15f, 0.0f).method_1336(playerColor.r, playerColor.g, playerColor.b, playerColor.a);
                class_4587Var.method_22909();
                class_4587Var.method_22903();
                class_4587Var.method_46416(0.15f, zMethod_5715 ? 0.6f : 0.7f, zMethod_5715 ? 0.23f : 0.0f);
                m163(class_4587Var, class_630Var5);
                Matrix4f matrix4fMethod_237613 = class_4587Var.method_23760().method_23761();
                class_287VarMethod_60827.method_22918(matrix4fMethod_237613, 0.0f, 0.0f, 0.0f).method_1336(playerColor.r, playerColor.g, playerColor.b, playerColor.a);
                class_287VarMethod_60827.method_22918(matrix4fMethod_237613, 0.0f, -0.6f, 0.0f).method_1336(playerColor.r, playerColor.g, playerColor.b, playerColor.a);
                class_4587Var.method_22909();
                class_4587Var.method_22903();
                class_4587Var.method_46416(-0.15f, zMethod_5715 ? 0.6f : 0.7f, zMethod_5715 ? 0.23f : 0.0f);
                m163(class_4587Var, class_630Var4);
                Matrix4f matrix4fMethod_237614 = class_4587Var.method_23760().method_23761();
                class_287VarMethod_60827.method_22918(matrix4fMethod_237614, 0.0f, 0.0f, 0.0f).method_1336(playerColor.r, playerColor.g, playerColor.b, playerColor.a);
                class_287VarMethod_60827.method_22918(matrix4fMethod_237614, 0.0f, -0.6f, 0.0f).method_1336(playerColor.r, playerColor.g, playerColor.b, playerColor.a);
                class_4587Var.method_22909();
                class_4587Var.method_22903();
                class_4587Var.method_46416(0.37f, zMethod_5715 ? 1.05f : 1.35f, 0.0f);
                m163(class_4587Var, class_630Var3);
                Matrix4f matrix4fMethod_237615 = class_4587Var.method_23760().method_23761();
                class_287VarMethod_60827.method_22918(matrix4fMethod_237615, 0.0f, 0.0f, 0.0f).method_1336(playerColor.r, playerColor.g, playerColor.b, playerColor.a);
                class_287VarMethod_60827.method_22918(matrix4fMethod_237615, 0.0f, -0.55f, 0.0f).method_1336(playerColor.r, playerColor.g, playerColor.b, playerColor.a);
                class_4587Var.method_22909();
                class_4587Var.method_22903();
                class_4587Var.method_46416(-0.37f, zMethod_5715 ? 1.05f : 1.35f, 0.0f);
                m163(class_4587Var, class_630Var2);
                Matrix4f matrix4fMethod_237616 = class_4587Var.method_23760().method_23761();
                class_287VarMethod_60827.method_22918(matrix4fMethod_237616, 0.0f, 0.0f, 0.0f).method_1336(playerColor.r, playerColor.g, playerColor.b, playerColor.a);
                class_287VarMethod_60827.method_22918(matrix4fMethod_237616, 0.0f, -0.55f, 0.0f).method_1336(playerColor.r, playerColor.g, playerColor.b, playerColor.a);
                class_4587Var.method_22909();
                tessellator.method_60828();
                class_286.method_43433(class_287VarMethod_60827.method_60800());
                if (zMethod_20232) {
                    class_4587Var.method_46416(0.0f, 0.95f, 0.0f);
                }
                if (zMethod_20232 || zMethod_6128) {
                    class_4587Var.method_22907(new Quaternionf().setAngleAxis(((90.0f + fMethod_5695) * 3.141592653589793d) / 180.0d, 1.0d, 0.0d, 0.0d));
                }
                if (zMethod_20232) {
                    class_4587Var.method_46416(0.0f, -0.35f, 0.0f);
                }
                class_4587Var.method_22907(new Quaternionf().setAngleAxis(((fMethod_17821 + 180.0f) * 3.141592653589793d) / 180.0d, 0.0d, 1.0d, 0.0d));
                class_4587Var.method_22904(-class_243VarM164.field_1352, -class_243VarM164.field_1351, -class_243VarM164.field_1350);
            }
        });
        RenderSystem.disableCull();
        RenderSystem.disableBlend();
        RenderSystem.enableDepthTest();
        RenderSystem.depthMask(true);
        RenderSystem.setShader(class_10142.field_53876);
    }

    private void m163(class_4587 class_4587Var, class_630 class_630Var) {
        if (class_630Var.field_3674 != 0.0f) {
            class_4587Var.method_22907(class_7833.field_40718.rotation(class_630Var.field_3674));
        }
        if (class_630Var.field_3675 != 0.0f) {
            class_4587Var.method_22907(class_7833.field_40715.rotation(class_630Var.field_3675));
        }
        if (class_630Var.field_3654 != 0.0f) {
            class_4587Var.method_22907(class_7833.field_40713.rotation(class_630Var.field_3654));
        }
    }

    private class_243 m164(class_1297 class_1297Var, double d) {
        double x = (class_1297Var.field_6014 + ((class_1297Var.method_23317() - class_1297Var.field_6014) * d)) - this.mc.method_1561().field_4686.method_19326().field_1352;
        double y = (class_1297Var.field_6036 + ((class_1297Var.method_23318() - class_1297Var.field_6036) * d)) - this.mc.method_1561().field_4686.method_19326().field_1351;
        double z = (class_1297Var.field_5969 + ((class_1297Var.method_23321() - class_1297Var.field_5969) * d)) - this.mc.method_1561().field_4686.method_19326().field_1350;
        return new class_243(x, y, z);
    }

    private Color m165(class_1297 class_1297Var) {
        int i;
        int i2;
        double dMethod_1022 = this.mc.field_1773.method_19418().method_19326().method_1022(class_1297Var.method_19538()) / 60.0d;
        if (dMethod_1022 < 0.0d || dMethod_1022 > 1.0d) {
            this.f174.set(0, 255, 0, 255);
            return this.f174;
        }
        if (dMethod_1022 < 0.5d) {
            i2 = 255;
            i = (int) ((255.0d * dMethod_1022) / 0.5d);
        } else {
            i = 255;
            i2 = 255 - ((int) ((255.0d * (dMethod_1022 - 0.5d)) / 0.5d));
        }
        this.f174.set(i2, i, 0, 255);
        return this.f174;
    }
}
