package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.mixininterface.IPlayerInteractEntityC2SPacket;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.systems.modules.combat.KillAura;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_2824;
import net.minecraft.class_2848;

public class KnockbackPlus extends Module {
    private final SettingGroup sgGeneral;
    private final Setting<Boolean> onlyKillAura;

    public KnockbackPlus() {
        super(MeteorRejectsAddon.CATEGORY, "增强击退", "提升对目标的攻击击退效果，使敌人更难接近。");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.onlyKillAura = this.sgGeneral.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("仅杀戮光环")).description("仅在使用杀戮光环攻击时增强击退效果。")).defaultValue(false)).build());
    }

    @EventHandler
    private void onSendPacket(PacketEvent.Send event) {
        IPlayerInteractEntityC2SPacket iPlayerInteractEntityC2SPacket = event.packet;
        if (iPlayerInteractEntityC2SPacket instanceof IPlayerInteractEntityC2SPacket) {
            IPlayerInteractEntityC2SPacket iPlayerInteractEntityC2SPacket2 = iPlayerInteractEntityC2SPacket;
            if (iPlayerInteractEntityC2SPacket2.meteor$getType() == class_2824.class_5907.field_29172) {
                class_1297 class_1297VarMeteor$getEntity = iPlayerInteractEntityC2SPacket2.meteor$getEntity();
                if (class_1297VarMeteor$getEntity instanceof class_1309) {
                    if (((Boolean) this.onlyKillAura.get()).booleanValue() && class_1297VarMeteor$getEntity != Modules.get().get(KillAura.class).getTarget()) {
                        return;
                    }
                    this.mc.field_1724.field_3944.method_52787(new class_2848(this.mc.field_1724, class_2848.class_2849.field_12981));
                }
            }
        }
    }
}
