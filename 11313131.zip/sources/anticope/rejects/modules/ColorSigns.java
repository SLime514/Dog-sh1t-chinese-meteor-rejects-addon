package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import java.util.List;
import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_2678;
import net.minecraft.class_2820;
import net.minecraft.class_2877;
import net.minecraft.server.MinecraftServer;

public class ColorSigns extends Module {
    private final SettingGroup sgGeneral;
    private final Setting<Boolean> signs;
    private final Setting<Boolean> books;
    static final boolean $assertionsDisabled;

    static {
        $assertionsDisabled = !ColorSigns.class.desiredAssertionStatus();
    }

    public ColorSigns() {
        super(MeteorRejectsAddon.CATEGORY, "彩色文字", "允许在非Paper服务器上使用彩色文字（使用\"&\"作为颜色代码前缀）");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.signs = this.sgGeneral.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("告示牌染色")).description("允许在告示牌上使用颜色代码。")).defaultValue(true)).build());
        this.books = this.sgGeneral.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("书籍染色")).description("允许在书籍上使用颜色代码。")).defaultValue(false)).build());
    }

    @EventHandler
    private void onPacketSend(PacketEvent.Send event) {
        if (event.packet instanceof class_2678) {
            m117();
            return;
        }
        if (((Boolean) this.signs.get()).booleanValue()) {
            class_2877 class_2877Var = event.packet;
            if (class_2877Var instanceof class_2877) {
                class_2877 class_2877Var2 = class_2877Var;
                for (int i = 0; i < class_2877Var2.method_12508().length; i++) {
                    class_2877Var2.method_12508()[i] = class_2877Var2.method_12508()[i].replaceAll("(?i)(?:&|(?<!§)§)([0-9A-Z])", "§§$1$1");
                }
            }
        }
        if (((Boolean) this.books.get()).booleanValue()) {
            class_2820 class_2820Var = event.packet;
            if (class_2820Var instanceof class_2820) {
                class_2820 class_2820Var2 = class_2820Var;
                List<String> list = class_2820Var2.comp_2286().stream().map(str -> {
                    return str.replaceAll("(?i)&([0-9A-Z])", "§$1");
                }).toList();
                if (!class_2820Var2.comp_2286().equals(list)) {
                    if (!$assertionsDisabled && this.mc.method_1562() == null) {
                        throw new AssertionError();
                    }
                    this.mc.method_1562().method_52787(new class_2820(class_2820Var2.comp_2285(), list, class_2820Var2.comp_2287()));
                    event.cancel();
                }
            }
        }
    }

    public void onActivate() {
        super.onActivate();
        m117();
    }

    private void m117() {
        String serverModName;
        if (!$assertionsDisabled && this.mc.field_1724 == null) {
            throw new AssertionError();
        }
        MinecraftServer minecraftServerMethod_5682 = this.mc.field_1724.method_5682();
        if (minecraftServerMethod_5682 != null && (serverModName = minecraftServerMethod_5682.getServerModName()) != null && serverModName.contains("Paper")) {
            warning("你正在使用Paper服务器，彩色文字功能可能无法工作", new Object[0]);
        }
    }
}
