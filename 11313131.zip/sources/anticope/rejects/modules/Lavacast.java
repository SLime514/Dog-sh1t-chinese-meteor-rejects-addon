package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import com.seedfinding.mccore.nbt.NBTType;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.player.Rotations;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2382;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_3959;
import net.minecraft.class_3965;

public class Lavacast extends Module {
    private final SettingGroup sgGeneral;
    private final SettingGroup sgShape;
    private final Setting<Integer> tickInterval;
    private final Setting<Integer> distMin;
    private final Setting<Integer> lavaDownMult;
    private final Setting<Integer> lavaUpMult;
    private final Setting<Integer> waterDownMult;
    private final Setting<Integer> waterUpMult;

    private int f149;

    private class_2338 f150;

    private int f151tick;

    private Stage f152;

    private enum Stage {
        None,
        LavaDown,
        LavaUp,
        WaterDown,
        WaterUp
    }

    public Lavacast() {
        super(MeteorRejectsAddon.CATEGORY, "岩浆浇筑", "自动执行岩浆浇筑操作，生成特定形状的岩浆结构（需配合桶类物品使用）。");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.sgShape = this.settings.createGroup("形状设置", false);
        this.tickInterval = this.sgGeneral.add(((IntSetting.Builder) ((IntSetting.Builder) ((IntSetting.Builder) new IntSetting.Builder().name("执行间隔")).description("每步浇筑操作之间的tick间隔（1秒=20tick，间隔越小速度越快）。")).defaultValue(2)).min(0).sliderMax(20).build());
        this.distMin = this.sgShape.add(((IntSetting.Builder) ((IntSetting.Builder) ((IntSetting.Builder) new IntSetting.Builder().name("最小浇筑距离")).description("岩浆浇筑的顶部平面截止高度，距离低于此值时自动停止模块。")).defaultValue(5)).min(0).sliderMax(10).build());
        this.lavaDownMult = this.sgShape.add(((IntSetting.Builder) ((IntSetting.Builder) ((IntSetting.Builder) new IntSetting.Builder().name("岩浆向下系数")).description("控制岩浆向下浇筑的形状范围或速度（数值越大，向下覆盖越广/越慢）。")).defaultValue(40)).min(1).sliderMax(100).build());
        this.lavaUpMult = this.sgShape.add(((IntSetting.Builder) ((IntSetting.Builder) ((IntSetting.Builder) new IntSetting.Builder().name("岩浆向上系数")).description("控制岩浆向上回收的形状范围或速度（数值越大，向上回收越广/越慢）。")).defaultValue(8)).min(1).sliderMax(100).build());
        this.waterDownMult = this.sgShape.add(((IntSetting.Builder) ((IntSetting.Builder) ((IntSetting.Builder) new IntSetting.Builder().name("水向下系数")).description("控制水向下浇筑的形状范围或速度（数值越大，向下覆盖越广/越慢）。")).defaultValue(4)).min(1).sliderMax(100).build());
        this.waterUpMult = this.sgShape.add(((IntSetting.Builder) ((IntSetting.Builder) ((IntSetting.Builder) new IntSetting.Builder().name("水向上系数")).description("控制水向上回收的形状范围或速度（数值越大，向上回收越广/越慢）。")).defaultValue(1)).min(1).sliderMax(100).build());
        this.f152 = Stage.None;
    }

    public void onActivate() {
        if (this.mc.field_1724 == null || this.mc.field_1687 == null) {
            toggle();
            return;
        }
        this.f151tick = 0;
        this.f152 = Stage.None;
        this.f150 = m138();
        if (this.f150 == null) {
            this.f150 = this.mc.field_1724.method_24515().method_10087(2);
        } else {
            this.f150 = this.f150.method_10084();
        }
        this.f149 = -1;
        m139(new class_2382(1, 0, 0));
        m139(new class_2382(-1, 0, 0));
        m139(new class_2382(0, 0, 1));
        m139(new class_2382(0, 0, -1));
        if (this.f149 < 1) {
            error("无法定位底部方块，无法执行浇筑。", new Object[0]);
            toggle();
        } else {
            info("检测到浇筑距离：(高亮)%d(默认)格。", new Object[]{Integer.valueOf(this.f149)});
        }
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (this.mc.field_1724 == null || this.mc.field_1687 == null) {
            return;
        }
        this.f151tick++;
        if (m132()) {
        }
        if (this.f149 < ((Integer) this.distMin.get()).intValue()) {
            toggle();
            return;
        }
        this.f151tick = 0;
        if (m133()) {
            return;
        }
        switch (this.f152.ordinal()) {
            case 0:
                Rotations.rotate(Rotations.getYaw(this.f150), Rotations.getPitch(this.f150), 100, this::m134);
                this.f152 = Stage.LavaDown;
                break;
            case 1:
                Rotations.rotate(Rotations.getYaw(this.f150), Rotations.getPitch(this.f150), 100, this::m136);
                this.f152 = Stage.LavaUp;
                break;
            case NBTType.SHORT:
                Rotations.rotate(Rotations.getYaw(this.f150), Rotations.getPitch(this.f150), 100, this::m135);
                this.f152 = Stage.WaterDown;
                break;
            case 3:
                Rotations.rotate(Rotations.getYaw(this.f150), Rotations.getPitch(this.f150), 100, this::m136);
                this.f152 = Stage.WaterUp;
                break;
            case 4:
                this.f149--;
                Rotations.rotate(Rotations.getYaw(this.f150), Rotations.getPitch(this.f150), 100, this::m134);
                this.f152 = Stage.LavaDown;
                break;
        }
    }

    private boolean m132() {
        if (this.f152 == Stage.LavaDown && this.f151tick < this.f149 * ((Integer) this.lavaDownMult.get()).intValue()) {
            return true;
        }
        if (this.f152 == Stage.LavaUp && this.f151tick < this.f149 * ((Integer) this.lavaUpMult.get()).intValue()) {
            return true;
        }
        if (this.f152 != Stage.WaterDown || this.f151tick >= this.f149 * ((Integer) this.waterDownMult.get()).intValue()) {
            return (this.f152 == Stage.WaterUp && this.f151tick < this.f149 * ((Integer) this.waterUpMult.get()).intValue()) || this.f151tick < ((Integer) this.tickInterval.get()).intValue();
        }
        return true;
    }

    private boolean m133() {
        if (this.f152 == Stage.None && this.mc.field_1687.method_8320(this.f150).method_26204() != class_2246.field_10124) {
            Rotations.rotate(Rotations.getYaw(this.f150), Rotations.getPitch(this.f150), 100, this::m137);
            return true;
        }
        return false;
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        if (this.f150 == null) {
            return;
        }
        double x1 = this.f150.method_10263();
        double y1 = this.f150.method_10264();
        double z1 = this.f150.method_10260();
        double x2 = x1 + 1.0d;
        double y2 = y1 + 1.0d;
        double z2 = z1 + 1.0d;
        SettingColor settingColor = new SettingColor(128, 128, 128);
        if (this.f152 == Stage.LavaDown) {
            settingColor = new SettingColor(255, 180, 10);
        }
        if (this.f152 == Stage.LavaUp) {
            settingColor = new SettingColor(255, 180, 128);
        }
        if (this.f152 == Stage.WaterDown) {
            settingColor = new SettingColor(10, 10, 255);
        }
        if (this.f152 == Stage.WaterUp) {
            settingColor = new SettingColor(128, 128, 255);
        }
        settingColor.a = 75;
        event.renderer.box(x1, y1, z1, x2, y2, z2, settingColor, settingColor, ShapeMode.Both, 0);
    }

    private void m134() {
        FindItemResult findItemResultFindInHotbar = InvUtils.findInHotbar(new class_1792[]{class_1802.field_8187});
        if (!findItemResultFindInHotbar.found()) {
            error("未在快捷栏中找到岩浆桶，无法继续浇筑。", new Object[0]);
            toggle();
        } else {
            int i = this.mc.field_1724.method_31548().field_7545;
            this.mc.field_1724.method_31548().field_7545 = findItemResultFindInHotbar.slot();
            this.mc.field_1761.method_2919(this.mc.field_1724, class_1268.field_5808);
            this.mc.field_1724.method_31548().field_7545 = i;
        }
    }

    private void m135() {
        FindItemResult findItemResultFindInHotbar = InvUtils.findInHotbar(new class_1792[]{class_1802.field_8705});
        if (!findItemResultFindInHotbar.found()) {
            error("未在快捷栏中找到水桶，无法继续浇筑。", new Object[0]);
            toggle();
        } else {
            int i = this.mc.field_1724.method_31548().field_7545;
            this.mc.field_1724.method_31548().field_7545 = findItemResultFindInHotbar.slot();
            this.mc.field_1761.method_2919(this.mc.field_1724, class_1268.field_5808);
            this.mc.field_1724.method_31548().field_7545 = i;
        }
    }

    private void m136() {
        FindItemResult findItemResultFindInHotbar = InvUtils.findInHotbar(new class_1792[]{class_1802.field_8550});
        if (!findItemResultFindInHotbar.found()) {
            error("未在快捷栏中找到空桶，无法回收流体。", new Object[0]);
            toggle();
        } else {
            int i = this.mc.field_1724.method_31548().field_7545;
            this.mc.field_1724.method_31548().field_7545 = findItemResultFindInHotbar.slot();
            this.mc.field_1761.method_2919(this.mc.field_1724, class_1268.field_5808);
            this.mc.field_1724.method_31548().field_7545 = i;
        }
    }

    private void m137() {
        this.mc.field_1761.method_2902(this.f150, class_2350.field_11036);
    }

    private class_2338 m138() {
        class_3965 class_3965Var = this.mc.field_1765;
        if (class_3965Var == null || class_3965Var.method_17783() != class_239.class_240.field_1332) {
            return null;
        }
        return class_3965Var.method_17777();
    }

    private void m139(class_2382 class_2382Var) {
        int iMethod_10264;
        class_2338 class_2338VarMethod_10081 = this.f150.method_10074().method_10081(class_2382Var);
        class_3965 class_3965VarMethod_17742 = this.mc.field_1687.method_17742(new class_3959(class_243.method_24953(class_2338VarMethod_10081), class_243.method_24953(class_2338VarMethod_10081.method_10087(250)), class_3959.class_3960.field_17558, class_3959.class_242.field_1347, this.mc.field_1724));
        if (class_3965VarMethod_17742 != null && class_3965VarMethod_17742.method_17783() == class_239.class_240.field_1332 && (iMethod_10264 = this.f150.method_10264() - class_3965VarMethod_17742.method_17777().method_10264()) > this.f149) {
            this.f149 = iMethod_10264;
        }
    }

    public String getInfoString() {
        return this.f152.toString();
    }
}
