package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import java.util.HashSet;
import meteordevelopment.meteorclient.events.entity.player.PlayerMoveEvent;
import meteordevelopment.meteorclient.events.entity.player.SendMovementPacketsEvent;
import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_10182;
import net.minecraft.class_243;
import net.minecraft.class_2708;
import net.minecraft.class_2793;
import net.minecraft.class_2828;
import net.minecraft.class_634;

public class PacketFly extends Module {

    private final HashSet<class_2828> f160;
    private final SettingGroup sgMovement;
    private final SettingGroup sgClient;
    private final SettingGroup sgBypass;
    private final Setting<Double> horizontalSpeed;
    private final Setting<Double> verticalSpeed;
    private final Setting<Boolean> sendTeleport;
    private final Setting<Boolean> setYaw;
    private final Setting<Boolean> setMove;
    private final Setting<Boolean> setPos;
    private final Setting<Boolean> setID;
    private final Setting<Boolean> antiKick;
    private final Setting<Integer> downDelay;
    private final Setting<Integer> downDelayFlying;
    private final Setting<Boolean> invalidPacket;

    private int f161;

    private int f162ID;

    public PacketFly() {
        super(MeteorRejectsAddon.CATEGORY, "数据包飞行", "通过发送自定义移动数据包实现飞行，可绕过部分反作弊。");
        this.f160 = new HashSet<>();
        this.sgMovement = this.settings.createGroup("移动设置");
        this.sgClient = this.settings.createGroup("客户端设置");
        this.sgBypass = this.settings.createGroup("绕过设置");
        this.horizontalSpeed = this.sgMovement.add(((DoubleSetting.Builder) ((DoubleSetting.Builder) new DoubleSetting.Builder().name("水平速度")).description("水平方向移动速度（单位：方块/秒）。")).defaultValue(5.2d).min(0.0d).max(20.0d).sliderMin(0.0d).sliderMax(20.0d).build());
        this.verticalSpeed = this.sgMovement.add(((DoubleSetting.Builder) ((DoubleSetting.Builder) new DoubleSetting.Builder().name("垂直速度")).description("垂直方向移动速度（单位：方块/秒）。")).defaultValue(1.24d).min(0.0d).max(20.0d).sliderMin(0.0d).sliderMax(20.0d).build());
        this.sendTeleport = this.sgMovement.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("发送传送包")).description("是否发送 teleport 确认数据包。")).defaultValue(true)).build());
        this.setYaw = this.sgClient.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("锁定视角Yaw")).description("在客户端保持玩家的Yaw（水平旋转）不变。")).defaultValue(true)).build());
        this.setMove = this.sgClient.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("客户端移动模拟")).description("是否在客户端模拟移动效果（影响本地视觉）。")).defaultValue(false)).build());
        this.setPos = this.sgClient.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("客户端位置同步")).description("是否在客户端同步服务器位置（影响本地视觉）。")).defaultValue(false)).build());
        this.setID = this.sgClient.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("同步传送ID")).description("收到服务器位置数据包时是否更新 teleport ID。")).defaultValue(false)).build());
        this.antiKick = this.sgBypass.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("防踢机制")).description("是否偶尔向下移动以防止被服务器检测并踢出。")).defaultValue(true)).build());
        this.downDelay = this.sgBypass.add(((IntSetting.Builder) ((IntSetting.Builder) ((IntSetting.Builder) new IntSetting.Builder().name("常规下移动间隔")).description("不向上飞行时，多久向下移动一次（单位：游戏刻，20刻=1秒）。")).defaultValue(4)).sliderMin(1).sliderMax(30).min(1).max(30).build());
        this.downDelayFlying = this.sgBypass.add(((IntSetting.Builder) ((IntSetting.Builder) ((IntSetting.Builder) new IntSetting.Builder().name("上升下移动间隔")).description("向上飞行时，多久向下移动一次（单位：游戏刻）。")).defaultValue(10)).sliderMin(1).sliderMax(30).min(1).max(30).build());
        this.invalidPacket = this.sgBypass.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("发送无效包")).description("是否发送无效的移动数据包以绕过反作弊检测。")).defaultValue(false)).build());
        this.f161 = 0;
        this.f162ID = 0;
    }

    @EventHandler
    public void onSendMovementPackets(SendMovementPacketsEvent.Pre event) {
        this.mc.field_1724.method_18800(0.0d, 0.0d, 0.0d);
        double dDoubleValue = 0.0d;
        boolean zM154 = m154();
        if (this.mc.field_1724.field_3913.field_54155.comp_3163()) {
            if (zM154 || (this.mc.field_1724.field_3913.field_3905 == 0.0d && this.mc.field_1724.field_3913.field_3907 == 0.0d)) {
                double dDoubleValue2 = (((Boolean) this.antiKick.get()).booleanValue() && !zM154 && m155(((Integer) this.downDelayFlying.get()).intValue())) ? -0.032d : ((Double) this.verticalSpeed.get()).doubleValue() / 20.0d;
                dDoubleValue = dDoubleValue2;
            }
        } else if (this.mc.field_1724.field_3913.field_54155.comp_3164()) {
            dDoubleValue = ((Double) this.verticalSpeed.get()).doubleValue() / (-20.0d);
        } else {
            double d = (!zM154 && m155(((Integer) this.downDelay.get()).intValue()) && ((Boolean) this.antiKick.get()).booleanValue()) ? -0.04d : 0.0d;
            dDoubleValue = d;
        }
        class_243 horizontalVelocity = PlayerUtils.getHorizontalVelocity(((Double) this.horizontalSpeed.get()).doubleValue());
        this.mc.field_1724.method_18800(horizontalVelocity.field_1352, dDoubleValue, horizontalVelocity.field_1350);
        m156(this.mc.field_1724.method_18798().field_1352, this.mc.field_1724.method_18798().field_1351, this.mc.field_1724.method_18798().field_1350, ((Boolean) this.sendTeleport.get()).booleanValue());
    }

    @EventHandler
    public void onMove(PlayerMoveEvent event) {
        if (((Boolean) this.setMove.get()).booleanValue() && this.f161 != 0) {
            event.movement = new class_243(this.mc.field_1724.method_18798().field_1352, this.mc.field_1724.method_18798().field_1351, this.mc.field_1724.method_18798().field_1350);
        }
    }

    @EventHandler
    public void onPacketSent(PacketEvent.Send event) {
        if ((event.packet instanceof class_2828) && !this.f160.remove(event.packet)) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onPacketReceive(PacketEvent.Receive event) {
        if ((event.packet instanceof class_2708) && this.mc.field_1724 != null && this.mc.field_1687 != null) {
            class_2708 class_2708Var = event.packet;
            class_10182 class_10182VarComp_3228 = class_2708Var.comp_3228();
            if (((Boolean) this.setYaw.get()).booleanValue()) {
                event.packet = class_2708.method_63542(class_2708Var.comp_3133(), new class_10182(class_10182VarComp_3228.comp_3148(), class_10182VarComp_3228.comp_3149(), this.mc.field_1724.method_36454(), this.mc.field_1724.method_36455()), class_2708Var.comp_3229());
            }
            if (((Boolean) this.setID.get()).booleanValue()) {
                this.f162ID = class_2708Var.comp_3133();
            }
        }
    }

    private boolean m154() {
        return !this.mc.field_1687.method_20812(this.mc.field_1724, this.mc.field_1724.method_5829().method_1012(-0.0625d, -0.0625d, -0.0625d)).iterator().hasNext();
    }

    private boolean m155(int i) {
        int i2 = this.f161 + 1;
        this.f161 = i2;
        if (i2 >= i) {
            this.f161 = 0;
            return true;
        }
        return false;
    }

    private void m156(double x, double y, double z, boolean z2) {
        class_243 class_243Var = new class_243(x, y, z);
        class_243 class_243VarMethod_1019 = this.mc.field_1724.method_19538().method_1019(class_243Var);
        class_243 class_243VarM158 = m158(class_243Var, class_243VarMethod_1019);
        m159(new class_2828.class_2829(class_243VarMethod_1019.field_1352, class_243VarMethod_1019.field_1351, class_243VarMethod_1019.field_1350, this.mc.field_1724.method_24828(), this.mc.field_1724.field_5976));
        if (((Boolean) this.invalidPacket.get()).booleanValue()) {
            m159(new class_2828.class_2829(class_243VarM158.field_1352, class_243VarM158.field_1351, class_243VarM158.field_1350, this.mc.field_1724.method_24828(), this.mc.field_1724.field_5976));
        }
        if (((Boolean) this.setPos.get()).booleanValue()) {
            this.mc.field_1724.method_23327(class_243VarMethod_1019.field_1352, class_243VarMethod_1019.field_1351, class_243VarMethod_1019.field_1350);
        }
        if (z2) {
            m157(class_243VarMethod_1019);
        }
    }

    private void m157(class_243 class_243Var) {
        class_634 class_634Var = this.mc.field_1724.field_3944;
        int i = this.f162ID + 1;
        this.f162ID = i;
        class_634Var.method_52787(new class_2793(i));
    }

    private class_243 m158(class_243 class_243Var, class_243 class_243Var2) {
        return class_243Var2.method_1031(0.0d, 1500.0d, 0.0d);
    }

    private void m159(class_2828 class_2828Var) {
        this.f160.add(class_2828Var);
        this.mc.field_1724.field_3944.method_52787(class_2828Var);
    }
}
