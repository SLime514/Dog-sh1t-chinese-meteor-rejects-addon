package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import java.util.List;
import java.util.Set;
import meteordevelopment.meteorclient.events.game.OpenScreenEvent;
import meteordevelopment.meteorclient.settings.EnchantmentListSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.ItemListSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.network.MeteorExecutor;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1887;
import net.minecraft.class_1890;
import net.minecraft.class_3803;
import net.minecraft.class_5321;
import net.minecraft.class_6880;
import net.minecraft.class_9304;
import net.minecraft.class_9334;
import net.minecraft.class_9636;

public class AutoGrind extends Module {
    private final SettingGroup sgGeneral;
    private final Setting<Integer> delay;
    private final Setting<List<class_1792>> itemBlacklist;
    private final Setting<Set<class_5321<class_1887>>> enchantmentBlacklist;

    public AutoGrind() {
        super(MeteorRejectsAddon.CATEGORY, "自动研磨", "自动为物品去附魔。");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.delay = this.sgGeneral.add(((IntSetting.Builder) ((IntSetting.Builder) ((IntSetting.Builder) new IntSetting.Builder().name("延迟")).description("研磨物品之间的tick延迟。")).defaultValue(50)).sliderMax(500).min(0).build());
        this.itemBlacklist = this.sgGeneral.add(((ItemListSetting.Builder) ((ItemListSetting.Builder) new ItemListSetting.Builder().name("物品黑名单")).description("应被忽略的物品。")).defaultValue(new class_1792[0]).filter(Item -> {
            return Item.method_57347().method_57829(class_9334.field_49629) != null;
        }).build());
        this.enchantmentBlacklist = this.sgGeneral.add(((EnchantmentListSetting.Builder) ((EnchantmentListSetting.Builder) new EnchantmentListSetting.Builder().name("附魔黑名单")).description("应被忽略的附魔。")).defaultValue(new class_5321[0]).build());
    }

    @EventHandler
    private void onOpenScreen(OpenScreenEvent event) {
        if (!(this.mc.field_1724.field_7512 instanceof class_3803)) {
            return;
        }
        MeteorExecutor.execute(() -> {
            for (int i = 0; i <= this.mc.field_1724.method_31548().method_5439(); i++) {
                if (canGrind(this.mc.field_1724.method_31548().method_5438(i))) {
                    try {
                        Thread.sleep(((Integer) this.delay.get()).intValue());
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    if (this.mc.field_1755 != null) {
                        InvUtils.shiftClick().slot(i);
                        InvUtils.move().fromId(2).to(i);
                    } else {
                        return;
                    }
                }
            }
        });
    }

    private boolean canGrind(class_1799 stack) {
        if (((List) this.itemBlacklist.get()).contains(stack.method_7909())) {
            return false;
        }
        class_9304 class_9304VarMethod_57532 = class_1890.method_57532(stack);
        int i = 0;
        for (class_6880<class_1887> class_6880Var : class_9304VarMethod_57532.method_57534()) {
            i++;
            if (class_1890.method_60138(stack, class_9636.field_51551)) {
                i--;
            }
            if (((Set) this.enchantmentBlacklist.get()).contains(class_6880Var.comp_349())) {
                return false;
            }
        }
        return !class_9304VarMethod_57532.method_57543() && i > 0;
    }
}
