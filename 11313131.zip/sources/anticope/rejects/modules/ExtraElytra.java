package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1304;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_243;
import net.minecraft.class_2848;
import net.minecraft.class_3532;

public class ExtraElytra extends Module {
    private final SettingGroup sgGeneral;
    private final Setting<Boolean> instantFly;
    private final Setting<Boolean> speedCtrl;
    private final Setting<Boolean> heightCtrl;
    private final Setting<Boolean> stopInWater;
    private int jumpTimer;

    public void onActivate() {
        this.jumpTimer = 0;
    }

    public ExtraElytra() {
        super(MeteorRejectsAddon.CATEGORY, "增强鞘翅", "简化鞘翅飞行操作，提供更便捷的飞行控制。");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.instantFly = this.sgGeneral.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("一键飞行")).description("按下跳跃键即可激活鞘翅飞行，无需繁琐的二段跳！")).defaultValue(true)).build());
        this.speedCtrl = this.sgGeneral.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("速度控制")).description("使用前后移动键控制飞行速度。\n（默认按键：W前进、S后退）\n无需烟花推进！")).defaultValue(true)).build());
        this.heightCtrl = this.sgGeneral.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("高度控制")).description("使用跳跃键和潜行键控制飞行高度。\n（默认按键：空格键上升、Shift键下降）\n无需烟花推进！")).defaultValue(false)).build());
        this.stopInWater = this.sgGeneral.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("水中停止飞行")).description("在水中自动停止鞘翅飞行。")).defaultValue(true)).build());
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (this.jumpTimer > 0) {
            this.jumpTimer--;
        }
        class_1799 class_1799VarMethod_6118 = this.mc.field_1724.method_6118(class_1304.field_6174);
        if (class_1799VarMethod_6118.method_7909() != class_1802.field_8833) {
            return;
        }
        if (this.mc.field_1724.method_6128()) {
            if (((Boolean) this.stopInWater.get()).booleanValue() && this.mc.field_1724.method_5799()) {
                m127();
                return;
            } else {
                m129();
                m128();
                return;
            }
        }
        if (class_1799VarMethod_6118.method_7919() < class_1799VarMethod_6118.method_7936() - 1 && this.mc.field_1690.field_1903.method_1434()) {
            m130();
        }
    }

    private void m127() {
        this.mc.field_1724.field_3944.method_52787(new class_2848(this.mc.field_1724, class_2848.class_2849.field_12982));
    }

    private void m128() {
        if (!((Boolean) this.heightCtrl.get()).booleanValue()) {
            return;
        }
        class_243 class_243VarMethod_18798 = this.mc.field_1724.method_18798();
        if (this.mc.field_1690.field_1903.method_1434()) {
            this.mc.field_1724.method_18800(class_243VarMethod_18798.field_1352, class_243VarMethod_18798.field_1351 + 0.08d, class_243VarMethod_18798.field_1350);
        } else if (this.mc.field_1690.field_1832.method_1434()) {
            this.mc.field_1724.method_18800(class_243VarMethod_18798.field_1352, class_243VarMethod_18798.field_1351 - 0.04d, class_243VarMethod_18798.field_1350);
        }
    }

    private void m129() {
        if (!((Boolean) this.speedCtrl.get()).booleanValue()) {
            return;
        }
        float radians = (float) Math.toRadians(this.mc.field_1724.method_36454());
        class_243 class_243Var = new class_243((-class_3532.method_15374(radians)) * 0.05d, 0.0d, class_3532.method_15362(radians) * 0.05d);
        class_243 class_243VarMethod_18798 = this.mc.field_1724.method_18798();
        if (this.mc.field_1690.field_1894.method_1434()) {
            this.mc.field_1724.method_18799(class_243VarMethod_18798.method_1019(class_243Var));
        } else if (this.mc.field_1690.field_1881.method_1434()) {
            this.mc.field_1724.method_18799(class_243VarMethod_18798.method_1020(class_243Var));
        }
    }

    private void m130() {
        if (!((Boolean) this.instantFly.get()).booleanValue()) {
            return;
        }
        if (this.jumpTimer <= 0) {
            this.jumpTimer = 20;
            this.mc.field_1724.method_6100(false);
            this.mc.field_1724.method_5728(true);
            this.mc.field_1724.method_6043();
        }
        m127();
    }
}
