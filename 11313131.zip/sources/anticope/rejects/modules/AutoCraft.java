package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import java.util.Iterator;
import java.util.List;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.ItemListSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_10297;
import net.minecraft.class_10363;
import net.minecraft.class_1713;
import net.minecraft.class_1714;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_516;

public class AutoCraft extends Module {
    private final SettingGroup sgGeneral;
    private final Setting<List<class_1792>> items;
    private final Setting<Boolean> antiDesync;
    private final Setting<Boolean> craftAll;
    private final Setting<Boolean> drop;

    public AutoCraft() {
        super(MeteorRejectsAddon.CATEGORY, "自动合成", "自动合成指定物品。");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.items = this.sgGeneral.add(((ItemListSetting.Builder) ((ItemListSetting.Builder) ((ItemListSetting.Builder) new ItemListSetting.Builder().name("目标物品")).description("你想要自动合成的物品。")).defaultValue(List.of())).build());
        this.antiDesync = this.sgGeneral.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("防不同步")).description("尝试防止背包数据不同步。")).defaultValue(false)).build());
        this.craftAll = this.sgGeneral.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("全部合成")).description("每次合成时合成最大可能数量（按住Shift点击效果）")).defaultValue(false)).build());
        this.drop = this.sgGeneral.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("自动丢弃")).description("自动丢弃合成出的物品（在背包空间不足时很有用）")).defaultValue(false)).build());
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (!Utils.canUpdate() || this.mc.field_1761 == null || ((List) this.items.get()).isEmpty() || !(this.mc.field_1724.field_7512 instanceof class_1714)) {
            return;
        }
        if (((Boolean) this.antiDesync.get()).booleanValue()) {
            this.mc.field_1724.method_31548().method_7381();
        }
        class_1714 class_1714Var = this.mc.field_1724.field_7512;
        List<class_1792> list = (List) this.items.get();
        Iterator<class_516> it = this.mc.field_1724.method_3130().method_1393().iterator();
        while (it.hasNext()) {
            for (class_10297 class_10297Var : it.next().method_64885(class_516.class_9937.field_52848)) {
                Iterator<class_1799> it2 = class_10297Var.comp_3263().comp_3258().method_64738(class_10363.method_65008(this.mc.field_1687)).iterator();
                while (it2.hasNext()) {
                    if (list.contains(it2.next().method_7909())) {
                        this.mc.field_1761.method_2912(class_1714Var.field_7763, class_10297Var.comp_3262(), ((Boolean) this.craftAll.get()).booleanValue());
                        this.mc.field_1761.method_2906(class_1714Var.field_7763, 0, 1, ((Boolean) this.drop.get()).booleanValue() ? class_1713.field_7795 : class_1713.field_7794, this.mc.field_1724);
                    }
                }
            }
        }
    }
}
