package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import com.seedfinding.mccore.nbt.NBTType;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.ColorSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.misc.Pool;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import meteordevelopment.meteorclient.utils.player.Rotations;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.meteorclient.utils.world.BlockIterator;
import meteordevelopment.meteorclient.utils.world.BlockUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_3726;

public class AutoWither extends Module {
    private final SettingGroup sgGeneral;
    private final SettingGroup sgRender;
    private final Setting<Integer> horizontalRadius;
    private final Setting<Integer> verticalRadius;
    private final Setting<Priority> priority;
    private final Setting<Integer> witherDelay;
    private final Setting<Integer> blockDelay;
    private final Setting<Boolean> rotate;
    private final Setting<Boolean> turnOff;
    private final Setting<ShapeMode> shapeMode;
    private final Setting<SettingColor> sideColor;
    private final Setting<SettingColor> lineColor;

    private final Pool<Wither> f108;

    private final ArrayList<Wither> f109;

    private Wither f110;

    private int f111;

    private int f112;

    public enum Priority {
        Closest,
        Furthest,
        Random
    }

    public AutoWither() {
        super(MeteorRejectsAddon.CATEGORY, "自动凋零", "自动建造凋零。");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.sgRender = this.settings.createGroup("渲染设置");
        this.horizontalRadius = this.sgGeneral.add(((IntSetting.Builder) ((IntSetting.Builder) ((IntSetting.Builder) new IntSetting.Builder().name("水平范围")).description("放置凋零的水平搜索范围")).defaultValue(4)).min(0).sliderMax(6).build());
        this.verticalRadius = this.sgGeneral.add(((IntSetting.Builder) ((IntSetting.Builder) ((IntSetting.Builder) new IntSetting.Builder().name("垂直范围")).description("放置凋零的垂直搜索范围")).defaultValue(3)).min(0).sliderMax(6).build());
        this.priority = this.sgGeneral.add(((EnumSetting.Builder) ((EnumSetting.Builder) ((EnumSetting.Builder) new EnumSetting.Builder().name("优先级")).description("凋零放置位置的选择优先级")).defaultValue(Priority.Random)).build());
        this.witherDelay = this.sgGeneral.add(((IntSetting.Builder) ((IntSetting.Builder) ((IntSetting.Builder) new IntSetting.Builder().name("凋零延迟")).description("两次凋零放置之间的tick延迟")).defaultValue(1)).min(1).sliderMax(10).build());
        this.blockDelay = this.sgGeneral.add(((IntSetting.Builder) ((IntSetting.Builder) ((IntSetting.Builder) new IntSetting.Builder().name("方块延迟")).description("两次方块放置之间的tick延迟")).defaultValue(1)).min(0).sliderMax(10).build());
        this.rotate = this.sgGeneral.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("自动转向")).description("建造时是否自动转向方块")).defaultValue(true)).build());
        this.turnOff = this.sgGeneral.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("自动关闭")).description("建造一个凋零后自动关闭模块")).defaultValue(true)).build());
        this.shapeMode = this.sgRender.add(((EnumSetting.Builder) ((EnumSetting.Builder) ((EnumSetting.Builder) new EnumSetting.Builder().name("形状模式")).description("渲染形状的方式")).defaultValue(ShapeMode.Both)).build());
        this.sideColor = this.sgRender.add(((ColorSetting.Builder) ((ColorSetting.Builder) new ColorSetting.Builder().name("侧面颜色")).description("目标方块渲染的侧面颜色")).defaultValue(new SettingColor(197, 137, 232, 10)).build());
        this.lineColor = this.sgRender.add(((ColorSetting.Builder) ((ColorSetting.Builder) new ColorSetting.Builder().name("线条颜色")).description("目标方块渲染的线条颜色")).defaultValue(new SettingColor(197, 137, 232)).build());
        this.f108 = new Pool<>(Wither::new);
        this.f109 = new ArrayList<>();
    }

    public void onDeactivate() {
        this.f110 = null;
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (this.f110 != null || this.f111 < ((Integer) this.witherDelay.get()).intValue() - 1) {
            return;
        }
        Iterator<Wither> it = this.f109.iterator();
        while (it.hasNext()) {
            this.f108.free(it.next());
        }
        this.f109.clear();
        BlockIterator.register(((Integer) this.horizontalRadius.get()).intValue(), ((Integer) this.verticalRadius.get()).intValue(), (class_2338Var, class_2680Var) -> {
            class_2350 class_2350VarMethod_10153 = class_2350.method_10150(Rotations.getYaw(class_2338Var)).method_10153();
            if (isValidSpawn(class_2338Var, class_2350VarMethod_10153)) {
                this.f109.add(((Wither) this.f108.get()).set(class_2338Var, class_2350VarMethod_10153));
            }
        });
    }

    @EventHandler
    private void onPostTick(TickEvent.Post event) {
        if (this.f110 == null) {
            if (this.f111 < ((Integer) this.witherDelay.get()).intValue() - 1) {
                this.f111++;
                return;
            }
            if (this.f109.isEmpty()) {
                return;
            }
            switch (((Priority) this.priority.get()).ordinal()) {
                case 0:
                    this.f109.sort(Comparator.comparingDouble(wither -> {
                        return PlayerUtils.distanceTo(wither.f113);
                    }));
                    break;
                case 1:
                    this.f109.sort((wither2, wither3) -> {
                        int iCompare = Double.compare(PlayerUtils.distanceTo(wither2.f113), PlayerUtils.distanceTo(wither3.f113));
                        if (iCompare == 0) {
                            return 0;
                        }
                        return iCompare > 0 ? -1 : 1;
                    });
                    break;
                case NBTType.SHORT:
                    Collections.shuffle(this.f109);
                    break;
            }
            this.f110 = this.f109.get(0);
        }
        FindItemResult findItemResultFindInHotbar = InvUtils.findInHotbar(new class_1792[]{class_1802.field_8067});
        if (!findItemResultFindInHotbar.found()) {
            findItemResultFindInHotbar = InvUtils.findInHotbar(new class_1792[]{class_1802.field_21999});
        }
        FindItemResult findItemResultFindInHotbar2 = InvUtils.findInHotbar(new class_1792[]{class_1802.field_8791});
        if (!findItemResultFindInHotbar.found() || !findItemResultFindInHotbar2.found()) {
            error("快捷栏中资源不足", new Object[0]);
            toggle();
            return;
        }
        if (((Integer) this.blockDelay.get()).intValue() == 0) {
            BlockUtils.place(this.f110.f113, findItemResultFindInHotbar, ((Boolean) this.rotate.get()).booleanValue(), -50);
            BlockUtils.place(this.f110.f113.method_10084(), findItemResultFindInHotbar, ((Boolean) this.rotate.get()).booleanValue(), -50);
            BlockUtils.place(this.f110.f113.method_10084().method_30513(this.f110.f8, -1), findItemResultFindInHotbar, ((Boolean) this.rotate.get()).booleanValue(), -50);
            BlockUtils.place(this.f110.f113.method_10084().method_30513(this.f110.f8, 1), findItemResultFindInHotbar, ((Boolean) this.rotate.get()).booleanValue(), -50);
            BlockUtils.place(this.f110.f113.method_10084().method_10084(), findItemResultFindInHotbar2, ((Boolean) this.rotate.get()).booleanValue(), -50);
            BlockUtils.place(this.f110.f113.method_10084().method_10084().method_30513(this.f110.f8, -1), findItemResultFindInHotbar2, ((Boolean) this.rotate.get()).booleanValue(), -50);
            BlockUtils.place(this.f110.f113.method_10084().method_10084().method_30513(this.f110.f8, 1), findItemResultFindInHotbar2, ((Boolean) this.rotate.get()).booleanValue(), -50);
            if (((Boolean) this.turnOff.get()).booleanValue()) {
                this.f110 = null;
                toggle();
            }
        } else {
            if (this.f112 < ((Integer) this.blockDelay.get()).intValue() - 1) {
                this.f112++;
                return;
            }
            switch (this.f110.f6) {
                case 0:
                    if (BlockUtils.place(this.f110.f113, findItemResultFindInHotbar, ((Boolean) this.rotate.get()).booleanValue(), -50)) {
                        this.f110.f6++;
                        break;
                    }
                    break;
                case 1:
                    if (BlockUtils.place(this.f110.f113.method_10084(), findItemResultFindInHotbar, ((Boolean) this.rotate.get()).booleanValue(), -50)) {
                        this.f110.f6++;
                        break;
                    }
                    break;
                case NBTType.SHORT:
                    if (BlockUtils.place(this.f110.f113.method_10084().method_30513(this.f110.f8, -1), findItemResultFindInHotbar, ((Boolean) this.rotate.get()).booleanValue(), -50)) {
                        this.f110.f6++;
                        break;
                    }
                    break;
                case 3:
                    if (BlockUtils.place(this.f110.f113.method_10084().method_30513(this.f110.f8, 1), findItemResultFindInHotbar, ((Boolean) this.rotate.get()).booleanValue(), -50)) {
                        this.f110.f6++;
                        break;
                    }
                    break;
                case 4:
                    if (BlockUtils.place(this.f110.f113.method_10084().method_10084(), findItemResultFindInHotbar2, ((Boolean) this.rotate.get()).booleanValue(), -50)) {
                        this.f110.f6++;
                        break;
                    }
                    break;
                case NBTType.FLOAT:
                    if (BlockUtils.place(this.f110.f113.method_10084().method_10084().method_30513(this.f110.f8, -1), findItemResultFindInHotbar2, ((Boolean) this.rotate.get()).booleanValue(), -50)) {
                        this.f110.f6++;
                        break;
                    }
                    break;
                case 6:
                    if (BlockUtils.place(this.f110.f113.method_10084().method_10084().method_30513(this.f110.f8, 1), findItemResultFindInHotbar2, ((Boolean) this.rotate.get()).booleanValue(), -50)) {
                        this.f110.f6++;
                        break;
                    }
                    break;
                case NBTType.BYTE_ARRAY:
                    if (((Boolean) this.turnOff.get()).booleanValue()) {
                        this.f110 = null;
                        toggle();
                        break;
                    }
                    break;
            }
        }
        this.f111 = 0;
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        if (this.f110 == null) {
            return;
        }
        event.renderer.box(this.f110.f113, (Color) this.sideColor.get(), (Color) this.lineColor.get(), (ShapeMode) this.shapeMode.get(), 0);
        event.renderer.box(this.f110.f113.method_10084(), (Color) this.sideColor.get(), (Color) this.lineColor.get(), (ShapeMode) this.shapeMode.get(), 0);
        event.renderer.box(this.f110.f113.method_10084().method_30513(this.f110.f8, -1), (Color) this.sideColor.get(), (Color) this.lineColor.get(), (ShapeMode) this.shapeMode.get(), 0);
        event.renderer.box(this.f110.f113.method_10084().method_30513(this.f110.f8, 1), (Color) this.sideColor.get(), (Color) this.lineColor.get(), (ShapeMode) this.shapeMode.get(), 0);
        class_2338 class_2338VarMethod_10084 = this.f110.f113.method_10084().method_10084();
        class_2338 class_2338VarMethod_30513 = this.f110.f113.method_10084().method_10084().method_30513(this.f110.f8, -1);
        class_2338 class_2338VarMethod_305132 = this.f110.f113.method_10084().method_10084().method_30513(this.f110.f8, 1);
        event.renderer.box(class_2338VarMethod_10084.method_10263() + 0.2d, class_2338VarMethod_10084.method_10264(), class_2338VarMethod_10084.method_10260() + 0.2d, class_2338VarMethod_10084.method_10263() + 0.8d, class_2338VarMethod_10084.method_10264() + 0.7d, class_2338VarMethod_10084.method_10260() + 0.8d, (Color) this.sideColor.get(), (Color) this.lineColor.get(), (ShapeMode) this.shapeMode.get(), 0);
        event.renderer.box(class_2338VarMethod_30513.method_10263() + 0.2d, class_2338VarMethod_30513.method_10264(), class_2338VarMethod_30513.method_10260() + 0.2d, class_2338VarMethod_30513.method_10263() + 0.8d, class_2338VarMethod_30513.method_10264() + 0.7d, class_2338VarMethod_30513.method_10260() + 0.8d, (Color) this.sideColor.get(), (Color) this.lineColor.get(), (ShapeMode) this.shapeMode.get(), 0);
        event.renderer.box(class_2338VarMethod_305132.method_10263() + 0.2d, class_2338VarMethod_305132.method_10264(), class_2338VarMethod_305132.method_10260() + 0.2d, class_2338VarMethod_305132.method_10263() + 0.8d, class_2338VarMethod_305132.method_10264() + 0.7d, class_2338VarMethod_305132.method_10260() + 0.8d, (Color) this.sideColor.get(), (Color) this.lineColor.get(), (ShapeMode) this.shapeMode.get(), 0);
    }

    private boolean isValidSpawn(class_2338 class_2338Var, class_2350 class_2350Var) {
        if (class_2338Var.method_10264() > 252) {
            return false;
        }
        int i = (class_2350Var == class_2350.field_11034 || class_2350Var == class_2350.field_11039) ? 1 : 0;
        int i2 = (class_2350Var == class_2350.field_11043 || class_2350Var == class_2350.field_11035) ? 1 : 0;
        class_2338.class_2339 class_2339Var = new class_2338.class_2339();
        for (int x = class_2338Var.method_10263() - i2; x <= class_2338Var.method_10263() + i2; x++) {
            for (int z = class_2338Var.method_10260() - i; z <= class_2338Var.method_10260(); z++) {
                for (int y = class_2338Var.method_10264(); y <= class_2338Var.method_10264() + 2; y++) {
                    class_2339Var.method_10103(x, y, z);
                    if (!this.mc.field_1687.method_8320(class_2339Var).method_45474() || !this.mc.field_1687.method_8628(class_2246.field_10340.method_9564(), class_2339Var, class_3726.method_16194())) {
                        return false;
                    }
                }
            }
        }
        return true;
    }

    private static class Wither {

        public int f6;

        public class_2338.class_2339 f113 = new class_2338.class_2339();

        public class_2350 f7;

        public class_2350.class_2351 f8;

        private Wither() {
        }

        public Wither set(class_2338 class_2338Var, class_2350 class_2350Var) {
            this.f6 = 0;
            this.f113.method_10101(class_2338Var);
            this.f7 = class_2350Var;
            this.f8 = class_2350Var.method_10166();
            return this;
        }
    }
}
