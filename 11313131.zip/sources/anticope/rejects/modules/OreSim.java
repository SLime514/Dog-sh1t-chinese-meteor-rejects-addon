package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import anticope.rejects.events.PlayerRespawnEvent;
import anticope.rejects.events.SeedChangedEvent;
import anticope.rejects.utils.Ore;
import anticope.rejects.utils.seeds.Seed;
import anticope.rejects.utils.seeds.Seeds;
import baritone.api.BaritoneAPI;
import java.util.ArrayList;
import java.util.BitSet;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.BlockUpdateEvent;
import meteordevelopment.meteorclient.events.world.ChunkDataEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.pathing.BaritoneUtils;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1923;
import net.minecraft.class_1959;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2791;
import net.minecraft.class_2806;
import net.minecraft.class_2826;
import net.minecraft.class_2902;
import net.minecraft.class_2919;
import net.minecraft.class_3532;
import net.minecraft.class_5321;
import net.minecraft.class_638;

public class OreSim extends Module {
    private final Map<Long, Map<Ore, Set<class_243>>> chunkRenderers;
    private Seed worldSeed;
    private Map<class_5321<class_1959>, List<Ore>> oreConfig;
    public List<class_2338> oreGoals;
    private final SettingGroup sgGeneral;
    private final Setting<Integer> horizontalRadius;
    private final Setting<AirCheck> airCheck;
    private final Setting<Boolean> baritone;

    public enum AirCheck {
        ON_LOAD,
        RECHECK,
        OFF
    }

    public OreSim() {
        super(MeteorRejectsAddon.CATEGORY, "矿石模拟", "简易的透视");
        this.chunkRenderers = new ConcurrentHashMap();
        this.worldSeed = null;
        this.oreGoals = new ArrayList();
        this.sgGeneral = this.settings.getDefaultGroup();
        this.horizontalRadius = this.sgGeneral.add(((IntSetting.Builder) ((IntSetting.Builder) ((IntSetting.Builder) new IntSetting.Builder().name("区块范围")).description("显示区块的出租车距离范围。")).defaultValue(5)).min(1).sliderMax(10).build());
        this.airCheck = this.sgGeneral.add(((EnumSetting.Builder) ((EnumSetting.Builder) ((EnumSetting.Builder) new EnumSetting.Builder().name("空气检查模式")).description("检查计算出的矿石位置是否有空气")).defaultValue(AirCheck.RECHECK)).build());
        this.baritone = this.sgGeneral.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("baritone")).description("将Baritone的矿石位置设置为模拟的位置。")).defaultValue(false)).build());
        SettingGroup sgOres = this.settings.createGroup("矿石");
        List<Setting<Boolean>> list = Ore.oreSettings;
        Objects.requireNonNull(sgOres);
        list.forEach(sgOres::add);
    }

    public boolean baritone() {
        return isActive() && ((Boolean) this.baritone.get()).booleanValue() && BaritoneUtils.IS_AVAILABLE;
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        if (this.mc.field_1724 != null && this.oreConfig != null && Seeds.get().getSeed() != null) {
            int chunkX = this.mc.field_1724.method_31476().field_9181;
            int chunkZ = this.mc.field_1724.method_31476().field_9180;
            int rangeVal = ((Integer) this.horizontalRadius.get()).intValue();
            for (int range = 0; range <= rangeVal; range++) {
                for (int x = (-range) + chunkX; x <= range + chunkX; x++) {
                    renderChunk(x, (chunkZ + range) - rangeVal, event);
                }
                for (int x2 = (-range) + 1 + chunkX; x2 < range + chunkX; x2++) {
                    renderChunk(x2, (chunkZ - range) + rangeVal + 1, event);
                }
            }
        }
    }

    private void renderChunk(int x, int z, Render3DEvent event) {
        long chunkKey = class_1923.method_8331(x, z);
        if (this.chunkRenderers.containsKey(Long.valueOf(chunkKey))) {
            Map<Ore, Set<class_243>> chunk = this.chunkRenderers.get(Long.valueOf(chunkKey));
            for (Map.Entry<Ore, Set<class_243>> oreRenders : chunk.entrySet()) {
                if (((Boolean) oreRenders.getKey().active.get()).booleanValue()) {
                    for (class_243 pos : oreRenders.getValue()) {
                        event.renderer.boxLines(pos.field_1352, pos.field_1351, pos.field_1350, pos.field_1352 + 1.0d, pos.field_1351 + 1.0d, pos.field_1350 + 1.0d, oreRenders.getKey().color, 0);
                    }
                }
            }
        }
    }

    @EventHandler
    private void onBlockUpdate(BlockUpdateEvent event) {
        if (this.airCheck.get() != AirCheck.RECHECK || event.newState.method_26225()) {
            return;
        }
        long chunkKey = class_1923.method_37232(event.pos);
        if (this.chunkRenderers.containsKey(Long.valueOf(chunkKey))) {
            class_243 pos = class_243.method_24954(event.pos);
            for (Set<class_243> ore : this.chunkRenderers.get(Long.valueOf(chunkKey)).values()) {
                ore.remove(pos);
            }
        }
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (this.mc.field_1724 != null && this.mc.field_1687 != null && this.oreConfig != null && baritone() && BaritoneAPI.getProvider().getPrimaryBaritone().getMineProcess().isActive()) {
            this.oreGoals.clear();
            class_1923 chunkPos = this.mc.field_1724.method_31476();
            for (int range = 0; range <= 4; range++) {
                for (int x = (-range) + chunkPos.field_9181; x <= range + chunkPos.field_9181; x++) {
                    this.oreGoals.addAll(addToBaritone(x, (chunkPos.field_9180 + range) - 4));
                }
                for (int x2 = (-range) + 1 + chunkPos.field_9181; x2 < range + chunkPos.field_9181; x2++) {
                    this.oreGoals.addAll(addToBaritone(x2, (chunkPos.field_9180 - range) + 4 + 1));
                }
            }
        }
    }

    private ArrayList<class_2338> addToBaritone(int chunkX, int chunkZ) {
        ArrayList<class_2338> baritoneGoals = new ArrayList<>();
        long chunkKey = class_1923.method_8331(chunkX, chunkZ);
        if (this.chunkRenderers.containsKey(Long.valueOf(chunkKey))) {
            Stream map = this.chunkRenderers.get(Long.valueOf(chunkKey)).entrySet().stream().filter(entry -> {
                return ((Boolean) ((Ore) entry.getKey()).active.get()).booleanValue();
            }).flatMap(entry2 -> {
                return ((Set) entry2.getValue()).stream();
            }).map((v0) -> {
                return class_2338.method_49638(v0);
            });
            Objects.requireNonNull(baritoneGoals);
            map.forEach((v1) -> {
                r1.add(v1);
            });
        }
        return baritoneGoals;
    }

    public void onActivate() {
        if (Seeds.get().getSeed() == null) {
            error("No seed found. To set a seed do .seed <seed>", new Object[0]);
            toggle();
        }
        reload();
    }

    public void onDeactivate() {
        this.chunkRenderers.clear();
        this.oreConfig = null;
    }

    @EventHandler
    private void onSeedChanged(SeedChangedEvent event) {
        reload();
    }

    @EventHandler
    private void onPlayerRespawn(PlayerRespawnEvent event) {
        reload();
    }

    private void loadVisibleChunks() {
        if (this.mc.field_1724 == null) {
            return;
        }
        for (class_2791 chunk : Utils.chunks(false)) {
            doMathOnChunk(chunk);
        }
    }

    private void reload() {
        Seed seed = Seeds.get().getSeed();
        if (seed == null) {
            return;
        }
        this.worldSeed = seed;
        this.oreConfig = Ore.getRegistry(PlayerUtils.getDimension());
        this.chunkRenderers.clear();
        if (this.mc.field_1687 != null && this.worldSeed != null) {
            loadVisibleChunks();
        }
    }

    @EventHandler
    public void onChunkData(ChunkDataEvent event) {
        doMathOnChunk(event.chunk());
    }

    private void doMathOnChunk(class_2791 chunk) {
        class_1923 chunkPos = chunk.method_12004();
        long chunkKey = chunkPos.method_8324();
        class_638 world = this.mc.field_1687;
        if (this.chunkRenderers.containsKey(Long.valueOf(chunkKey)) || world == null) {
            return;
        }
        Set<class_5321<class_1959>> biomes = new HashSet<>();
        class_1923.method_19280(chunkPos, 1).forEach(chunkPosx -> {
            class_2791 chunkxx = world.method_8402(chunkPosx.field_9181, chunkPosx.field_9180, class_2806.field_12794, false);
            if (chunkxx == null) {
                return;
            }
            for (class_2826 chunkSection : chunkxx.method_12006()) {
                chunkSection.method_38294().method_39793(entry -> {
                    biomes.add((class_5321) entry.method_40230().get());
                });
            }
        });
        Set<Ore> oreSet = (Set) biomes.stream().flatMap(b -> {
            return getDefaultOres(b).stream();
        }).collect(Collectors.toSet());
        int chunkX = chunkPos.field_9181 << 4;
        int chunkZ = chunkPos.field_9180 << 4;
        class_2919 random = new class_2919(class_2919.class_6675.field_35143.method_39006(0L));
        long populationSeed = random.method_12661(this.worldSeed.seed.longValue(), chunkX, chunkZ);
        HashMap<Ore, Set<class_243>> h = new HashMap<>();
        for (Ore ore : oreSet) {
            HashSet<class_243> ores = new HashSet<>();
            random.method_12664(populationSeed, ore.index, ore.step);
            int repeat = ore.count.method_35008(random);
            for (int i = 0; i < repeat; i++) {
                if (ore.rarity == 1.0f || random.method_43057() < 1.0f / ore.rarity) {
                    int x = random.method_43048(16) + chunkX;
                    int z = random.method_43048(16) + chunkZ;
                    int y = ore.heightProvider.method_35391(random, ore.heightContext);
                    class_2338 origin = new class_2338(x, y, z);
                    class_5321<class_1959> biome = (class_5321) chunk.method_16359(x, y, z).method_40230().get();
                    if (getDefaultOres(biome).contains(ore)) {
                        if (ore.scattered) {
                            ores.addAll(generateHidden(world, random, origin, ore.size));
                        } else {
                            ores.addAll(generateNormal(world, random, origin, ore.size, ore.discardOnAirChance));
                        }
                    }
                }
            }
            if (!ores.isEmpty()) {
                h.put(ore, ores);
            }
        }
        this.chunkRenderers.put(Long.valueOf(chunkKey), h);
    }

    private List<Ore> getDefaultOres(class_5321<class_1959> biomeRegistryKey) {
        if (this.oreConfig.containsKey(biomeRegistryKey)) {
            return this.oreConfig.get(biomeRegistryKey);
        }
        return this.oreConfig.values().stream().findAny().get();
    }

    private ArrayList<class_243> generateNormal(class_638 world, class_2919 random, class_2338 blockPos, int veinSize, float discardOnAir) {
        float f = random.method_43057() * 3.1415927f;
        float g = veinSize / 8.0f;
        int i = class_3532.method_15386((((veinSize / 16.0f) * 2.0f) + 1.0f) / 2.0f);
        double d = blockPos.method_10263() + (Math.sin(f) * g);
        double e = blockPos.method_10263() - (Math.sin(f) * g);
        double h = blockPos.method_10260() + (Math.cos(f) * g);
        double j = blockPos.method_10260() - (Math.cos(f) * g);
        double l = (blockPos.method_10264() + random.method_43048(3)) - 2;
        double m = (blockPos.method_10264() + random.method_43048(3)) - 2;
        int n = (blockPos.method_10263() - class_3532.method_15386(g)) - i;
        int o = (blockPos.method_10264() - 2) - i;
        int p = (blockPos.method_10260() - class_3532.method_15386(g)) - i;
        int q = 2 * (class_3532.method_15386(g) + i);
        int r = 2 * (2 + i);
        for (int s = n; s <= n + q; s++) {
            for (int t = p; t <= p + q; t++) {
                if (o <= world.method_8624(class_2902.class_2903.field_13197, s, t)) {
                    return generateVeinPart(world, random, veinSize, d, e, h, j, l, m, n, o, p, q, r, discardOnAir);
                }
            }
        }
        return new ArrayList<>();
    }

    private ArrayList<class_243> generateVeinPart(class_638 world, class_2919 random, int veinSize, double startX, double endX, double startZ, double endZ, double startY, double endY, int x, int y, int z, int size, int i, float discardOnAir) {
        BitSet bitSet = new BitSet(size * i * size);
        class_2338.class_2339 mutable = new class_2338.class_2339();
        double[] ds = new double[veinSize * 4];
        ArrayList<class_243> poses = new ArrayList<>();
        for (int n = 0; n < veinSize; n++) {
            float f = n / veinSize;
            double p = class_3532.method_16436(f, startX, endX);
            double q = class_3532.method_16436(f, startY, endY);
            double r = class_3532.method_16436(f, startZ, endZ);
            double m = (((class_3532.method_15374(3.1415927f * f) + 1.0f) * ((random.method_43058() * veinSize) / 16.0d)) + 1.0d) / 2.0d;
            ds[n * 4] = p;
            ds[(n * 4) + 1] = q;
            ds[(n * 4) + 2] = r;
            ds[(n * 4) + 3] = m;
        }
        for (int n2 = 0; n2 < veinSize - 1; n2++) {
            if (ds[(n2 * 4) + 3] > 0.0d) {
                for (int o = n2 + 1; o < veinSize; o++) {
                    if (ds[(o * 4) + 3] > 0.0d) {
                        double p2 = ds[n2 * 4] - ds[o * 4];
                        double q2 = ds[(n2 * 4) + 1] - ds[(o * 4) + 1];
                        double r2 = ds[(n2 * 4) + 2] - ds[(o * 4) + 2];
                        double s = ds[(n2 * 4) + 3] - ds[(o * 4) + 3];
                        if (s * s > (p2 * p2) + (q2 * q2) + (r2 * r2)) {
                            if (s > 0.0d) {
                                ds[(o * 4) + 3] = -1.0d;
                            } else {
                                ds[(n2 * 4) + 3] = -1.0d;
                            }
                        }
                    }
                }
            }
        }
        for (int n3 = 0; n3 < veinSize; n3++) {
            double u = ds[(n3 * 4) + 3];
            if (u >= 0.0d) {
                double v = ds[n3 * 4];
                double w = ds[(n3 * 4) + 1];
                double aa = ds[(n3 * 4) + 2];
                int ab = Math.max(class_3532.method_15357(v - u), x);
                int ac = Math.max(class_3532.method_15357(w - u), y);
                int ad = Math.max(class_3532.method_15357(aa - u), z);
                int ae = Math.max(class_3532.method_15357(v + u), ab);
                int af = Math.max(class_3532.method_15357(w + u), ac);
                int ag = Math.max(class_3532.method_15357(aa + u), ad);
                for (int ah = ab; ah <= ae; ah++) {
                    double ai = ((ah + 0.5d) - v) / u;
                    if (ai * ai < 1.0d) {
                        for (int aj = ac; aj <= af; aj++) {
                            double ak = ((aj + 0.5d) - w) / u;
                            if ((ai * ai) + (ak * ak) < 1.0d) {
                                for (int al = ad; al <= ag; al++) {
                                    double am = ((al + 0.5d) - aa) / u;
                                    if ((ai * ai) + (ak * ak) + (am * am) < 1.0d) {
                                        int an = (ah - x) + ((aj - y) * size) + ((al - z) * size * i);
                                        if (!bitSet.get(an)) {
                                            bitSet.set(an);
                                            mutable.method_10103(ah, aj, al);
                                            if (aj >= -64 && aj < 320 && ((this.airCheck.get() == AirCheck.OFF || world.method_8320(mutable).method_26225()) && shouldPlace(world, mutable, discardOnAir, random))) {
                                                poses.add(new class_243(ah, aj, al));
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        return poses;
    }

    private boolean shouldPlace(class_638 world, class_2338 orePos, float discardOnAir, class_2919 random) {
        if (discardOnAir == 0.0f) {
            return true;
        }
        if (discardOnAir != 1.0f && random.method_43057() >= discardOnAir) {
            return true;
        }
        for (class_2350 direction : class_2350.values()) {
            if (!world.method_8320(orePos.method_10081(direction.method_62675())).method_26225() && discardOnAir != 1.0f) {
                return false;
            }
        }
        return true;
    }

    private ArrayList<class_243> generateHidden(class_638 world, class_2919 random, class_2338 blockPos, int size) {
        ArrayList<class_243> poses = new ArrayList<>();
        int i = random.method_43048(size + 1);
        for (int j = 0; j < i; j++) {
            int size2 = Math.min(j, 7);
            int x = randomCoord(random, size2) + blockPos.method_10263();
            int y = randomCoord(random, size2) + blockPos.method_10264();
            int z = randomCoord(random, size2) + blockPos.method_10260();
            if ((this.airCheck.get() == AirCheck.OFF || world.method_8320(new class_2338(x, y, z)).method_26225()) && shouldPlace(world, new class_2338(x, y, z), 1.0f, random)) {
                poses.add(new class_243(x, y, z));
            }
        }
        return poses;
    }

    private int randomCoord(class_2919 random, int size) {
        return Math.round((random.method_43057() - random.method_43057()) * size);
    }
}
