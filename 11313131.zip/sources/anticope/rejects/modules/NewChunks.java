package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.ColorSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1923;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2626;
import net.minecraft.class_2637;
import net.minecraft.class_2672;
import net.minecraft.class_2818;
import net.minecraft.class_2902;
import net.minecraft.class_3610;

public class NewChunks extends Module {
    private final SettingGroup sgGeneral;
    private final SettingGroup sgRender;
    private final Setting<Boolean> removeCache;
    public final Setting<Integer> renderHeight;
    private final Setting<ShapeMode> shapeMode;
    private final Setting<SettingColor> newChunksSideColor;
    private final Setting<SettingColor> oldChunksSideColor;
    private final Setting<SettingColor> newChunksLineColor;
    private final Setting<SettingColor> oldChunksLineColor;

    private final Set<class_1923> f155;

    private final Set<class_1923> f156;

    private static final class_2350[] f157 = {class_2350.field_11034, class_2350.field_11043, class_2350.field_11039, class_2350.field_11035, class_2350.field_11036};

    private final Executor f158;

    public NewChunks() {
        super(MeteorRejectsAddon.CATEGORY, "新区块检测", "通过区块的特定特征（如流体状态）检测完全新生成的区块，并用不同颜色渲染区分。");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.sgRender = this.settings.createGroup("渲染设置");
        this.removeCache = this.sgGeneral.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("清除缓存")).description("禁用模块时是否清除已缓存的区块数据。")).defaultValue(true)).build());
        this.renderHeight = this.sgRender.add(((IntSetting.Builder) ((IntSetting.Builder) ((IntSetting.Builder) new IntSetting.Builder().name("渲染高度")).description("新区块渲染时的垂直高度（从区块底部开始计算）。")).defaultValue(0)).min(-64).sliderRange(-64, 319).build());
        this.shapeMode = this.sgRender.add(((EnumSetting.Builder) ((EnumSetting.Builder) ((EnumSetting.Builder) new EnumSetting.Builder().name("形状模式")).description("区块的渲染方式（仅线框/仅填充/两者都显示）。")).defaultValue(ShapeMode.Both)).build());
        this.newChunksSideColor = this.sgRender.add(((ColorSetting.Builder) ((ColorSetting.Builder) ((ColorSetting.Builder) new ColorSetting.Builder().name("新区块填充色")).description("（大概率）完全新生成的区块的填充颜色。")).defaultValue(new SettingColor(255, 0, 0, 75)).visible(() -> {
            return this.shapeMode.get() == ShapeMode.Sides || this.shapeMode.get() == ShapeMode.Both;
        })).build());
        this.oldChunksSideColor = this.sgRender.add(((ColorSetting.Builder) ((ColorSetting.Builder) ((ColorSetting.Builder) new ColorSetting.Builder().name("旧区块填充色")).description("（大概率）之前已加载过的区块的填充颜色。")).defaultValue(new SettingColor(0, 255, 0, 75)).visible(() -> {
            return this.shapeMode.get() == ShapeMode.Sides || this.shapeMode.get() == ShapeMode.Both;
        })).build());
        this.newChunksLineColor = this.sgRender.add(((ColorSetting.Builder) ((ColorSetting.Builder) ((ColorSetting.Builder) new ColorSetting.Builder().name("新区块线框色")).description("（大概率）完全新生成的区块的线框颜色。")).defaultValue(new SettingColor(255, 0, 0, 255)).visible(() -> {
            return this.shapeMode.get() == ShapeMode.Lines || this.shapeMode.get() == ShapeMode.Both;
        })).build());
        this.oldChunksLineColor = this.sgRender.add(((ColorSetting.Builder) ((ColorSetting.Builder) ((ColorSetting.Builder) new ColorSetting.Builder().name("旧区块线框色")).description("（大概率）之前已加载过的区块的线框颜色。")).defaultValue(new SettingColor(0, 255, 0, 255)).visible(() -> {
            return this.shapeMode.get() == ShapeMode.Lines || this.shapeMode.get() == ShapeMode.Both;
        })).build());
        this.f155 = Collections.synchronizedSet(new HashSet());
        this.f156 = Collections.synchronizedSet(new HashSet());
        this.f158 = Executors.newSingleThreadExecutor();
    }

    public void onDeactivate() {
        if (((Boolean) this.removeCache.get()).booleanValue()) {
            this.f155.clear();
            this.f156.clear();
        }
        super.onDeactivate();
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        if (((SettingColor) this.newChunksLineColor.get()).a > 5 || ((SettingColor) this.newChunksSideColor.get()).a > 5) {
            synchronized (this.f155) {
                for (class_1923 class_1923Var : this.f155) {
                    if (this.mc.method_1560().method_24515().method_19771(class_1923Var.method_8323(), 1024.0d)) {
                        m144(new class_238(class_243.method_24954(class_1923Var.method_8323()), class_243.method_24954(class_1923Var.method_8323().method_10069(16, ((Integer) this.renderHeight.get()).intValue(), 16))), (Color) this.newChunksSideColor.get(), (Color) this.newChunksLineColor.get(), (ShapeMode) this.shapeMode.get(), event);
                    }
                }
            }
        }
        if (((SettingColor) this.oldChunksLineColor.get()).a > 5 || ((SettingColor) this.oldChunksSideColor.get()).a > 5) {
            synchronized (this.f156) {
                for (class_1923 class_1923Var2 : this.f156) {
                    if (this.mc.method_1560().method_24515().method_19771(class_1923Var2.method_8323(), 1024.0d)) {
                        m144(new class_238(class_243.method_24954(class_1923Var2.method_8323()), class_243.method_24954(class_1923Var2.method_8323().method_10069(16, ((Integer) this.renderHeight.get()).intValue(), 16))), (Color) this.oldChunksSideColor.get(), (Color) this.oldChunksLineColor.get(), (ShapeMode) this.shapeMode.get(), event);
                    }
                }
            }
        }
    }

    private void m144(class_238 class_238Var, Color color, Color color2, ShapeMode shapeMode, Render3DEvent event) {
        event.renderer.box(class_238Var.field_1323, class_238Var.field_1322, class_238Var.field_1321, class_238Var.field_1320, class_238Var.field_1325, class_238Var.field_1324, color, color2, shapeMode, 0);
    }

    @EventHandler
    private void onReadPacket(PacketEvent.Receive event) {
        if (event.packet instanceof class_2637) {
            event.packet.method_30621((class_2338Var, class_2680Var) -> {
                class_3610 class_3610VarMethod_26227 = class_2680Var.method_26227();
                if (!class_3610VarMethod_26227.method_15769() && !class_3610VarMethod_26227.method_15771()) {
                    class_1923 class_1923Var = new class_1923(class_2338Var);
                    for (class_2350 class_2350Var : f157) {
                        if (this.mc.field_1687.method_8320(class_2338Var.method_10093(class_2350Var)).method_26227().method_15771() && !this.f156.contains(class_1923Var)) {
                            this.f155.add(class_1923Var);
                            return;
                        }
                    }
                }
            });
            return;
        }
        if (event.packet instanceof class_2626) {
            class_2626 class_2626Var = event.packet;
            class_3610 class_3610VarMethod_26227 = class_2626Var.method_11308().method_26227();
            if (!class_3610VarMethod_26227.method_15769() && !class_3610VarMethod_26227.method_15771()) {
                class_1923 class_1923Var = new class_1923(class_2626Var.method_11309());
                for (class_2350 class_2350Var : f157) {
                    if (this.mc.field_1687.method_8320(class_2626Var.method_11309().method_10093(class_2350Var)).method_26227().method_15771() && !this.f156.contains(class_1923Var)) {
                        this.f155.add(class_1923Var);
                        return;
                    }
                }
                return;
            }
            return;
        }
        if ((event.packet instanceof class_2672) && this.mc.field_1687 != null) {
            class_2672 class_2672Var = event.packet;
            class_1923 class_1923Var2 = new class_1923(class_2672Var.method_11523(), class_2672Var.method_11524());
            if (!this.f155.contains(class_1923Var2) && this.mc.field_1687.method_2935().method_12246(class_2672Var.method_11523(), class_2672Var.method_11524()) == null) {
                class_2818 class_2818Var = new class_2818(this.mc.field_1687, class_1923Var2);
                try {
                    this.f158.execute(() -> {
                        class_2818Var.method_12224(class_2672Var.method_38598().method_38586(), new class_2487(), class_2672Var.method_38598().method_38587(class_2672Var.method_11523(), class_2672Var.method_11524()));
                    });
                    for (int x = 0; x < 16; x++) {
                        for (int z = 0; z < 16; z++) {
                            int iMethod_8624 = this.mc.field_1687.method_8624(class_2902.class_2903.field_13197, x, z);
                            for (int y = this.mc.field_1687.method_31607(); y < iMethod_8624; y++) {
                                class_3610 class_3610VarMethod_12234 = class_2818Var.method_12234(x, y, z);
                                if (!class_3610VarMethod_12234.method_15769() && !class_3610VarMethod_12234.method_15771()) {
                                    this.f156.add(class_1923Var2);
                                    return;
                                }
                            }
                        }
                    }
                } catch (ArrayIndexOutOfBoundsException e) {
                }
            }
        }
    }
}
