package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1935;
import net.minecraft.class_2873;
import net.minecraft.class_5819;
import net.minecraft.class_7923;

public class ItemGenerator extends Module {
    private final SettingGroup sgGeneral;
    private final Setting<Integer> speed;
    private final Setting<Integer> stackSize;

    private final class_5819 f148;

    public ItemGenerator() {
        super(MeteorRejectsAddon.CATEGORY, "物品生成器", "随机生成物品并将其掉落至地面（仅创造模式可用）。");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.speed = this.sgGeneral.add(((IntSetting.Builder) ((IntSetting.Builder) ((IntSetting.Builder) new IntSetting.Builder().name("生成速度")).description("每tick生成的物品堆叠数量（速度过高可能导致卡顿）。")).defaultValue(1)).min(1).max(36).sliderMax(36).build());
        this.stackSize = this.sgGeneral.add(((IntSetting.Builder) ((IntSetting.Builder) ((IntSetting.Builder) new IntSetting.Builder().name("堆叠数量")).description("每个物品堆叠中包含的物品数量（最大64，符合原版堆叠上限）。")).defaultValue(1)).min(1).max(64).sliderMax(64).build());
        this.f148 = class_5819.method_43047();
    }

    public void onActivate() {
        if (!this.mc.field_1724.method_31549().field_7477) {
            error("仅创造模式可用。", new Object[0]);
            toggle();
        }
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        int iIntValue = ((Integer) this.speed.get()).intValue();
        int iIntValue2 = ((Integer) this.stackSize.get()).intValue();
        for (int i = 9; i < 9 + iIntValue; i++) {
            this.mc.field_1724.field_3944.method_52787(new class_2873(i, new class_1799((class_1935) class_7923.field_41178.method_10240(this.f148).map((v0) -> {
                return v0.comp_349();
            }).orElse(class_1802.field_8831), iIntValue2)));
        }
        for (int i2 = 9; i2 < 9 + iIntValue; i2++) {
            InvUtils.drop().slot(i2);
        }
    }
}
