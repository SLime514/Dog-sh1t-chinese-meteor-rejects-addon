package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import java.util.List;
import java.util.Objects;
import meteordevelopment.meteorclient.events.game.OpenScreenEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.ItemListSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.network.MeteorExecutor;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1703;
import net.minecraft.class_1718;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1890;
import net.minecraft.class_636;
import net.minecraft.class_746;

public class AutoEnchant extends Module {
    public final SettingGroup sgGeneral;
    private final Setting<Integer> delay;
    private final Setting<Integer> level;
    private final Setting<Boolean> drop;
    private final Setting<List<class_1792>> itemWhitelist;

    public AutoEnchant() {
        super(MeteorRejectsAddon.CATEGORY, "自动附魔", "自动为物品进行附魔。");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.delay = this.sgGeneral.add(((IntSetting.Builder) ((IntSetting.Builder) ((IntSetting.Builder) new IntSetting.Builder().name("延迟")).description("物品附魔之间的tick延迟。")).defaultValue(50)).sliderMax(500).min(0).build());
        this.level = this.sgGeneral.add(((IntSetting.Builder) ((IntSetting.Builder) ((IntSetting.Builder) new IntSetting.Builder().name("附魔等级")).description("选择1-3级的附魔等级")).defaultValue(3)).max(3).min(1).build());
        this.drop = this.sgGeneral.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("自动丢弃")).description("自动丢弃附魔后的物品（在背包空间不足时很有用）")).defaultValue(false)).build());
        this.itemWhitelist = this.sgGeneral.add(((ItemListSetting.Builder) ((ItemListSetting.Builder) new ItemListSetting.Builder().name("物品白名单")).description("需要进行附魔的物品。")).defaultValue(new class_1792[0]).filter(item -> {
            return item.equals(class_1802.field_8529) || new class_1799(item).method_7963();
        }).build());
    }

    @EventHandler
    private void onOpenScreen(OpenScreenEvent event) {
        if (!(((class_746) Objects.requireNonNull(this.mc.field_1724)).field_7512 instanceof class_1718)) {
            return;
        }
        MeteorExecutor.execute(this::m73);
    }

    private void m73() throws InterruptedException {
        class_1718 class_1718Var = ((class_746) Objects.requireNonNull(this.mc.field_1724)).field_7512;
        if (!(class_1718Var instanceof class_1718)) {
            return;
        }
        class_1718 class_1718Var2 = class_1718Var;
        if (this.mc.field_1724.field_7520 < 30) {
            info("你的经验等级不足", new Object[0]);
            return;
        }
        while (true) {
            if (m76(class_1718Var2) > 2 || ((Boolean) this.drop.get()).booleanValue()) {
                if (!(this.mc.field_1724.field_7512 instanceof class_1718)) {
                    info("附魔台已关闭。", new Object[0]);
                    return;
                }
                if (class_1718Var2.method_7638() < ((Integer) this.level.get()).intValue() && !m75()) {
                    info("未找到青金石。", new Object[0]);
                    return;
                }
                if (!m74()) {
                    info("未找到可附魔的物品。", new Object[0]);
                    return;
                }
                ((class_636) Objects.requireNonNull(this.mc.field_1761)).method_2900(class_1718Var2.field_7763, ((Integer) this.level.get()).intValue() - 1);
                if (m76(class_1718Var2) > 2) {
                    InvUtils.shiftClick().slotId(0);
                } else if (((Boolean) this.drop.get()).booleanValue() && class_1718Var2.method_7611(0).method_7681()) {
                    this.mc.execute(() -> {
                        InvUtils.drop().slotId(0);
                    });
                }
                try {
                    Thread.sleep(((Integer) this.delay.get()).intValue());
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            } else {
                return;
            }
        }
    }

    private boolean m74() {
        FindItemResult findItemResultFind = InvUtils.find(stack -> {
            return ((List) this.itemWhitelist.get()).contains(stack.method_7909()) && class_1890.method_57529(stack);
        });
        if (!findItemResultFind.found()) {
            return false;
        }
        InvUtils.shiftClick().slot(findItemResultFind.slot());
        return true;
    }

    private boolean m75() {
        FindItemResult findItemResultFind = InvUtils.find(new class_1792[]{class_1802.field_8759});
        if (!findItemResultFind.found()) {
            return false;
        }
        InvUtils.shiftClick().slot(findItemResultFind.slot());
        return true;
    }

    private int m76(class_1703 class_1703Var) {
        int i = 0;
        for (int i2 = 0; i2 < class_1703Var.field_7761.size(); i2++) {
            if (((class_1735) class_1703Var.field_7761.get(i2)).method_7677().method_7909().equals(class_1802.field_8162)) {
                i++;
            }
        }
        return i;
    }
}
