package anticope.rejects.events;

import net.minecraft.class_1799;

public class StopUsingItemEvent {
    private static final StopUsingItemEvent INSTANCE = new StopUsingItemEvent();
    public class_1799 itemStack;

    public static StopUsingItemEvent get(class_1799 itemStack) {
        INSTANCE.itemStack = itemStack;
        return INSTANCE;
    }
}
