package anticope.rejects.events;

public class TeleportParticleEvent {
    private static final TeleportParticleEvent INSTANCE = new TeleportParticleEvent();

    public double f1x;

    public double f2y;

    public double f3z;

    public static TeleportParticleEvent get(double x, double y, double z) {
        INSTANCE.f1x = x;
        INSTANCE.f2y = y;
        INSTANCE.f3z = z;
        return INSTANCE;
    }
}
