package anticope.rejects.mixin;

import anticope.rejects.modules.SilentDisconnect;
import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import net.minecraft.class_2561;
import net.minecraft.class_8673;
import net.minecraft.class_9812;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_8673.class})
public class ClientCommonNetwokHandlerMixin {
    @Inject(method = {"onDisconnected"}, at = {@At("HEAD")}, cancellable = true)
    private void onDisconnected(class_9812 info, CallbackInfo ci) {
        if (Modules.get().isActive(SilentDisconnect.class) && MeteorClient.mc.field_1687 != null && MeteorClient.mc.field_1724 != null) {
            ChatUtils.info(class_2561.method_43471("disconnect.lost").getString() + ":", new Object[0]);
            ChatUtils.sendMsg(info.comp_2853());
            ci.cancel();
        }
    }
}
