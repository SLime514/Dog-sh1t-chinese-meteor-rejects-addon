package anticope.rejects.mixin;

import anticope.rejects.modules.Rendering;
import meteordevelopment.meteorclient.systems.modules.Modules;
import net.minecraft.class_2248;
import net.minecraft.class_2350;
import net.minecraft.class_2464;
import net.minecraft.class_2518;
import net.minecraft.class_2680;
import net.minecraft.class_4970;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({class_2518.class})
public abstract class StructureVoidBlockMixin extends class_2248 {
    public StructureVoidBlockMixin(class_4970.class_2251 settings) {
        super(settings);
    }

    @Inject(at = {@At("HEAD")}, method = {"getRenderType"}, cancellable = true)
    public void getRenderType(class_2680 state, CallbackInfoReturnable<class_2464> info) {
        info.setReturnValue(class_2464.field_11458);
    }

    public boolean method_9522(class_2680 state, class_2680 neighbor, class_2350 facing) {
        Rendering renderingModule = (Rendering) Modules.get().get(Rendering.class);
        return renderingModule == null || !renderingModule.renderStructureVoid();
    }
}
