package anticope.rejects.mixin;

import net.minecraft.class_4267;
import net.minecraft.class_500;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin({class_500.class})
public interface MultiplayerScreenAccessor {
    @Accessor("serverListWidget")
    class_4267 getServerListWidget();
}
