package anticope.rejects.mixin;

import anticope.rejects.gui.servers.ServerManagerScreen;
import meteordevelopment.meteorclient.gui.GuiThemes;
import net.minecraft.class_2561;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_500;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_500.class})
public abstract class MultiplayerScreenMixin extends class_437 {
    protected MultiplayerScreenMixin(class_2561 title) {
        super(title);
    }

    @Inject(method = {"init"}, at = {@At("TAIL")})
    private void onInit(CallbackInfo info) {
        method_37063(new class_4185.class_7840(class_2561.method_43470("Servers"), button -> {
            this.field_22787.method_1507(new ServerManagerScreen(GuiThemes.get(), (class_500) this));
        }).method_46437(75, 20).method_46433((((((this.field_22789 - 75) - 3) - 75) - 2) - 75) - 2, 3).method_46431());
    }
}
