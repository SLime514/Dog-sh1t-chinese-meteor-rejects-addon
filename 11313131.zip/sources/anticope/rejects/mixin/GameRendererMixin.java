package anticope.rejects.mixin;

import anticope.rejects.modules.Rendering;
import meteordevelopment.meteorclient.systems.modules.Modules;
import net.minecraft.class_279;
import net.minecraft.class_310;
import net.minecraft.class_757;
import net.minecraft.class_9779;
import net.minecraft.class_9920;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_757.class})
public class GameRendererMixin {

    @Shadow
    @Final
    class_310 field_4015;

    @Shadow
    @Final
    class_9920 field_53066;

    @Inject(method = {"render"}, at = {@At(value = "INVOKE", target = "Lnet/minecraft/client/render/WorldRenderer;drawEntityOutlinesFramebuffer()V", ordinal = 0)})
    private void renderShader(class_9779 tickCounter, boolean tick, CallbackInfo ci) {
        class_279 shader;
        Rendering renderingModule = (Rendering) Modules.get().get(Rendering.class);
        if (renderingModule != null && (shader = renderingModule.getShaderEffect()) != null) {
            shader.method_1258(this.field_4015.method_1522(), this.field_53066);
        }
    }
}
