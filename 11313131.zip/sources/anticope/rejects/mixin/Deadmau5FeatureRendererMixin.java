package anticope.rejects.mixin;

import anticope.rejects.modules.Rendering;
import meteordevelopment.meteorclient.systems.modules.Modules;
import net.minecraft.class_978;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin({class_978.class})
public class Deadmau5FeatureRendererMixin {
    @Redirect(method = {"render"}, at = @At(value = "INVOKE", target = "Ljava/lang/String;equals(Ljava/lang/Object;)Z"))
    private boolean redirectAllow(String s, Object name) {
        Rendering renderingModule = (Rendering) Modules.get().get(Rendering.class);
        if (renderingModule == null || !renderingModule.deadmau5EarsEnabled()) {
            return name.equals(s);
        }
        return true;
    }
}
