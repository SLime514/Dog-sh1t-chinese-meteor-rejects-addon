package anticope.rejects.mixin.meteor.modules;

import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.movement.Flight;
import net.minecraft.class_243;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({Flight.class})
public class FlightMixin {

    @Shadow(remap = false)
    @Final
    private SettingGroup sgGeneral;
    private Setting<Boolean> stopMomentum = null;

    @Inject(method = {"<init>"}, at = {@At("TAIL")}, remap = false)
    private void onInit(CallbackInfo ci) {
        this.stopMomentum = this.sgGeneral.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("stop-momentum")).description("Stops momentum on flight disable")).defaultValue(false)).build());
    }

    @Inject(method = {"onDeactivate"}, at = {@At("TAIL")}, remap = false)
    private void onDeactivate(CallbackInfo ci) {
        if (MeteorClient.mc.field_1724 == null || this.stopMomentum == null || !((Boolean) this.stopMomentum.get()).booleanValue()) {
            return;
        }
        MeteorClient.mc.field_1690.field_1894.method_23481(false);
        MeteorClient.mc.field_1690.field_1913.method_23481(false);
        MeteorClient.mc.field_1690.field_1881.method_23481(false);
        MeteorClient.mc.field_1690.field_1849.method_23481(false);
        MeteorClient.mc.field_1724.method_18799(class_243.field_1353);
    }
}
