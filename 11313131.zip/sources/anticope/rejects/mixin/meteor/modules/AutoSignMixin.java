package anticope.rejects.mixin.meteor.modules;

import java.util.Random;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import meteordevelopment.meteorclient.events.game.OpenScreenEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Category;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.world.AutoSign;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value = {AutoSign.class}, remap = false)
public class AutoSignMixin extends Module {
    private final SettingGroup sgGeneral;

    @Shadow
    private String[] text;
    private final Setting<Boolean> random;
    private final Setting<Integer> length;

    public AutoSignMixin(Category category, String name, String description) {
        super(category, name, description);
        this.sgGeneral = this.settings.getDefaultGroup();
        this.random = this.sgGeneral.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("random")).description("Spams trash text to make people lag.")).defaultValue(false)).build());
        this.length = this.sgGeneral.add(((IntSetting.Builder) ((IntSetting.Builder) ((IntSetting.Builder) new IntSetting.Builder().name("random-length")).description("Random character length.")).defaultValue(500)).min(1).sliderMax(1000).build());
    }

    @Inject(method = {"onOpenScreen"}, at = {@At(value = "INVOKE", target = "Lmeteordevelopment/meteorclient/mixin/AbstractSignEditScreenAccessor;getSign()Lnet/minecraft/block/entity/SignBlockEntity;")})
    private void beforeGetSign(OpenScreenEvent event, CallbackInfo info) {
        if (((Boolean) this.random.get()).booleanValue()) {
            this.text = new String[4];
            IntStream.range(0, this.text.length).forEach(i -> {
                IntStream chars = new Random().ints(0, 1114111);
                int amount = ((Integer) this.length.get()).intValue();
                this.text[i] = (String) chars.limit(amount * 5).mapToObj(i1 -> {
                    return String.valueOf((char) i1);
                }).collect(Collectors.joining());
            });
        }
    }
}
