package anticope.rejects.mixin.meteor;

import anticope.rejects.utils.accounts.CustomYggdrasilAccount;
import meteordevelopment.meteorclient.systems.accounts.Account;
import meteordevelopment.meteorclient.systems.accounts.Accounts;
import meteordevelopment.meteorclient.utils.misc.NbtException;
import net.minecraft.class_2487;
import net.minecraft.class_2520;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

@Mixin({Accounts.class})
public class AccountsMixin {
    @Inject(method = {"lambda$fromTag$0"}, at = {@At(value = "INVOKE", target = "Lnet/minecraft/nbt/NbtCompound;getString(Ljava/lang/String;)Ljava/lang/String;")}, locals = LocalCapture.CAPTURE_FAILHARD, cancellable = true)
    private static void onFromTag(class_2520 tag1, CallbackInfoReturnable<Account<?>> cir, class_2487 t) throws NbtException {
        if (t.method_10558("type").equals("Yggdrasil")) {
            Account<CustomYggdrasilAccount> account = new CustomYggdrasilAccount(null, null, null).m199fromTag(t);
            if (account.fetchInfo()) {
                cir.setReturnValue(account);
            }
        }
    }
}
