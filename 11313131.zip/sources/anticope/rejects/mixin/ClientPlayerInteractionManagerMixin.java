package anticope.rejects.mixin;

import anticope.rejects.events.StopUsingItemEvent;
import meteordevelopment.meteorclient.MeteorClient;
import net.minecraft.class_1657;
import net.minecraft.class_636;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_636.class})
public class ClientPlayerInteractionManagerMixin {
    @Inject(method = {"stopUsingItem"}, at = {@At("HEAD")})
    public void onStopUsingItem(class_1657 player, CallbackInfo ci) {
        MeteorClient.EVENT_BUS.post(StopUsingItemEvent.get(player.method_31548().method_7391()));
    }
}
