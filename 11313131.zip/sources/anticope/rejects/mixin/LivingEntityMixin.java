package anticope.rejects.mixin;

import anticope.rejects.events.TeleportParticleEvent;
import meteordevelopment.meteorclient.MeteorClient;
import net.minecraft.class_1309;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_1309.class})
public class LivingEntityMixin {
    @Inject(method = {"handleStatus"}, at = {@At("HEAD")})
    private void onHandleStatus(byte status, CallbackInfo ci) {
        if (this == MeteorClient.mc.field_1724 && status == 46) {
            MeteorClient.EVENT_BUS.post(TeleportParticleEvent.get(MeteorClient.mc.field_1724.method_23317(), MeteorClient.mc.field_1724.method_23318(), MeteorClient.mc.field_1724.method_23321()));
        }
    }
}
