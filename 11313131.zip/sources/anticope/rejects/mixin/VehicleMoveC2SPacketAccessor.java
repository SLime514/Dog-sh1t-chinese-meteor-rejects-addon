package anticope.rejects.mixin;

import net.minecraft.class_243;
import net.minecraft.class_2833;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin({class_2833.class})
public interface VehicleMoveC2SPacketAccessor {
    @Accessor("position")
    class_243 getPosition();

    @Invoker("<init>")
    static class_2833 create(class_243 position, float yaw, float pitch, boolean onGround) {
        throw new AssertionError();
    }
}
