package anticope.rejects.mixin;

import anticope.rejects.modules.Rendering;
import meteordevelopment.meteorclient.systems.modules.Modules;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10042;
import net.minecraft.class_10055;
import net.minecraft.class_1309;
import net.minecraft.class_4587;
import net.minecraft.class_583;
import net.minecraft.class_7833;
import net.minecraft.class_922;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_922.class})
@Environment(EnvType.CLIENT)
public class LivingEntityRendererMixin<T extends class_1309, S extends class_10042, M extends class_583<? super S>> {
    @Inject(method = {"setupTransforms"}, at = {@At("TAIL")})
    private void dinnerboneEntities(S state, class_4587 matrices, float animationProgress, float bodyYaw, CallbackInfo ci) {
        Rendering renderingModule = (Rendering) Modules.get().get(Rendering.class);
        if (renderingModule != null && !(state instanceof class_10055) && renderingModule.dinnerboneEnabled()) {
            matrices.method_22904(0.0d, ((class_10042) state).field_53330 + 0.1f, 0.0d);
            matrices.method_22907(class_7833.field_40718.rotationDegrees(180.0f));
        }
    }
}
