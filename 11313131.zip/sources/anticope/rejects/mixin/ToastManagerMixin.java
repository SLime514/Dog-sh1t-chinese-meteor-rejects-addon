package anticope.rejects.mixin;

import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.systems.modules.render.NoRender;
import net.minecraft.class_368;
import net.minecraft.class_374;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_374.class})
public class ToastManagerMixin {
    @Inject(method = {"add"}, at = {@At("HEAD")}, cancellable = true)
    public void preventAdd(class_368 toast, CallbackInfo ci) {
        if (Modules.get().get(NoRender.class).disableToasts()) {
            ci.cancel();
        }
    }
}
