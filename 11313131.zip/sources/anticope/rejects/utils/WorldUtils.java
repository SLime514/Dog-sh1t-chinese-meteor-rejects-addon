package anticope.rejects.utils;

import java.util.ArrayList;
import java.util.List;
import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.player.Rotations;
import net.minecraft.class_1268;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_3965;

public class WorldUtils {
    public static List<class_2338> getSphere(class_2338 centerPos, int radius, int height) {
        ArrayList<class_2338> blocks = new ArrayList<>();
        for (int i = centerPos.method_10263() - radius; i < centerPos.method_10263() + radius; i++) {
            for (int j = centerPos.method_10264() - height; j < centerPos.method_10264() + height; j++) {
                for (int k = centerPos.method_10260() - radius; k < centerPos.method_10260() + radius; k++) {
                    class_2338 pos = new class_2338(i, j, k);
                    if (distanceBetween(centerPos, pos) <= radius && !blocks.contains(pos)) {
                        blocks.add(pos);
                    }
                }
            }
        }
        return blocks;
    }

    public static double distanceBetween(class_2338 pos1, class_2338 pos2) {
        double d = pos1.method_10263() - pos2.method_10263();
        double e = pos1.method_10264() - pos2.method_10264();
        double f = pos1.method_10260() - pos2.method_10260();
        return class_3532.method_15355((float) ((d * d) + (e * e) + (f * f)));
    }

    public static boolean interact(class_2338 pos, FindItemResult findItemResult, boolean rotate) {
        if (!findItemResult.found()) {
            return false;
        }
        Runnable action = () -> {
            boolean wasSneaking = MeteorClient.mc.field_1724.method_5715();
            MeteorClient.mc.field_1724.method_5660(false);
            InvUtils.swap(findItemResult.slot(), true);
            MeteorClient.mc.field_1761.method_2896(MeteorClient.mc.field_1724, class_1268.field_5808, new class_3965(class_243.method_24953(pos), class_2350.field_11036, pos, false));
            MeteorClient.mc.field_1724.method_6104(class_1268.field_5808);
            InvUtils.swapBack();
            MeteorClient.mc.field_1724.method_5660(wasSneaking);
        };
        if (!rotate) {
            action.run();
            return true;
        }
        Rotations.rotate(Rotations.getYaw(pos), Rotations.getPitch(pos), -100, action);
        return true;
    }
}
