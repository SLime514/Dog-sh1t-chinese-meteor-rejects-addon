package anticope.rejects.utils.server;

public interface IServerFinderDoneListener {
    void onServerDone(ServerPinger serverPinger);

    void onServerFailed(ServerPinger serverPinger);
}
