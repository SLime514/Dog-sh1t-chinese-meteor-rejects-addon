package anticope.rejects.utils.server;

public class IPAddress {
    private final int[] octets;
    private final int port;
    static final boolean $assertionsDisabled;

    static {
        $assertionsDisabled = !IPAddress.class.desiredAssertionStatus();
    }

    public IPAddress(int o1, int o2, int o3, int o4, int port) {
        this.octets = new int[]{o1, o2, o3, o4};
        this.port = port;
    }

    public IPAddress(int[] octets, int port) {
        this.octets = octets;
        this.port = port;
    }

    public static IPAddress fromText(String ip) throws NumberFormatException {
        String[] sections = ip.split(":");
        if (sections.length < 1 || sections.length > 2) {
            return null;
        }
        int port = 25565;
        if (sections.length == 2) {
            try {
                port = Integer.parseInt(sections[1].trim());
            } catch (NumberFormatException e) {
                return null;
            }
        }
        int[] octets = new int[4];
        String[] address = sections[0].trim().split("\\.");
        if (address.length != 4) {
            return null;
        }
        for (int i = 0; i < 4; i++) {
            try {
                octets[i] = Integer.parseInt(address[i].trim());
            } catch (NumberFormatException e2) {
                return null;
            }
        }
        return new IPAddress(octets, port);
    }

    public boolean equals(Object o) {
        if (!(o instanceof IPAddress)) {
            return false;
        }
        IPAddress other = (IPAddress) o;
        if (this.octets.length != other.octets.length || this.port != other.port) {
            return false;
        }
        for (int i = 0; i < this.octets.length; i++) {
            if (this.octets[i] != other.octets[i]) {
                return false;
            }
        }
        return true;
    }

    public int hashCode() {
        if (!$assertionsDisabled && this.octets.length != 4) {
            throw new AssertionError();
        }
        int hash = (43 * 59) + this.octets[0];
        return (((((((hash * 83) + this.octets[1]) * 71) + this.octets[2]) * 17) + this.octets[3]) * 31) + this.port;
    }

    public String toString() {
        if (this.octets.length == 0) {
            return null;
        }
        StringBuilder result = new StringBuilder();
        result.append(this.octets[0]);
        for (int i = 1; i < this.octets.length; i++) {
            result.append('.').append(this.octets[i]);
        }
        result.append(':').append(this.port);
        return result.toString();
    }
}
