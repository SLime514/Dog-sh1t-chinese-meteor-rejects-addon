package anticope.rejects.utils.server;

import java.util.Collections;
import java.util.List;
import net.minecraft.class_155;
import net.minecraft.class_2561;

public class MServerInfo {
    public String name;
    public String address;
    public String playerCountLabel;
    public int playerCount;
    public int playercountMax;
    public String label;
    public long ping;
    public int protocolVersion = class_155.method_16673().method_48020();
    public String version = null;
    public List<class_2561> playerListSummary = Collections.emptyList();
    private byte[] icon;

    public MServerInfo(String name, String address) {
        this.name = name;
        this.address = address;
    }

    public byte[] getIcon() {
        return this.icon;
    }

    public void setIcon(byte[] bytes) {
        this.icon = bytes;
    }
}
