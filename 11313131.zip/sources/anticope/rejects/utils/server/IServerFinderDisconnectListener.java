package anticope.rejects.utils.server;

public interface IServerFinderDisconnectListener {
    void onServerDisconnect();

    void onServerFailed();
}
