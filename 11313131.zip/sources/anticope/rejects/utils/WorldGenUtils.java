package anticope.rejects.utils;

import anticope.rejects.utils.seeds.Seed;
import anticope.rejects.utils.seeds.Seeds;
import baritone.api.BaritoneAPI;
import com.seedfinding.mcbiome.source.BiomeSource;
import com.seedfinding.mccore.nbt.NBTType;
import com.seedfinding.mccore.rand.ChunkRand;
import com.seedfinding.mccore.state.Dimension;
import com.seedfinding.mccore.util.data.SpiralIterator;
import com.seedfinding.mccore.util.pos.BPos;
import com.seedfinding.mccore.util.pos.CPos;
import com.seedfinding.mccore.util.pos.RPos;
import com.seedfinding.mccore.version.MCVersion;
import com.seedfinding.mcfeature.Feature;
import com.seedfinding.mcfeature.misc.SlimeChunk;
import com.seedfinding.mcfeature.structure.BastionRemnant;
import com.seedfinding.mcfeature.structure.BuriedTreasure;
import com.seedfinding.mcfeature.structure.DesertPyramid;
import com.seedfinding.mcfeature.structure.EndCity;
import com.seedfinding.mcfeature.structure.Fortress;
import com.seedfinding.mcfeature.structure.Mansion;
import com.seedfinding.mcfeature.structure.Mineshaft;
import com.seedfinding.mcfeature.structure.Monument;
import com.seedfinding.mcfeature.structure.RegionStructure;
import com.seedfinding.mcfeature.structure.Stronghold;
import com.seedfinding.mcfeature.structure.Structure;
import com.seedfinding.mcfeature.structure.Village;
import com.seedfinding.mcterrain.TerrainGenerator;
import cubitect.Cubiomes;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.stream.StreamSupport;
import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1439;
import net.minecraft.class_1545;
import net.minecraft.class_1550;
import net.minecraft.class_1564;
import net.minecraft.class_1577;
import net.minecraft.class_1606;
import net.minecraft.class_1621;
import net.minecraft.class_1639;
import net.minecraft.class_1646;
import net.minecraft.class_1694;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_5419;
import net.minecraft.class_9292;
import net.minecraft.class_9334;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class WorldGenUtils {
    private static final Logger LOG = LogManager.getLogger();
    private static final HashMap<Feature, List<class_2248>> FEATURE_BLOCKS = new HashMap<Feature, List<class_2248>>() {
        {
            put(Feature.nether_fortress, Arrays.asList(class_2246.field_10266, class_2246.field_10364, class_2246.field_9974));
            put(Feature.ocean_monument, Arrays.asList(class_2246.field_10006, class_2246.field_10174, class_2246.field_10297));
            put(Feature.stronghold, Arrays.asList(class_2246.field_10398, class_2246.field_10027));
            put(Feature.end_city, Arrays.asList(class_2246.field_10286, class_2246.field_10505, class_2246.field_9992, class_2246.field_10455));
            put(Feature.village, Arrays.asList(class_2246.field_16332, class_2246.field_10333, class_2246.field_16334, class_2246.field_16333, class_2246.field_16331, class_2246.field_16335, class_2246.field_10083, class_2246.field_16337, class_2246.field_16330));
            put(Feature.mineshaft, Collections.singletonList(class_2246.field_10167));
            put(Feature.desert_pyramid, Arrays.asList(class_2246.field_10375, class_2246.field_10292, class_2246.field_10158));
        }
    };
    private static final HashMap<Feature, List<Class<? extends class_1297>>> FEATURE_ENTITIES = new HashMap<Feature, List<Class<? extends class_1297>>>() {
        {
            put(Feature.ocean_monument, Arrays.asList(class_1550.class, class_1577.class));
            put(Feature.nether_fortress, Arrays.asList(class_1545.class, class_1639.class));
            put(Feature.mansion, Collections.singletonList(class_1564.class));
            put(Feature.slime_chunk, Collections.singletonList(class_1621.class));
            put(Feature.bastion_remnant, Collections.singletonList(class_5419.class));
            put(Feature.end_city, Collections.singletonList(class_1606.class));
            put(Feature.village, Arrays.asList(class_1646.class, class_1439.class));
            put(Feature.mineshaft, Collections.singletonList(class_1694.class));
        }
    };

    public enum Feature {
        buried_treasure,
        mansion,
        stronghold,
        nether_fortress,
        ocean_monument,
        bastion_remnant,
        end_city,
        village,
        mineshaft,
        slime_chunk,
        desert_pyramid
    }

    public static class_2338 locateFeature(Cubiomes.StructureType cfeature, class_2338 center) {
        Feature feature;
        switch (C00123.$SwitchMap$cubitect$Cubiomes$StructureType[cfeature.ordinal()]) {
            case 1:
                feature = Feature.buried_treasure;
                break;
            case NBTType.SHORT:
                feature = Feature.mansion;
                break;
            case 3:
                feature = Feature.stronghold;
                break;
            case 4:
                feature = Feature.nether_fortress;
                break;
            case NBTType.FLOAT:
                feature = Feature.ocean_monument;
                break;
            case 6:
                feature = Feature.bastion_remnant;
                break;
            case NBTType.BYTE_ARRAY:
                feature = Feature.end_city;
                break;
            case 8:
                feature = Feature.village;
                break;
            case 9:
                feature = Feature.mineshaft;
                break;
            case NBTType.COMPOUND:
                feature = Feature.desert_pyramid;
                break;
            default:
                feature = null;
                break;
        }
        Feature feature2 = feature;
        Seed seed = Seeds.get().getSeed();
        class_2338 pos = null;
        if (!checkIfInDimension(getDimension(feature2))) {
            return null;
        }
        if (seed != null) {
            try {
                pos = locateFeature(seed, feature2, center);
            } catch (Error | Exception ex) {
                LOG.error(ex);
            }
            if (pos != null) {
                return pos;
            }
        }
        if (MeteorClient.mc.field_1724 != null) {
            class_1799 stack = MeteorClient.mc.field_1724.method_5998(class_1268.field_5808);
            if (stack.method_7909() != class_1802.field_8204) {
                stack = MeteorClient.mc.field_1724.method_5998(class_1268.field_5810);
            }
            if (stack.method_7909() == class_1802.field_8204) {
                try {
                    pos = locateFeatureMap(feature2, stack);
                } catch (Error | Exception ex2) {
                    LOG.error(ex2);
                }
                if (pos != null) {
                    return pos;
                }
            }
        }
        try {
            pos = locateFeatureEntities(feature2);
        } catch (Error | Exception ex3) {
            LOG.error(ex3);
        }
        if (pos != null) {
            return pos;
        }
        try {
            pos = locateFeatureBlocks(feature2);
        } catch (Error | Exception ex4) {
            LOG.error(ex4);
        }
        return pos;
    }

    private static class_2338 locateFeatureMap(Feature feature, class_1799 stack) {
        if (isValidMap(feature, stack)) {
            return getMapMarker(stack);
        }
        return null;
    }

    private static class_2338 locateFeatureBlocks(Feature feature) {
        List<class_2248> blocks = FEATURE_BLOCKS.get(feature);
        if (blocks == null) {
            return null;
        }
        List<class_2338> posList = BaritoneAPI.getProvider().getWorldScanner().scanChunkRadius(BaritoneAPI.getProvider().getPrimaryBaritone().getPlayerContext(), blocks, 64, 10, 32);
        if (posList.isEmpty()) {
            return null;
        }
        if (posList.size() < 5) {
            ChatUtils.warningPrefix("Locate", "Only %d block(s) found. This search might be a false positive.", new Object[]{Integer.valueOf(posList.size())});
        }
        return posList.get(0);
    }

    private static class_2338 locateFeatureEntities(Feature feature) {
        List<Class<? extends class_1297>> entities = FEATURE_ENTITIES.get(feature);
        if (entities == null || MeteorClient.mc.field_1687 == null) {
            return null;
        }
        for (class_1297 e : MeteorClient.mc.field_1687.method_18112()) {
            for (Class<? extends class_1297> clazz : entities) {
                if (clazz.isInstance(e)) {
                    return e.method_24515();
                }
            }
        }
        return null;
    }

    private static class_2338 locateFeature(Seed seed, Feature feature, class_2338 center) {
        return feature == Feature.slime_chunk ? locateSlimeChunk(seed, center) : locateStructure(seed, feature, center);
    }

    private static class_2338 locateSlimeChunk(Seed seed, class_2338 center) {
        Dimension dimension = getDimension(Feature.slime_chunk);
        MCVersion mcVersion = seed.version;
        CPos centerChunk = new CPos(center.method_10263() >> 4, center.method_10260() >> 4);
        CPos slimeChunkPos = locateSlimeChunk(new SlimeChunk(mcVersion), centerChunk, 6400, seed.seed.longValue(), new ChunkRand(), dimension);
        if (slimeChunkPos == null) {
            return null;
        }
        return toBlockPos(slimeChunkPos.toBlockPos());
    }

    private static CPos locateSlimeChunk(SlimeChunk slimeChunk, CPos centerChunk, int radius, long seed, ChunkRand rand, Dimension dimension) {
        if (!slimeChunk.isValidDimension(dimension)) {
            return null;
        }
        SpiralIterator<CPos> spiralIterator = new SpiralIterator<>(centerChunk, new CPos(radius, radius), (x, y, z) -> {
            return new CPos(x, z);
        });
        Iterator it = spiralIterator.iterator();
        while (it.hasNext()) {
            CPos next = (CPos) it.next();
            SlimeChunk.Data data = slimeChunk.m13at(next.getX(), next.getZ(), true);
            if (data.testStart(seed, rand)) {
                return next;
            }
        }
        return null;
    }

    private static class_2338 locateStructure(Seed seed, Feature feature, class_2338 center) {
        MCVersion mcVersion;
        Structure<?, ?> structure;
        BPos structurePos;
        Dimension dimension = getDimension(feature);
        if ((dimension == Dimension.OVERWORLD && seed.version.isNewerThan(MCVersion.v1_18)) || (structure = getStructure(feature, (mcVersion = seed.version))) == null) {
            return null;
        }
        BiomeSource biomeSource = BiomeSource.m8of(dimension, mcVersion, seed.seed.longValue());
        if (structure.isValidDimension(biomeSource.getDimension()) && (structurePos = locateStructure(structure, new BPos(center.method_10263(), center.method_10264(), center.method_10260()), 6400, new ChunkRand(), biomeSource, TerrainGenerator.m42of(biomeSource))) != null) {
            return toBlockPos(structurePos);
        }
        return null;
    }

    private static BPos locateStructure(Structure<?, ?> structure, BPos center, int radius, ChunkRand chunkRand, BiomeSource source, TerrainGenerator terrainGenerator) {
        if (structure instanceof RegionStructure) {
            RegionStructure<?, ?> regionStructure = (RegionStructure) structure;
            int chunkInRegion = regionStructure.getSpacing();
            int regionSize = chunkInRegion * 16;
            SpiralIterator<RPos> spiralIterator = new SpiralIterator<>(center.toRegionPos(regionSize), new BPos(-30000000, 0, -30000000).toRegionPos(regionSize), new BPos(30000000, 0, 30000000).toRegionPos(regionSize), 1, (x, y, z) -> {
                return new RPos(x, z, regionSize);
            });
            return (BPos) StreamSupport.stream(spiralIterator.spliterator(), false).map(rPos -> {
                return regionStructure.getInRegion(source.getWorldSeed(), rPos.getX(), rPos.getZ(), chunkRand);
            }).filter((v0) -> {
                return Objects.nonNull(v0);
            }).filter(cPos -> {
                return regionStructure.canSpawn(cPos, source) && (terrainGenerator == null || regionStructure.canGenerate(cPos, terrainGenerator));
            }).findAny().map(cPos2 -> {
                return cPos2.toBlockPos().add(9, 0, 9);
            }).orElse(null);
        }
        if (structure instanceof Stronghold) {
            Stronghold strongholdStructure = (Stronghold) structure;
            CPos currentChunkPos = center.toChunkPos();
            int squaredDistance = Integer.MAX_VALUE;
            CPos closest = new CPos(0, 0);
            for (CPos stronghold : strongholdStructure.getAllStarts(source, chunkRand)) {
                int newSquaredDistance = ((currentChunkPos.getX() - stronghold.getX()) * (currentChunkPos.getX() - stronghold.getX())) + ((currentChunkPos.getZ() - stronghold.getZ()) * (currentChunkPos.getZ() - stronghold.getZ()));
                if (newSquaredDistance < squaredDistance) {
                    squaredDistance = newSquaredDistance;
                    closest = stronghold;
                }
            }
            BPos dimPos = closest.toBlockPos().add(9, 0, 9);
            return new BPos(dimPos.getX(), 0, dimPos.getZ());
        }
        if (structure instanceof Mineshaft) {
            Mineshaft mineshaft = (Mineshaft) structure;
            SpiralIterator<CPos> spiralIterator2 = new SpiralIterator<>(new CPos(center.getX() >> 4, center.getZ() >> 4), new CPos(radius, radius), (x2, y2, z2) -> {
                return new CPos(x2, z2);
            });
            return (BPos) StreamSupport.stream(spiralIterator2.spliterator(), false).filter(cPos3 -> {
                Feature.Data<Mineshaft> data = mineshaft.m15at(cPos3.getX(), cPos3.getZ());
                return data.testStart(source.getWorldSeed(), chunkRand) && data.testBiome(source) && data.testGenerate(terrainGenerator);
            }).findAny().map(cPos4 -> {
                return cPos4.toBlockPos().add(9, 0, 9);
            }).orElse(null);
        }
        return null;
    }

    private static Dimension getDimension(Feature feature) {
        switch (feature.ordinal()) {
        }
        return Dimension.OVERWORLD;
    }

    static class C00123 {
        static final int[] $SwitchMap$cubitect$Cubiomes$StructureType;
        static final int[] $SwitchMap$com$seedfinding$mccore$state$Dimension = new int[Dimension.values().length];

        static {
            try {
                $SwitchMap$com$seedfinding$mccore$state$Dimension[Dimension.OVERWORLD.ordinal()] = 1;
            } catch (NoSuchFieldError e) {
            }
            try {
                $SwitchMap$com$seedfinding$mccore$state$Dimension[Dimension.NETHER.ordinal()] = 2;
            } catch (NoSuchFieldError e2) {
            }
            try {
                $SwitchMap$com$seedfinding$mccore$state$Dimension[Dimension.END.ordinal()] = 3;
            } catch (NoSuchFieldError e3) {
            }
            $SwitchMap$cubitect$Cubiomes$StructureType = new int[Cubiomes.StructureType.values().length];
            try {
                $SwitchMap$cubitect$Cubiomes$StructureType[Cubiomes.StructureType.Treasure.ordinal()] = 1;
            } catch (NoSuchFieldError e4) {
            }
            try {
                $SwitchMap$cubitect$Cubiomes$StructureType[Cubiomes.StructureType.Mansion.ordinal()] = 2;
            } catch (NoSuchFieldError e5) {
            }
            try {
                $SwitchMap$cubitect$Cubiomes$StructureType[Cubiomes.StructureType.Stronghold.ordinal()] = 3;
            } catch (NoSuchFieldError e6) {
            }
            try {
                $SwitchMap$cubitect$Cubiomes$StructureType[Cubiomes.StructureType.Fortress.ordinal()] = 4;
            } catch (NoSuchFieldError e7) {
            }
            try {
                $SwitchMap$cubitect$Cubiomes$StructureType[Cubiomes.StructureType.Monument.ordinal()] = 5;
            } catch (NoSuchFieldError e8) {
            }
            try {
                $SwitchMap$cubitect$Cubiomes$StructureType[Cubiomes.StructureType.Bastion.ordinal()] = 6;
            } catch (NoSuchFieldError e9) {
            }
            try {
                $SwitchMap$cubitect$Cubiomes$StructureType[Cubiomes.StructureType.End_City.ordinal()] = 7;
            } catch (NoSuchFieldError e10) {
            }
            try {
                $SwitchMap$cubitect$Cubiomes$StructureType[Cubiomes.StructureType.Village.ordinal()] = 8;
            } catch (NoSuchFieldError e11) {
            }
            try {
                $SwitchMap$cubitect$Cubiomes$StructureType[Cubiomes.StructureType.Mineshaft.ordinal()] = 9;
            } catch (NoSuchFieldError e12) {
            }
            try {
                $SwitchMap$cubitect$Cubiomes$StructureType[Cubiomes.StructureType.Desert_Pyramid.ordinal()] = 10;
            } catch (NoSuchFieldError e13) {
            }
        }
    }

    private static boolean checkIfInDimension(Dimension dimension) throws MatchException {
        switch (C00123.$SwitchMap$com$seedfinding$mccore$state$Dimension[dimension.ordinal()]) {
            case 1:
                return PlayerUtils.getDimension() == meteordevelopment.meteorclient.utils.world.Dimension.Overworld;
            case NBTType.SHORT:
                return PlayerUtils.getDimension() == meteordevelopment.meteorclient.utils.world.Dimension.Nether;
            case 3:
                return PlayerUtils.getDimension() == meteordevelopment.meteorclient.utils.world.Dimension.End;
            default:
                throw new MatchException((String) null, (Throwable) null);
        }
    }

    private static Structure<?, ?> getStructure(Feature feature, MCVersion version) {
        switch (feature.ordinal()) {
            case 0:
                return new BuriedTreasure(version);
            case 1:
                return new Mansion(version);
            case NBTType.SHORT:
                return new Stronghold(version);
            case 3:
                return new Fortress(version);
            case 4:
                return new Monument(version);
            case NBTType.FLOAT:
                return new BastionRemnant(version);
            case 6:
                return new EndCity(version);
            case NBTType.BYTE_ARRAY:
                return new Village(version);
            case 8:
                return new Mineshaft(version);
            case 9:
            default:
                return null;
            case NBTType.COMPOUND:
                return new DesertPyramid(version);
        }
    }

    private static class_2338 toBlockPos(BPos pos) {
        return new class_2338(pos.getX(), pos.getY(), pos.getZ());
    }

    private static boolean isValidMap(Feature feature, class_1799 stack) {
        if (stack.method_57353().method_57837() || !stack.method_57353().method_57832(class_9334.field_49647)) {
            return false;
        }
        class_9292 displayTag = (class_9292) stack.method_58658().method_57829(class_9334.field_49647);
        if (!displayTag.toString().contains("Name")) {
            return false;
        }
        String nameTag = String.valueOf(displayTag.comp_2404().get("Name"));
        if (!nameTag.contains("translate")) {
            return false;
        }
        if (feature == Feature.buried_treasure) {
            return nameTag.contains("filled_map.buried_treasure");
        }
        if (feature == Feature.ocean_monument) {
            return nameTag.contains("filled_map.monument");
        }
        if (feature == Feature.mansion) {
            return nameTag.contains("filled_map.mansion");
        }
        return false;
    }

    private static class_2338 getMapMarker(class_1799 stack) {
        if (stack.method_57353().method_57837() || !stack.method_58658().method_57832(class_9334.field_49647)) {
            return null;
        }
        class_9292 decorationsTag = (class_9292) stack.method_57824(class_9334.field_49647);
        if (decorationsTag.comp_2404().isEmpty()) {
            return null;
        }
        class_9292.class_9293 iconTag = (class_9292.class_9293) decorationsTag.comp_2404().get(0);
        return new class_2338((int) iconTag.comp_2406(), 0, (int) iconTag.comp_2407());
    }
}
