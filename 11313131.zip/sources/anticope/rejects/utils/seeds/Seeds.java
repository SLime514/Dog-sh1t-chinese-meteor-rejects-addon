package anticope.rejects.utils.seeds;

import anticope.rejects.events.SeedChangedEvent;
import com.seedfinding.mccore.version.MCVersion;
import java.util.HashMap;
import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.systems.System;
import meteordevelopment.meteorclient.systems.config.Config;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import net.minecraft.class_124;
import net.minecraft.class_2487;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2568;
import net.minecraft.class_5250;
import net.minecraft.class_642;

public class Seeds extends System<Seeds> {
    private static final Seeds INSTANCE = new Seeds();
    public HashMap<String, Seed> seeds;

    public Seeds() {
        super("seeds");
        this.seeds = new HashMap<>();
        init();
        load(MeteorClient.FOLDER);
    }

    public static Seeds get() {
        return INSTANCE;
    }

    public Seed getSeed() {
        if (MeteorClient.mc.method_1496() && MeteorClient.mc.method_1576() != null) {
            MCVersion version = MCVersion.fromString(MeteorClient.mc.method_1576().method_3827());
            if (version == null) {
                version = MCVersion.latest();
            }
            return new Seed(Long.valueOf(MeteorClient.mc.method_1576().method_30002().method_8412()), version);
        }
        return this.seeds.get(Utils.getWorldName());
    }

    public void setSeed(String seed, MCVersion version) {
        if (MeteorClient.mc.method_1496()) {
            return;
        }
        long numSeed = toSeed(seed);
        this.seeds.put(Utils.getWorldName(), new Seed(Long.valueOf(numSeed), version));
        MeteorClient.EVENT_BUS.post(SeedChangedEvent.get(numSeed));
    }

    public void setSeed(String seed) {
        if (MeteorClient.mc.method_1496()) {
            return;
        }
        class_642 server = MeteorClient.mc.method_1558();
        MCVersion ver = null;
        if (server != null) {
            ver = MCVersion.fromString(server.field_3760.getString());
        }
        if (ver == null) {
            String targetVer = server != null ? server.field_3760.getString() : "unknown";
            sendInvalidVersionWarning(seed, targetVer);
            ver = MCVersion.latest();
        }
        setSeed(seed, ver);
    }

    public class_2487 toTag() {
        class_2487 tag = new class_2487();
        this.seeds.forEach((key, seed) -> {
            if (seed == null) {
                return;
            }
            tag.method_10566(key, seed.toTag());
        });
        return tag;
    }

    public Seeds m204fromTag(class_2487 tag) {
        tag.method_10541().forEach(key -> {
            this.seeds.put(key, Seed.fromTag(tag.method_10562(key)));
        });
        return this;
    }

    private static long toSeed(String inSeed) {
        try {
            return Long.parseLong(inSeed);
        } catch (NumberFormatException e) {
            return inSeed.strip().hashCode();
        }
    }

    private static void sendInvalidVersionWarning(String seed, String targetVer) {
        class_5250 msg = class_2561.method_43470(String.format("Couldn't resolve minecraft version \"%s\". Using %s instead. If you wish to change the version run: ", targetVer, MCVersion.latest().name));
        String cmd = String.format("%sseed %s ", Config.get().prefix, seed);
        class_5250 cmdText = class_2561.method_43470(cmd + "<version>");
        cmdText.method_10862(cmdText.method_10866().method_30938(true).method_10958(new class_2558(class_2558.class_2559.field_11745, cmd)).method_10949(new class_2568(class_2568.class_5247.field_24342, class_2561.method_43470("run command"))));
        msg.method_10852(cmdText);
        msg.method_10862(msg.method_10866().method_10977(class_124.field_1054));
        ChatUtils.sendMsg("Seed", msg);
    }
}
