package anticope.rejects.utils;

import anticope.rejects.mixin.CountPlacementModifierAccessor;
import anticope.rejects.mixin.HeightRangePlacementModifierAccessor;
import anticope.rejects.mixin.RarityFilterPlacementModifierAccessor;
import com.seedfinding.mccore.nbt.NBTType;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Stream;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.world.Dimension;
import net.minecraft.class_1959;
import net.minecraft.class_2794;
import net.minecraft.class_2975;
import net.minecraft.class_310;
import net.minecraft.class_3124;
import net.minecraft.class_5317;
import net.minecraft.class_5321;
import net.minecraft.class_5363;
import net.minecraft.class_5539;
import net.minecraft.class_5868;
import net.minecraft.class_5875;
import net.minecraft.class_6016;
import net.minecraft.class_6017;
import net.minecraft.class_6122;
import net.minecraft.class_6793;
import net.minecraft.class_6795;
import net.minecraft.class_6796;
import net.minecraft.class_6799;
import net.minecraft.class_6816;
import net.minecraft.class_6880;
import net.minecraft.class_7145;
import net.minecraft.class_7225;
import net.minecraft.class_7510;
import net.minecraft.class_7887;
import net.minecraft.class_7924;

public class Ore {
    private static final Setting<Boolean> coal = ((BoolSetting.Builder) new BoolSetting.Builder().name("Coal")).build();
    private static final Setting<Boolean> iron = ((BoolSetting.Builder) new BoolSetting.Builder().name("Iron")).build();
    private static final Setting<Boolean> gold = ((BoolSetting.Builder) new BoolSetting.Builder().name("Gold")).build();
    private static final Setting<Boolean> redstone = ((BoolSetting.Builder) new BoolSetting.Builder().name("Redstone")).build();
    private static final Setting<Boolean> diamond = ((BoolSetting.Builder) new BoolSetting.Builder().name("Diamond")).build();
    private static final Setting<Boolean> lapis = ((BoolSetting.Builder) new BoolSetting.Builder().name("Lapis")).build();
    private static final Setting<Boolean> copper = ((BoolSetting.Builder) new BoolSetting.Builder().name("Kappa")).build();
    private static final Setting<Boolean> emerald = ((BoolSetting.Builder) new BoolSetting.Builder().name("Emerald")).build();
    private static final Setting<Boolean> quartz = ((BoolSetting.Builder) new BoolSetting.Builder().name("Quartz")).build();
    private static final Setting<Boolean> debris = ((BoolSetting.Builder) new BoolSetting.Builder().name("Ancient Debris")).build();
    public static final List<Setting<Boolean>> oreSettings = new ArrayList(Arrays.asList(coal, iron, gold, redstone, diamond, lapis, copper, emerald, quartz, debris));
    public int step;
    public int index;
    public Setting<Boolean> active;
    public class_6017 count;
    public class_6122 heightProvider;
    public class_5868 heightContext;
    public float rarity;
    public float discardOnAirChance;
    public int size;
    public Color color;
    public boolean scattered;

    public static Map<class_5321<class_1959>, List<Ore>> getRegistry(Dimension dimension) throws MatchException {
        class_5363 class_5363Var;
        class_7225.class_7874 registry = class_7887.method_46817();
        class_7225.class_7226<class_6796> features = registry.method_46762(class_7924.field_41245);
        Map<class_5321<class_5363>, class_5363> reg = ((class_7145) registry.method_46762(class_7924.field_41250).method_46747(class_5317.field_25050).comp_349()).method_45546().comp_1014();
        switch (C00091.$SwitchMap$meteordevelopment$meteorclient$utils$world$Dimension[dimension.ordinal()]) {
            case 1:
                class_5363Var = reg.get(class_5363.field_25412);
                break;
            case NBTType.SHORT:
                class_5363Var = reg.get(class_5363.field_25413);
                break;
            case 3:
                class_5363Var = reg.get(class_5363.field_25414);
                break;
            default:
                throw new MatchException((String) null, (Throwable) null);
        }
        class_5363 dim = class_5363Var;
        Set<class_6880<class_1959>> biomes = dim.comp_1013().method_12098().method_28443();
        List<class_6880<class_1959>> biomes1 = biomes.stream().toList();
        List<class_7510.class_6827> indexer = class_7510.method_44210(biomes1, biomeEntry -> {
            return ((class_1959) biomeEntry.comp_349()).method_30970().method_30983();
        }, true);
        Map<class_6796, Ore> featureToOre = new HashMap<>();
        registerOre(featureToOre, indexer, features, class_6816.field_36070, 6, coal, new Color(47, 44, 54));
        registerOre(featureToOre, indexer, features, class_6816.field_36069, 6, coal, new Color(47, 44, 54));
        registerOre(featureToOre, indexer, features, class_6816.field_36072, 6, iron, new Color(236, 173, 119));
        registerOre(featureToOre, indexer, features, class_6816.field_36073, 6, iron, new Color(236, 173, 119));
        registerOre(featureToOre, indexer, features, class_6816.field_36071, 6, iron, new Color(236, 173, 119));
        registerOre(featureToOre, indexer, features, class_6816.field_36075, 6, gold, new Color(247, 229, 30));
        registerOre(featureToOre, indexer, features, class_6816.field_36076, 6, gold, new Color(247, 229, 30));
        registerOre(featureToOre, indexer, features, class_6816.field_36074, 6, gold, new Color(247, 229, 30));
        registerOre(featureToOre, indexer, features, class_6816.field_36056, 7, gold, new Color(247, 229, 30));
        registerOre(featureToOre, indexer, features, class_6816.field_36054, 7, gold, new Color(247, 229, 30));
        registerOre(featureToOre, indexer, features, class_6816.field_36077, 6, redstone, new Color(245, 7, 23));
        registerOre(featureToOre, indexer, features, class_6816.field_36039, 6, redstone, new Color(245, 7, 23));
        registerOre(featureToOre, indexer, features, class_6816.field_36040, 6, diamond, new Color(33, 244, 255));
        registerOre(featureToOre, indexer, features, class_6816.field_36042, 6, diamond, new Color(33, 244, 255));
        registerOre(featureToOre, indexer, features, class_6816.field_36041, 6, diamond, new Color(33, 244, 255));
        registerOre(featureToOre, indexer, features, class_6816.field_45664, 6, diamond, new Color(33, 244, 255));
        registerOre(featureToOre, indexer, features, class_6816.field_36043, 6, lapis, new Color(8, 26, 189));
        registerOre(featureToOre, indexer, features, class_6816.field_36044, 6, lapis, new Color(8, 26, 189));
        registerOre(featureToOre, indexer, features, class_6816.field_36049, 6, copper, new Color(239, 151, 0));
        registerOre(featureToOre, indexer, features, class_6816.field_36050, 6, copper, new Color(239, 151, 0));
        registerOre(featureToOre, indexer, features, class_6816.field_36046, 6, emerald, new Color(27, 209, 45));
        registerOre(featureToOre, indexer, features, class_6816.field_36057, 7, quartz, new Color(205, 205, 205));
        registerOre(featureToOre, indexer, features, class_6816.field_36055, 7, quartz, new Color(205, 205, 205));
        registerOre(featureToOre, indexer, features, class_6816.field_36048, 7, debris, new Color(209, 27, 245));
        registerOre(featureToOre, indexer, features, class_6816.field_36047, 7, debris, new Color(209, 27, 245));
        Map<class_5321<class_1959>, List<Ore>> biomeOreMap = new HashMap<>();
        biomes1.forEach(biome -> {
            biomeOreMap.put((class_5321) biome.method_40230().get(), new ArrayList());
            Stream map = ((class_1959) biome.comp_349()).method_30970().method_30983().stream().flatMap((v0) -> {
                return v0.method_40239();
            }).map((v0) -> {
                return v0.comp_349();
            });
            Objects.requireNonNull(featureToOre);
            map.filter((v1) -> {
                return r1.containsKey(v1);
            }).forEach(feature -> {
                ((List) biomeOreMap.get(biome.method_40230().get())).add((Ore) featureToOre.get(feature));
            });
        });
        return biomeOreMap;
    }

    static class C00091 {
        static final int[] $SwitchMap$meteordevelopment$meteorclient$utils$world$Dimension = new int[Dimension.values().length];

        static {
            try {
                $SwitchMap$meteordevelopment$meteorclient$utils$world$Dimension[Dimension.Overworld.ordinal()] = 1;
            } catch (NoSuchFieldError e) {
            }
            try {
                $SwitchMap$meteordevelopment$meteorclient$utils$world$Dimension[Dimension.Nether.ordinal()] = 2;
            } catch (NoSuchFieldError e2) {
            }
            try {
                $SwitchMap$meteordevelopment$meteorclient$utils$world$Dimension[Dimension.End.ordinal()] = 3;
            } catch (NoSuchFieldError e3) {
            }
        }
    }

    private static void registerOre(Map<class_6796, Ore> map, List<class_7510.class_6827> indexer, class_7225.class_7226<class_6796> oreRegistry, class_5321<class_6796> oreKey, int genStep, Setting<Boolean> active, Color color) {
        class_6796 orePlacement = (class_6796) oreRegistry.method_46747(oreKey).comp_349();
        int index = indexer.get(genStep).comp_304().applyAsInt(orePlacement);
        Ore ore = new Ore(orePlacement, genStep, index, active, color);
        map.put(orePlacement, ore);
    }

    private Ore(class_6796 feature, int step, int index, Setting<Boolean> active, Color color) {
        this.count = class_6016.method_34998(1);
        this.rarity = 1.0f;
        this.step = step;
        this.index = index;
        this.active = active;
        this.color = color;
        int bottom = class_310.method_1551().field_1687.method_31607();
        int height = class_310.method_1551().field_1687.method_8597().comp_653();
        this.heightContext = new class_5868((class_2794) null, class_5539.method_39034(bottom, height));
        for (CountPlacementModifierAccessor countPlacementModifierAccessor : feature.comp_335()) {
            if (countPlacementModifierAccessor instanceof class_6793) {
                this.count = countPlacementModifierAccessor.getCount();
            } else if (countPlacementModifierAccessor instanceof class_6795) {
                this.heightProvider = ((HeightRangePlacementModifierAccessor) countPlacementModifierAccessor).getHeight();
            } else if (countPlacementModifierAccessor instanceof class_6799) {
                this.rarity = ((RarityFilterPlacementModifierAccessor) countPlacementModifierAccessor).getChance();
            }
        }
        class_3124 class_3124VarComp_333 = ((class_2975) feature.comp_334().comp_349()).comp_333();
        if (class_3124VarComp_333 instanceof class_3124) {
            class_3124 oreFeatureConfig = class_3124VarComp_333;
            this.discardOnAirChance = oreFeatureConfig.field_29064;
            this.size = oreFeatureConfig.field_13723;
            if (((class_2975) feature.comp_334().comp_349()).comp_332() instanceof class_5875) {
                this.scattered = true;
                return;
            }
            return;
        }
        throw new IllegalStateException("config for " + String.valueOf(feature) + "is not OreFeatureConfig.class");
    }
}
