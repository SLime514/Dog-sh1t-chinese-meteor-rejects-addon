package anticope.rejects.utils.gui;

import meteordevelopment.meteorclient.renderer.Renderer2D;
import meteordevelopment.meteorclient.utils.render.color.Color;

public class RoundedRenderer2D {
    private static final double circleNone = 0.0d;
    private static final double circleQuarter = 1.5707963267948966d;
    private static final double circleHalf = 3.141592653589793d;
    private static final double circleThreeQuarter = 4.71238898038469d;

    public static void quadRoundedOutline(Renderer2D mb, double x, double y, double width, double height, Color color, double r, double s) {
        double r2 = getR(r, width, height);
        if (r2 <= circleNone) {
            mb.quad(x, y, width, s, color);
            mb.quad(x, (y + height) - s, width, s, color);
            mb.quad(x, y + s, s, height - (s * 2.0d), color);
            mb.quad((x + width) - s, y + s, s, height - (s * 2.0d), color);
            return;
        }
        circlePartOutline(mb, x + r2, y + r2, r2, circleThreeQuarter, circleQuarter, color, s);
        mb.quad(x + r2, y, width - (r2 * 2.0d), s, color);
        circlePartOutline(mb, (x + width) - r2, y + r2, r2, circleNone, circleQuarter, color, s);
        mb.quad(x, y + r2, s, height - (r2 * 2.0d), color);
        mb.quad((x + width) - s, y + r2, s, height - (r2 * 2.0d), color);
        circlePartOutline(mb, (x + width) - r2, (y + height) - r2, r2, circleQuarter, circleQuarter, color, s);
        mb.quad(x + r2, (y + height) - s, width - (r2 * 2.0d), s, color);
        circlePartOutline(mb, x + r2, (y + height) - r2, r2, circleHalf, circleQuarter, color, s);
    }

    public static void quadRounded(Renderer2D mb, double x, double y, double width, double height, Color color, double r, boolean roundTop) {
        double r2 = getR(r, width, height);
        if (r2 <= circleNone) {
            mb.quad(x, y, width, height, color);
            return;
        }
        if (roundTop) {
            circlePart(mb, x + r2, y + r2, r2, circleThreeQuarter, circleQuarter, color);
            mb.quad(x + r2, y, width - (2.0d * r2), r2, color);
            circlePart(mb, (x + width) - r2, y + r2, r2, circleNone, circleQuarter, color);
            mb.quad(x, y + r2, width, height - (2.0d * r2), color);
        } else {
            mb.quad(x, y, width, height - r2, color);
        }
        circlePart(mb, (x + width) - r2, (y + height) - r2, r2, circleQuarter, circleQuarter, color);
        mb.quad(x + r2, (y + height) - r2, width - (2.0d * r2), r2, color);
        circlePart(mb, x + r2, (y + height) - r2, r2, circleHalf, circleQuarter, color);
    }

    public static void quadRoundedSide(Renderer2D mb, double x, double y, double width, double height, Color color, double r, boolean right) {
        double r2 = getR(r, width, height);
        if (r2 <= circleNone) {
            mb.quad(x, y, width, height, color);
            return;
        }
        if (right) {
            circlePart(mb, (x + width) - r2, y + r2, r2, circleNone, circleQuarter, color);
            circlePart(mb, (x + width) - r2, (y + height) - r2, r2, circleQuarter, circleQuarter, color);
            mb.quad(x, y, width - r2, height, color);
            mb.quad((x + width) - r2, y + r2, r2, height - (r2 * 2.0d), color);
            return;
        }
        circlePart(mb, x + r2, y + r2, r2, circleThreeQuarter, circleQuarter, color);
        circlePart(mb, x + r2, (y + height) - r2, r2, circleHalf, circleQuarter, color);
        mb.quad(x + r2, y, width - r2, height, color);
        mb.quad(x, y + r2, r2, height - (r2 * 2.0d), color);
    }

    private static double getR(double r, double w, double h) {
        if (r * 2.0d > h) {
            r = h / 2.0d;
        }
        if (r * 2.0d > w) {
            r = w / 2.0d;
        }
        return r;
    }

    private static int getCirDepth(double r, double angle) {
        return Math.max(1, (int) ((angle * r) / circleQuarter));
    }

    public static void circlePart(Renderer2D mb, double x, double y, double r, double startAngle, double angle, Color color) {
        int cirDepth = getCirDepth(r, angle);
        double cirPart = angle / cirDepth;
        int center = mb.triangles.vec2(x, y).color(color).next();
        int prev = vecOnCircle(mb, x, y, r, startAngle, color);
        for (int i = 1; i < cirDepth + 1; i++) {
            int next = vecOnCircle(mb, x, y, r, startAngle + (cirPart * i), color);
            mb.triangles.quad(prev, center, next, next);
            prev = next;
        }
    }

    public static void circlePartOutline(Renderer2D mb, double x, double y, double r, double startAngle, double angle, Color color, double outlineWidth) {
        if (outlineWidth >= r) {
            circlePart(mb, x, y, r, startAngle, angle, color);
            return;
        }
        int cirDepth = getCirDepth(r, angle);
        double cirPart = angle / cirDepth;
        int innerPrev = vecOnCircle(mb, x, y, r - outlineWidth, startAngle, color);
        int outerPrev = vecOnCircle(mb, x, y, r, startAngle, color);
        for (int i = 1; i < cirDepth + 1; i++) {
            int inner = vecOnCircle(mb, x, y, r - outlineWidth, startAngle + (cirPart * i), color);
            int outer = vecOnCircle(mb, x, y, r, startAngle + (cirPart * i), color);
            mb.triangles.quad(inner, innerPrev, outerPrev, outer);
            innerPrev = inner;
            outerPrev = outer;
        }
    }

    private static int vecOnCircle(Renderer2D mb, double x, double y, double r, double angle, Color color) {
        return mb.triangles.vec2(x + (Math.sin(angle) * r), y - (Math.cos(angle) * r)).color(color).next();
    }
}
