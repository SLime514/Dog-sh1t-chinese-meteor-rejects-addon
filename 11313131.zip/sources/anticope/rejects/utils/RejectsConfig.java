package anticope.rejects.utils;

import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.systems.System;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.utils.render.prompts.OkPrompt;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2519;
import net.minecraft.class_2520;

public class RejectsConfig extends System<RejectsConfig> {
    private static final RejectsConfig INSTANCE = new RejectsConfig();
    public HttpAllowed httpAllowed;
    public String httpUserAgent;
    public Set<String> hiddenModules;
    public boolean loadSystemFonts;
    public boolean duplicateModuleNames;

    public enum HttpAllowed {
        Everything,
        NotMeteorApi,
        NotMeteorPing,
        Nothing
    }

    public RejectsConfig() {
        super("rejects-config");
        this.httpAllowed = HttpAllowed.Everything;
        this.httpUserAgent = "Meteor Client";
        this.hiddenModules = new HashSet();
        this.loadSystemFonts = true;
        this.duplicateModuleNames = false;
        init();
        load(MeteorClient.FOLDER);
    }

    public static RejectsConfig get() {
        return INSTANCE;
    }

    public void setHiddenModules(List<Module> newList) {
        if (newList.size() < this.hiddenModules.size()) {
            ((OkPrompt) ((OkPrompt) ((OkPrompt) OkPrompt.create().title("Hidden Modules")).message("In order to see the modules you have removed from the list you need to restart Minecraft.")).id("hidden-modules-unhide")).show();
        }
        this.hiddenModules.clear();
        for (Module module : newList) {
            if (module != null) {
                if (module.isActive()) {
                    module.toggle();
                }
                this.hiddenModules.add(module.name);
            }
        }
    }

    public List<Module> getHiddenModules() {
        Modules modules = Modules.get();
        if (modules == null) {
            return List.of();
        }
        Stream<String> stream = this.hiddenModules.stream();
        Objects.requireNonNull(modules);
        return (List) stream.map(modules::get).collect(Collectors.toList());
    }

    public class_2487 toTag() {
        class_2487 tag = new class_2487();
        tag.method_10582("httpAllowed", this.httpAllowed.toString());
        tag.method_10582("httpUserAgent", this.httpUserAgent);
        tag.method_10556("loadSystemFonts", this.loadSystemFonts);
        tag.method_10556("duplicateModuleNames", this.duplicateModuleNames);
        class_2499 modulesTag = new class_2499();
        for (String module : this.hiddenModules) {
            modulesTag.add(class_2519.method_23256(module));
        }
        tag.method_10566("hiddenModules", modulesTag);
        return tag;
    }

    public RejectsConfig m193fromTag(class_2487 tag) {
        this.httpAllowed = HttpAllowed.valueOf(tag.method_10558("httpAllowed"));
        this.httpUserAgent = tag.method_10558("httpUserAgent");
        this.loadSystemFonts = tag.method_10577("loadSystemFonts");
        this.duplicateModuleNames = tag.method_10577("duplicateModuleNames");
        class_2499 valueTag = tag.method_10554("hiddenModules", 8);
        Iterator it = valueTag.iterator();
        while (it.hasNext()) {
            class_2520 tagI = (class_2520) it.next();
            this.hiddenModules.add(tagI.method_10714());
        }
        return this;
    }
}
