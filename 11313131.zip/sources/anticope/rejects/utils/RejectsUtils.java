package anticope.rejects.utils;

import anticope.rejects.MeteorRejectsAddon;
import anticope.rejects.utils.seeds.Seeds;
import java.util.Iterator;
import java.util.Random;
import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.events.entity.player.PlayerMoveEvent;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.utils.PostInit;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import net.minecraft.class_1297;
import net.minecraft.class_3532;

public class RejectsUtils {
    @PostInit
    public static void init() {
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            System.out.println("saving seeds...");
            RejectsConfig.get().save(MeteorClient.FOLDER);
            Seeds.get().save(MeteorClient.FOLDER);
        }));
    }

    public static String getModuleName(String name) {
        int dupe = 0;
        Modules modules = Modules.get();
        if (modules == null) {
            MeteorRejectsAddon.LOG.warn("Module instantiation before Modules initialized.");
            return name;
        }
        Iterator it = modules.getAll().iterator();
        while (true) {
            if (!it.hasNext()) {
                break;
            }
            Module module = (Module) it.next();
            if (module.name.equals(name)) {
                dupe = 0 + 1;
                break;
            }
        }
        return dupe == 0 ? name : getModuleName(name + "*".repeat(dupe));
    }

    public static String getRandomPassword(int num) {
        Random random = new Random();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < num; i++) {
            int number = random.nextInt(63);
            sb.append("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_".charAt(number));
        }
        return sb.toString();
    }

    public static boolean inFov(class_1297 entity, double fov) {
        if (fov >= 360.0d) {
            return true;
        }
        float[] angle = PlayerUtils.calculateAngle(entity.method_5829().method_1005());
        double xDist = class_3532.method_15356(angle[0], MeteorClient.mc.field_1724.method_36454());
        double yDist = class_3532.method_15356(angle[1], MeteorClient.mc.field_1724.method_36455());
        double angleDistance = Math.hypot(xDist, yDist);
        return angleDistance <= fov;
    }

    public static float fullFlightMove(PlayerMoveEvent event, double speed, boolean verticalSpeedMatch) {
        if (PlayerUtils.isMoving()) {
            double dir = getDir();
            double xDir = Math.cos(Math.toRadians(dir + 90.0d));
            double zDir = Math.sin(Math.toRadians(dir + 90.0d));
            event.movement.meteor$setXZ(xDir * speed, zDir * speed);
        } else {
            event.movement.meteor$setXZ(0.0d, 0.0d);
        }
        float ySpeed = 0.0f;
        if (MeteorClient.mc.field_1690.field_1903.method_1434()) {
            ySpeed = (float) (0.0f + speed);
        }
        if (MeteorClient.mc.field_1690.field_1832.method_1434()) {
            ySpeed = (float) (ySpeed - speed);
        }
        event.movement.meteor$setY(verticalSpeedMatch ? ySpeed : ySpeed / 2.0f);
        return ySpeed;
    }

    private static double getDir() {
        double dir = 0.0d;
        if (Utils.canUpdate()) {
            dir = MeteorClient.mc.field_1724.method_36454() + (MeteorClient.mc.field_1724.field_6250 < 0.0f ? 180 : 0);
            if (MeteorClient.mc.field_1724.field_6212 > 0.0f) {
                dir += (-90.0f) * (MeteorClient.mc.field_1724.field_6250 < 0.0f ? -0.5f : MeteorClient.mc.field_1724.field_6250 > 0.0f ? 0.5f : 1.0f);
            } else if (MeteorClient.mc.field_1724.field_6212 < 0.0f) {
                dir += 90.0f * (MeteorClient.mc.field_1724.field_6250 < 0.0f ? -0.5f : MeteorClient.mc.field_1724.field_6250 > 0.0f ? 0.5f : 1.0f);
            }
        }
        return dir;
    }
}
