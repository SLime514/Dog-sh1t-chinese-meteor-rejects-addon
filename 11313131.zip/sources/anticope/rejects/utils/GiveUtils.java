package anticope.rejects.utils;

import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.SimpleCommandExceptionType;
import it.unimi.dsi.fastutil.ints.IntArrayList;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Random;
import java.util.function.Function;
import meteordevelopment.meteorclient.MeteorClient;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1844;
import net.minecraft.class_1887;
import net.minecraft.class_1893;
import net.minecraft.class_2378;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2522;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_6880;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_9279;
import net.minecraft.class_9283;
import net.minecraft.class_9284;
import net.minecraft.class_9304;
import net.minecraft.class_9326;
import net.minecraft.class_9334;
import org.apache.commons.lang3.text.WordUtils;
import org.apache.commons.lang3.tuple.Triple;

public class GiveUtils {
    public static final Map<String, Function<Boolean, class_1799>> PRESETS = new HashMap();
    private static final SimpleCommandExceptionType NOT_IN_CREATIVE = new SimpleCommandExceptionType(class_2561.method_43470("You must be in creative mode to use this."));
    private static final SimpleCommandExceptionType NO_SPACE = new SimpleCommandExceptionType(class_2561.method_43470("No space in hotbar."));
    private static final List<class_2960> HIDDEN_ENTITIES = Arrays.asList(class_2960.method_60654("giant"), class_2960.method_60654("ender_dragon"), class_2960.method_60654("wither"), class_2960.method_60654("iron_golem"), class_2960.method_60654("ender_dragon"), class_2960.method_60654("tnt_minecart"), class_2960.method_60654("lightning_bolt"));
    private static final List<Triple<String, class_1792, String>> ENTITY_PRESETS = Arrays.asList(Triple.of("pigs_egg", class_1802.field_8835, "{MaxNearbyEntities:1000,RequiredPlayerRange:100,CustomDisplayTile:1b,DisplayState:{Properties:{hinge:\"left\",half:\"upper\",open:\"true\"},Name:\"minecraft:acacia_door\"},SpawnData:{id:\"minecraft:minecart\"},id:\"minecraft:spawner_minecart\",MaxSpawnDelay:0,Delay:1,MinSpawnDelay:0}"), Triple.of("end_portal_arrow", class_1802.field_8769, "{SoundEvent:\"block.end_portal.spawn\",pickup:1b,id:\"minecraft:arrow\"}"), Triple.of("wither_spawn_arrow", class_1802.field_8769, "{SoundEvent:\"entity.wither.spawn\",pickup:1b,id:\"minecraft:arrow\"}"), Triple.of("eg_curse_arrow", class_1802.field_8769, "{SoundEvent:\"entity.elder_guardian.curse\",pickup:1b,id:\"minecraft:arrow\"}"), Triple.of("big_slime", class_1802.field_8881, "{Size:50,id:\"minecraft:slime\"}"), Triple.of("particle_area_expand", class_1802.field_8300, "{Particle:\"angry_villager\",Radius:1.0f,RadiusOnUse:1.0f,Duration:10000,id:\"minecraft:area_effect_cloud\",RadiusPerTick:10.0f}"), Triple.of("armor_stand_spawner_minecart", class_1802.field_8727, "{SpawnData:{id:\"minecraft:armor_stand\"},id:\"minecraft:spawner_minecart\"}"), Triple.of("dud_tnt", class_1802.field_8083, "{Fuse:30000,Invulnerable:1b,id:\"minecraft:tnt\"}"));
    private static final List<Triple<String, class_1792, String>> BLOCK_PRESETS = Arrays.asList(Triple.of("lag_spawner", class_1802.field_8849, "{MaxNearbyEntities:32767,RequiredPlayerRange:32767,SpawnCount:50,MaxSpawnDelay:0,id:\"minecraft:spawner\",SpawnRange:32767,Delay:0,MinSpawnDelay:0}"), Triple.of("tnt_spawner", class_1802.field_8849, "{MaxNearbyEntities:32767,RequiredPlayerRange:32767,SpawnCount:50,SpawnData:{entity:{id:\"minecraft:tnt\",fuse:1}},MaxSpawnDelay:0,id:\"minecraft:mob_spawner\",SpawnRange:10,Delay:0,MinSpawnDelay:0}"), Triple.of("boat_spawner", class_1802.field_8849, "{SpawnCount:50,SpawnData:{entity:{Type:\"jungle\",CustomName:'{\"bold\":true,\"color\":\"aqua\",\"italic\":true,\"text\":\"Boat\",\"underlined\":true}',Invulnerable:1b,id:\"minecraft:boat\",Glowing:1b,CustomNameVisible:1b}},id:\"minecraft:spawner\",SpawnRange:10}"));
    private static final Random random = new Random();
    private static class_2378<class_1887> enchantmentRegistry;

    static {
        ENTITY_PRESETS.forEach(preset -> {
            PRESETS.put((String) preset.getLeft(), preview -> {
                if (preview.booleanValue()) {
                    ((class_1792) preset.getMiddle()).method_7854();
                }
                class_1799 item = ((class_1792) preset.getMiddle()).method_7854();
                try {
                    item.method_57379(class_9334.field_49609, class_9279.method_57456(class_2522.method_10718((String) preset.getRight())));
                } catch (CommandSyntaxException e) {
                }
                item.method_57379(class_9334.field_49631, class_2561.method_43470(toName(preset.getLeft())));
                return item;
            });
        });
        BLOCK_PRESETS.forEach(preset2 -> {
            PRESETS.put((String) preset2.getLeft(), preview -> {
                if (preview.booleanValue()) {
                    ((class_1792) preset2.getMiddle()).method_7854();
                }
                class_1799 item = ((class_1792) preset2.getMiddle()).method_7854();
                try {
                    item.method_57379(class_9334.field_49611, class_9279.method_57456(class_2522.method_10718((String) preset2.getRight())));
                } catch (CommandSyntaxException e) {
                }
                item.method_57379(class_9334.field_49631, class_2561.method_43470(toName(preset2.getLeft())));
                return item;
            });
        });
        PRESETS.put("force_op", preview -> {
            if (preview.booleanValue()) {
                class_1802.field_8185.method_7854();
            }
            class_1799 item = class_1802.field_8185.method_7854();
            String nick = MeteorClient.mc.field_1724.method_5477().getString();
            try {
                item.method_57379(class_9334.field_49609, class_9279.method_57456(class_2522.method_10718("{Time:1,BlockState:{Name:\"minecraft:spawner\"},id:\"minecraft:falling_block\",TileEntityData:{SpawnCount:20,SpawnData:{id:\"minecraft:villager\",Passengers:[{Time:1,BlockState:{Name:\"minecraft:redstone_block\"},id:\"minecraft:falling_block\",Passengers:[{id:\"minecraft:fox\",Passengers:[{Time:1,BlockState:{Name:\"minecraft:activator_rail\"},id:\"minecraft:falling_block\",Passengers:[{Command:\"execute as @e run op " + nick + "\",id:\"minecraft:command_block_minecart\"}]}],NoAI:1b,Health:1.0f,ActiveEffects:[{Duration:1000,Id:20b,Amplifier:4b}]}]}],NoAI:1b,Health:1.0f,ActiveEffects:[{Duration:1000,Id:20b,Amplifier:4b}]},MaxSpawnDelay:100,SpawnRange:10,Delay:1,MinSpawnDelay:100}}")));
            } catch (CommandSyntaxException e) {
            }
            item.method_57379(class_9334.field_49631, class_2561.method_30163("Force OP"));
            return item;
        });
        PRESETS.put("troll_potion", preview2 -> {
            if (preview2.booleanValue()) {
                class_1802.field_8150.method_7854();
            }
            class_1799 stack = class_1802.field_8150.method_7854();
            ArrayList<class_1293> effects = new ArrayList<>();
            for (int i = 1; i <= 31; i++) {
                class_1291 effect = (class_1291) ((class_6880.class_6883) class_7923.field_41174.method_40265(i).get()).comp_349();
                class_6880<class_1291> entry = class_7923.field_41174.method_47983(effect);
                effects.add(new class_1293(entry, Integer.MAX_VALUE, Integer.MAX_VALUE));
            }
            stack.method_57379(class_9334.field_49651, new class_1844(Optional.empty(), Optional.empty(), effects, Optional.empty()));
            stack.method_57379(class_9334.field_49631, class_2561.method_43470("Lingering Potion of Trolling"));
            return stack;
        });
        PRESETS.put("32k", preview3 -> {
            enchantmentRegistry = MeteorClient.mc.field_1687.method_30349().method_30530(class_7924.field_41265);
            if (preview3.booleanValue() || enchantmentRegistry == null) {
                return class_1802.field_8802.method_7854();
            }
            class_1799 stack = class_1802.field_8802.method_7854();
            stack.method_57368(class_9334.field_49633, class_9304.field_49385, component -> {
                class_9304.class_9305 builder = new class_9304.class_9305(component);
                builder.method_57550(enchantmentRegistry.method_46747(class_1893.field_9118), 255);
                builder.method_57550(enchantmentRegistry.method_46747(class_1893.field_9121), 255);
                builder.method_57550(enchantmentRegistry.method_46747(class_1893.field_9124), 255);
                builder.method_57550(enchantmentRegistry.method_46747(class_1893.field_9110), 10);
                builder.method_57550(enchantmentRegistry.method_46747(class_1893.field_9115), 3);
                builder.method_57550(enchantmentRegistry.method_46747(class_1893.field_9119), 255);
                builder.method_57550(enchantmentRegistry.method_46747(class_1893.field_9101), 1);
                builder.method_57550(enchantmentRegistry.method_46747(class_1893.field_9109), 1);
                return builder.method_57549();
            });
            stack.method_57379(class_9334.field_49631, class_2561.method_43470("Bonk"));
            return stack;
        });
        PRESETS.put("crash_chest", preview4 -> {
            if (preview4.booleanValue()) {
                return class_1802.field_8106.method_7854();
            }
            class_1799 stack = class_1802.field_8106.method_7854();
            class_2487 nbtCompound = new class_2487();
            class_2499 nbtList = new class_2499();
            for (int i = 0; i < 40000; i++) {
                nbtList.add(new class_2499());
            }
            nbtCompound.method_10566("nothingsuspicioushere", nbtList);
            stack.method_57379(class_9334.field_49628, class_9279.method_57456(nbtCompound));
            stack.method_57379(class_9334.field_49631, class_2561.method_43470("Copy Me"));
            return stack;
        });
        PRESETS.put("firework", preview5 -> {
            if (preview5.booleanValue()) {
                return class_1802.field_8639.method_7854();
            }
            class_1799 firework = new class_1799(class_1802.field_8639);
            IntArrayList intArrayList = new IntArrayList(new int[]{1973019, 11743532, 3887386, 5320730, 2437522, 8073150, 2651799, 11250603, 4408131, 14188952, 4312372, 14602026, 6719955, 12801229, 15435844, 15790320});
            ArrayList<class_9283> explosions = new ArrayList<>();
            for (int i = 0; i < 200; i++) {
                explosions.add(new class_9283(class_9283.class_1782.method_7813(random.nextInt(5)), intArrayList, intArrayList, true, true));
            }
            class_9326 changes = class_9326.method_57841().method_57854(class_9334.field_49616, new class_9284(1, explosions)).method_57852();
            firework.method_59692(changes);
            return firework;
        });
        HIDDEN_ENTITIES.forEach(id -> {
            PRESETS.put(id.method_12832() + "_spawn_egg", preview6 -> {
                if (preview6.booleanValue()) {
                    return class_1802.field_8493.method_7854();
                }
                class_1799 egg = class_1802.field_8493.method_7854();
                class_2487 entityTag = new class_2487();
                entityTag.method_10582("id", id.toString());
                class_9326 changes = class_9326.method_57841().method_57854(class_9334.field_49631, class_2561.method_43470(String.format("%s", toName(id.method_12832())))).method_57854(class_9334.field_49609, class_9279.method_57456(entityTag)).method_57852();
                egg.method_59692(changes);
                return egg;
            });
        });
    }

    public static void giveItem(class_1799 item) throws CommandSyntaxException {
        if (!MeteorClient.mc.field_1724.method_31549().field_7477) {
            throw NOT_IN_CREATIVE.create();
        }
        if (!MeteorClient.mc.field_1724.method_31548().method_7394(item)) {
            throw NO_SPACE.create();
        }
    }

    public static class_1799 getPreset(String name, boolean preview) {
        return PRESETS.get(name).apply(Boolean.valueOf(preview));
    }

    public static class_1799 getPreset(String name) {
        return getPreset(name, false);
    }

    private static String toName(Object id) {
        return WordUtils.capitalizeFully(id.toString().replace("_", " "));
    }
}
