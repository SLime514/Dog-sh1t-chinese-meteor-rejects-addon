package anticope.rejects.utils.accounts;

import anticope.rejects.MeteorRejectsAddon;
import anticope.rejects.utils.accounts.CustomYggdrasilLogin;
import com.mojang.authlib.exceptions.AuthenticationException;
import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.systems.accounts.Account;
import meteordevelopment.meteorclient.systems.accounts.AccountType;
import meteordevelopment.meteorclient.utils.misc.NbtException;
import net.minecraft.class_2487;
import net.minecraft.class_320;

public class CustomYggdrasilAccount extends Account<CustomYggdrasilAccount> {
    private String password;
    private String server;

    public CustomYggdrasilAccount(String name, String password, String server) {
        super(AccountType.Cracked, name);
        this.password = password;
        this.server = server;
    }

    public boolean fetchInfo() {
        try {
            class_320 session = CustomYggdrasilLogin.login(this.name, this.password, this.server);
            this.cache.username = session.method_1676();
            this.cache.uuid = session.method_44717().toString();
            return true;
        } catch (AuthenticationException e) {
            return false;
        }
    }

    public boolean login() {
        try {
            CustomYggdrasilLogin.LocalYggdrasilAuthenticationService service = new CustomYggdrasilLogin.LocalYggdrasilAuthenticationService(MeteorClient.mc.getProxy(), this.server);
            applyLoginEnvironment(service, new CustomYggdrasilLogin.LocalYggdrasilMinecraftSessionService(service, service.server));
            class_320 session = CustomYggdrasilLogin.login(this.name, this.password, this.server);
            setSession(session);
            this.cache.username = session.method_1676();
            this.cache.loadHead();
            return true;
        } catch (AuthenticationException e) {
            if (e.getMessage().contains("Invalid username or password") || e.getMessage().contains("account migrated")) {
                MeteorRejectsAddon.LOG.error("Wrong password.");
                return false;
            }
            MeteorRejectsAddon.LOG.error("Failed to contact the authentication server.");
            return false;
        }
    }

    public class_2487 toTag() {
        class_2487 tag = super.toTag();
        tag.method_10582("password", this.password);
        tag.method_10582("server", this.server);
        return tag;
    }

    public CustomYggdrasilAccount m199fromTag(class_2487 tag) throws NbtException {
        super.fromTag(tag);
        if (!tag.method_10545("password")) {
            throw new NbtException();
        }
        this.password = tag.method_10558("password");
        this.server = tag.method_10558("server");
        return this;
    }

    public boolean equals(Object o) {
        if (o instanceof CustomYggdrasilAccount) {
            return ((CustomYggdrasilAccount) o).name.equals(this.name);
        }
        return false;
    }
}
