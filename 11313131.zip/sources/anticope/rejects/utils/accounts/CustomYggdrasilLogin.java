package anticope.rejects.utils.accounts;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonParser;
import com.mojang.authlib.Environment;
import com.mojang.authlib.SignatureState;
import com.mojang.authlib.exceptions.AuthenticationException;
import com.mojang.authlib.minecraft.MinecraftProfileTexture;
import com.mojang.authlib.minecraft.MinecraftProfileTextures;
import com.mojang.authlib.properties.Property;
import com.mojang.authlib.yggdrasil.ServicesKeyInfo;
import com.mojang.authlib.yggdrasil.YggdrasilAuthenticationService;
import com.mojang.authlib.yggdrasil.YggdrasilMinecraftSessionService;
import com.mojang.authlib.yggdrasil.YggdrasilServicesKeyInfo;
import com.mojang.authlib.yggdrasil.response.MinecraftTexturesPayload;
import com.mojang.util.UUIDTypeAdapter;
import java.net.Proxy;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.utils.network.Http;
import net.minecraft.class_320;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class CustomYggdrasilLogin {
    public static Environment localYggdrasilApi = new Environment("/sessionserver", "/minecraftservices", "Custom-Yggdrasil");

    public static class_320 login(String name, String password, String server) throws AuthenticationException {
        try {
            String url = server + "/authserver/authenticate";
            JsonObject agent = new JsonObject();
            agent.addProperty("name", "Minecraft");
            agent.addProperty("version", 1);
            JsonObject root = new JsonObject();
            root.add("agent", agent);
            root.addProperty("username", name);
            root.addProperty("password", password);
            String data = Http.post(url).bodyJson(root).sendString();
            JsonObject json = JsonParser.parseString(data).getAsJsonObject();
            if (json.has("error")) {
                throw new AuthenticationException(json.get("errorMessage").getAsString());
            }
            String token = json.get("accessToken").getAsString();
            UUID uuid = UUID.fromString(json.get("selectedProfile").getAsJsonObject().get("id").getAsString());
            String username = json.get("selectedProfile").getAsJsonObject().get("name").getAsString();
            return new class_320(username, uuid, token, Optional.empty(), Optional.empty(), class_320.class_321.field_1988);
        } catch (Exception e) {
            throw new AuthenticationException(e);
        }
    }

    public static class LocalYggdrasilMinecraftSessionService extends YggdrasilMinecraftSessionService {
        private static final Logger LOGGER = LogManager.getLogger();
        private final ServicesKeyInfo publicKey;
        private final Gson gson;

        public LocalYggdrasilMinecraftSessionService(YggdrasilAuthenticationService service, String serverUrl) {
            super(service.getServicesKeySet(), MeteorClient.mc.method_1487(), CustomYggdrasilLogin.localYggdrasilApi);
            this.gson = new GsonBuilder().registerTypeAdapter(UUID.class, new UUIDTypeAdapter()).create();
            String data = Http.get(serverUrl).sendString();
            JsonObject json = JsonParser.parseString(data).getAsJsonObject();
            this.publicKey = getPublicKey(json.get("signaturePublickey").getAsString());
        }

        private static ServicesKeyInfo getPublicKey(String key) {
            try {
                byte[] byteKey = Base64.getDecoder().decode(key.replace("-----BEGIN PUBLIC KEY-----", "").replace("-----END PUBLIC KEY-----", "").replace("\n", ""));
                return YggdrasilServicesKeyInfo.parse(byteKey);
            } catch (IllegalArgumentException e) {
                e.printStackTrace();
                return null;
            }
        }

        private SignatureState getPropertySignatureState(Property property) {
            if (!property.hasSignature()) {
                return SignatureState.UNSIGNED;
            }
            if (!this.publicKey.validateProperty(property)) {
                return SignatureState.INVALID;
            }
            return SignatureState.SIGNED;
        }

        public MinecraftProfileTextures unpackTextures(Property packedTextures) {
            String value = packedTextures.value();
            SignatureState signatureState = getPropertySignatureState(packedTextures);
            try {
                String json = new String(Base64.getDecoder().decode(value), StandardCharsets.UTF_8);
                MinecraftTexturesPayload result = (MinecraftTexturesPayload) this.gson.fromJson(json, MinecraftTexturesPayload.class);
                if (result == null || result.textures() == null || result.textures().isEmpty()) {
                    return MinecraftProfileTextures.EMPTY;
                }
                Map<MinecraftProfileTexture.Type, MinecraftProfileTexture> textures = result.textures();
                return new MinecraftProfileTextures(textures.get(MinecraftProfileTexture.Type.SKIN), textures.get(MinecraftProfileTexture.Type.CAPE), textures.get(MinecraftProfileTexture.Type.ELYTRA), signatureState);
            } catch (JsonParseException | IllegalArgumentException e) {
                LOGGER.error("Could not decode textures payload", e);
                return MinecraftProfileTextures.EMPTY;
            }
        }
    }

    public static class LocalYggdrasilAuthenticationService extends YggdrasilAuthenticationService {
        public final String server;

        public LocalYggdrasilAuthenticationService(Proxy proxy, String server) {
            super(proxy, CustomYggdrasilLogin.localYggdrasilApi);
            this.server = server;
        }
    }
}
