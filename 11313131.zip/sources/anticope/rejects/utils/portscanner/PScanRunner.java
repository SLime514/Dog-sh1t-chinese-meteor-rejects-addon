package anticope.rejects.utils.portscanner;

import anticope.rejects.utils.portscanner.PortScannerManager;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

public class PScanRunner {

    ExecutorService f11es;
    Thread runner;
    public boolean running = true;
    public int portsScanned = 0;
    List<Future<PortScannerManager.ScanResult>> futures = new ArrayList();

    public PScanRunner(InetAddress address, int threads, int threadDelay, int timeoutMS, Collection<Integer> ports, Consumer<List<PortScannerManager.ScanResult>> callback) {
        this.runner = new Thread(() -> {
            this.f11es = Executors.newFixedThreadPool(threads);
            ports.forEach(port -> {
                this.futures.add(isPortOpen(this.f11es, address.getHostAddress(), port.intValue(), timeoutMS, threadDelay));
            });
            try {
                this.f11es.awaitTermination(200L, TimeUnit.MILLISECONDS);
            } catch (InterruptedException e) {
            }
            ArrayList arrayList = new ArrayList();
            for (Future<PortScannerManager.ScanResult> fsc : this.futures) {
                try {
                    arrayList.add(fsc.get());
                } catch (InterruptedException | ExecutionException e2) {
                    e2.printStackTrace();
                }
            }
            callback.accept(arrayList);
        });
        this.runner.start();
    }

    public void cancel() {
        this.running = false;
    }

    private Future<PortScannerManager.ScanResult> isPortOpen(ExecutorService es, String ip, int port, int timeout, int delay) {
        return es.submit(() -> {
            if (!this.running) {
                return new PortScannerManager.ScanResult(port, false);
            }
            Thread.sleep(delay);
            this.portsScanned++;
            try {
                Socket socket = new Socket();
                socket.connect(new InetSocketAddress(ip, port), timeout);
                socket.close();
                return new PortScannerManager.ScanResult(port, true);
            } catch (Exception e) {
                return new PortScannerManager.ScanResult(port, false);
            }
        });
    }
}
