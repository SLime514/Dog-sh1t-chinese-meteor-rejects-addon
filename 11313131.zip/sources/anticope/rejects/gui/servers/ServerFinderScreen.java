package anticope.rejects.gui.servers;

import anticope.rejects.utils.server.IServerFinderDoneListener;
import anticope.rejects.utils.server.MServerInfo;
import anticope.rejects.utils.server.ServerPinger;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Stack;
import meteordevelopment.meteorclient.gui.GuiTheme;
import meteordevelopment.meteorclient.gui.WindowScreen;
import meteordevelopment.meteorclient.gui.widgets.WLabel;
import meteordevelopment.meteorclient.gui.widgets.containers.WHorizontalList;
import meteordevelopment.meteorclient.gui.widgets.containers.WTable;
import meteordevelopment.meteorclient.gui.widgets.input.WIntEdit;
import meteordevelopment.meteorclient.gui.widgets.input.WTextBox;
import meteordevelopment.meteorclient.gui.widgets.pressable.WButton;
import meteordevelopment.meteorclient.gui.widgets.pressable.WCheckbox;
import net.minecraft.class_4267;
import net.minecraft.class_437;
import net.minecraft.class_500;
import net.minecraft.class_642;

public class ServerFinderScreen extends WindowScreen implements IServerFinderDoneListener {
    public static ServerFinderScreen instance = null;
    private static int searchNumber = 0;
    private final class_500 multiplayerScreen;
    private final WTextBox ipBox;
    private final WTextBox versionBox;
    private final WIntEdit maxThreadsBox;
    private final WButton searchButton;
    private final WLabel stateLabel;
    private final WLabel checkedLabel;
    private final WLabel workingLabel;
    private final WCheckbox scanPortsBox;
    private final Stack<String> ipsToPing;
    private final Object serverFinderLock;
    private ServerFinderState state;
    private int maxThreads;
    private volatile int numActiveThreads;
    private volatile int checked;
    private volatile int working;
    private int targetChecked;
    private ArrayList<String> versionFilters;
    private int playerCountFilter;

    public ServerFinderScreen(GuiTheme theme, class_500 multiplayerScreen, class_437 parent) {
        super(theme, "Server Discovery");
        this.ipsToPing = new Stack<>();
        this.serverFinderLock = new Object();
        this.targetChecked = 1792;
        this.versionFilters = new ArrayList<>();
        this.playerCountFilter = 0;
        this.multiplayerScreen = multiplayerScreen;
        this.parent = parent;
        this.ipBox = theme.textBox("127.0.0.1");
        this.versionBox = theme.textBox("1.20; 1.19; 1.18; 1.17; 1.16; 1.15; 1.14; 1.13; 1.12; 1.11; 1.10; 1.9; 1.8");
        this.maxThreadsBox = theme.intEdit(128, 1, 1024, 1, 1024);
        this.stateLabel = theme.label("");
        this.checkedLabel = theme.label("");
        this.searchButton = theme.button("Search");
        this.workingLabel = theme.label("");
        this.scanPortsBox = theme.checkbox(true);
        this.state = ServerFinderState.NOT_RUNNING;
        newSearch();
        instance = this;
    }

    public static int getSearchNumber() {
        return searchNumber;
    }

    public void initWidgets() {
        add(this.theme.label("This will search for servers with similar IPs"));
        add(this.theme.label("to the IP you type into the field below."));
        add(this.theme.label("The servers it finds will be added to your server list."));
        WTable table = add(new WTable()).expandX().widget();
        table.add(this.theme.label("Server address:"));
        table.add(this.ipBox).expandX();
        table.row();
        table.add(this.theme.label("Max. Threads:"));
        table.add(this.maxThreadsBox);
        table.row();
        table.add(this.theme.label("Scan ports"));
        table.add(this.scanPortsBox);
        table.row();
        table.add(this.theme.label("Versions:"));
        table.add(this.versionBox).expandX();
        add(this.stateLabel);
        add(this.checkedLabel);
        add(this.workingLabel);
        WHorizontalList list = add(this.theme.horizontalList()).expandX().widget();
        list.add(this.searchButton).expandX();
        this.searchButton.action = this::searchOrCancel;
    }

    private void newSearch() {
        searchNumber = (searchNumber + 1) % 1000;
    }

    public void incrementTargetChecked(int amount) {
        synchronized (this.serverFinderLock) {
            if (this.state != ServerFinderState.CANCELLED) {
                this.targetChecked += amount;
            }
        }
    }

    public ServerFinderState getState() {
        return this.state;
    }

    private void searchOrCancel() throws UnknownHostException {
        if (this.state.isRunning()) {
            this.state = ServerFinderState.CANCELLED;
            return;
        }
        this.state = ServerFinderState.RESOLVING;
        this.maxThreads = this.maxThreadsBox.get();
        this.ipsToPing.clear();
        this.targetChecked = 1792;
        this.numActiveThreads = 0;
        this.checked = 0;
        this.working = 0;
        newSearch();
        parseVersionFilters();
        findServers();
    }

    private void parseVersionFilters() {
        String filter = this.versionBox.get();
        String[] versions = filter.split(";");
        if (this.versionFilters == null) {
            this.versionFilters = new ArrayList<>();
        }
        this.versionFilters.clear();
        for (String version : versions) {
            String trimmed = version.trim();
            if (!trimmed.isEmpty()) {
                this.versionFilters.add(version.trim());
            }
        }
    }

    private void findServers() throws UnknownHostException {
        try {
            InetAddress addr = InetAddress.getByName(this.ipBox.get().split(":")[0].trim());
            int[] ipParts = new int[4];
            for (int i = 0; i < 4; i++) {
                ipParts[i] = addr.getAddress()[i] & 255;
            }
            this.state = ServerFinderState.SEARCHING;
            int[] changes = {0, 1, -1, 2, -2, 3, -3};
            for (int change : changes) {
                for (int i2 = 0; i2 <= 255; i2++) {
                    if (this.state == ServerFinderState.CANCELLED) {
                        return;
                    }
                    int[] ipParts2 = (int[]) ipParts.clone();
                    ipParts2[2] = (ipParts[2] + change) & 255;
                    ipParts2[3] = i2;
                    String ip = ipParts2[0] + "." + ipParts2[1] + "." + ipParts2[2] + "." + ipParts2[3];
                    this.ipsToPing.push(ip);
                }
            }
            while (this.numActiveThreads < this.maxThreads && pingNewIP()) {
            }
        } catch (UnknownHostException e) {
            this.state = ServerFinderState.UNKNOWN_HOST;
        } catch (Exception e2) {
            e2.printStackTrace();
            this.state = ServerFinderState.ERROR;
        }
    }

    private boolean pingNewIP() {
        synchronized (this.serverFinderLock) {
            if (!this.ipsToPing.isEmpty()) {
                String ip = this.ipsToPing.pop();
                ServerPinger pinger = new ServerPinger(this.scanPortsBox.checked, searchNumber);
                pinger.addServerFinderDoneListener(this);
                pinger.ping(ip);
                this.numActiveThreads++;
                return true;
            }
            return false;
        }
    }

    public void method_25393() {
        this.searchButton.set(this.state.isRunning() ? "Cancel" : "Search");
        if (this.state.isRunning()) {
            this.ipBox.setFocused(false);
            this.maxThreadsBox.set(this.maxThreads);
        }
        this.stateLabel.set(this.state.toString());
        this.checkedLabel.set("Checked: " + this.checked + " / " + this.targetChecked);
        this.workingLabel.set("Working: " + this.working);
        this.searchButton.visible = !this.ipBox.get().isEmpty();
    }

    private boolean isServerInList(String ip) {
        for (int i = 0; i < this.multiplayerScreen.method_2529().method_2984(); i++) {
            if (this.multiplayerScreen.method_2529().method_2982(i).field_3761.equals(ip)) {
                return true;
            }
        }
        return false;
    }

    public void method_25419() {
        this.state = ServerFinderState.CANCELLED;
        super.method_25419();
    }

    private boolean filterPass(MServerInfo info) {
        if (info == null || info.playerCount < this.playerCountFilter) {
            return false;
        }
        Iterator<String> it = this.versionFilters.iterator();
        while (it.hasNext()) {
            String version = it.next();
            if (info.version != null && info.version.contains(version)) {
                return true;
            }
        }
        return this.versionFilters.isEmpty();
    }

    @Override
    public void onServerDone(ServerPinger pinger) {
        if (this.state == ServerFinderState.CANCELLED || pinger == null || pinger.getSearchNumber() != searchNumber) {
            return;
        }
        synchronized (this.serverFinderLock) {
            this.checked++;
            this.numActiveThreads--;
        }
        if (pinger.isWorking() && !isServerInList(pinger.getServerIP()) && filterPass(pinger.getServerInfo())) {
            synchronized (this.serverFinderLock) {
                this.working++;
                this.multiplayerScreen.method_2529().method_2988(new class_642("Server discovery #" + this.working, pinger.getServerIP(), class_642.class_8678.field_45611), false);
                this.multiplayerScreen.method_2529().method_2987();
                this.multiplayerScreen.getServerListWidget().method_20122((class_4267.class_504) null);
                this.multiplayerScreen.getServerListWidget().method_20125(this.multiplayerScreen.method_2529());
            }
        }
        while (this.numActiveThreads < this.maxThreads && pingNewIP()) {
        }
        synchronized (this.serverFinderLock) {
            if (this.checked == this.targetChecked) {
                this.state = ServerFinderState.DONE;
            }
        }
    }

    @Override
    public void onServerFailed(ServerPinger pinger) {
        if (this.state == ServerFinderState.CANCELLED || pinger == null || pinger.getSearchNumber() != searchNumber) {
            return;
        }
        synchronized (this.serverFinderLock) {
            this.checked++;
            this.numActiveThreads--;
        }
        while (this.numActiveThreads < this.maxThreads && pingNewIP()) {
        }
        synchronized (this.serverFinderLock) {
            if (this.checked == this.targetChecked) {
                this.state = ServerFinderState.DONE;
            }
        }
    }

    public enum ServerFinderState {
        NOT_RUNNING(""),
        SEARCHING("Searching..."),
        RESOLVING("Resolving..."),
        UNKNOWN_HOST("Unknown Host!"),
        CANCELLED("Cancelled!"),
        DONE("Done!"),
        ERROR("An error occurred!");

        private final String name;

        ServerFinderState(String name) {
            this.name = name;
        }

        public boolean isRunning() {
            return this == SEARCHING || this == RESOLVING;
        }

        @Override
        public String toString() {
            return this.name;
        }
    }
}
