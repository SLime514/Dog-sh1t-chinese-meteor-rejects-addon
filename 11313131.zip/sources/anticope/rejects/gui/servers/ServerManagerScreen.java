package anticope.rejects.gui.servers;

import anticope.rejects.MeteorRejectsAddon;
import anticope.rejects.utils.server.IPAddress;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.OpenOption;
import java.nio.file.Path;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.function.Consumer;
import meteordevelopment.meteorclient.gui.GuiTheme;
import meteordevelopment.meteorclient.gui.WindowScreen;
import meteordevelopment.meteorclient.gui.widgets.containers.WContainer;
import meteordevelopment.meteorclient.gui.widgets.containers.WHorizontalList;
import meteordevelopment.meteorclient.gui.widgets.pressable.WButton;
import meteordevelopment.meteorclient.utils.misc.IGetter;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_370;
import net.minecraft.class_4267;
import net.minecraft.class_437;
import net.minecraft.class_500;
import net.minecraft.class_641;
import net.minecraft.class_642;
import org.lwjgl.BufferUtils;
import org.lwjgl.PointerBuffer;
import org.lwjgl.system.MemoryUtil;
import org.lwjgl.util.tinyfd.TinyFileDialogs;

public class ServerManagerScreen extends WindowScreen {
    private static final PointerBuffer saveFileFilters = BufferUtils.createPointerBuffer(1);
    private final class_500 multiplayerScreen;

    static {
        saveFileFilters.put(MemoryUtil.memASCII("*.txt"));
        saveFileFilters.rewind();
    }

    public ServerManagerScreen(GuiTheme theme, class_500 multiplayerScreen) {
        super(theme, "Manage Servers");
        this.parent = multiplayerScreen;
        this.multiplayerScreen = multiplayerScreen;
    }

    public static Runnable tryHandle(ThrowingRunnable<?> tr, Consumer<Throwable> handler) {
        return ((ThrowingRunnable) Objects.requireNonNull(tr)).addHandler(handler);
    }

    public void initWidgets() {
        WHorizontalList l = add(this.theme.horizontalList()).expandX().widget();
        addButton(l, "Find Servers (new)", () -> {
            return new ServerFinderScreen(this.theme, this.multiplayerScreen, this);
        });
        addButton(l, "Find Servers (legacy)", () -> {
            return new LegacyServerFinderScreen(this.theme, this.multiplayerScreen, this);
        });
        addButton(l, "Clean Up", () -> {
            return new CleanUpScreen(this.theme, this.multiplayerScreen, this);
        });
        WHorizontalList l2 = add(this.theme.horizontalList()).expandX().widget();
        l2.add(this.theme.button("Save IPs")).expandX().widget().action = tryHandle(() -> {
            String targetPath = TinyFileDialogs.tinyfd_saveFileDialog("Save IPs", (CharSequence) null, saveFileFilters, (CharSequence) null);
            if (targetPath == null) {
                return;
            }
            if (!targetPath.endsWith(".txt")) {
                targetPath = targetPath + ".txt";
            }
            Path filePath = Path.of(targetPath, new String[0]);
            int newIPs = 0;
            Set<IPAddress> hashedIPs = new HashSet<>();
            if (Files.exists(filePath, new LinkOption[0])) {
                try {
                    List<String> ips = Files.readAllLines(filePath);
                    for (String ip : ips) {
                        IPAddress parsedIP = IPAddress.fromText(ip);
                        if (parsedIP != null) {
                            hashedIPs.add(parsedIP);
                        }
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            class_641 servers = this.multiplayerScreen.method_2529();
            for (int i = 0; i < servers.method_2984(); i++) {
                class_642 info = servers.method_2982(i);
                IPAddress addr = IPAddress.fromText(info.field_3761);
                if (addr != null && hashedIPs.add(addr)) {
                    newIPs++;
                }
            }
            StringBuilder fileOutput = new StringBuilder();
            for (IPAddress ip2 : hashedIPs) {
                String stringIP = ip2.toString();
                if (stringIP != null) {
                    fileOutput.append(stringIP).append("\n");
                }
            }
            try {
                Files.writeString(filePath, fileOutput.toString(), new OpenOption[0]);
            } catch (IOException e2) {
                e2.printStackTrace();
            }
            toast("Success!", newIPs == 1 ? "Saved %s new IP" : "Saved %s new IPs", Integer.valueOf(newIPs));
        }, e -> {
            MeteorRejectsAddon.LOG.error("Could not save IPs");
            toast("Something went wrong", "The IPs could not be saved, look at the log for details", new Object[0]);
        });
        l2.add(this.theme.button("Load IPs")).expandX().widget().action = tryHandle(() -> {
            String targetPath = TinyFileDialogs.tinyfd_openFileDialog("Load IPs", (CharSequence) null, saveFileFilters, "", false);
            if (targetPath == null) {
                return;
            }
            Path filePath = Path.of(targetPath, new String[0]);
            if (Files.exists(filePath, new LinkOption[0])) {
                List<class_642> servers = this.multiplayerScreen.method_2529().getServers();
                Set<String> presentAddresses = new HashSet<>();
                int newIPs = 0;
                for (class_642 server : servers) {
                    presentAddresses.add(server.field_3761);
                }
                for (String str : class_310.method_1551().field_1774.method_1460().split("[\r\n]+")) {
                    String addr = str.split(" ")[0];
                    if (presentAddresses.add(addr)) {
                        servers.add(new class_642("Server discovery #" + presentAddresses.size(), addr, class_642.class_8678.field_45611));
                        newIPs++;
                    }
                }
                this.multiplayerScreen.method_2529().method_2987();
                this.multiplayerScreen.getServerListWidget().method_20122((class_4267.class_504) null);
                this.multiplayerScreen.getServerListWidget().method_20125(this.multiplayerScreen.method_2529());
                toast("Success!", newIPs == 1 ? "Loaded %s new IP" : "Loaded %s new IPs", Integer.valueOf(newIPs));
            }
        }, e2 -> {
            MeteorRejectsAddon.LOG.error("Could not load IPs");
            toast("Something went wrong", "The IPs could not be loaded, look at the log for details", new Object[0]);
        });
    }

    private void toast(String titleKey, String descriptionKey, Object... params) {
        class_370.method_27024(this.field_22787.method_1566(), class_370.class_9037.field_47584, class_2561.method_43470(titleKey), class_2561.method_43469(descriptionKey, params));
    }

    private void addButton(WContainer c, String text, IGetter<class_437> action) {
        WButton button = c.add(this.theme.button(text)).expandX().widget();
        button.action = () -> {
            this.field_22787.method_1507((class_437) action.get());
        };
    }

    public interface ThrowingRunnable<TEx extends Throwable> {
        void run() throws Throwable;

        default Runnable addHandler(Consumer<Throwable> handler) {
            Objects.requireNonNull(handler);
            return () -> {
                try {
                    run();
                } catch (Throwable var3) {
                    handler.accept(var3);
                }
            };
        }
    }
}
