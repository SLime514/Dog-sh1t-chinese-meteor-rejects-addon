package anticope.rejects.gui.servers;

import anticope.rejects.utils.server.LegacyServerPinger;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import meteordevelopment.meteorclient.gui.GuiTheme;
import meteordevelopment.meteorclient.gui.WindowScreen;
import meteordevelopment.meteorclient.gui.widgets.WLabel;
import meteordevelopment.meteorclient.gui.widgets.containers.WTable;
import meteordevelopment.meteorclient.gui.widgets.input.WIntEdit;
import meteordevelopment.meteorclient.gui.widgets.input.WTextBox;
import meteordevelopment.meteorclient.gui.widgets.pressable.WButton;
import net.minecraft.class_4267;
import net.minecraft.class_437;
import net.minecraft.class_500;
import net.minecraft.class_642;

public class LegacyServerFinderScreen extends WindowScreen {
    private final class_500 multiplayerScreen;
    private final WTextBox ipBox;
    private final WIntEdit maxThreadsBox;
    private final WButton searchButton;
    private final WLabel stateLabel;
    private final WLabel checkedLabel;
    private final WLabel workingLabel;
    private ServerFinderState state;
    private int maxThreads;
    private int checked;
    private int working;

    public LegacyServerFinderScreen(GuiTheme theme, class_500 multiplayerScreen, class_437 parent) {
        super(theme, "Legacy Server Discovery");
        this.multiplayerScreen = multiplayerScreen;
        this.parent = parent;
        this.ipBox = theme.textBox("127.0.0.1");
        this.maxThreadsBox = theme.intEdit(128, 1, 256, 1, 256);
        this.stateLabel = theme.label("");
        this.checkedLabel = theme.label("");
        this.workingLabel = theme.label("");
        this.searchButton = theme.button("Search");
        this.state = ServerFinderState.NOT_RUNNING;
    }

    public void initWidgets() {
        add(this.theme.label("This will search for servers with similar IPs"));
        add(this.theme.label("to the IP you type into the field below."));
        add(this.theme.label("The servers it finds will be added to your server list."));
        WTable table = add(new WTable()).expandX().widget();
        table.add(this.theme.label("Server address:"));
        table.add(this.ipBox).expandX();
        table.row();
        table.add(this.theme.label("Max. Threads:"));
        table.add(this.maxThreadsBox);
        add(this.stateLabel);
        add(this.checkedLabel);
        add(this.workingLabel);
        add(this.searchButton).expandX();
        this.searchButton.action = this::searchOrCancel;
    }

    private void searchOrCancel() {
        if (this.state.isRunning()) {
            this.state = ServerFinderState.CANCELLED;
            return;
        }
        this.state = ServerFinderState.RESOLVING;
        this.maxThreads = this.maxThreadsBox.get();
        this.checked = 0;
        this.working = 0;
        new Thread(this::findServers, "Server Discovery").start();
    }

    private void findServers() throws UnknownHostException {
        try {
            InetAddress addr = InetAddress.getByName(this.ipBox.get().split(":")[0].trim());
            int[] ipParts = new int[4];
            for (int i = 0; i < 4; i++) {
                ipParts[i] = addr.getAddress()[i] & 255;
            }
            this.state = ServerFinderState.SEARCHING;
            ArrayList<LegacyServerPinger> pingers = new ArrayList<>();
            int[] changes = {0, 1, -1, 2, -2, 3, -3};
            for (int change : changes) {
                for (int i2 = 0; i2 <= 255; i2++) {
                    if (this.state == ServerFinderState.CANCELLED) {
                        return;
                    }
                    int[] ipParts2 = (int[]) ipParts.clone();
                    ipParts2[2] = (ipParts[2] + change) & 255;
                    ipParts2[3] = i2;
                    String ip = ipParts2[0] + "." + ipParts2[1] + "." + ipParts2[2] + "." + ipParts2[3];
                    LegacyServerPinger pinger = new LegacyServerPinger();
                    pinger.ping(ip);
                    pingers.add(pinger);
                    while (pingers.size() >= this.maxThreads) {
                        if (this.state == ServerFinderState.CANCELLED) {
                            return;
                        } else {
                            updatePingers(pingers);
                        }
                    }
                }
            }
            while (!pingers.isEmpty()) {
                if (this.state == ServerFinderState.CANCELLED) {
                    return;
                } else {
                    updatePingers(pingers);
                }
            }
            this.state = ServerFinderState.DONE;
        } catch (UnknownHostException e) {
            this.state = ServerFinderState.UNKNOWN_HOST;
        } catch (Exception e2) {
            e2.printStackTrace();
            this.state = ServerFinderState.ERROR;
        }
    }

    public void method_25393() {
        this.searchButton.set(this.state.isRunning() ? "Cancel" : "Search");
        if (this.state.isRunning()) {
            this.ipBox.setFocused(false);
            this.maxThreadsBox.set(this.maxThreads);
        }
        this.stateLabel.set(this.state.toString());
        this.checkedLabel.set("Checked: " + this.checked + " / 1792");
        this.workingLabel.set("Working: " + this.working);
        this.searchButton.visible = !this.ipBox.get().isEmpty();
    }

    private boolean isServerInList(String ip) {
        for (int i = 0; i < this.multiplayerScreen.method_2529().method_2984(); i++) {
            if (this.multiplayerScreen.method_2529().method_2982(i).field_3761.equals(ip)) {
                return true;
            }
        }
        return false;
    }

    private void updatePingers(ArrayList<LegacyServerPinger> pingers) {
        for (int i = 0; i < pingers.size(); i++) {
            if (!pingers.get(i).isStillPinging()) {
                this.checked++;
                if (pingers.get(i).isWorking()) {
                    this.working++;
                    if (!isServerInList(pingers.get(i).getServerIP())) {
                        this.multiplayerScreen.method_2529().method_2988(new class_642("Server discovery " + this.working, pingers.get(i).getServerIP(), class_642.class_8678.field_45611), false);
                        this.multiplayerScreen.method_2529().method_2987();
                        this.multiplayerScreen.getServerListWidget().method_20122((class_4267.class_504) null);
                        this.multiplayerScreen.getServerListWidget().method_20125(this.multiplayerScreen.method_2529());
                    }
                }
                pingers.remove(i);
            }
        }
    }

    public void method_25419() {
        this.state = ServerFinderState.CANCELLED;
        super.method_25419();
    }

    enum ServerFinderState {
        NOT_RUNNING(""),
        SEARCHING("Searching..."),
        RESOLVING("Resolving..."),
        UNKNOWN_HOST("Unknown Host!"),
        CANCELLED("Cancelled!"),
        DONE("Done!"),
        ERROR("An error occurred!");

        private final String name;

        ServerFinderState(String name) {
            this.name = name;
        }

        public boolean isRunning() {
            return this == SEARCHING || this == RESOLVING;
        }

        @Override
        public String toString() {
            return this.name;
        }
    }
}
