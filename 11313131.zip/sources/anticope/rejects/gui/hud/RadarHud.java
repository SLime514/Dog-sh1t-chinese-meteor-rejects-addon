package anticope.rejects.gui.hud;

import anticope.rejects.MeteorRejectsAddon;
import java.util.Iterator;
import java.util.Set;
import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.renderer.Renderer2D;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.ColorSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.EntityTypeListSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.hud.HudElement;
import meteordevelopment.meteorclient.systems.hud.HudElementInfo;
import meteordevelopment.meteorclient.systems.hud.HudRenderer;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.systems.modules.render.ESP;
import meteordevelopment.meteorclient.systems.waypoints.Waypoint;
import meteordevelopment.meteorclient.systems.waypoints.Waypoints;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_4587;

public class RadarHud extends HudElement {
    public static final HudElementInfo<RadarHud> INFO = new HudElementInfo<>(MeteorRejectsAddon.HUD_GROUP, "radar", "Draws a Radar on your HUD telling you where entities are.", RadarHud::new);
    private final SettingGroup sgGeneral;
    private final Setting<SettingColor> backgroundColor;
    private final Setting<Set<class_1299<?>>> entities;
    private final Setting<Boolean> letters;
    private final Setting<Boolean> showWaypoints;
    private final Setting<Double> scale;
    private final Setting<Double> zoom;

    public RadarHud() {
        super(INFO);
        this.sgGeneral = this.settings.getDefaultGroup();
        this.backgroundColor = this.sgGeneral.add(((ColorSetting.Builder) ((ColorSetting.Builder) new ColorSetting.Builder().name("background-color")).description("Color of background.")).defaultValue(new SettingColor(0, 0, 0, 64)).build());
        this.entities = this.sgGeneral.add(((EntityTypeListSetting.Builder) ((EntityTypeListSetting.Builder) new EntityTypeListSetting.Builder().name("entities")).description("Select specific entities.")).defaultValue(new class_1299[]{class_1299.field_6097}).build());
        this.letters = this.sgGeneral.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("letters")).description("Use entity's type first letter.")).defaultValue(true)).build());
        this.showWaypoints = this.sgGeneral.add(((BoolSetting.Builder) ((BoolSetting.Builder) ((BoolSetting.Builder) new BoolSetting.Builder().name("waypoints")).description("Show waypoints.")).defaultValue(false)).build());
        this.scale = this.sgGeneral.add(((DoubleSetting.Builder) ((DoubleSetting.Builder) ((DoubleSetting.Builder) new DoubleSetting.Builder().name("scale")).description("The scale.")).defaultValue(1.0d).min(1.0d).sliderRange(0.01d, 5.0d).onChanged(aDouble -> {
            calculateSize();
        })).build());
        this.zoom = this.sgGeneral.add(((DoubleSetting.Builder) ((DoubleSetting.Builder) new DoubleSetting.Builder().name("zoom")).description("Radar zoom.")).defaultValue(1.0d).min(0.01d).sliderRange(0.01d, 3.0d).build());
        calculateSize();
    }

    public void calculateSize() {
        setSize(200.0d * ((Double) this.scale.get()).doubleValue(), 200.0d * ((Double) this.scale.get()).doubleValue());
    }

    public void render(HudRenderer renderer) {
        ESP esp = Modules.get().get(ESP.class);
        if (esp == null) {
            return;
        }
        renderer.post(() -> {
            if (MeteorClient.mc.field_1724 == null) {
                return;
            }
            double width = getWidth();
            double height = getHeight();
            Renderer2D.COLOR.begin();
            Renderer2D.COLOR.quad(this.x, this.y, width, height, (Color) this.backgroundColor.get());
            Renderer2D.COLOR.render((class_4587) null);
            if (MeteorClient.mc.field_1687 != null) {
                for (class_1297 entity : MeteorClient.mc.field_1687.method_18112()) {
                    if (!((Set) this.entities.get()).contains(entity.method_5864())) {
                        return;
                    }
                    double xPos = ((entity.method_23317() - MeteorClient.mc.field_1724.method_23317()) * ((Double) this.scale.get()).doubleValue() * ((Double) this.zoom.get()).doubleValue()) + (width / 2.0d);
                    double yPos = ((entity.method_23321() - MeteorClient.mc.field_1724.method_23321()) * ((Double) this.scale.get()).doubleValue() * ((Double) this.zoom.get()).doubleValue()) + (height / 2.0d);
                    if (xPos >= 0.0d && yPos >= 0.0d && xPos <= width - ((Double) this.scale.get()).doubleValue() && yPos <= height - ((Double) this.scale.get()).doubleValue()) {
                        String icon = "*";
                        if (((Boolean) this.letters.get()).booleanValue()) {
                            icon = entity.method_5864().method_35050().substring(0, 1).toUpperCase();
                        }
                        Color c = esp.getColor(entity);
                        if (c == null) {
                            c = Color.WHITE;
                        }
                        renderer.text(icon, xPos + this.x, yPos + this.y, c, false);
                    }
                }
            }
            if (((Boolean) this.showWaypoints.get()).booleanValue()) {
                Iterator it = Waypoints.get().iterator();
                while (it.hasNext()) {
                    Waypoint waypoint = (Waypoint) it.next();
                    class_2338 blockPos = waypoint.getPos();
                    class_243 coords = new class_243(blockPos.method_10263() + 0.5d, blockPos.method_10264(), blockPos.method_10260() + 0.5d);
                    double xPos2 = ((coords.method_10216() - MeteorClient.mc.field_1724.method_23317()) * ((Double) this.scale.get()).doubleValue() * ((Double) this.zoom.get()).doubleValue()) + (width / 2.0d);
                    double yPos2 = ((coords.method_10215() - MeteorClient.mc.field_1724.method_23321()) * ((Double) this.scale.get()).doubleValue() * ((Double) this.zoom.get()).doubleValue()) + (height / 2.0d);
                    if (xPos2 >= 0.0d && yPos2 >= 0.0d && xPos2 <= width - ((Double) this.scale.get()).doubleValue() && yPos2 <= height - ((Double) this.scale.get()).doubleValue()) {
                        String icon2 = "*";
                        if (((Boolean) this.letters.get()).booleanValue() && !((String) waypoint.name.get()).isEmpty()) {
                            icon2 = ((String) waypoint.name.get()).substring(0, 1);
                        }
                        renderer.text(icon2, xPos2 + this.x, yPos2 + this.y, (Color) waypoint.color.get(), false);
                    }
                }
            }
            Renderer2D.COLOR.render((class_4587) null);
        });
    }
}
