package anticope.rejects.gui.screens;

import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.gui.GuiTheme;
import meteordevelopment.meteorclient.gui.GuiThemes;
import meteordevelopment.meteorclient.gui.WindowScreen;
import meteordevelopment.meteorclient.gui.widgets.containers.WSection;
import meteordevelopment.meteorclient.utils.world.TickRate;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1078;
import net.minecraft.class_1291;
import net.minecraft.class_1292;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1320;
import net.minecraft.class_238;
import net.minecraft.class_2477;

public class StatsScreen extends WindowScreen {
    public final class_1297 entity;
    private boolean effectListExpanded;
    private boolean attribListExpanded;
    private boolean dimensionExpanded;

    public StatsScreen(class_1297 e) {
        super(GuiThemes.get(), e.method_5477().getString());
        this.effectListExpanded = true;
        this.attribListExpanded = true;
        this.dimensionExpanded = true;
        this.entity = e;
        updateData();
        MeteorClient.EVENT_BUS.subscribe(this);
    }

    protected void onClosed() {
        MeteorClient.EVENT_BUS.unsubscribe(this);
        super.onClosed();
    }

    private void updateData() {
        clear();
        GuiTheme theme = GuiThemes.get();
        class_2477 lang = class_1078.method_10517();
        add(theme.label(String.format("Type: %s", lang.method_48307(this.entity.method_5864().method_5882()))));
        add(theme.label(String.format("Age: %d", Integer.valueOf(this.entity.field_6012))));
        add(theme.label(String.format("UUID: %s", this.entity.method_5845())));
        class_1309 class_1309Var = this.entity;
        if (class_1309Var instanceof class_1309) {
            class_1309 liv = class_1309Var;
            add(theme.label(String.format("Health: %.2f/%.2f", Float.valueOf(liv.method_6032()), Float.valueOf(liv.method_6063()))));
            add(theme.label(String.format("Armor: %d/20", Integer.valueOf(liv.method_6096()))));
            WSection effectList = add(theme.section("Status Effects", this.effectListExpanded)).expandX().widget();
            effectList.action = () -> {
                this.effectListExpanded = effectList.isExpanded();
            };
            liv.method_6088().forEach((effect, instance) -> {
                String status;
                String status2 = lang.method_48307(((class_1291) effect.comp_349()).method_5567());
                float tps = TickRate.INSTANCE.getTickRate();
                if (instance.method_5578() != 0) {
                    status = status2 + String.format(" %d (%s)", Integer.valueOf(instance.method_5578() + 1), class_1292.method_5577(instance, 1.0f, tps));
                } else {
                    status = status2 + String.format(" (%s)", class_1292.method_5577(instance, 1.0f, tps));
                }
                effectList.add(theme.label(status)).expandX();
            });
            if (liv.method_6088().isEmpty()) {
                effectList.add(theme.label("No effects")).expandX();
            }
            WSection attribList = add(theme.section("Attributes", this.attribListExpanded)).expandX().widget();
            attribList.action = () -> {
                this.attribListExpanded = attribList.isExpanded();
            };
            liv.method_6127().method_60497().forEach(attrib -> {
                attribList.add(theme.label(String.format("%s: %.2f", lang.method_48307(((class_1320) attrib.method_6198().comp_349()).method_26830()), Double.valueOf(attrib.method_6194())))).expandX();
            });
        }
        WSection dimension = add(theme.section("Dimensions", this.dimensionExpanded)).expandX().widget();
        dimension.action = () -> {
            this.dimensionExpanded = dimension.isExpanded();
        };
        dimension.add(theme.label(String.format("Position: %.2f, %.2f, %.2f", Double.valueOf(this.entity.method_23317()), Double.valueOf(this.entity.method_23318()), Double.valueOf(this.entity.method_23321())))).expandX();
        dimension.add(theme.label(String.format("Yaw: %.2f, Pitch: %.2f", Float.valueOf(this.entity.method_36454()), Float.valueOf(this.entity.method_36455())))).expandX();
        class_238 box = this.entity.method_5829();
        dimension.add(theme.label(String.format("Bounding Box: %.2f, %.2f, %.2f", Double.valueOf(box.field_1320 - box.field_1323), Double.valueOf(box.field_1325 - box.field_1322), Double.valueOf(box.field_1324 - box.field_1321)))).expandX();
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        updateData();
    }

    public void initWidgets() {
    }
}
