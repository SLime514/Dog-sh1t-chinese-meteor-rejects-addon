package anticope.rejects.gui.screens;

import anticope.rejects.mixin.EntityAccessor;
import anticope.rejects.modules.InteractionMenu;
import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import com.seedfinding.mccore.nbt.NBTType;
import java.awt.Point;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.runtime.SwitchBootstraps;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Consumer;
import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.events.meteor.KeyEvent;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.utils.misc.Keybind;
import meteordevelopment.meteorclient.utils.misc.MeteorStarscript;
import meteordevelopment.meteorclient.utils.render.PeekScreen;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import meteordevelopment.starscript.Script;
import meteordevelopment.starscript.Section;
import meteordevelopment.starscript.compiler.Compiler;
import meteordevelopment.starscript.compiler.Parser;
import meteordevelopment.starscript.utils.Error;
import meteordevelopment.starscript.utils.StarscriptError;
import net.minecraft.class_10142;
import net.minecraft.class_10185;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1496;
import net.minecraft.class_1560;
import net.minecraft.class_1657;
import net.minecraft.class_1693;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1921;
import net.minecraft.class_2561;
import net.minecraft.class_2824;
import net.minecraft.class_2851;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_3675;
import net.minecraft.class_408;
import net.minecraft.class_437;
import net.minecraft.class_4587;
import net.minecraft.class_490;
import net.minecraft.class_5146;
import net.minecraft.class_9334;
import org.joml.Vector2f;

public class InteractionScreen extends class_437 {
    public static class_1297 interactionMenuEntity;
    private final class_1297 entity;
    private String focusedString;
    private int crosshairX;
    private int crosshairY;
    private int focusedDot;
    private float yaw;
    private float pitch;
    private final Map<String, Consumer<class_1297>> functions;
    private final Map<String, String> msgs;
    private final class_2960 GUI_ICONS_TEXTURE;
    private final StaticListener shiftListener;
    private final int selectedDotColor;
    private final int dotColor;
    private final int backgroundColor;
    private final int borderColor;
    private final int textColor;

    public InteractionScreen(class_1297 e) {
        this(e, (InteractionMenu) Modules.get().get(InteractionMenu.class));
    }

    public InteractionScreen(class_1297 entity, InteractionMenu module) {
        super(class_2561.method_43470("Menu Screen"));
        this.focusedString = null;
        this.focusedDot = -1;
        this.GUI_ICONS_TEXTURE = class_2960.method_60654("textures/gui/icons.png");
        this.shiftListener = new StaticListener();
        if (module == null) {
            closeScreen();
        }
        this.selectedDotColor = ((SettingColor) module.selectedDotColor.get()).getPacked();
        this.dotColor = ((SettingColor) module.dotColor.get()).getPacked();
        this.backgroundColor = ((SettingColor) module.backgroundColor.get()).getPacked();
        this.borderColor = ((SettingColor) module.borderColor.get()).getPacked();
        this.textColor = ((SettingColor) module.textColor.get()).getPacked();
        this.entity = entity;
        this.functions = new HashMap();
        this.functions.put("Stats", e -> {
            closeScreen();
            this.field_22787.method_1507(new StatsScreen(e));
        });
        switch ((int) SwitchBootstraps.typeSwitch(MethodHandles.lookup(), "typeSwitch", MethodType.methodType(Integer.TYPE, Object.class, Integer.TYPE), class_1657.class, class_1496.class, class_1693.class).dynamicInvoker().invoke(entity, 0) /* invoke-custom */) {
            case -1:
            default:
                this.functions.put("Open Inventory", e2 -> {
                    closeScreen();
                    class_1799 container = new class_1799(class_1802.field_8106);
                    container.method_57379(class_9334.field_49631, e2.method_5477());
                    this.field_22787.method_1507(new PeekScreen(container, getInventory(e2)));
                });
                break;
            case 0:
                this.functions.put("Open Inventory", e3 -> {
                    closeScreen();
                    this.field_22787.method_1507(new class_490((class_1657) e3));
                });
                break;
            case 1:
                this.functions.put("Open Inventory", e4 -> {
                    closeScreen();
                    if (this.field_22787.field_1724.method_3144()) {
                        this.field_22787.field_1724.field_3944.method_52787(new class_2851(new class_10185(false, false, false, false, false, true, false)));
                    }
                    this.field_22787.field_1724.field_3944.method_52787(class_2824.method_34207(entity, true, class_1268.field_5808));
                    this.field_22787.field_1724.method_5660(false);
                });
                break;
            case NBTType.SHORT:
                this.functions.put("Open Inventory", e5 -> {
                    closeScreen();
                    this.field_22787.field_1724.field_3944.method_52787(class_2824.method_34207(entity, true, class_1268.field_5808));
                });
                break;
        }
        this.functions.put("Spectate", e6 -> {
            class_310.method_1551().method_1504(e6);
            this.field_22787.field_1724.method_7353(class_2561.method_43470("Sneak to un-spectate."), true);
            MeteorClient.EVENT_BUS.subscribe(this.shiftListener);
            closeScreen();
        });
        if (entity.method_5851()) {
            this.functions.put("Remove glow", e7 -> {
                e7.method_5834(false);
                ((EntityAccessor) e7).invokeSetFlag(6, false);
                closeScreen();
            });
        } else {
            this.functions.put("Glow", e8 -> {
                e8.method_5834(true);
                ((EntityAccessor) e8).invokeSetFlag(6, true);
                closeScreen();
            });
        }
        if (entity.field_5960) {
            this.functions.put("Disable NoClip", e9 -> {
                entity.field_5960 = false;
                closeScreen();
            });
        } else {
            this.functions.put("NoClip", e10 -> {
                entity.field_5960 = true;
                closeScreen();
            });
        }
        this.msgs = (Map) ((InteractionMenu) Modules.get().get(InteractionMenu.class)).messages.get();
        this.msgs.keySet().forEach(key -> {
            this.functions.put(key, e11 -> {
                closeScreen();
                interactionMenuEntity = e11;
                Parser.Result result = Parser.parse(this.msgs.get(key));
                if (result.hasErrors()) {
                    for (Error error : result.errors) {
                        MeteorStarscript.printChatError(error);
                    }
                    return;
                }
                Script script = Compiler.compile(result);
                try {
                    Section section = MeteorStarscript.ss.run(script);
                    this.field_22787.method_1507(new class_408(section.text));
                } catch (StarscriptError err) {
                    MeteorStarscript.printChatError(err);
                }
            });
        });
        this.functions.put("Cancel", e11 -> {
            closeScreen();
        });
    }

    private class_1799[] getInventory(class_1297 e) {
        class_1799[] stack = new class_1799[27];
        int[] index = {0};
        if (e instanceof class_1560) {
            try {
                stack[index[0]] = ((class_1560) e).method_7027().method_26204().method_8389().method_7854();
                index[0] = index[0] + 1;
            } catch (NullPointerException e2) {
            }
        }
        if ((e instanceof class_5146) && ((class_5146) e).method_6725()) {
            stack[index[0]] = class_1802.field_8175.method_7854();
            index[0] = index[0] + 1;
        }
        class_1309 a = (class_1309) e;
        a.method_5877().forEach(itemStack -> {
            if (itemStack != null) {
                stack[index[0]] = itemStack;
                index[0] = index[0] + 1;
            }
        });
        a.method_5661().forEach(itemStack2 -> {
            if (itemStack2 != null) {
                stack[index[0]] = itemStack2;
                index[0] = index[0] + 1;
            }
        });
        for (int i = index[0]; i < 27; i++) {
            stack[i] = class_1802.field_8162.method_7854();
        }
        return stack;
    }

    public void method_25426() {
        super.method_25426();
        cursorMode(212994);
        this.yaw = this.field_22787.field_1724.method_36454();
        this.pitch = this.field_22787.field_1724.method_36455();
    }

    private void cursorMode(int mode) {
        class_304.method_1437();
        double x = this.field_22787.method_22683().method_4480() / 2.0d;
        double y = this.field_22787.method_22683().method_4507() / 2.0d;
        class_3675.method_15984(this.field_22787.method_22683().method_4490(), mode, x, y);
    }

    public void method_25393() {
        if (((Keybind) ((InteractionMenu) Modules.get().get(InteractionMenu.class)).keybind.get()).isPressed()) {
            method_25419();
        }
    }

    private void closeScreen() {
        this.field_22787.method_1507((class_437) null);
    }

    public void method_25419() {
        cursorMode(212993);
        if (this.focusedString != null) {
            this.functions.get(this.focusedString).accept(this.entity);
        } else {
            this.field_22787.method_1507((class_437) null);
        }
    }

    public boolean isPauseScreen() {
        return false;
    }

    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        class_4587 matrix = context.method_51448();
        RenderSystem.setShaderColor(1.0f, 1.0f, 1.0f, 1.0f);
        RenderSystem.setShader(class_10142.field_53879);
        RenderSystem.enableBlend();
        RenderSystem.blendFuncSeparate(GlStateManager.class_4535.ONE_MINUS_DST_COLOR, GlStateManager.class_4534.ONE_MINUS_SRC_COLOR, GlStateManager.class_4535.ONE, GlStateManager.class_4534.ZERO);
        context.method_25290(class_1921::method_62277, this.GUI_ICONS_TEXTURE, this.crosshairX - 8, this.crosshairY - 8, 0.0f, 0.0f, 15, 15, 256, 256);
        drawDots(context, (int) ((Math.min(this.field_22790, this.field_22789) / 2) * 0.75d), mouseX, mouseY);
        matrix.method_22905(2.0f, 2.0f, 1.0f);
        context.method_27534(this.field_22793, this.entity.method_5477(), this.field_22789 / 4, 6, -1);
        Vector2f mouse = getMouseVecs(mouseX, mouseY);
        this.crosshairX = ((int) mouse.x) + (this.field_22789 / 2);
        this.crosshairY = ((int) mouse.y) + (this.field_22790 / 2);
        this.field_22787.field_1724.method_36456(this.yaw + (mouse.x / 3.0f));
        this.field_22787.field_1724.method_36457(class_3532.method_15363(this.pitch + (mouse.y / 3.0f), -90.0f, 90.0f));
        super.method_25394(context, mouseX, mouseY, delta);
    }

    private Vector2f getMouseVecs(int mouseX, int mouseY) {
        int scale = ((Integer) this.field_22787.field_1690.method_42474().method_41753()).intValue();
        Vector2f mouse = new Vector2f(mouseX, mouseY);
        Vector2f center = new Vector2f(this.field_22789 / 2, this.field_22790 / 2);
        mouse.sub(center).normalize();
        if (scale == 0) {
            scale = 4;
        }
        if (Math.hypot((this.field_22789 / 2) - mouseX, (this.field_22790 / 2) - mouseY) < (1.0f / scale) * 200.0f) {
            mouse.mul((float) Math.hypot((this.field_22789 / 2) - mouseX, (this.field_22790 / 2) - mouseY));
        } else {
            mouse.mul((1.0f / scale) * 200.0f);
        }
        return mouse;
    }

    private void drawDots(class_332 context, int radius, int mouseX, int mouseY) {
        ArrayList<Point> pointList = new ArrayList<>();
        String[] cache = new String[this.functions.size()];
        double lowestDistance = Double.MAX_VALUE;
        int i = 0;
        for (String string : this.functions.keySet()) {
            double s = (i / this.functions.size()) * 2.0d * 3.141592653589793d;
            int x = (int) Math.round((radius * Math.cos(s)) + (this.field_22789 / 2));
            int y = (int) Math.round((radius * Math.sin(s)) + (this.field_22790 / 2));
            drawTextField(context, x, y, string);
            if (Math.hypot(x - mouseX, y - mouseY) < lowestDistance) {
                lowestDistance = Math.hypot(x - mouseX, y - mouseY);
                this.focusedDot = i;
            }
            cache[i] = string;
            pointList.add(new Point(x, y));
            i++;
        }
        for (int j = 0; j < this.functions.size(); j++) {
            Point point = pointList.get(j);
            if (pointList.get(this.focusedDot) == point) {
                drawDot(context, point.x - 4, point.y - 4, this.selectedDotColor);
                this.focusedString = cache[this.focusedDot];
            } else {
                drawDot(context, point.x - 4, point.y - 4, this.dotColor);
            }
        }
    }

    private void drawRect(class_332 context, int startX, int startY, int width, int height, int colorInner, int colorOuter) {
        context.method_25292(startX, startX + width, startY, colorOuter);
        context.method_25292(startX, startX + width, startY + height, colorOuter);
        context.method_25301(startX, startY, startY + height, colorOuter);
        context.method_25301(startX + width, startY, startY + height, colorOuter);
        context.method_25294(startX + 1, startY + 1, startX + width, startY + height, colorInner);
    }

    private void drawTextField(class_332 context, int x, int y, String key) {
        if (x >= this.field_22789 / 2) {
            drawRect(context, x + 10, y - 8, this.field_22793.method_1727(key) + 3, 15, this.backgroundColor, this.borderColor);
            context.method_25303(this.field_22793, key, x + 12, y - 4, this.textColor);
        } else {
            drawRect(context, (x - 14) - this.field_22793.method_1727(key), y - 8, this.field_22793.method_1727(key) + 3, 15, this.backgroundColor, this.borderColor);
            context.method_25303(this.field_22793, key, (x - 12) - this.field_22793.method_1727(key), y - 4, this.textColor);
        }
    }

    private void drawDot(class_332 context, int startX, int startY, int colorInner) {
        context.method_25292(startX + 2, startX + 5, startY, this.borderColor);
        context.method_25292(startX + 1, startX + 6, startY + 1, this.borderColor);
        context.method_25292(startX + 2, startX + 5, startY + 1, colorInner);
        context.method_25294(startX, startY + 2, startX + 8, startY + 6, this.borderColor);
        context.method_25294(startX + 1, startY + 2, startX + 7, startY + 6, colorInner);
        context.method_25292(startX + 1, startX + 6, startY + 6, this.borderColor);
        context.method_25292(startX + 2, startX + 5, startY + 6, colorInner);
        context.method_25292(startX + 2, startX + 5, startY + 7, this.borderColor);
        context.method_25292(startX + 2, startX + 3, startY + 1, -2130706433);
        context.method_25292(startX + 1, startX + 1, startY + 2, -2130706433);
    }

    private class StaticListener {
        private StaticListener() {
        }

        @EventHandler
        private void onKey(KeyEvent event) {
            if (InteractionScreen.this.field_22787.field_1690.field_1832.method_1417(event.key, 0) || InteractionScreen.this.field_22787.field_1690.field_1832.method_1433(event.key)) {
                InteractionScreen.this.field_22787.method_1504(InteractionScreen.this.field_22787.field_1724);
                event.cancel();
                MeteorClient.EVENT_BUS.unsubscribe(this);
            }
        }
    }
}
