package anticope.rejects.gui.screens;

import anticope.rejects.utils.GiveUtils;
import com.google.common.reflect.TypeToken;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.gui.GuiTheme;
import meteordevelopment.meteorclient.gui.WindowScreen;
import meteordevelopment.meteorclient.gui.widgets.containers.WTable;
import meteordevelopment.meteorclient.gui.widgets.pressable.WButton;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.Settings;
import meteordevelopment.meteorclient.utils.network.Http;
import meteordevelopment.meteorclient.utils.network.MeteorExecutor;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2561;
import net.minecraft.class_9279;
import net.minecraft.class_9334;

public class HeadScreen extends WindowScreen {
    private final Settings settings;
    private final SettingGroup sgGeneral;
    private final Setting<Categories> categorySetting;
    private static final Type gsonType = new TypeToken<List<Map<String, String>>>() {
    }.getType();
    private static Categories category = Categories.Decoration;

    public enum Categories {
        Alphabet,
        Animals,
        Blocks,
        Decoration,
        Food_Drinks,
        Humanoid,
        Miscellaneous,
        Monsters,
        Plants
    }

    public HeadScreen(GuiTheme theme) {
        super(theme, "Heads");
        this.settings = new Settings();
        this.sgGeneral = this.settings.getDefaultGroup();
        this.categorySetting = this.sgGeneral.add(((EnumSetting.Builder) ((EnumSetting.Builder) ((EnumSetting.Builder) ((EnumSetting.Builder) new EnumSetting.Builder().name("Category")).defaultValue(category)).description("Category")).onChanged(v -> {
            loadHeads();
        })).build());
        loadHeads();
    }

    private void set() {
        clear();
        add(this.theme.settings(this.settings)).expandX();
        add(this.theme.horizontalSeparator()).expandX();
    }

    private String getCat() {
        category = (Categories) this.categorySetting.get();
        return category.toString().replace("_", "-");
    }

    private void loadHeads() {
        MeteorExecutor.execute(() -> {
            List<Map<String, String>> res = (List) Http.get("https://minecraft-heads.com/scripts/api.php?cat=" + getCat()).sendJson(gsonType);
            List<class_1799> heads = new ArrayList<>();
            res.forEach(a -> {
                try {
                    heads.add(createHeadStack((String) a.get("uuid"), (String) a.get("value"), (String) a.get("name")));
                } catch (Exception e) {
                }
            });
            WTable t = this.theme.table();
            for (class_1799 head : heads) {
                t.add(this.theme.item(head));
                t.add(this.theme.label(head.method_7964().getString()));
                WButton give = t.add(this.theme.button("Give")).widget();
                give.action = () -> {
                    try {
                        GiveUtils.giveItem(head);
                    } catch (CommandSyntaxException e) {
                        ChatUtils.errorPrefix("Heads", e.getMessage(), new Object[0]);
                    }
                };
                WButton equip = t.add(this.theme.button("Equip")).widget();
                equip.tooltip = "Equip client-side.";
                equip.action = () -> {
                    MeteorClient.mc.field_1724.method_31548().field_7548.set(3, head);
                };
                t.row();
            }
            set();
            add(t).expandX().minWidth(400.0d).widget();
        });
    }

    private class_1799 createHeadStack(String uuid, String value, String name) {
        class_1799 head = class_1802.field_8575.method_7854();
        class_2487 tag = new class_2487();
        class_2487 skullOwner = new class_2487();
        skullOwner.method_25927("Id", UUID.fromString(uuid));
        class_2487 properties = new class_2487();
        class_2499 textures = new class_2499();
        class_2487 Value = new class_2487();
        Value.method_10582("Value", value);
        textures.add(Value);
        properties.method_10566("textures", textures);
        skullOwner.method_10566("Properties", properties);
        tag.method_10566("SkullOwner", skullOwner);
        head.method_57379(class_9334.field_49628, class_9279.method_57456(tag));
        head.method_57379(class_9334.field_49631, class_2561.method_43470(name));
        return head;
    }

    public void initWidgets() {
    }
}
