package anticope.rejects.gui.themes.rounded.widgets.input;

import anticope.rejects.gui.themes.rounded.MeteorRoundedGuiTheme;
import anticope.rejects.gui.themes.rounded.MeteorWidget;
import meteordevelopment.meteorclient.gui.renderer.GuiRenderer;
import meteordevelopment.meteorclient.gui.widgets.input.WSlider;
import meteordevelopment.meteorclient.utils.render.color.Color;

public class WMeteorSlider extends WSlider implements MeteorWidget {
    public WMeteorSlider(double value, double min, double max) {
        super(value, min, max);
    }

    protected void onRender(GuiRenderer renderer, double mouseX, double mouseY, double delta) {
        double valueWidth = valueWidth();
        renderBar(renderer, valueWidth);
        renderHandle(renderer, valueWidth);
    }

    private void renderBar(GuiRenderer renderer, double valueWidth) {
        MeteorRoundedGuiTheme theme = theme();
        double s = theme.scale(3.0d);
        double handleSize = handleSize();
        double x = this.x + (handleSize / 2.0d);
        double y = (this.y + (this.height / 2.0d)) - (s / 2.0d);
        renderer.quad(x, y, valueWidth, s, (Color) theme.sliderLeft.get());
        renderer.quad(x + valueWidth, y, (this.width - valueWidth) - handleSize, s, (Color) theme.sliderRight.get());
    }

    private void renderHandle(GuiRenderer renderer, double valueWidth) {
        MeteorRoundedGuiTheme theme = theme();
        double s = handleSize();
        renderer.quad(this.x + valueWidth, this.y, s, s, GuiRenderer.CIRCLE, theme.sliderHandle.get(this.dragging, this.handleMouseOver));
    }
}
