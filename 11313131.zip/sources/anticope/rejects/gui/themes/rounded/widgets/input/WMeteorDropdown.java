package anticope.rejects.gui.themes.rounded.widgets.input;

import anticope.rejects.gui.themes.rounded.MeteorRoundedGuiTheme;
import anticope.rejects.gui.themes.rounded.MeteorWidget;
import meteordevelopment.meteorclient.gui.renderer.GuiRenderer;
import meteordevelopment.meteorclient.gui.widgets.input.WDropdown;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;

public class WMeteorDropdown<T> extends WDropdown<T> implements MeteorWidget {
    public WMeteorDropdown(T[] values, T value) {
        super(values, value);
    }

    protected WDropdown.WDropdownRoot createRootWidget() {
        return new WRoot();
    }

    protected WDropdown<T>.WDropdownValue createValueWidget() {
        return new WValue(this);
    }

    protected void onRender(GuiRenderer renderer, double mouseX, double mouseY, double delta) {
        MeteorRoundedGuiTheme theme = theme();
        double pad = pad();
        double s = theme.textHeight();
        renderBackground(renderer, this, this.pressed, this.mouseOver);
        String text = get().toString();
        double w = theme.textWidth(text);
        renderer.text(text, ((this.x + pad) + (this.maxValueWidth / 2.0d)) - (w / 2.0d), this.y + pad, (Color) theme.textColor.get(), false);
        renderer.rotatedQuad(this.x + pad + this.maxValueWidth + pad, this.y + pad, s, s, 0.0d, GuiRenderer.TRIANGLE, (Color) theme.textColor.get());
    }

    private static class WRoot extends WDropdown.WDropdownRoot implements MeteorWidget {
        private WRoot() {
        }

        protected void onRender(GuiRenderer renderer, double mouseX, double mouseY, double delta) {
            MeteorRoundedGuiTheme theme = theme();
            double s = theme.scale(2.0d);
            SettingColor settingColor = theme.outlineColor.get();
            renderer.quad(this.x, (this.y + this.height) - s, this.width, s, settingColor);
            renderer.quad(this.x, this.y, s, this.height - s, settingColor);
            renderer.quad((this.x + this.width) - s, this.y, s, this.height - s, settingColor);
        }
    }

    private class WValue extends WDropdown<T>.WDropdownValue implements MeteorWidget {
        private WValue(WMeteorDropdown wMeteorDropdown) {
            super(wMeteorDropdown);
        }

        protected void onCalculateSize() {
            double pad = pad();
            this.width = pad + this.theme.textWidth(this.value.toString()) + pad;
            this.height = pad + this.theme.textHeight() + pad;
        }

        protected void onRender(GuiRenderer renderer, double mouseX, double mouseY, double delta) {
            MeteorRoundedGuiTheme theme = theme();
            SettingColor settingColor = theme.backgroundColor.get(this.pressed, this.mouseOver, true);
            int preA = ((Color) settingColor).a;
            ((Color) settingColor).a += ((Color) settingColor).a / 2;
            settingColor.validate();
            renderer.quad(this, settingColor);
            ((Color) settingColor).a = preA;
            String text = this.value.toString();
            renderer.text(text, (this.x + (this.width / 2.0d)) - (theme.textWidth(text) / 2.0d), this.y + pad(), (Color) theme.textColor.get(), false);
        }
    }
}
