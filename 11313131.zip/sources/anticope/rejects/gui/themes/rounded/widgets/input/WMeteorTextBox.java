package anticope.rejects.gui.themes.rounded.widgets.input;

import anticope.rejects.gui.themes.rounded.MeteorRoundedGuiTheme;
import anticope.rejects.gui.themes.rounded.MeteorWidget;
import anticope.rejects.gui.themes.rounded.widgets.WMeteorLabel;
import meteordevelopment.meteorclient.gui.renderer.GuiRenderer;
import meteordevelopment.meteorclient.gui.utils.CharFilter;
import meteordevelopment.meteorclient.gui.widgets.WWidget;
import meteordevelopment.meteorclient.gui.widgets.containers.WContainer;
import meteordevelopment.meteorclient.gui.widgets.containers.WVerticalList;
import meteordevelopment.meteorclient.gui.widgets.input.WTextBox;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import net.minecraft.class_3532;

public class WMeteorTextBox extends WTextBox implements MeteorWidget {
    private boolean cursorVisible;
    private double cursorTimer;
    private double animProgress;

    public WMeteorTextBox(String text, String placeholder, CharFilter filter, Class<? extends WTextBox.Renderer> renderer) {
        super(text, placeholder, filter, renderer);
    }

    protected void onCursorChanged() {
        this.cursorVisible = true;
        this.cursorTimer = 0.0d;
    }

    protected void onRender(GuiRenderer renderer, double mouseX, double mouseY, double delta) {
        if (this.cursorTimer >= 1.0d) {
            this.cursorVisible = !this.cursorVisible;
            this.cursorTimer = 0.0d;
        } else {
            this.cursorTimer += delta * 1.75d;
        }
        renderBackground(renderer, this, false, false);
        MeteorRoundedGuiTheme theme = theme();
        double pad = pad();
        double overflowWidth = getOverflowWidthForRender();
        renderer.scissorStart(this.x + pad, this.y + pad, this.width - (pad * 2.0d), this.height - (pad * 2.0d));
        if (!this.text.isEmpty()) {
            renderer.text(this.text, (this.x + pad) - overflowWidth, this.y + pad, (Color) theme.textColor.get(), false);
        } else if (this.placeholder != null) {
            this.renderer.render(renderer, (this.x + pad) - overflowWidth, this.y + pad, this.placeholder, (Color) theme.placeholderColor.get());
        }
        if (this.focused && (this.cursor != this.selectionStart || this.cursor != this.selectionEnd)) {
            double selStart = ((this.x + pad) + getTextWidth(this.selectionStart)) - overflowWidth;
            double selEnd = ((this.x + pad) + getTextWidth(this.selectionEnd)) - overflowWidth;
            renderer.quad(selStart, this.y + pad, selEnd - selStart, theme.textHeight(), (Color) theme.textHighlightColor.get());
        }
        this.animProgress += delta * 10.0d * ((this.focused && this.cursorVisible) ? 1 : -1);
        this.animProgress = class_3532.method_15350(this.animProgress, 0.0d, 1.0d);
        if ((this.focused && this.cursorVisible) || this.animProgress > 0.0d) {
            renderer.setAlpha(this.animProgress);
            renderer.quad(((this.x + pad) + getTextWidth(this.cursor)) - overflowWidth, this.y + pad, theme.scale(1.0d), theme.textHeight(), (Color) theme.textColor.get());
            renderer.setAlpha(1.0d);
        }
        renderer.scissorEnd();
    }

    protected WContainer createCompletionsRootWidget() {
        return new WVerticalList() {
            protected void onRender(GuiRenderer renderer1, double mouseX, double mouseY, double delta) {
                MeteorRoundedGuiTheme theme1 = WMeteorTextBox.this.theme();
                double s = theme1.scale(2.0d);
                SettingColor settingColor = theme1.outlineColor.get();
                SettingColor settingColor2 = theme1.backgroundColor.get();
                int preA = ((Color) settingColor2).a;
                ((Color) settingColor2).a += ((Color) settingColor2).a / 2;
                settingColor2.validate();
                renderer1.quad(this, settingColor2);
                ((Color) settingColor2).a = preA;
                renderer1.quad(this.x, (this.y + this.height) - s, this.width, s, settingColor);
                renderer1.quad(this.x, this.y, s, this.height - s, settingColor);
                renderer1.quad((this.x + this.width) - s, this.y, s, this.height - s, settingColor);
            }
        };
    }

    protected <T extends WWidget & WTextBox.ICompletionItem> T createCompletionsValueWidth(String completion, boolean selected) {
        return new CompletionItem(completion, false, selected);
    }

    private static class CompletionItem extends WMeteorLabel implements WTextBox.ICompletionItem {
        private static final Color SELECTED_COLOR = new Color(255, 255, 255, 15);
        private boolean selected;

        public CompletionItem(String text, boolean title, boolean selected) {
            super(text, title);
            this.selected = selected;
        }

        @Override
        protected void onRender(GuiRenderer renderer, double mouseX, double mouseY, double delta) {
            super.onRender(renderer, mouseX, mouseY, delta);
            if (this.selected) {
                renderer.quad(this, SELECTED_COLOR);
            }
        }

        public boolean isSelected() {
            return this.selected;
        }

        public void setSelected(boolean selected) {
            this.selected = selected;
        }

        public String getCompletion() {
            return this.text;
        }
    }
}
