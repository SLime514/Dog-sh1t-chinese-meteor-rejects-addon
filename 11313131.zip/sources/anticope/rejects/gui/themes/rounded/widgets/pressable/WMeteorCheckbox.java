package anticope.rejects.gui.themes.rounded.widgets.pressable;

import anticope.rejects.gui.themes.rounded.MeteorRoundedGuiTheme;
import anticope.rejects.gui.themes.rounded.MeteorWidget;
import anticope.rejects.utils.gui.GuiUtils;
import meteordevelopment.meteorclient.gui.renderer.GuiRenderer;
import meteordevelopment.meteorclient.gui.widgets.pressable.WCheckbox;
import meteordevelopment.meteorclient.utils.render.color.Color;
import net.minecraft.class_3532;

public class WMeteorCheckbox extends WCheckbox implements MeteorWidget {
    private double animProgress;

    public WMeteorCheckbox(boolean checked) {
        super(checked);
        this.animProgress = checked ? 1.0d : 0.0d;
    }

    protected void onRender(GuiRenderer renderer, double mouseX, double mouseY, double delta) {
        MeteorRoundedGuiTheme theme = theme();
        this.animProgress += (this.checked ? 1 : -1) * delta * 14.0d;
        this.animProgress = class_3532.method_15350(this.animProgress, 0.0d, 1.0d);
        renderBackground(renderer, this, this.pressed, this.mouseOver);
        if (this.animProgress > 0.0d) {
            double cs = ((this.width - theme.scale(2.0d)) / 1.75d) * this.animProgress;
            GuiUtils.quadRounded(renderer, this.x + ((this.width - cs) / 2.0d), this.y + ((this.height - cs) / 2.0d), cs, cs, (Color) theme.checkboxColor.get(), theme.roundAmount());
        }
    }
}
