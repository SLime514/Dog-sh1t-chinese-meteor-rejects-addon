package anticope.rejects.gui.themes.rounded.widgets;

import anticope.rejects.gui.themes.rounded.MeteorRoundedGuiTheme;
import anticope.rejects.gui.themes.rounded.MeteorWidget;
import meteordevelopment.meteorclient.gui.renderer.GuiRenderer;
import meteordevelopment.meteorclient.gui.widgets.WVerticalSeparator;
import meteordevelopment.meteorclient.utils.render.color.Color;

public class WMeteorVerticalSeparator extends WVerticalSeparator implements MeteorWidget {
    protected void onRender(GuiRenderer renderer, double mouseX, double mouseY, double delta) {
        MeteorRoundedGuiTheme theme = theme();
        Color colorEdges = (Color) theme.separatorEdges.get();
        Color colorCenter = (Color) theme.separatorCenter.get();
        double s = theme.scale(1.0d);
        double offsetX = Math.round(this.width / 2.0d);
        renderer.quad(this.x + offsetX, this.y, s, this.height / 2.0d, colorEdges, colorEdges, colorCenter, colorCenter);
        renderer.quad(this.x + offsetX, this.y + (this.height / 2.0d), s, this.height / 2.0d, colorCenter, colorCenter, colorEdges, colorEdges);
    }
}
