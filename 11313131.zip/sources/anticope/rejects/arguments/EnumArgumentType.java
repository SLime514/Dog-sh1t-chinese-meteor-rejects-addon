package anticope.rejects.arguments;

import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.DynamicCommandExceptionType;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import java.lang.Enum;
import java.lang.reflect.InvocationTargetException;
import java.util.Arrays;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_2172;
import net.minecraft.class_2561;

public class EnumArgumentType<T extends Enum<?>> implements ArgumentType<T> {
    private static final DynamicCommandExceptionType NO_SUCH_TYPE = new DynamicCommandExceptionType(o -> {
        return class_2561.method_43470(String.valueOf(o) + " is not a valid argument.");
    });
    private T[] values;

    public EnumArgumentType(T t) {
        try {
            this.values = (T[]) ((Enum[]) t.getClass().getMethod("values", new Class[0]).invoke(null, new Object[0]));
        } catch (IllegalAccessException | NoSuchMethodException | InvocationTargetException e) {
            e.printStackTrace();
        }
    }

    public static <T extends Enum<?>> EnumArgumentType<T> enumArgument(T defaultValue) {
        return new EnumArgumentType<>(defaultValue);
    }

    public static <T extends Enum<?>> T getEnum(CommandContext<?> context, String name, T defaultValue) {
        return (T) context.getArgument(name, defaultValue.getClass());
    }

    public T m47parse(StringReader reader) throws CommandSyntaxException {
        String argument = reader.readString();
        for (T t : this.values) {
            if (t.toString().equals(argument)) {
                return t;
            }
        }
        throw NO_SUCH_TYPE.create(argument);
    }

    public <S> CompletableFuture<Suggestions> listSuggestions(CommandContext<S> context, SuggestionsBuilder builder) {
        return class_2172.method_9264(Arrays.stream(this.values).map((v0) -> {
            return v0.toString();
        }), builder);
    }
}
