package anticope.rejects.mixininterface;

public interface IInventoryTweaks {
    void stealCallback(Runnable runnable);
}
