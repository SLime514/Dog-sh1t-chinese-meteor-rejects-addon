package anticope.rejects.mixininterface;

public interface INoRender {
    boolean noCommandSuggestions();

    boolean disableToasts();
}
