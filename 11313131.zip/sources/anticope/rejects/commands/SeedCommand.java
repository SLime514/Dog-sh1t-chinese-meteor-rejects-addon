package anticope.rejects.commands;

import anticope.rejects.arguments.EnumArgumentType;
import anticope.rejects.utils.seeds.Seed;
import anticope.rejects.utils.seeds.Seeds;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.exceptions.SimpleCommandExceptionType;
import com.seedfinding.mccore.version.MCVersion;
import meteordevelopment.meteorclient.commands.Command;
import meteordevelopment.meteorclient.utils.Utils;
import net.minecraft.class_2172;
import net.minecraft.class_2561;
import net.minecraft.class_5250;

public class SeedCommand extends Command {
    private static final SimpleCommandExceptionType NO_SEED = new SimpleCommandExceptionType(class_2561.method_43470("No seed for current world saved."));

    public SeedCommand() {
        super("seed", "Get or set seed for the current world.", new String[0]);
    }

    public void build(LiteralArgumentBuilder<class_2172> builder) {
        builder.executes(ctx -> {
            Seed seed = Seeds.get().getSeed();
            if (seed == null) {
                throw NO_SEED.create();
            }
            info(seed.toText());
            return 1;
        });
        builder.then(literal("list").executes(ctx2 -> {
            Seeds.get().seeds.forEach((name, seed) -> {
                class_5250 text = class_2561.method_43470(name + " ");
                text.method_10852(seed.toText());
                info(text);
            });
            return 1;
        }));
        builder.then(literal("delete").executes(ctx3 -> {
            Seed seed = Seeds.get().getSeed();
            if (seed != null) {
                class_5250 text = class_2561.method_43470("Deleted ");
                text.method_10852(seed.toText());
                info(text);
            }
            Seeds.get().seeds.remove(Utils.getWorldName());
            return 1;
        }));
        builder.then(argument("seed", StringArgumentType.string()).executes(ctx4 -> {
            Seeds.get().setSeed(StringArgumentType.getString(ctx4, "seed"));
            return 1;
        }));
        builder.then(argument("seed", StringArgumentType.string()).then(argument("version", EnumArgumentType.enumArgument(MCVersion.latest())).executes(ctx5 -> {
            Seeds.get().setSeed(StringArgumentType.getString(ctx5, "seed"), (MCVersion) EnumArgumentType.getEnum(ctx5, "version", MCVersion.latest()));
            return 1;
        })));
    }
}
