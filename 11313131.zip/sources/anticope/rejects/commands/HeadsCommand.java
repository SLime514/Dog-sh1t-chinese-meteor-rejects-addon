package anticope.rejects.commands;

import anticope.rejects.gui.screens.HeadScreen;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import meteordevelopment.meteorclient.commands.Command;
import meteordevelopment.meteorclient.gui.GuiThemes;
import meteordevelopment.meteorclient.utils.Utils;
import net.minecraft.class_2172;

public class HeadsCommand extends Command {
    public HeadsCommand() {
        super("heads", "Display heads gui", new String[0]);
    }

    public void build(LiteralArgumentBuilder<class_2172> builder) {
        builder.executes(ctx -> {
            Utils.screenToOpen = new HeadScreen(GuiThemes.get());
            return 1;
        });
    }
}
