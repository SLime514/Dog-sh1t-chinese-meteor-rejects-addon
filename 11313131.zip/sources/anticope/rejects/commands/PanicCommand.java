package anticope.rejects.commands;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import java.util.ArrayList;
import meteordevelopment.meteorclient.commands.Command;
import meteordevelopment.meteorclient.systems.modules.Modules;
import net.minecraft.class_2172;

public class PanicCommand extends Command {
    public PanicCommand() {
        super("panic", "Disables all modules.", new String[]{"disable-all"});
    }

    public void build(LiteralArgumentBuilder<class_2172> builder) {
        builder.executes(context -> {
            new ArrayList(Modules.get().getActive()).forEach((v0) -> {
                v0.toggle();
            });
            return 1;
        });
    }
}
