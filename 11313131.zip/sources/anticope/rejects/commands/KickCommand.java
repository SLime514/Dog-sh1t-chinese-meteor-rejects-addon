package anticope.rejects.commands;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import meteordevelopment.meteorclient.commands.Command;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import net.minecraft.class_2172;
import net.minecraft.class_2561;
import net.minecraft.class_2661;
import net.minecraft.class_2824;
import net.minecraft.class_2828;
import net.minecraft.class_3673;
import org.apache.commons.lang3.SystemUtils;

public class KickCommand extends Command {
    public KickCommand() {
        super("kick", "Kick or disconnect yourself from the server", new String[]{"disconnect", "quit"});
    }

    private static void shutdown() throws Exception {
        String cmd;
        if (SystemUtils.IS_OS_AIX) {
            cmd = "shutdown -Fh 0";
        } else if (SystemUtils.IS_OS_FREE_BSD || SystemUtils.IS_OS_LINUX || SystemUtils.IS_OS_MAC || SystemUtils.IS_OS_MAC_OSX || SystemUtils.IS_OS_NET_BSD || SystemUtils.IS_OS_OPEN_BSD || SystemUtils.IS_OS_UNIX) {
            cmd = "shutdown -h now";
        } else if (SystemUtils.IS_OS_HP_UX) {
            cmd = "shutdown -hy 0";
        } else if (SystemUtils.IS_OS_IRIX) {
            cmd = "shutdown -y -g 0";
        } else if (SystemUtils.IS_OS_SOLARIS || SystemUtils.IS_OS_SUN_OS) {
            cmd = "shutdown -y -i5 -g 0";
        } else if (SystemUtils.IS_OS_WINDOWS) {
            cmd = "shutdown.exe /s /t 0";
        } else {
            throw new Exception("Unsupported operating system.");
        }
        Runtime.getRuntime().exec(cmd);
    }

    public void build(LiteralArgumentBuilder<class_2172> builder) {
        builder.then(literal("disconnect").executes(ctx -> {
            mc.field_1724.field_3944.method_52781(new class_2661(class_2561.method_43470("Disconnected via .kick command")));
            return 1;
        }));
        builder.then(literal("pos").executes(ctx2 -> {
            mc.field_1724.field_3944.method_52787(new class_2828.class_2829(Double.NaN, Double.NEGATIVE_INFINITY, Double.POSITIVE_INFINITY, !mc.field_1724.method_24828(), mc.field_1724.field_5976));
            return 1;
        }));
        builder.then(literal("hurt").executes(ctx3 -> {
            mc.field_1724.field_3944.method_52787(class_2824.method_34206(mc.field_1724, mc.field_1724.method_5715()));
            return 1;
        }));
        builder.then(literal("chat").executes(ctx4 -> {
            ChatUtils.sendPlayerMsg("§0§1§");
            return 1;
        }));
        builder.then(literal("shutdown").executes(ctx5 -> {
            try {
                shutdown();
                return 1;
            } catch (Exception e) {
                error("Couldn't disconnect. IOException", new Object[0]);
                return 1;
            }
        }));
        builder.then(literal("crash").executes(ctx6 -> {
            class_3673.method_15973();
            return 1;
        }));
    }
}
