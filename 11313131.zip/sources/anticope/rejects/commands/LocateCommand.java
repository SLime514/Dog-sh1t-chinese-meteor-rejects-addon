package anticope.rejects.commands;

import anticope.rejects.arguments.EnumArgumentType;
import anticope.rejects.utils.WorldGenUtils;
import anticope.rejects.utils.seeds.Seeds;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.exceptions.DynamicCommandExceptionType;
import com.seedfinding.mccore.nbt.NBTType;
import com.seedfinding.mccore.version.MCVersion;
import cubitect.Cubiomes;
import meteordevelopment.meteorclient.commands.Command;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import net.minecraft.class_2172;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_5250;

public class LocateCommand extends Command {
    private static final DynamicCommandExceptionType NOT_FOUND = new DynamicCommandExceptionType(o -> {
        if (o instanceof Cubiomes.StructureType) {
            return class_2561.method_43470(String.format("%s not found.", Utils.nameToTitle(o.toString().replaceAll("_", "-"))));
        }
        return class_2561.method_43470("Not found.");
    });

    public LocateCommand() {
        super("locate", "Locates structures.", new String[]{"loc"});
    }

    public void build(LiteralArgumentBuilder<class_2172> builder) {
        builder.then(literal("feature").then(argument("feature", EnumArgumentType.enumArgument(Cubiomes.StructureType.Village)).executes(ctx -> {
            Cubiomes.Pos pos;
            Cubiomes.StructureType feature = (Cubiomes.StructureType) EnumArgumentType.getEnum(ctx, "feature", Cubiomes.StructureType.Village);
            class_2338 playerPos = mc.field_1724.method_24515();
            long seed = Seeds.get().getSeed().seed.longValue();
            MCVersion version = Seeds.get().getSeed().version;
            Cubiomes.MCVersion cubiomesVersion = null;
            if (version.isNewerOrEqualTo(MCVersion.v1_20)) {
                cubiomesVersion = Cubiomes.MCVersion.MC_1_20;
            } else if (version.isNewerOrEqualTo(MCVersion.v1_19)) {
                switch (C00001.$SwitchMap$com$seedfinding$mccore$version$MCVersion[version.ordinal()]) {
                    case 1:
                    case NBTType.SHORT:
                        cubiomesVersion = Cubiomes.MCVersion.MC_1_19;
                        break;
                    case 3:
                    case 4:
                    case NBTType.FLOAT:
                        cubiomesVersion = Cubiomes.MCVersion.MC_1_19_2;
                        break;
                    default:
                        throw new IllegalStateException("Unexpected value: " + String.valueOf(version));
                }
            } else if (version.isNewerOrEqualTo(MCVersion.v1_18)) {
                cubiomesVersion = Cubiomes.MCVersion.MC_1_18;
            }
            if (cubiomesVersion != null) {
                pos = Cubiomes.GetNearestStructure(feature, playerPos.method_10263(), playerPos.method_10260(), Long.valueOf(seed), cubiomesVersion);
            } else {
                class_2338 bpos = WorldGenUtils.locateFeature(feature, playerPos);
                pos = new Cubiomes.Pos();
                pos.f75x = bpos.method_10263();
                pos.f76z = bpos.method_10260();
            }
            if (pos != null) {
                int distance = (int) Math.hypot(pos.f75x - playerPos.method_10263(), pos.f76z - playerPos.method_10260());
                class_5250 text = class_2561.method_43470(String.format("%s located at ", Utils.nameToTitle(feature.toString().replaceAll("_", "-"))));
                class_243 coords = new class_243(pos.f75x, 0.0d, pos.f76z);
                text.method_10852(ChatUtils.formatCoords(coords));
                text.method_27693(".");
                if (distance > 0) {
                    text.method_27693(String.format(" (%d blocks away)", Integer.valueOf(distance)));
                }
                info(text);
                return 1;
            }
            throw NOT_FOUND.create(feature);
        })));
    }

    static class C00001 {
        static final int[] $SwitchMap$com$seedfinding$mccore$version$MCVersion = new int[MCVersion.values().length];

        static {
            try {
                $SwitchMap$com$seedfinding$mccore$version$MCVersion[MCVersion.v1_19.ordinal()] = 1;
            } catch (NoSuchFieldError e) {
            }
            try {
                $SwitchMap$com$seedfinding$mccore$version$MCVersion[MCVersion.v1_19_1.ordinal()] = 2;
            } catch (NoSuchFieldError e2) {
            }
            try {
                $SwitchMap$com$seedfinding$mccore$version$MCVersion[MCVersion.v1_19_2.ordinal()] = 3;
            } catch (NoSuchFieldError e3) {
            }
            try {
                $SwitchMap$com$seedfinding$mccore$version$MCVersion[MCVersion.v1_19_3.ordinal()] = 4;
            } catch (NoSuchFieldError e4) {
            }
            try {
                $SwitchMap$com$seedfinding$mccore$version$MCVersion[MCVersion.v1_19_4.ordinal()] = 5;
            } catch (NoSuchFieldError e5) {
            }
        }
    }
}
