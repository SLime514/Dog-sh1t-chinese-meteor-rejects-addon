package anticope.rejects.commands;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.SimpleCommandExceptionType;
import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.UUID;
import meteordevelopment.meteorclient.commands.Command;
import meteordevelopment.meteorclient.commands.arguments.PlayerListEntryArgumentType;
import meteordevelopment.meteorclient.utils.network.Http;
import net.minecraft.class_2172;
import net.minecraft.class_2561;
import org.apache.commons.codec.binary.Base64;
import org.lwjgl.BufferUtils;
import org.lwjgl.PointerBuffer;
import org.lwjgl.system.MemoryUtil;
import org.lwjgl.util.tinyfd.TinyFileDialogs;

public class SaveSkinCommand extends Command {
    private static final SimpleCommandExceptionType IO_EXCEPTION = new SimpleCommandExceptionType(class_2561.method_43470("An exception occurred"));
    private final PointerBuffer filters;
    private final Gson GSON;

    public SaveSkinCommand() {
        super("save-skin", "Download a player's skin by name.", new String[]{"skin", "skinsteal"});
        this.GSON = new Gson();
        this.filters = BufferUtils.createPointerBuffer(1);
        ByteBuffer pngFilter = MemoryUtil.memASCII("*.png");
        this.filters.put(pngFilter);
        this.filters.rewind();
    }

    public void build(LiteralArgumentBuilder<class_2172> builder) {
        builder.then(argument("player", PlayerListEntryArgumentType.create()).executes(ctx -> {
            UUID id = PlayerListEntryArgumentType.get(ctx).method_2966().getId();
            String path = TinyFileDialogs.tinyfd_saveFileDialog("Save image", (CharSequence) null, this.filters, (CharSequence) null);
            if (path == null) {
                IO_EXCEPTION.create();
            }
            if (path != null) {
                if (!path.endsWith(".png")) {
                    path = path + ".png";
                }
                saveSkin(id.toString(), path);
                return 1;
            }
            return 1;
        }));
    }

    private void saveSkin(String uuid, String path) throws IOException, CommandSyntaxException {
        try {
            JsonObject object = (JsonObject) Http.get(String.format("https://sessionserver.mojang.com/session/minecraft/profile/%s", uuid)).sendJson(JsonObject.class);
            JsonArray array = object.getAsJsonArray("properties");
            JsonObject property = array.get(0).getAsJsonObject();
            String base64String = property.get("value").getAsString();
            byte[] bs = Base64.decodeBase64(base64String);
            String secondResponse = new String(bs, StandardCharsets.UTF_8);
            JsonObject finalResponseObject = (JsonObject) this.GSON.fromJson(secondResponse, JsonObject.class);
            JsonObject texturesObject = finalResponseObject.getAsJsonObject("textures");
            JsonObject skinObj = texturesObject.getAsJsonObject("SKIN");
            String skinURL = skinObj.get("url").getAsString();
            InputStream in = new BufferedInputStream(new URL(skinURL).openStream());
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[1024];
            while (true) {
                int n = in.read(buf);
                if (-1 != n) {
                    out.write(buf, 0, n);
                } else {
                    out.close();
                    in.close();
                    byte[] response = out.toByteArray();
                    File file = new File(path);
                    FileOutputStream fos = new FileOutputStream(file.getPath());
                    fos.write(response);
                    fos.close();
                    return;
                }
            }
        } catch (IOException | NullPointerException e) {
            throw IO_EXCEPTION.create();
        }
    }
}
