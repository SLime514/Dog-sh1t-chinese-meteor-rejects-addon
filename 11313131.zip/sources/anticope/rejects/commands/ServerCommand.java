package anticope.rejects.commands;

import anticope.rejects.utils.portscanner.PScanRunner;
import anticope.rejects.utils.portscanner.PortScannerManager;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.SimpleCommandExceptionType;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Objects;
import meteordevelopment.meteorclient.commands.Command;
import net.minecraft.class_124;
import net.minecraft.class_2172;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2568;
import net.minecraft.class_5250;
import net.minecraft.class_642;

public class ServerCommand extends Command {
    private static final SimpleCommandExceptionType ADDRESS_ERROR = new SimpleCommandExceptionType(class_2561.method_43470("Couldn't obtain server address"));
    private static final SimpleCommandExceptionType INVALID_RANGE = new SimpleCommandExceptionType(class_2561.method_43470("Invalid range"));
    private static final HashMap<Integer, String> ports = new HashMap<>();

    public ServerCommand() {
        super("server", "Prints server information", new String[0]);
        ports.put(20, "FTP");
        ports.put(22, "SSH");
        ports.put(80, "HTTP");
        ports.put(443, "HTTPS");
        ports.put(25565, "Java Server");
        ports.put(25575, "Java Server RCON");
        ports.put(19132, "Bedrock Server");
        ports.put(19133, "Bedrock Server IPv6");
        ports.put(8123, "DynMap");
        ports.put(25566, "Minequery");
        ports.put(3306, "MySQL");
        ports.put(3389, "RDP");
    }

    public void build(LiteralArgumentBuilder<class_2172> builder) {
        builder.then(literal("ports").executes(ctx -> {
            scanKnownPorts(getAddress());
            return 1;
        }));
        builder.then(literal("ports").then(literal("known").executes(ctx2 -> {
            scanKnownPorts(getAddress());
            return 1;
        })));
        builder.then(literal("ports").then(argument("from", IntegerArgumentType.integer(0)).then(argument("to", IntegerArgumentType.integer(1)).executes(ctx3 -> {
            scanRange(getAddress(), IntegerArgumentType.getInteger(ctx3, "from"), IntegerArgumentType.getInteger(ctx3, "to"));
            return 1;
        }))));
    }

    private InetAddress getAddress() throws CommandSyntaxException {
        if (mc.method_1496()) {
            try {
                return InetAddress.getLocalHost();
            } catch (UnknownHostException e) {
                throw ADDRESS_ERROR.create();
            }
        }
        class_642 server = mc.method_1558();
        if (server == null) {
            throw ADDRESS_ERROR.create();
        }
        try {
            return InetAddress.getByName(server.field_3761);
        } catch (UnknownHostException e2) {
            throw ADDRESS_ERROR.create();
        }
    }

    private void scanPorts(InetAddress address, Collection<Integer> port_list) {
        info("Started scanning %d ports", new Object[]{Integer.valueOf(port_list.size())});
        PScanRunner pScanRunner = new PScanRunner(address, 5, 3, 200, port_list, scanResults -> {
            int open_ports = 0;
            info("Open ports:", new Object[0]);
            Iterator it = scanResults.iterator();
            while (it.hasNext()) {
                PortScannerManager.ScanResult result = (PortScannerManager.ScanResult) it.next();
                if (result.isOpen()) {
                    info(formatPort(result.getPort(), address));
                    open_ports++;
                }
            }
            info("Open count: %d/%d", new Object[]{Integer.valueOf(open_ports), Integer.valueOf(scanResults.size())});
        });
        PortScannerManager.scans.add(pScanRunner);
    }

    private void scanKnownPorts(InetAddress address) {
        scanPorts(address, ports.keySet());
    }

    private void scanRange(InetAddress address, int min, int max) throws CommandSyntaxException {
        if (max < min) {
            throw INVALID_RANGE.create();
        }
        List<Integer> port_list = new LinkedList<>();
        for (int i = min; i <= max; i++) {
            port_list.add(Integer.valueOf(i));
        }
        scanPorts(address, port_list);
    }

    private class_5250 formatPort(int port, InetAddress address) {
        class_5250 text = class_2561.method_43470(String.format("- %s%d%s ", class_124.field_1060, Integer.valueOf(port), class_124.field_1080));
        if (ports.containsKey(Integer.valueOf(port))) {
            text.method_27693(ports.get(Integer.valueOf(port)));
            if (ports.get(Integer.valueOf(port)).startsWith("HTTP") || ports.get(Integer.valueOf(port)).startsWith("FTP")) {
                text.method_10862(text.method_10866().method_10958(new class_2558(class_2558.class_2559.field_11749, String.format("%s://%s:%d", ports.get(Integer.valueOf(port)).toLowerCase(), address.getHostAddress(), Integer.valueOf(port)))).method_10949(new class_2568(class_2568.class_5247.field_24342, class_2561.method_43470("Open in browser"))));
            } else if (Objects.equals(ports.get(Integer.valueOf(port)), "DynMap")) {
                text.method_10862(text.method_10866().method_10958(new class_2558(class_2558.class_2559.field_11749, String.format("http://%s:%d", address.getHostAddress(), Integer.valueOf(port)))).method_10949(new class_2568(class_2568.class_5247.field_24342, class_2561.method_43470("Open in browser"))));
            } else {
                text.method_10862(text.method_10866().method_10958(new class_2558(class_2558.class_2559.field_21462, String.format("%s:%d", address.getHostAddress(), Integer.valueOf(port)))).method_10949(new class_2568(class_2568.class_5247.field_24342, class_2561.method_43470("Copy"))));
            }
        } else {
            text.method_10862(text.method_10866().method_10958(new class_2558(class_2558.class_2559.field_21462, String.format("%s:%d", address.getHostAddress(), Integer.valueOf(port)))).method_10949(new class_2568(class_2568.class_5247.field_24342, class_2561.method_43470("Copy"))));
        }
        return text;
    }
}
