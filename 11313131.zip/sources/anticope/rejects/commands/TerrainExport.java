package anticope.rejects.commands;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.exceptions.SimpleCommandExceptionType;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.ByteBuffer;
import meteordevelopment.meteorclient.commands.Command;
import net.minecraft.class_2172;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import org.lwjgl.BufferUtils;
import org.lwjgl.PointerBuffer;
import org.lwjgl.system.MemoryUtil;
import org.lwjgl.util.tinyfd.TinyFileDialogs;

public class TerrainExport extends Command {
    private static final SimpleCommandExceptionType IO_EXCEPTION = new SimpleCommandExceptionType(class_2561.method_43470("An IOException occurred"));
    private final PointerBuffer filters;

    public TerrainExport() {
        super("terrain-export", "Export an area to the c++ terrain finder format (very popbob command).", new String[0]);
        this.filters = BufferUtils.createPointerBuffer(1);
        ByteBuffer txtFilter = MemoryUtil.memASCII("*.txt");
        this.filters.put(txtFilter);
        this.filters.rewind();
    }

    public void build(LiteralArgumentBuilder<class_2172> builder) {
        builder.then(argument("distance", IntegerArgumentType.integer(1)).executes(context -> {
            int distance = IntegerArgumentType.getInteger(context, "distance");
            StringBuilder stringBuilder = new StringBuilder();
            for (int x = -distance; x <= distance; x++) {
                for (int z = -distance; z <= distance; z++) {
                    for (int y = distance; y >= (-distance); y--) {
                        class_2338 pos = mc.field_1724.method_24515().method_10069(x, y, z);
                        if (mc.field_1687.method_8320(pos).method_26234(mc.field_1687, pos)) {
                            stringBuilder.append(String.format("%d, %d, %d\n", Integer.valueOf(x + distance), Integer.valueOf(y + distance), Integer.valueOf(z + distance)));
                        }
                    }
                }
            }
            String path = TinyFileDialogs.tinyfd_saveFileDialog("Save data", (CharSequence) null, this.filters, (CharSequence) null);
            if (path == null) {
                throw IO_EXCEPTION.create();
            }
            if (!path.endsWith(".txt")) {
                path = path + ".txt";
            }
            try {
                FileWriter file = new FileWriter(path);
                file.write(stringBuilder.toString().trim());
                file.close();
                return 1;
            } catch (IOException e) {
                throw IO_EXCEPTION.create();
            }
        }));
    }
}
