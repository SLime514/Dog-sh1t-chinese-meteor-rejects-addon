package anticope.rejects.commands;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import meteordevelopment.meteorclient.commands.Command;
import net.minecraft.class_2172;

public class ClearChatCommand extends Command {
    public ClearChatCommand() {
        super("clear-chat", "Clears your chat.", new String[]{"clear", "cls"});
    }

    public void build(LiteralArgumentBuilder<class_2172> builder) {
        builder.executes(context -> {
            mc.field_1705.method_1743().method_1808(false);
            return 1;
        });
    }
}
