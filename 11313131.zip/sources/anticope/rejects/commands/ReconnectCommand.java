package anticope.rejects.commands;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import meteordevelopment.meteorclient.commands.Command;
import net.minecraft.class_2172;
import net.minecraft.class_412;
import net.minecraft.class_442;
import net.minecraft.class_500;
import net.minecraft.class_639;
import net.minecraft.class_642;
import net.minecraft.class_9112;

public class ReconnectCommand extends Command {
    public ReconnectCommand() {
        super("reconnect", "Reconnects server.", new String[0]);
    }

    public void build(LiteralArgumentBuilder<class_2172> builder) {
        builder.executes(context -> {
            class_642 info = mc.method_1542() ? null : mc.method_1558();
            if (info != null) {
                mc.field_1687.method_8525();
                class_412.method_36877(new class_500(new class_442()), mc, class_639.method_2950(info.field_3761), info, false, (class_9112) null);
                return 1;
            }
            return 1;
        });
    }
}
