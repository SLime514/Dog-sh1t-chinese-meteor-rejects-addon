package anticope.rejects.commands;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import meteordevelopment.meteorclient.commands.Command;
import net.minecraft.class_2172;
import net.minecraft.class_2828;
import net.minecraft.class_3532;

public class CenterCommand extends Command {
    public CenterCommand() {
        super("center", "Centers the player on a block.", new String[0]);
    }

    public void build(LiteralArgumentBuilder<class_2172> builder) {
        builder.then(literal("middle").executes(context -> {
            double x = class_3532.method_15357(mc.field_1724.method_23317()) + 0.5d;
            double z = class_3532.method_15357(mc.field_1724.method_23321()) + 0.5d;
            mc.field_1724.method_5814(x, mc.field_1724.method_23318(), z);
            mc.field_1724.field_3944.method_52787(new class_2828.class_2829(mc.field_1724.method_23317(), mc.field_1724.method_23318(), mc.field_1724.method_23321(), mc.field_1724.method_24828(), mc.field_1724.field_5976));
            return 1;
        }));
        builder.then(literal("center").executes(context2 -> {
            double x = class_3532.method_15357(mc.field_1724.method_23317());
            double z = class_3532.method_15357(mc.field_1724.method_23321());
            mc.field_1724.method_5814(x, mc.field_1724.method_23318(), z);
            mc.field_1724.field_3944.method_52787(new class_2828.class_2829(mc.field_1724.method_23317(), mc.field_1724.method_23318(), mc.field_1724.method_23321(), mc.field_1724.method_24828(), mc.field_1724.field_5976));
            return 1;
        }));
    }
}
