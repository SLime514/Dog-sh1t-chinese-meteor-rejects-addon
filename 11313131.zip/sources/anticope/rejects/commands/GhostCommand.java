package anticope.rejects.commands;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import meteordevelopment.meteorclient.commands.Command;
import net.minecraft.class_2172;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2846;
import net.minecraft.class_634;

public class GhostCommand extends Command {
    public GhostCommand() {
        super("ghost", "Remove ghost blocks & bypass AntiXray", new String[]{"aax", "anti-anti-xray"});
    }

    public void build(LiteralArgumentBuilder<class_2172> builder) {
        builder.executes(ctx -> {
            execute(4);
            return 1;
        });
        builder.then(argument("radius", IntegerArgumentType.integer(1)).executes(ctx2 -> {
            int radius = IntegerArgumentType.getInteger(ctx2, "radius");
            execute(radius);
            return 1;
        }));
    }

    private void execute(int radius) {
        class_634 conn = mc.method_1562();
        if (conn == null) {
            return;
        }
        class_2338 pos = mc.field_1724.method_24515();
        for (int dx = -radius; dx <= radius; dx++) {
            for (int dy = -radius; dy <= radius; dy++) {
                for (int dz = -radius; dz <= radius; dz++) {
                    class_2846 packet = new class_2846(class_2846.class_2847.field_12971, new class_2338(pos.method_10263() + dx, pos.method_10264() + dy, pos.method_10260() + dz), class_2350.field_11036);
                    conn.method_52787(packet);
                }
            }
        }
    }
}
