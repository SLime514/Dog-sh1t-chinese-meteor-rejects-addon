package anticope.rejects.commands;

import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import meteordevelopment.meteorclient.commands.Command;
import net.minecraft.class_2172;
import net.minecraft.class_243;

public class SetVelocityCommand extends Command {
    public SetVelocityCommand() {
        super("set-velocity", "Sets player velocity", new String[]{"velocity", "vel"});
    }

    public void build(LiteralArgumentBuilder<class_2172> builder) {
        builder.then(argument("y", DoubleArgumentType.doubleArg()).executes(ctx -> {
            class_243 currentVelocity = mc.field_1724.method_18798();
            mc.field_1724.method_18800(currentVelocity.field_1352, DoubleArgumentType.getDouble(ctx, "y"), currentVelocity.field_1350);
            return 1;
        }));
        builder.then(argument("x", DoubleArgumentType.doubleArg()).then(argument("z", DoubleArgumentType.doubleArg()).executes(ctx2 -> {
            double x = DoubleArgumentType.getDouble(ctx2, "x");
            double z = DoubleArgumentType.getDouble(ctx2, "z");
            mc.field_1724.method_18800(x, mc.field_1724.method_18798().field_1351, z);
            return 1;
        })));
        builder.then(argument("x", DoubleArgumentType.doubleArg()).then(argument("y", DoubleArgumentType.doubleArg()).then(argument("z", DoubleArgumentType.doubleArg()).executes(ctx3 -> {
            double x = DoubleArgumentType.getDouble(ctx3, "x");
            double y = DoubleArgumentType.getDouble(ctx3, "y");
            double z = DoubleArgumentType.getDouble(ctx3, "z");
            mc.field_1724.method_18800(x, y, z);
            return 1;
        }))));
    }
}
