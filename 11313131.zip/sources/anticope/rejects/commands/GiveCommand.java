package anticope.rejects.commands;

import anticope.rejects.arguments.EnumStringArgumentType;
import anticope.rejects.utils.GiveUtils;
import anticope.rejects.utils.accounts.GetPlayerUUID;
import com.mojang.authlib.GameProfile;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import java.util.Collection;
import meteordevelopment.meteorclient.commands.Command;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2172;
import net.minecraft.class_2487;
import net.minecraft.class_2489;
import net.minecraft.class_2499;
import net.minecraft.class_2519;
import net.minecraft.class_2561;
import net.minecraft.class_7923;
import net.minecraft.class_9279;
import net.minecraft.class_9296;
import net.minecraft.class_9326;
import net.minecraft.class_9334;

public class GiveCommand extends Command {
    private final Collection<String> PRESETS;

    public GiveCommand() {
        super("give", "Gives items in creative", new String[]{"item", "kit"});
        this.PRESETS = GiveUtils.PRESETS.keySet();
    }

    public void build(LiteralArgumentBuilder<class_2172> builder) {
        builder.then(literal("egg").executes(ctx -> {
            class_1799 inHand = mc.field_1724.method_6047();
            class_1799 item = new class_1799(class_1802.field_23255);
            class_2487 ct = new class_2487();
            if (inHand.method_7909() instanceof class_1747) {
                ct.method_10569("Time", 1);
                ct.method_10582("id", "minecraft:falling_block");
                ct.method_10566("BlockState", new class_2487());
                ct.method_10562("BlockState").method_10582("Name", class_7923.field_41178.method_10221(inHand.method_7909()).toString());
            } else {
                ct.method_10582("id", "minecraft:item");
                class_2487 itemTag = new class_2487();
                itemTag.method_10582("id", class_7923.field_41178.method_10221(inHand.method_7909()).toString());
                itemTag.method_10569("Count", inHand.method_7947());
                ct.method_10566("Item", itemTag);
            }
            class_2487 t = new class_2487();
            t.method_10566("EntityTag", ct);
            class_9326 changes = class_9326.method_57841().method_57854(class_9334.field_49631, inHand.method_7964()).method_57854(class_9334.field_49628, class_9279.method_57456(t)).method_57852();
            item.method_59692(changes);
            GiveUtils.giveItem(item);
            return 1;
        }));
        builder.then(literal("holo").then(argument("message", StringArgumentType.greedyString()).executes(ctx2 -> {
            String message = ((String) ctx2.getArgument("message", String.class)).replace("&", "§");
            class_1799 stack = new class_1799(class_1802.field_23255);
            class_2487 tag = new class_2487();
            class_2499 pos = new class_2499();
            pos.add(class_2489.method_23241(mc.field_1724.method_23317()));
            pos.add(class_2489.method_23241(mc.field_1724.method_23318()));
            pos.add(class_2489.method_23241(mc.field_1724.method_23321()));
            tag.method_10582("id", "minecraft:armor_stand");
            tag.method_10566("Pos", pos);
            tag.method_10556("Invisible", true);
            tag.method_10556("Invulnerable", true);
            tag.method_10556("NoGravity", true);
            tag.method_10556("CustomNameVisible", true);
            class_9326 changes = class_9326.method_57841().method_57854(class_9334.field_49631, class_2561.method_43470(message)).method_57854(class_9334.field_49609, class_9279.method_57456(tag)).method_57852();
            stack.method_59692(changes);
            GiveUtils.giveItem(stack);
            return 1;
        })));
        builder.then(literal("bossbar").then(argument("message", StringArgumentType.greedyString()).executes(ctx3 -> {
            String message = ((String) ctx3.getArgument("message", String.class)).replace("&", "§");
            class_1799 stack = new class_1799(class_1802.field_8727);
            class_2487 tag = new class_2487();
            tag.method_10556("NoAI", true);
            tag.method_10556("Silent", true);
            tag.method_10556("PersistenceRequired", true);
            tag.method_10566("id", class_2519.method_23256("minecraft:wither"));
            class_9326 changes = class_9326.method_57841().method_57854(class_9334.field_49631, class_2561.method_43470(message)).method_57854(class_9334.field_49609, class_9279.method_57456(tag)).method_57852();
            stack.method_59692(changes);
            GiveUtils.giveItem(stack);
            return 1;
        })));
        builder.then(literal("head").then(argument("owner", StringArgumentType.greedyString()).executes(ctx4 -> {
            String playerName = (String) ctx4.getArgument("owner", String.class);
            class_1799 itemStack = new class_1799(class_1802.field_8575);
            class_9326 changes = class_9326.method_57841().method_57854(class_9334.field_49617, new class_9296(new GameProfile(GetPlayerUUID.getUUID(playerName), playerName))).method_57852();
            itemStack.method_59692(changes);
            GiveUtils.giveItem(itemStack);
            return 1;
        })));
        builder.then(literal("preset").then(argument("name", new EnumStringArgumentType(this.PRESETS)).executes(context -> {
            String name = (String) context.getArgument("name", String.class);
            GiveUtils.giveItem(GiveUtils.getPreset(name));
            return 1;
        })));
    }
}
