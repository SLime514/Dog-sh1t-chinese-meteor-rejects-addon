package anticope.rejects.commands;

import anticope.rejects.arguments.ClientPosArgumentType;
import com.mojang.brigadier.arguments.FloatArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import meteordevelopment.meteorclient.commands.Command;
import net.minecraft.class_2172;
import net.minecraft.class_243;

public class TeleportCommand extends Command {
    public TeleportCommand() {
        super("teleport", "Sends a packet to the server with new position. Allows to teleport small distances.", new String[]{"tp"});
    }

    public void build(LiteralArgumentBuilder<class_2172> builder) {
        builder.then(argument("pos", ClientPosArgumentType.pos()).executes(ctx -> {
            class_243 pos = ClientPosArgumentType.getPos(ctx, "pos");
            mc.field_1724.method_30634(pos.method_10216(), pos.method_10214(), pos.method_10215());
            return 1;
        }));
        builder.then(argument("pos", ClientPosArgumentType.pos()).then(argument("yaw", FloatArgumentType.floatArg()).then(argument("pitch", FloatArgumentType.floatArg()).executes(ctx2 -> {
            class_243 pos = ClientPosArgumentType.getPos(ctx2, "pos");
            float yaw = FloatArgumentType.getFloat(ctx2, "yaw");
            float pitch = FloatArgumentType.getFloat(ctx2, "pitch");
            mc.field_1724.method_5641(pos.method_10216(), pos.method_10214(), pos.method_10215(), yaw, pitch);
            return 1;
        }))));
    }
}
