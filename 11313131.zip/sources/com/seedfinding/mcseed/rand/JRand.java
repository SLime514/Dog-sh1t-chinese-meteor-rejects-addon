package com.seedfinding.mcseed.rand;

import com.seedfinding.mcseed.lcg.LCG;
import java.util.List;
import java.util.ListIterator;
import java.util.Random;
import java.util.RandomAccess;

public class JRand extends Rand implements IRand {
    private static final double DOUBLE_UNIT = 1.1102230246251565E-16d;
    private double nextNextGaussian;
    private boolean haveNextNextGaussian;

    protected JRand(LCG lcg, long seed) {
        super(lcg, seed);
    }

    protected JRand(LCG lcg, long seed, boolean scramble) {
        super(lcg);
        setSeed(seed, scramble);
    }

    public JRand(long seed) {
        this(LCG.JAVA, seed, true);
    }

    public JRand(long seed, boolean scramble) {
        super(LCG.JAVA);
        setSeed(seed, scramble);
    }

    public static JRand ofInternalSeed(long seed) {
        return new JRand(seed, false);
    }

    public static JRand ofScrambledSeed(long seed) {
        return new JRand(seed, true);
    }

    public static boolean nextBoolean(long seed) {
        return ((seed >>> 47) & 1) == 1;
    }

    public static int nextInt(long seed) {
        return (int) (seed >>> 16);
    }

    public static int nextInt(long seed, int bound) {
        int bits;
        int value;
        if (bound <= 0) {
            throw new IllegalArgumentException("bound must be positive");
        }
        if ((bound & (-bound)) == bound) {
            return (int) ((bound * seed) >> 31);
        }
        do {
            bits = (int) (seed >>> 17);
            value = bits % bound;
            seed = LCG.JAVA.nextSeed(seed);
        } while ((bits - value) + (bound - 1) < 0);
        return value;
    }

    public static float nextFloat(long seed) {
        return ((int) (seed >>> 24)) / 1.6777216E7f;
    }

    public static long nextLong(long seed) {
        return ((seed >>> 16) << 32) + ((int) (LCG.JAVA.nextSeed(seed) >>> 16));
    }

    public static double nextDouble(long seed) {
        return ((((int) (seed >>> 22)) << 27) + ((int) (LCG.JAVA.nextSeed(seed) >>> 21))) * DOUBLE_UNIT;
    }

    public static void shuffle(List<?> list, JRand rand) {
        rand.shuffle(list);
    }

    public static void swap(Object[] arr, int i, int j) {
        Object tmp = arr[i];
        arr[i] = arr[j];
        arr[j] = tmp;
    }

    public static void swap(List<?> list, int i, int j) {
        list.set(i, list.set(j, list.get(i)));
    }

    @Override
    public void setSeed(long seed) {
        setSeed(seed, true);
    }

    public void setSeed(long seed, boolean scramble) {
        if (!scramble) {
            super.setSeed(seed);
        } else {
            super.setSeed(seed ^ LCG.JAVA.multiplier);
        }
    }

    public int next(int bits) {
        return (int) nextBits(bits);
    }

    @Override
    public boolean nextBoolean() {
        return next(1) == 1;
    }

    @Override
    public int nextInt() {
        return next(32);
    }

    public int nextInt(int bound) {
        int bits;
        int value;
        if (bound <= 0) {
            throw new IllegalArgumentException("bound must be positive");
        }
        if ((bound & (-bound)) == bound) {
            return (int) ((bound * next(31)) >> 31);
        }
        do {
            bits = next(31);
            value = bits % bound;
        } while ((bits - value) + (bound - 1) < 0);
        return value;
    }

    @Override
    public float nextFloat() {
        return next(24) / 1.6777216E7f;
    }

    @Override
    public long nextLong() {
        return (next(32) << 32) + next(32);
    }

    @Override
    public double nextDouble() {
        return ((next(26) << 27) + next(27)) * DOUBLE_UNIT;
    }

    @Override
    public double nextGaussian() {
        if (this.haveNextNextGaussian) {
            this.haveNextNextGaussian = false;
            return this.nextNextGaussian;
        }
        while (true) {
            double v1 = (2.0d * nextDouble()) - 1.0d;
            double v2 = (2.0d * nextDouble()) - 1.0d;
            double s = (v1 * v1) + (v2 * v2);
            if (s < 1.0d && s != 0.0d) {
                double multiplier = StrictMath.sqrt(((-2.0d) * StrictMath.log(s)) / s);
                this.nextNextGaussian = v2 * multiplier;
                this.haveNextNextGaussian = true;
                return v1 * multiplier;
            }
        }
    }

    public void shuffle(List<?> list) {
        int size = list.size();
        if (size < 5 || (list instanceof RandomAccess)) {
            for (int i = size; i > 1; i--) {
                swap(list, i - 1, nextInt(i));
            }
            return;
        }
        Object[] arr = list.toArray();
        for (int i2 = size; i2 > 1; i2--) {
            swap(arr, i2 - 1, nextInt(i2));
        }
        ListIterator it = list.listIterator();
        for (Object e : arr) {
            it.next();
            it.set(e);
        }
    }

    public CombinedJRand combine(long steps) {
        return new CombinedJRand(steps, getSeed(), false);
    }

    public JRand copy() {
        return new JRand(getSeed(), false);
    }

    public Random asRandomView() {
        return new RandomWrapper();
    }

    public Debugger asDebugger() {
        return new Debugger(this);
    }

    public Random copyToRandom() {
        return copy().asRandomView();
    }

    public Random toRandom() {
        return new Random(getSeed() ^ LCG.JAVA.multiplier);
    }

    private static final class RandomWrapper extends Random {
        private final JRand delegate;

        private RandomWrapper(JRand delegate) {
            this.delegate = delegate;
        }

        @Override
        protected int next(int bits) {
            return this.delegate.next(bits);
        }

        @Override
        public void setSeed(long seed) {
            this.delegate.setSeed(seed);
        }
    }

    public static final class Debugger extends JRand {
        private final JRand delegate;
        private long globalCounter;
        private long nextIntSkip;
        private boolean hasCalledAdvance;

        public Debugger(JRand delegate) {
            super(delegate.getLcg(), delegate.getSeed());
            this.delegate = delegate;
            this.globalCounter = 0L;
            this.nextIntSkip = 0L;
        }

        @Override
        public long nextSeed() {
            if (this.delegate != null) {
                this.globalCounter++;
                return this.delegate.nextSeed();
            }
            return super.nextSeed();
        }

        @Override
        public void advance(long calls) {
            if (this.delegate != null) {
                this.globalCounter += calls;
                this.hasCalledAdvance = true;
                this.delegate.advance(calls);
                return;
            }
            super.advance(calls);
        }

        @Override
        public int nextInt(int bound) {
            int bits;
            int value;
            if (this.delegate != null) {
                if (bound <= 0) {
                    throw new IllegalArgumentException("bound must be positive");
                }
                if ((bound & (-bound)) == bound) {
                    this.globalCounter++;
                    return (int) ((bound * this.delegate.next(31)) >> 31);
                }
                long oldCounter = this.globalCounter;
                do {
                    this.globalCounter++;
                    bits = this.delegate.next(31);
                    value = bits % bound;
                } while ((bits - value) + (bound - 1) < 0);
                this.nextIntSkip += (this.globalCounter - oldCounter) - 1;
                return value;
            }
            return super.nextInt(bound);
        }

        @Override
        public int next(int bits) {
            if (this.delegate != null) {
                this.globalCounter++;
                return this.delegate.next(bits);
            }
            return super.next(bits);
        }

        @Override
        public void advance(LCG lcg) {
            if (this.delegate != null) {
                long old = getSeed();
                this.delegate.advance(lcg);
                if (this.hasCalledAdvance) {
                    this.hasCalledAdvance = false;
                    return;
                } else {
                    this.globalCounter += LCG.JAVA.distance(old, getSeed()) - 1;
                    return;
                }
            }
            super.advance(lcg);
        }

        @Override
        public long getSeed() {
            if (this.delegate != null) {
                return this.delegate.getSeed();
            }
            return super.getSeed();
        }

        @Override
        public void setSeed(long seed) {
            if (this.delegate != null) {
                this.globalCounter = 0L;
                this.delegate.setSeed(seed);
            } else {
                super.setSeed(seed, false);
            }
        }

        public long getGlobalCounter() {
            return this.globalCounter;
        }

        public long getNextIntSkip() {
            return this.nextIntSkip;
        }
    }
}
