package com.seedfinding.mcseed.lcg;

import com.seedfinding.mcmath.util.Mth;
import java.util.Objects;

public class LCG {
    public static final LCG CC65_M23 = new LCG(65793, 4282663, 8388608);
    public static final LCG VISUAL_BASIC = new LCG(1140671485, 12820163, 16777216);
    public static final LCG RTL_UNIFORM = new LCG(2147483629, 2147483587, 2147483647L);
    public static final LCG MINSTD_RAND0_C = new LCG(16807, 0, 2147483647L);
    public static final LCG MINSTD_RAND_C = new LCG(48271, 0, 2147483647L);
    public static final LCG CC65_M31 = new LCG(16843009, 826366247, 8388608);
    public static final LCG RANDU = new LCG(65539, 0, 2147483648L);
    public static final LCG GLIB_C = new LCG(1103515245, 12345, 2147483648L);
    public static final LCG BORLAND_C = new LCG(22695477, 1, 4294967296L);
    public static final LCG PASCAL = new LCG(134775813, 1, 4294967296L);
    public static final LCG OPEN_VMS = new LCG(69069, 1, 4294967296L);
    public static final LCG NUMERICAL_RECIPES = new LCG(1664525, 1013904223, 4294967296L);
    public static final LCG MS_VISUAL_C = new LCG(214013, 2531011, 4294967296L);
    public static final LCG JAVA = new LCG(25214903917L, 11, 281474976710656L);
    public static final LCG JAVA_UNIQUIFIER_OLD = new LCG(181783497276652981L, 0);
    public static final LCG JAVA_UNIQUIFIER_NEW = new LCG(1181783497276652981L, 0);
    public static final LCG MMIX = new LCG(6364136223846793005L, 1442695040888963407L);
    public static final LCG NEWLIB_C = new LCG(6364136223846793005L, 1);
    public static final LCG XKCD = new LCG(0, 4);
    public final long multiplier;
    public final long addend;
    public final long modulus;
    private final boolean isPowerOf2;
    private final int trailingZeros;

    public LCG(long multiplier, long addend) {
        this(multiplier, addend, 0L);
    }

    public LCG(long multiplier, long addend, long modulus) {
        this.multiplier = multiplier;
        this.addend = addend;
        this.modulus = modulus;
        this.isPowerOf2 = Mth.isPowerOf2(this.modulus);
        this.trailingZeros = this.isPowerOf2 ? Long.numberOfTrailingZeros(this.modulus) : -1;
    }

    public static LCG combine(LCG... lcgs) {
        LCG lcg = lcgs[0];
        for (int i = 1; i < lcgs.length; i++) {
            lcg = lcg.combine(lcgs[i]);
        }
        return lcg;
    }

    public boolean isModPowerOf2() {
        return this.isPowerOf2;
    }

    public int getModTrailingZeroes() {
        return this.trailingZeros;
    }

    public boolean isMultiplicative() {
        return this.addend == 0;
    }

    public long nextSeed(long seed) {
        return mod((seed * this.multiplier) + this.addend);
    }

    public long mod(long n) {
        if (isModPowerOf2()) {
            return n & (this.modulus - 1);
        }
        if (n <= 4294967296L) {
            return Long.remainderUnsigned(n, this.modulus);
        }
        throw new UnsupportedOperationException();
    }

    public LCG combine(long steps) {
        long multiplier = 1;
        long addend = 0;
        long intermediateMultiplier = this.multiplier;
        long intermediateAddend = this.addend;
        long j = steps;
        while (true) {
            long k = j;
            if (k != 0) {
                if ((k & 1) != 0) {
                    multiplier *= intermediateMultiplier;
                    addend = (intermediateMultiplier * addend) + intermediateAddend;
                }
                intermediateAddend = (intermediateMultiplier + 1) * intermediateAddend;
                intermediateMultiplier *= intermediateMultiplier;
                j = k >>> 1;
            } else {
                return new LCG(mod(multiplier), mod(addend), this.modulus);
            }
        }
    }

    public LCG combine(LCG lcg) {
        if (this.modulus != lcg.modulus) {
            throw new UnsupportedOperationException();
        }
        return new LCG(this.multiplier * lcg.multiplier, (lcg.multiplier * this.addend) + lcg.addend, this.modulus);
    }

    public LCG invert() {
        return combine(-1L);
    }

    public long distance(long seed1, long seed2) {
        if (DiscreteLog.supports(this)) {
            long aFromZero = DiscreteLog.distanceFromZero(this, seed1);
            long bFromZero = DiscreteLog.distanceFromZero(this, seed2);
            return Mth.maskSigned(bFromZero - aFromZero, getModTrailingZeroes());
        }
        throw new UnsupportedOperationException("DiscreteLog is not supported by this LCG");
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof LCG)) {
            return false;
        }
        LCG lcg = (LCG) obj;
        return this.multiplier == lcg.multiplier && this.addend == lcg.addend && this.modulus == lcg.modulus;
    }

    public int hashCode() {
        return Objects.hash(Long.valueOf(this.multiplier), Long.valueOf(this.addend), Long.valueOf(this.modulus));
    }

    public String toString() {
        return "LCG{multiplier=" + this.multiplier + ", addend=" + this.addend + ", modulo=" + this.modulus + '}';
    }

    public String toPrettyString() {
        return "Multiplier: " + String.format("0x%X (%d)", Long.valueOf(this.multiplier), Long.valueOf(this.multiplier)) + ", Addend: " + String.format("0x%X (%d)", Long.valueOf(this.addend), Long.valueOf(this.addend)) + ", Modulo: " + String.format("0x%X (%d)", Long.valueOf(this.modulus), Long.valueOf(this.modulus));
    }
}
