package com.seedfinding.mcseed.lcg;

import com.seedfinding.mcmath.util.Mth;
import java.math.BigInteger;

public class DiscreteLog {
    public static boolean supports(LCG lcg) {
        return lcg.isModPowerOf2() && lcg.getModTrailingZeroes() <= 61 && lcg.multiplier % 2 != 0 && lcg.addend % 2 != 0;
    }

    public static long distanceFromZero(LCG lcg, long seed) {
        int exp = lcg.getModTrailingZeroes();
        long a = lcg.multiplier;
        long b = Mth.mask((seed * (lcg.multiplier - 1) * Mth.modInverse(lcg.addend, exp)) + 1, exp + 2);
        long aBar = theta(a, exp);
        long bBar = theta(b, exp);
        return bBar * Mth.mask(Mth.modInverse(aBar, exp), exp);
    }

    private static long theta(long number, int exp) {
        if (number % 4 == 3) {
            number = Mth.getPow2(exp + 2) - number;
        }
        BigInteger xHat = BigInteger.valueOf(number);
        return xHat.modPow(BigInteger.ONE.shiftLeft(exp + 1), BigInteger.ONE.shiftLeft((2 * exp) + 3)).subtract(BigInteger.ONE).divide(BigInteger.ONE.shiftLeft(exp + 3)).mod(BigInteger.ONE.shiftLeft(exp)).longValue();
    }
}
