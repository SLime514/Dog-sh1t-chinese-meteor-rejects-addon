package com.seedfinding.mcmath.decomposition;

import com.seedfinding.mcmath.arithmetic.Rational;
import com.seedfinding.mcmath.arithmetic.Real;
import com.seedfinding.mcmath.component.matrix.QMatrix;
import com.seedfinding.mcmath.component.matrix.RMatrix;

public class LUDecomposition {
    public static C0162Q m39of(QMatrix matrix) {
        return new C0162Q(matrix);
    }

    public static C0163R m40of(RMatrix matrix) {
        return new C0163R(matrix);
    }

    public static class C0162Q {
        private final QMatrix matrix;
        private final int size;

        private QMatrix f65P;

        private QMatrix f66L;

        private QMatrix f67U;

        private QMatrix f68LU;
        private boolean singular;
        private int swaps;
        private int[] pivot;
        private Rational det;
        private QMatrix inv;

        protected C0162Q(QMatrix matrix) {
            if (!matrix.isSquare()) {
                throw new IllegalArgumentException("Matrix is not square");
            }
            this.matrix = matrix;
            this.size = this.matrix.getRowCount();
        }

        public C0162Q refresh() {
            this.f65P = null;
            this.f66L = null;
            this.f67U = null;
            this.f68LU = null;
            this.singular = false;
            this.swaps = -1;
            this.pivot = null;
            this.det = null;
            this.inv = null;
            return this;
        }

        public QMatrix getMatrix() {
            return this.matrix;
        }

        public int getSize() {
            return this.size;
        }

        public QMatrix getP() {
            if (this.f65P != null) {
                return this.f65P;
            }
            int[] pivot = getPivot();
            if (pivot == null) {
                return null;
            }
            this.f65P = QMatrix.identity(this.size);
            for (int i = 0; i < this.size; i++) {
                this.f65P.swapRowsAndSet(i, pivot[i]);
            }
            return this.f65P;
        }

        public QMatrix getL() {
            if (this.f66L != null) {
                return this.f66L;
            }
            QMatrix lu = getLU();
            if (lu == null) {
                return null;
            }
            QMatrix map = lu.map((row, column, oldValue) -> {
                return row > column ? oldValue : row == column ? Rational.ONE : Rational.ZERO;
            });
            this.f66L = map;
            return map;
        }

        public QMatrix getU() {
            if (this.f67U != null) {
                return this.f67U;
            }
            QMatrix lu = getLU();
            if (lu == null) {
                return null;
            }
            QMatrix map = lu.map((row, col, oldValue) -> {
                return row <= col ? oldValue : Rational.ZERO;
            });
            this.f67U = map;
            return map;
        }

        public boolean isSingular() {
            getLU();
            return this.singular;
        }

        public QMatrix getLU() {
            if (this.f68LU != null || this.singular) {
                return this.f68LU;
            }
            this.f68LU = this.matrix.copy();
            this.pivot = new int[this.size];
            this.swaps = 0;
            for (int i = 0; i < this.size; i++) {
                int pivot = -1;
                Rational largest = Rational.ZERO;
                for (int row = i; row < this.size; row++) {
                    Rational value = this.f68LU.get(row, i).abs();
                    if (value.signum() != 0 && value.compareTo(largest) > 0) {
                        largest = value;
                        pivot = row;
                    }
                }
                if (pivot == -1) {
                    this.singular = true;
                    this.f68LU = null;
                    this.pivot = null;
                    this.swaps = -1;
                    return null;
                }
                this.pivot[i] = pivot;
                if (pivot != i) {
                    this.f68LU.swapRowsAndSet(i, pivot);
                    this.swaps++;
                }
                for (int row2 = i + 1; row2 < this.size; row2++) {
                    Rational divisor = this.f68LU.get(i, i);
                    this.f68LU.set(row2, i, this.f68LU.get(row2, i).divide(divisor));
                }
                for (int row3 = i + 1; row3 < this.size; row3++) {
                    for (int column = i + 1; column < this.size; column++) {
                        Rational subtrahend = this.f68LU.get(row3, i).multiply(this.f68LU.get(i, column));
                        this.f68LU.set(row3, column, this.f68LU.get(row3, column).subtract(subtrahend));
                    }
                }
            }
            return this.f68LU;
        }

        public int getSwaps() {
            if (this.f68LU != null) {
                return this.swaps;
            }
            getLU();
            return this.swaps;
        }

        public int[] getPivot() {
            if (this.pivot != null) {
                return this.pivot;
            }
            getLU();
            return this.pivot;
        }

        public Rational getDeterminant() {
            if (this.det != null) {
                return this.det;
            }
            QMatrix lu = getLU();
            if (!isSingular()) {
                this.det = Rational.ONE;
                for (int i = 0; i < this.size; i++) {
                    this.det = this.det.multiply(lu.get(i, i));
                }
                if ((getSwaps() & 1) != 0) {
                    this.det = this.det.negate();
                }
            } else {
                this.det = Rational.ZERO;
            }
            return this.det;
        }

        public QMatrix getInverse() {
            if (this.inv != null) {
                return this.inv;
            }
            QMatrix lu = getLU();
            if (lu == null) {
                return null;
            }
            this.inv = getP().copy();
            for (int dcol = 0; dcol < this.size; dcol++) {
                for (int row = 0; row < this.size; row++) {
                    Rational value = this.inv.get(row, dcol);
                    for (int col = 0; col < row; col++) {
                        value = value.subtract(lu.get(row, col).multiply(this.inv.get(col, dcol)));
                    }
                    this.inv.set(row, dcol, value);
                }
            }
            for (int dcol2 = 0; dcol2 < this.size; dcol2++) {
                for (int row2 = this.size - 1; row2 >= 0; row2--) {
                    Rational value2 = this.inv.get(row2, dcol2);
                    for (int col2 = this.size - 1; col2 > row2; col2--) {
                        value2 = value2.subtract(lu.get(row2, col2).multiply(this.inv.get(col2, dcol2)));
                    }
                    this.inv.set(row2, dcol2, value2.divide(lu.get(row2, row2)));
                }
            }
            return this.inv;
        }
    }

    public static class C0163R {
        private final RMatrix matrix;
        private final int size;

        private RMatrix f69P;

        private RMatrix f70L;

        private RMatrix f71U;

        private RMatrix f72LU;
        private boolean singular;
        private int swaps;
        private int[] pivot;
        private Real det;
        private RMatrix inv;

        protected C0163R(RMatrix matrix) {
            if (!matrix.isSquare()) {
                throw new IllegalArgumentException("Matrix is not square");
            }
            this.matrix = matrix;
            this.size = this.matrix.getRowCount();
        }

        public C0163R refresh() {
            this.f69P = null;
            this.f70L = null;
            this.f71U = null;
            this.f72LU = null;
            this.singular = false;
            this.swaps = -1;
            this.pivot = null;
            this.det = null;
            this.inv = null;
            return this;
        }

        public RMatrix getMatrix() {
            return this.matrix;
        }

        public int getSize() {
            return this.size;
        }

        public RMatrix getP() {
            if (this.f69P != null) {
                return this.f69P;
            }
            int[] pivot = getPivot();
            if (pivot == null) {
                return null;
            }
            this.f69P = RMatrix.identity(this.size);
            for (int i = 0; i < this.size; i++) {
                this.f69P.swapRowsAndSet(i, pivot[i]);
            }
            return this.f69P;
        }

        public RMatrix getL() {
            if (this.f70L != null) {
                return this.f70L;
            }
            RMatrix lu = getLU();
            if (lu == null) {
                return null;
            }
            RMatrix map = lu.map((row, column, oldValue) -> {
                return row > column ? oldValue : row == column ? Real.ONE : Real.ZERO;
            });
            this.f70L = map;
            return map;
        }

        public RMatrix getU() {
            if (this.f71U != null) {
                return this.f71U;
            }
            RMatrix lu = getLU();
            if (lu == null) {
                return null;
            }
            RMatrix map = lu.map((row, col, oldValue) -> {
                return row <= col ? oldValue : Real.ZERO;
            });
            this.f71U = map;
            return map;
        }

        public boolean isSingular() {
            getLU();
            return this.singular;
        }

        public RMatrix getLU() {
            if (this.f72LU != null || this.singular) {
                return this.f72LU;
            }
            this.f72LU = this.matrix.copy();
            this.pivot = new int[this.size];
            this.swaps = 0;
            for (int i = 0; i < this.size; i++) {
                int pivot = -1;
                Real largest = Real.ZERO;
                for (int row = i; row < this.size; row++) {
                    Real value = this.f72LU.get(row, i).abs();
                    if (value.signum() != 0 && value.compareTo(largest) > 0) {
                        largest = value;
                        pivot = row;
                    }
                }
                if (pivot == -1) {
                    this.singular = true;
                    this.f72LU = null;
                    this.pivot = null;
                    this.swaps = -1;
                    return null;
                }
                this.pivot[i] = pivot;
                if (pivot != i) {
                    this.f72LU.swapRowsAndSet(i, pivot);
                    this.swaps++;
                }
                for (int row2 = i + 1; row2 < this.size; row2++) {
                    Real divisor = this.f72LU.get(i, i);
                    this.f72LU.set(row2, i, this.f72LU.get(row2, i).divide(divisor));
                }
                for (int row3 = i + 1; row3 < this.size; row3++) {
                    for (int column = i + 1; column < this.size; column++) {
                        Real subtrahend = this.f72LU.get(row3, i).multiply(this.f72LU.get(i, column));
                        this.f72LU.set(row3, column, this.f72LU.get(row3, column).subtract(subtrahend));
                    }
                }
            }
            return this.f72LU;
        }

        public int getSwaps() {
            if (this.f72LU != null) {
                return this.swaps;
            }
            getLU();
            return this.swaps;
        }

        public int[] getPivot() {
            if (this.pivot != null) {
                return this.pivot;
            }
            getLU();
            return this.pivot;
        }

        public Real getDeterminant() {
            if (this.det != null) {
                return this.det;
            }
            RMatrix lu = getLU();
            if (!isSingular()) {
                this.det = Real.ONE;
                for (int i = 0; i < this.size; i++) {
                    this.det = this.det.multiply(lu.get(i, i));
                }
                if ((getSwaps() & 1) != 0) {
                    this.det = this.det.negate();
                }
            } else {
                this.det = Real.ZERO;
            }
            return this.det;
        }

        public RMatrix getInverse() {
            if (this.inv != null) {
                return this.inv;
            }
            RMatrix lu = getLU();
            if (lu == null) {
                return null;
            }
            this.inv = getP().copy();
            for (int dcol = 0; dcol < this.size; dcol++) {
                for (int row = 0; row < this.size; row++) {
                    Real value = this.inv.get(row, dcol);
                    for (int col = 0; col < row; col++) {
                        value = value.subtract(lu.get(row, col).multiply(this.inv.get(col, dcol)));
                    }
                    this.inv.set(row, dcol, value);
                }
            }
            for (int dcol2 = 0; dcol2 < this.size; dcol2++) {
                for (int row2 = this.size - 1; row2 >= 0; row2--) {
                    Real value2 = this.inv.get(row2, dcol2);
                    for (int col2 = this.size - 1; col2 > row2; col2--) {
                        value2 = value2.subtract(lu.get(row2, col2).multiply(this.inv.get(col2, dcol2)));
                    }
                    this.inv.set(row2, dcol2, value2.divide(lu.get(row2, row2)));
                }
            }
            return this.inv;
        }
    }
}
