package com.seedfinding.mcmath.arithmetic;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;

public class Real extends Number implements Comparable<Real> {
    public static final Real ZERO = m37of(0.0d);
    public static final Real HALF = m37of(0.5d);
    public static final Real ONE = m37of(1.0d);
    public static final Real TWO = m37of(2.0d);
    protected BigDecimal value;

    protected Real(BigDecimal value) {
        this.value = value;
    }

    public static Real m35of(BigDecimal value) {
        return new Real(value);
    }

    public static Real m36of(BigInteger value) {
        return m35of(new BigDecimal(value).setScale(10, RoundingMode.HALF_UP));
    }

    public static Real m37of(double value) {
        return m35of(BigDecimal.valueOf(value).setScale(10, RoundingMode.HALF_UP));
    }

    public static Real m38of(long value) {
        return m35of(BigDecimal.valueOf(value).setScale(10, RoundingMode.HALF_UP));
    }

    public BigDecimal getValue() {
        return this.value;
    }

    public int getScale() {
        return getValue().scale();
    }

    private Real setScale(int scale) {
        return setScale(scale, RoundingMode.HALF_UP);
    }

    public Real setScale(int scale, RoundingMode rounding) {
        return m35of(getValue().setScale(scale, rounding));
    }

    public Real strip() {
        return m35of(getValue().stripTrailingZeros());
    }

    public Real abs() {
        return m35of(getValue().abs());
    }

    public Real negate() {
        return m35of(getValue().negate());
    }

    public Real invert() {
        return m35of(BigDecimal.ONE.divide(getValue(), getValue().scale(), RoundingMode.HALF_UP));
    }

    public int signum() {
        return getValue().signum();
    }

    public Real min(Real other) {
        return compareTo(other) <= 0 ? this : other;
    }

    public Real max(Real other) {
        return compareTo(other) >= 0 ? this : other;
    }

    public Real add(Real addend) {
        return add(addend.getValue());
    }

    public Real add(Rational addend) {
        return add(addend.toBigDecimal(getScale(), RoundingMode.HALF_UP));
    }

    public Real add(BigDecimal addend) {
        return m35of(getValue().add(addend));
    }

    public Real add(BigInteger addend) {
        return add(new BigDecimal(addend));
    }

    public Real add(double addend) {
        return add(BigDecimal.valueOf(addend));
    }

    public Real add(long addend) {
        return add(BigDecimal.valueOf(addend));
    }

    public Real subtract(Real subtrahend) {
        return subtract(subtrahend.getValue());
    }

    public Real subtract(Rational subtrahend) {
        return subtract(subtrahend.toBigDecimal(getScale(), RoundingMode.HALF_UP));
    }

    public Real subtract(BigDecimal subtrahend) {
        return m35of(getValue().subtract(subtrahend));
    }

    public Real subtract(BigInteger subtrahend) {
        return subtract(new BigDecimal(subtrahend));
    }

    public Real subtract(double subtrahend) {
        return subtract(BigDecimal.valueOf(subtrahend));
    }

    public Real subtract(long subtrahend) {
        return subtract(BigDecimal.valueOf(subtrahend));
    }

    public Real multiply(Real multiplier) {
        return multiply(multiplier.getValue());
    }

    public Real multiply(Rational multiplier) {
        return multiply(multiplier.toBigDecimal(getScale(), RoundingMode.HALF_UP));
    }

    public Real multiply(BigDecimal multiplier) {
        return m35of(getValue().multiply(multiplier));
    }

    public Real multiply(BigInteger multiplier) {
        return multiply(new BigDecimal(multiplier));
    }

    public Real multiply(double multiplier) {
        return multiply(BigDecimal.valueOf(multiplier));
    }

    public Real multiply(long multiplier) {
        return multiply(BigDecimal.valueOf(multiplier));
    }

    public Real divide(Real divisor) {
        return divide(divisor.getValue());
    }

    public Real divide(Rational divisor) {
        return divide(divisor.toBigDecimal(getScale(), RoundingMode.HALF_UP));
    }

    public Real divide(BigDecimal divisor) {
        return m35of(getValue().divide(divisor, RoundingMode.HALF_UP));
    }

    public Real divide(BigInteger divisor) {
        return divide(new BigDecimal(divisor));
    }

    public Real divide(double divisor) {
        return divide(BigDecimal.valueOf(divisor));
    }

    public Real divide(long divisor) {
        return divide(BigDecimal.valueOf(divisor));
    }

    public Real pow(Rational exponent) {
        return pow(exponent.getNumerator()).nthRoot(exponent.getDenominator());
    }

    public Real pow(BigInteger exponent) {
        return pow(exponent.intValueExact());
    }

    public Real pow(int exponent) {
        return m35of(getValue().pow(exponent));
    }

    public Real nthRoot(BigInteger n) {
        return nthRoot(n.intValue());
    }

    public Real nthRoot(int n) {
        if (n <= 0) {
            throw new IllegalArgumentException("Root must be positive");
        }
        if (compareTo(ZERO) < 0) {
            throw new IllegalArgumentException("Root of negative number");
        }
        if (equals(ZERO)) {
            return ZERO;
        }
        if (n == 1) {
            return this;
        }
        Real xPrev = this;
        Real x = divide(n);
        Real a = m38of(n - 1);
        Real p = m35of(BigDecimal.ONE.movePointLeft(getScale()));
        while (x.subtract(xPrev).abs().compareTo(p) > 0) {
            xPrev = x;
            x = a.multiply(x).add(divide(x.pow(n - 1))).divide(n);
        }
        return x.setScale(getScale(), RoundingMode.HALF_UP);
    }

    public Real sqrt() {
        return nthRoot(2);
    }

    public Real cbrt() {
        return nthRoot(3);
    }

    public Real floor() {
        return setScale(0, RoundingMode.FLOOR);
    }

    public Real ceil() {
        return setScale(0, RoundingMode.CEILING);
    }

    public Real round() {
        return setScale(0, RoundingMode.HALF_UP);
    }

    @Override
    public int intValue() {
        return getValue().intValue();
    }

    @Override
    public long longValue() {
        return getValue().longValue();
    }

    @Override
    public float floatValue() {
        return getValue().floatValue();
    }

    @Override
    public double doubleValue() {
        return getValue().doubleValue();
    }

    public BigInteger toBigInteger() {
        return getValue().toBigInteger();
    }

    public BigDecimal toBigDecimal() {
        return getValue();
    }

    public Rational toRational() {
        return Rational.m31of(getValue());
    }

    @Override
    public int compareTo(Real other) {
        return getValue().compareTo(other.getValue());
    }

    public int hashCode() {
        return getValue().hashCode();
    }

    public boolean equals(Object other) {
        return getValue().equals(other);
    }

    public String toString() {
        return getValue().stripTrailingZeros().toString();
    }
}
