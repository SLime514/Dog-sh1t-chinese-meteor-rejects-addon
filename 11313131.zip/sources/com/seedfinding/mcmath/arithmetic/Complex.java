package com.seedfinding.mcmath.arithmetic;

import java.math.BigDecimal;
import java.math.BigInteger;

public class Complex {
    public static final Complex ZERO = m17of(Real.ZERO, Real.ZERO);
    public static final Complex ONE = m17of(Real.ONE, Real.ZERO);
    protected final Real real;
    protected final Real imaginary;

    protected Complex(Real real, Real imaginary) {
        this.real = real;
        this.imaginary = imaginary;
    }

    public Real getReal() {
        return this.real;
    }

    public Real getImaginary() {
        return this.imaginary;
    }

    public Complex negate() {
        return m17of(getReal().negate(), getImaginary().negate());
    }

    public Real magnitude() {
        return magnitudeSq().sqrt();
    }

    public Real magnitudeSq() {
        return getReal().multiply(getReal()).add(getImaginary().multiply(getImaginary()));
    }

    public Complex invert() {
        Real magnitude = magnitude();
        return m17of(getReal().divide(magnitude), getImaginary().divide(magnitude).negate());
    }

    public Complex conjugate() {
        return m17of(getReal(), getImaginary().negate());
    }

    public Complex add(Complex other) {
        return m17of(getReal().add(other.getReal()), getImaginary().add(other.getImaginary()));
    }

    public Complex subtract(Complex other) {
        return m17of(getReal().subtract(other.getReal()), getImaginary().subtract(other.getImaginary()));
    }

    public Complex multiply(Complex other) {
        Real a = getReal().multiply(other.getReal()).subtract(getImaginary().multiply(other.getImaginary()));
        Real b = getReal().multiply(other.getImaginary()).add(getImaginary().multiply(other.getReal()));
        return m17of(a, b);
    }

    public Complex multiply(Real other) {
        return m17of(getReal().multiply(other), getImaginary().multiply(other));
    }

    public Complex multiply(Rational other) {
        return m17of(getReal().multiply(other), getImaginary().multiply(other));
    }

    public Complex multiply(BigDecimal other) {
        return m17of(getReal().multiply(other), getImaginary().multiply(other));
    }

    public Complex multiply(BigInteger other) {
        return m17of(getReal().multiply(other), getImaginary().multiply(other));
    }

    public Complex multiply(double other) {
        return m17of(getReal().multiply(other), getImaginary().multiply(other));
    }

    public Complex multiply(long other) {
        return m17of(getReal().multiply(other), getImaginary().multiply(other));
    }

    public Complex divide(Complex other) {
        return multiply(other.invert());
    }

    public Complex divide(Real other) {
        return m17of(getReal().divide(other), getImaginary().divide(other));
    }

    public Complex divide(Rational other) {
        return m17of(getReal().divide(other), getImaginary().divide(other));
    }

    public Complex divide(BigDecimal other) {
        return m17of(getReal().divide(other), getImaginary().divide(other));
    }

    public Complex divide(BigInteger other) {
        return m17of(getReal().divide(other), getImaginary().divide(other));
    }

    public Complex divide(double other) {
        return m17of(getReal().divide(other), getImaginary().divide(other));
    }

    public Complex divide(long other) {
        return m17of(getReal().divide(other), getImaginary().divide(other));
    }

    public int hashCode() {
        return (getReal().hashCode() * 31) + getImaginary().hashCode();
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof Complex)) {
            return false;
        }
        Complex complex = (Complex) other;
        return getReal().compareTo(complex.getReal()) == 0 && getImaginary().compareTo(complex.getImaginary()) == 0;
    }

    public String toString() {
        if (getReal().signum() == 0 && getImaginary().signum() == 0) {
            return "0";
        }
        if (getReal().signum() == 0) {
            return getImaginary().toString() + "i";
        }
        if (getImaginary().signum() == 0) {
            return getReal().toString();
        }
        return getReal().toString() + (getImaginary().signum() > 0 ? " + " : " - ") + getImaginary().abs().toString() + "i";
    }

    public static Complex m17of(Real real, Real imaginary) {
        return new Complex(real, imaginary);
    }

    public static Complex m18of(BigDecimal real, BigDecimal imaginary) {
        return m17of(Real.m35of(real), Real.m35of(imaginary));
    }

    public static Complex m19of(BigInteger real, BigInteger imaginary) {
        return m17of(Real.m36of(real), Real.m36of(imaginary));
    }

    public static Complex m20of(double real, double imaginary) {
        return m17of(Real.m37of(real), Real.m37of(imaginary));
    }

    public static Complex m21of(long real, long imaginary) {
        return m17of(Real.m38of(real), Real.m38of(imaginary));
    }

    public static Complex m22of(Real real) {
        return m17of(real, Real.ZERO);
    }

    public static Complex m23of(BigDecimal value) {
        return m22of(Real.m35of(value));
    }

    public static Complex m24of(BigInteger value) {
        return m22of(Real.m36of(value));
    }

    public static Complex m25of(double value) {
        return m22of(Real.m37of(value));
    }

    public static Complex m26of(long value) {
        return m22of(Real.m38of(value));
    }
}
