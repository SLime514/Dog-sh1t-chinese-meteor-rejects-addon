package com.seedfinding.mcmath.arithmetic;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.MathContext;
import java.math.RoundingMode;

public class Rational extends Number implements Comparable<Rational> {
    protected static final BigInteger THRESHOLD = BigInteger.ONE.shiftLeft(128);
    public static final Rational ZERO = m28of(0, 1);
    public static final Rational HALF = m28of(1, 2);
    public static final Rational ONE = m28of(1, 1);
    protected BigInteger numerator;
    protected BigInteger denominator;

    protected Rational(BigInteger numerator, BigInteger denominator) {
        if (denominator.signum() == 0) {
            throw new ArithmeticException("/ by zero");
        }
        this.numerator = numerator;
        this.denominator = denominator;
        simplify();
    }

    public BigInteger getNumerator() {
        return this.numerator;
    }

    public BigInteger getDenominator() {
        return this.denominator;
    }

    protected Rational simplify() {
        if (this.numerator.signum() == 0) {
            this.denominator = BigInteger.ONE;
            return this;
        }
        if (this.denominator.signum() < 0) {
            this.numerator = this.numerator.negate();
            this.denominator = this.denominator.negate();
        }
        return (this.numerator.compareTo(THRESHOLD) >= 0 || this.denominator.compareTo(THRESHOLD) >= 0) ? reduce() : this;
    }

    protected Rational reduce() {
        BigInteger gcd = this.numerator.gcd(this.denominator);
        this.numerator = this.numerator.divide(gcd);
        this.denominator = this.denominator.divide(gcd);
        return this;
    }

    public Rational abs() {
        return getNumerator().signum() < 0 ? negate() : this;
    }

    public Rational negate() {
        return m27of(getNumerator().negate(), getDenominator());
    }

    public Rational invert() {
        return m27of(getDenominator(), getNumerator());
    }

    public int signum() {
        return getNumerator().signum();
    }

    public Rational min(Rational other) {
        return compareTo(other) <= 0 ? this : other;
    }

    public Rational max(Rational other) {
        return compareTo(other) >= 0 ? this : other;
    }

    public Rational add(Rational addend) {
        BigInteger a = getNumerator().multiply(addend.getDenominator());
        BigInteger b = addend.getNumerator().multiply(getDenominator());
        return m27of(a.add(b), getDenominator().multiply(addend.getDenominator()));
    }

    public Rational add(BigDecimal addend) {
        return add(m31of(addend));
    }

    public Rational add(BigInteger addend) {
        return m27of(getNumerator().add(addend.multiply(getDenominator())), getDenominator());
    }

    public Rational add(double addend) {
        return add(m33of(addend));
    }

    public Rational add(long addend) {
        return add(BigInteger.valueOf(addend));
    }

    public Rational subtract(Rational subtrahend) {
        return add(subtrahend.negate());
    }

    public Rational subtract(BigDecimal subtrahend) {
        return subtract(m31of(subtrahend));
    }

    public Rational subtract(BigInteger subtrahend) {
        return add(subtrahend.negate());
    }

    public Rational subtract(double subtrahend) {
        return subtract(m33of(subtrahend));
    }

    public Rational subtract(long subtrahend) {
        return subtract(BigInteger.valueOf(subtrahend));
    }

    public Rational multiply(Rational multiplier) {
        BigInteger a = getNumerator().multiply(multiplier.getNumerator());
        BigInteger b = getDenominator().multiply(multiplier.getDenominator());
        return m27of(a, b);
    }

    public Rational multiply(BigDecimal multiplier) {
        return multiply(m31of(multiplier));
    }

    public Rational multiply(BigInteger multiplier) {
        return m27of(getNumerator().multiply(multiplier), getDenominator());
    }

    public Rational multiply(double multiplier) {
        return multiply(m33of(multiplier));
    }

    public Rational multiply(long multiplier) {
        return multiply(BigInteger.valueOf(multiplier));
    }

    public Rational divide(Rational divisor) {
        return multiply(divisor.invert());
    }

    public Rational divide(BigDecimal divisor) {
        return divide(m31of(divisor));
    }

    public Rational divide(BigInteger divisor) {
        return m27of(getNumerator(), getDenominator().multiply(divisor));
    }

    public Rational divide(double divisor) {
        return divide(m33of(divisor));
    }

    public Rational divide(long divisor) {
        return divide(BigInteger.valueOf(divisor));
    }

    public Rational pow(BigInteger exponent) {
        return pow(exponent.intValueExact());
    }

    public Rational pow(int exponent) {
        BigInteger a = getNumerator().pow(exponent);
        BigInteger b = getDenominator().pow(exponent);
        return m27of(a, b);
    }

    public Rational shiftRight(int n) {
        Rational r = this;
        int i = Math.min(getNumerator().getLowestSetBit(), n);
        if (i > 0) {
            r = m27of(getNumerator().shiftRight(i), getDenominator());
        }
        if (n - i > 0) {
            r = m27of(r.getNumerator(), r.getDenominator().shiftLeft(n - i));
        }
        return r;
    }

    public Rational shiftLeft(int n) {
        Rational r = this;
        int i = Math.min(getDenominator().getLowestSetBit(), n);
        if (i > 0) {
            r = m27of(getNumerator(), getDenominator().shiftRight(i));
        }
        if (n - i > 0) {
            r = m27of(r.getNumerator().shiftLeft(n - i), r.getDenominator());
        }
        return r;
    }

    public Rational floor() {
        if (getDenominator().equals(BigInteger.ONE)) {
            return this;
        }
        BigInteger a = getNumerator().divide(getDenominator());
        if (getNumerator().signum() < 0) {
            a = a.subtract(BigInteger.ONE);
        }
        return m32of(a);
    }

    public Rational ceil() {
        if (getDenominator().equals(BigInteger.ONE)) {
            return this;
        }
        BigInteger a = getNumerator().divide(getDenominator());
        if (getNumerator().signum() < 0) {
            a = a.add(BigInteger.ONE);
        }
        return m32of(a);
    }

    public Rational round() {
        return add(HALF).floor();
    }

    @Override
    public int intValue() {
        return getNumerator().divide(getDenominator()).intValue();
    }

    @Override
    public long longValue() {
        return getNumerator().divide(getDenominator()).longValue();
    }

    @Override
    public float floatValue() {
        BigDecimal a = new BigDecimal(getNumerator());
        BigDecimal b = new BigDecimal(getDenominator());
        return a.divide(b, MathContext.DECIMAL32).floatValue();
    }

    @Override
    public double doubleValue() {
        BigDecimal a = new BigDecimal(getNumerator());
        BigDecimal b = new BigDecimal(getDenominator());
        return a.divide(b, MathContext.DECIMAL64).doubleValue();
    }

    public BigInteger toBigInteger() {
        return getNumerator().divide(getDenominator());
    }

    public BigDecimal toBigDecimal(int scale, RoundingMode roundingMode) {
        return new BigDecimal(getNumerator()).setScale(scale, roundingMode).divide(new BigDecimal(getDenominator()), roundingMode);
    }

    public Real toReal(int scale, RoundingMode roundingMode) {
        return Real.m35of(toBigDecimal(scale, roundingMode));
    }

    @Override
    public int compareTo(Rational other) {
        BigInteger a = getNumerator().multiply(other.getDenominator());
        BigInteger b = getDenominator().multiply(other.getNumerator());
        return a.compareTo(b);
    }

    public int hashCode() {
        return getNumerator().hashCode() + (31 * getDenominator().hashCode());
    }

    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        return (other instanceof Rational) && compareTo((Rational) other) == 0;
    }

    public String toString() {
        Rational r = reduce();
        return (r.signum() == 0 || r.getDenominator().equals(BigInteger.ONE)) ? r.getNumerator().toString() : r.getNumerator() + " / " + r.getDenominator();
    }

    public String toString(int scale) {
        return toBigDecimal(scale, RoundingMode.HALF_UP).stripTrailingZeros().toPlainString();
    }

    public static Rational m27of(BigInteger numerator, BigInteger denominator) {
        return new Rational(numerator, denominator);
    }

    public static Rational m28of(long numerator, long denominator) {
        return m27of(BigInteger.valueOf(numerator), BigInteger.valueOf(denominator));
    }

    public static Rational m29of(BigInteger numerator, long denominator) {
        return m27of(numerator, BigInteger.valueOf(denominator));
    }

    public static Rational m30of(long numerator, BigInteger denominator) {
        return m27of(BigInteger.valueOf(numerator), denominator);
    }

    public static Rational m31of(BigDecimal value) {
        BigDecimal value2 = value.stripTrailingZeros();
        return m27of(value2.movePointRight(value2.scale()).toBigIntegerExact(), BigInteger.TEN.pow(value2.scale()));
    }

    public static Rational m32of(BigInteger value) {
        return m27of(value, BigInteger.ONE);
    }

    public static Rational m33of(double value) {
        return m31of(BigDecimal.valueOf(value));
    }

    public static Rational m34of(long value) {
        return m28of(value, 1L);
    }
}
