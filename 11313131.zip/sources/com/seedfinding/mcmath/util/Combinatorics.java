package com.seedfinding.mcmath.util;

import java.math.BigInteger;
import java.util.function.Predicate;

public final class Combinatorics {
    public static final int MAX_LONG_FACTORIAL = 20;
    private static final long[] FACTORIAL = new long[21];

    static {
        FACTORIAL[0] = 1;
        for (int i = 1; i < FACTORIAL.length; i++) {
            FACTORIAL[i] = FACTORIAL[i - 1] * i;
        }
    }

    public static long getFactorial(int n) {
        return FACTORIAL[n];
    }

    public static BigInteger getBigFactorial(int n) {
        if (n <= 20) {
            return BigInteger.valueOf(getFactorial(n));
        }
        BigInteger result = BigInteger.valueOf(getFactorial(20));
        for (int i = 20; i < n; i++) {
            result = result.multiply(BigInteger.valueOf(i + 1));
        }
        return result;
    }

    public static long getPermutations(int n, int r) {
        return getFactorial(n) / getFactorial(n - r);
    }

    public static BigInteger getBigPermutations(int n, int r) {
        return getBigFactorial(n).divide(getBigFactorial(n - r));
    }

    public static long getCombinations(int n, int r) {
        return getPermutations(n, r) / getFactorial(r);
    }

    public static BigInteger getBigCombinations(int n, int r) {
        return getBigPermutations(n, r).divide(getBigFactorial(r));
    }

    public static void permute(int n, int r, Predicate<int[]> shouldContinue) {
        if (n <= 20) {
            smallPermute(n, r, shouldContinue);
        } else {
            bigPermute(n, r, shouldContinue);
        }
    }

    private static void smallPermute(int n, int r, Predicate<int[]> shouldContinue) {
        long max = getFactorial(n);
        long increment = getFactorial(n - r);
        long j = 0;
        while (true) {
            long perm = j;
            if (perm < max) {
                long permCopy = perm;
                int[] indices = new int[n];
                for (int i = 0; i < n; i++) {
                    indices[i] = (int) (permCopy / getFactorial((n - 1) - i));
                    permCopy -= indices[i] * getFactorial((n - 1) - i);
                }
                if (!acceptPermutation(n, r, indices, shouldContinue)) {
                    return;
                } else {
                    j = perm + increment;
                }
            } else {
                return;
            }
        }
    }

    private static void bigPermute(int n, int r, Predicate<int[]> shouldContinue) {
        BigInteger max = getBigFactorial(n);
        BigInteger increment = getBigFactorial(n - r);
        BigInteger bigIntegerAdd = BigInteger.ZERO;
        while (true) {
            BigInteger perm = bigIntegerAdd;
            if (perm.compareTo(max) < 0) {
                BigInteger permCopy = perm;
                int[] indices = new int[n];
                for (int i = 0; i < n; i++) {
                    BigInteger f = getBigFactorial((n - 1) - i);
                    indices[i] = permCopy.divide(f).intValue();
                    permCopy = permCopy.subtract(f.multiply(BigInteger.valueOf(indices[i])));
                }
                if (!acceptPermutation(n, r, indices, shouldContinue)) {
                    return;
                } else {
                    bigIntegerAdd = perm.add(increment);
                }
            } else {
                return;
            }
        }
    }

    private static boolean acceptPermutation(int n, int r, int[] indices, Predicate<int[]> shouldContinue) {
        int[] permutation = new int[n];
        for (int i = 0; i < r; i++) {
            int wantedIndex = indices[i];
            int currentIndex = 0;
            int j = 0;
            while (true) {
                if (j >= permutation.length) {
                    break;
                }
                if (permutation[j] == 0) {
                    int i2 = currentIndex;
                    currentIndex++;
                    if (i2 == wantedIndex) {
                        currentIndex = j;
                        break;
                    }
                }
                j++;
            }
            permutation[currentIndex] = i + 1;
        }
        return shouldContinue.test(permutation);
    }

    public static void combine(int n, int r, Predicate<int[]> shouldContinue) {
        int[] combination = new int[r];
        for (int i = 0; i < r; i++) {
            combination[i] = i;
        }
        while (combination[r - 1] < n && shouldContinue.test(combination)) {
            int t = r - 1;
            while (t != 0 && combination[t] == (n - r) + t) {
                t--;
            }
            int i2 = t;
            combination[i2] = combination[i2] + 1;
            for (int i3 = t + 1; i3 < r; i3++) {
                combination[i3] = combination[i3 - 1] + 1;
            }
        }
    }
}
