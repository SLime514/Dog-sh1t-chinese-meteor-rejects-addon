package com.seedfinding.mcmath.component.matrix;

import com.seedfinding.mcmath.arithmetic.Real;
import com.seedfinding.mcmath.component.vector.RVector;
import com.seedfinding.mcmath.decomposition.LUDecomposition;

public class RMatrix {
    private final Real[][] elements;

    protected RMatrix(int rows, int columns) {
        this.elements = new Real[rows][columns];
    }

    public RMatrix(int size, Generator generator) {
        this(size, size, generator);
    }

    public RMatrix(int rows, int columns, Generator generator) {
        this(rows, columns);
        for (int row = 0; row < rows; row++) {
            for (int column = 0; column < columns; column++) {
                this.elements[row][column] = generator.getValue(row, column);
            }
        }
    }

    public RMatrix(RVector... rows) {
        this(rows.length, rows[0].getDimension(), (row, column) -> {
            return rows[row].get(column);
        });
    }

    public RMatrix(Real[]... elements) {
        this(elements.length, elements[0].length, (row, column) -> {
            return elements[row][column];
        });
    }

    public static RMatrix zero(int rows, int columns) {
        return new RMatrix(rows, columns, (row, column) -> {
            return Real.ZERO;
        });
    }

    public static RMatrix identity(int size) {
        return new RMatrix(size, size, (row, column) -> {
            return row == column ? Real.ONE : Real.ZERO;
        });
    }

    public int getRowCount() {
        return this.elements.length;
    }

    public int getColumnCount() {
        return this.elements[0].length;
    }

    public boolean isSquare() {
        return getRowCount() == getColumnCount();
    }

    public Generator toGenerator() {
        return this::get;
    }

    public Mapper toMapper() {
        return toGenerator().asMapper();
    }

    public Real get(int row, int column) {
        return this.elements[row][column];
    }

    public RMatrix set(int row, int column, Real value) {
        this.elements[row][column] = value;
        return this;
    }

    public RMatrix with(int row, int column, Real value) {
        return copy().set(row, column, value);
    }

    public RMatrix map(Mapper mapper) {
        return new RMatrix(getRowCount(), getColumnCount(), (row, column) -> {
            return mapper.getNewValue(row, column, get(row, column));
        });
    }

    public RMatrix mapAndSet(Mapper mapper) {
        for (int row = 0; row < getRowCount(); row++) {
            for (int column = 0; column < getColumnCount(); column++) {
                set(row, column, mapper.getNewValue(row, column, get(row, column)));
            }
        }
        return this;
    }

    public RMatrix mapRow(int row, RVector.Mapper mapper) {
        return new RMatrix(getRowCount(), getColumnCount(), (row1, column) -> {
            return row == row1 ? mapper.getNewValue(column, get(row, column)) : get(row1, column);
        });
    }

    public RMatrix mapRowAndSet(int row, RVector.Mapper mapper) {
        for (int column = 0; column < getColumnCount(); column++) {
            set(row, column, mapper.getNewValue(column, get(row, column)));
        }
        return this;
    }

    public RMatrix mapColumn(int column, RVector.Mapper mapper) {
        return new RMatrix(getRowCount(), getColumnCount(), (row, column1) -> {
            return column == column1 ? mapper.getNewValue(row, get(row, column)) : get(row, column1);
        });
    }

    public RMatrix mapColumnAndSet(int column, RVector.Mapper mapper) {
        for (int row = 0; row < getRowCount(); row++) {
            set(row, column, mapper.getNewValue(row, get(row, column)));
        }
        return this;
    }

    public RVector.View getRow(int row) {
        return new RVector.View(getColumnCount(), column -> {
            return get(row, column);
        }, (column2, value) -> {
            set(row, column2, value);
        });
    }

    public RVector.View getColumn(int column) {
        return new RVector.View(getRowCount(), row -> {
            return get(row, column);
        }, (row2, value) -> {
            set(row2, column, value);
        });
    }

    public RVector getRowCopy(int row) {
        return new RVector(getColumnCount(), i -> {
            return get(row, i);
        });
    }

    public RVector getColumnCopy(int column) {
        return new RVector(getRowCount(), i -> {
            return get(i, column);
        });
    }

    public RMatrix setRow(int row, RVector value) {
        return mapRowAndSet(row, (index, oldValue) -> {
            return value.get(index);
        });
    }

    public RMatrix setColumn(int column, RVector value) {
        return mapColumnAndSet(column, (index, oldValue) -> {
            return value.get(index);
        });
    }

    public RMatrix withRow(int row, RVector value) {
        return mapRow(row, value.toMapper());
    }

    public RMatrix withColumn(int column, RVector value) {
        return mapColumn(column, value.toMapper());
    }

    public RVector.View[] getRows() {
        RVector.View[] rows = new RVector.View[getRowCount()];
        for (int i = 0; i < rows.length; i++) {
            rows[i] = getRow(i);
        }
        return rows;
    }

    public RVector.View[] getColumns() {
        RVector.View[] columns = new RVector.View[getColumnCount()];
        for (int i = 0; i < columns.length; i++) {
            columns[i] = getColumn(i);
        }
        return columns;
    }

    public RVector[] getRowsCopy() {
        RVector[] rows = new RVector[getRowCount()];
        for (int i = 0; i < rows.length; i++) {
            rows[i] = getRowCopy(i);
        }
        return rows;
    }

    public RVector[] getColumnsCopy() {
        RVector[] columns = new RVector[getColumnCount()];
        for (int i = 0; i < columns.length; i++) {
            columns[i] = getColumnCopy(i);
        }
        return columns;
    }

    public RMatrix swap(int r1, int c1, int r2, int c2) {
        return map((row, column, oldValue) -> {
            if (row == r1 && column == c1) {
                row = r2;
                column = c2;
            } else if (row == r2 && column == c2) {
                row = r1;
                column = c1;
            }
            return get(row, column);
        });
    }

    public RMatrix swapRows(int r1, int r2) {
        return map((row, column, oldValue) -> {
            if (row == r1) {
                row = r2;
            } else if (row == r2) {
                row = r1;
            }
            return get(row, column);
        });
    }

    public RMatrix swapColumns(int c1, int c2) {
        return map((row, column, oldValue) -> {
            if (column == c1) {
                column = c2;
            } else if (column == c2) {
                column = c1;
            }
            return get(row, column);
        });
    }

    public RMatrix swapAndSet(int r1, int c1, int r2, int c2) {
        Real oldValue = get(r1, c1);
        return set(r1, c1, get(r2, c2)).set(r2, c2, oldValue);
    }

    public RMatrix swapRowsAndSet(int r1, int r2) {
        RVector oldRow = getRowCopy(r1);
        return mapRowAndSet(r1, (index, oldValue) -> {
            return get(r2, index);
        }).mapRowAndSet(r2, oldRow.toMapper());
    }

    public RMatrix swapColumnsAndSet(int c1, int c2) {
        RVector oldColumn = getColumnCopy(c1);
        return mapColumnAndSet(c1, (index, oldValue) -> {
            return get(c2, index);
        }).mapColumnAndSet(c2, oldColumn.toMapper());
    }

    public RMatrix transpose() {
        return new RMatrix(getColumnCount(), getRowCount(), (row, column) -> {
            return get(column, row);
        });
    }

    public RMatrix transposeAndSet() {
        if (!isSquare()) {
            throw new IllegalStateException("Mutating a non-square matrix");
        }
        return mapAndSet((row, column, oldValue) -> {
            return get(column, row);
        });
    }

    public RMatrix add(RMatrix other) {
        if (getRowCount() != other.getRowCount() || getColumnCount() != other.getColumnCount()) {
            throw new IllegalArgumentException("Adding two matrices with different dimensions");
        }
        return map((row, column, oldValue) -> {
            return oldValue.add(other.get(row, column));
        });
    }

    public RMatrix addAndSet(RMatrix other) {
        if (getRowCount() != other.getRowCount() || getColumnCount() != other.getColumnCount()) {
            throw new IllegalArgumentException("Adding two matrices with different dimensions");
        }
        return mapAndSet((row, column, oldValue) -> {
            return oldValue.add(other.get(row, column));
        });
    }

    public RMatrix subtract(RMatrix other) {
        if (getRowCount() != other.getRowCount() || getColumnCount() != other.getColumnCount()) {
            throw new IllegalArgumentException("Adding two matrices with different dimensions");
        }
        return map((row, column, oldValue) -> {
            return oldValue.subtract(other.get(row, column));
        });
    }

    public RMatrix subtractAndSet(RMatrix other) {
        if (getRowCount() != other.getRowCount() || getColumnCount() != other.getColumnCount()) {
            throw new IllegalArgumentException("Adding two matrices with different dimensions");
        }
        return mapAndSet((row, column, oldValue) -> {
            return oldValue.subtract(other.get(row, column));
        });
    }

    public RMatrix multiply(RMatrix other) {
        if (getColumnCount() != other.getRowCount()) {
            throw new IllegalArgumentException("Multiplying two matrices with disallowed dimensions");
        }
        RVector[] rows = getRows();
        RVector[] columns = other.getColumns();
        return new RMatrix(rows.length, columns.length, (row, column) -> {
            return rows[row].dot(columns[column]);
        });
    }

    public RMatrix multiplyAndSet(RMatrix other) {
        if (getRowCount() != other.getRowCount() || getColumnCount() != other.getColumnCount()) {
            throw new IllegalArgumentException("Multiplying mutable matrix with disallowed dimensions");
        }
        RVector[] rows = getRows();
        RVector[] columns = other.getColumns();
        return mapAndSet((row, column, oldValue) -> {
            return rows[row].dot(columns[column]);
        });
    }

    public RVector multiply(RVector vector) {
        return vector.multiply(this);
    }

    public RVector multiplyAndSet(RVector vector) {
        return vector.multiplyAndSet(this);
    }

    public RMatrix multiply(Real scalar) {
        return map((row, column, oldValue) -> {
            return get(row, column).multiply(scalar);
        });
    }

    public RMatrix multiplyAndSet(Real scalar) {
        return mapAndSet((row, column, oldValue) -> {
            return get(row, column).multiply(scalar);
        });
    }

    public RMatrix divide(Real scalar) {
        return map((row, column, oldValue) -> {
            return get(row, column).divide(scalar);
        });
    }

    public RMatrix divideAndSet(Real scalar) {
        return mapAndSet((row, column, oldValue) -> {
            return get(row, column).divide(scalar);
        });
    }

    public RMatrix invert() {
        return luDecompose().getInverse();
    }

    public RMatrix invertAndSet() {
        RMatrix inverse = invert();
        return mapAndSet((row, column, oldValue) -> {
            return inverse.get(row, column);
        });
    }

    public Real getDeterminant() {
        return luDecompose().getDeterminant();
    }

    public LUDecomposition.C0163R luDecompose() {
        return LUDecomposition.m40of(this);
    }

    public RMatrix sub(int r1, int c1, int rowCount, int columnCount) {
        return new View(rowCount, columnCount, (row, column) -> {
            return get(r1 + row, c1 + column);
        }, (row2, column2, value) -> {
            set(r1 + row2, c1 + column2, value);
        });
    }

    public RMatrix subCopy(int r1, int c1, int rowCount, int columnCount) {
        return sub(r1, c1, rowCount, columnCount).copy();
    }

    public Augmented mergeToAugmented(RMatrix extra) {
        if (getRowCount() != extra.getRowCount()) {
            throw new UnsupportedOperationException("Merging two matrices with different row count");
        }
        return new Augmented(this, extra);
    }

    public Augmented splitToAugmented(int columnSplit) {
        return new Augmented(this, columnSplit);
    }

    public RMatrix copy() {
        return new RMatrix(getRowCount(), getColumnCount(), toGenerator());
    }

    public int hashCode() {
        int result = 1;
        for (int row = 0; row < getRowCount(); row++) {
            result = (31 * result) + getRow(row).hashCode();
        }
        return (getRowCount() * 961) + (getColumnCount() * 31) + result;
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof RMatrix)) {
            return false;
        }
        RMatrix matrix = (RMatrix) other;
        if (getRowCount() != matrix.getRowCount() || getColumnCount() != matrix.getColumnCount()) {
            return false;
        }
        for (int row = 0; row < getRowCount(); row++) {
            for (int column = 0; column < getColumnCount(); column++) {
                if (!get(row, column).equals(matrix.get(row, column))) {
                    return false;
                }
            }
        }
        return true;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        RVector[] rows = getRows();
        int i = 0;
        while (i < rows.length) {
            sb.append(rows[i].toString()).append(i < rows.length - 1 ? "\n" : "");
            i++;
        }
        return sb.toString();
    }

    public static class View extends RMatrix {
        private final int rows;
        private final int columns;
        private final Generator getter;
        private final Setter setter;

        @FunctionalInterface
        public interface Setter {
            void set(int i, int i2, Real real);
        }

        public View(int rows, int columns, Generator getter, Setter setter) {
            super(0, 0);
            this.rows = rows;
            this.columns = columns;
            this.getter = getter;
            this.setter = setter;
        }

        @Override
        public int getRowCount() {
            return this.rows;
        }

        @Override
        public int getColumnCount() {
            return this.columns;
        }

        @Override
        public Real get(int row, int column) {
            return this.getter.getValue(row, column);
        }

        @Override
        public RMatrix set(int row, int column, Real value) {
            this.setter.set(row, column, value);
            return this;
        }
    }

    public static class Augmented extends RMatrix {
        private final RMatrix base;
        private final RMatrix extra;
        private final int split;

        public Augmented(RMatrix base, RMatrix extra) {
            super(0, 0);
            this.base = base;
            this.extra = extra;
            this.split = base.getColumnCount();
        }

        public Augmented(RMatrix merged, int split) {
            this(merged.sub(0, 0, merged.getRowCount() - 1, split - 1), merged.sub(0, 0, merged.getRowCount() - 1, split - 1));
        }

        public RMatrix getBaseMatrix() {
            return this.base;
        }

        public RMatrix getExtraMatrix() {
            return this.extra;
        }

        public int getSplit() {
            return this.split;
        }

        @Override
        public int getRowCount() {
            return getBaseMatrix().getRowCount();
        }

        @Override
        public int getColumnCount() {
            return getBaseMatrix().getColumnCount() + getExtraMatrix().getColumnCount();
        }

        @Override
        public Real get(int row, int column) {
            return column < getSplit() ? getBaseMatrix().get(row, column) : getExtraMatrix().get(row, column - getSplit());
        }

        @Override
        public RMatrix set(int row, int column, Real value) {
            if (column < getSplit()) {
                getBaseMatrix().set(row, column, value);
            } else {
                getExtraMatrix().set(row, column - getSplit(), value);
            }
            return this;
        }
    }

    @FunctionalInterface
    public interface Generator {
        Real getValue(int i, int i2);

        default RVector.Generator forRow(int row) {
            return index -> {
                return getValue(row, index);
            };
        }

        default RVector.Generator forColumn(int column) {
            return index -> {
                return getValue(index, column);
            };
        }

        default Mapper asMapper() {
            return (row, column, oldValue) -> {
                return getValue(row, column);
            };
        }
    }

    @FunctionalInterface
    public interface Mapper {
        Real getNewValue(int i, int i2, Real real);

        default RVector.Mapper forRow(int row) {
            return (index, oldValue) -> {
                return getNewValue(row, index, oldValue);
            };
        }

        default RVector.Mapper forColumn(int column) {
            return (index, oldValue) -> {
                return getNewValue(index, column, oldValue);
            };
        }

        default Generator asGenerator() {
            return (row, column) -> {
                return getNewValue(row, column, null);
            };
        }
    }
}
