package com.seedfinding.mcmath.component.matrix;

import com.seedfinding.mcmath.arithmetic.Complex;
import com.seedfinding.mcmath.component.vector.CVector;

public class CMatrix {
    private final Complex[][] elements;

    protected CMatrix(int rows, int columns) {
        this.elements = new Complex[rows][columns];
    }

    public CMatrix(int size, Generator generator) {
        this(size, size, generator);
    }

    public CMatrix(int rows, int columns, Generator generator) {
        this(rows, columns);
        for (int row = 0; row < rows; row++) {
            for (int column = 0; column < columns; column++) {
                this.elements[row][column] = generator.getValue(row, column);
            }
        }
    }

    public CMatrix(CVector... rows) {
        this(rows.length, rows[0].getDimension(), (row, column) -> {
            return rows[row].get(column);
        });
    }

    public CMatrix(Complex[]... elements) {
        this(elements.length, elements[0].length, (row, column) -> {
            return elements[row][column];
        });
    }

    public static CMatrix zero(int rows, int columns) {
        return new CMatrix(rows, columns, (row, column) -> {
            return Complex.ZERO;
        });
    }

    public static CMatrix identity(int size) {
        return new CMatrix(size, size, (row, column) -> {
            return row == column ? Complex.ONE : Complex.ZERO;
        });
    }

    public int getRowCount() {
        return this.elements.length;
    }

    public int getColumnCount() {
        return this.elements[0].length;
    }

    public boolean isSquare() {
        return getRowCount() == getColumnCount();
    }

    public Generator toGenerator() {
        return this::get;
    }

    public Mapper toMapper() {
        return toGenerator().asMapper();
    }

    public Complex get(int row, int column) {
        return this.elements[row][column];
    }

    public CMatrix set(int row, int column, Complex value) {
        this.elements[row][column] = value;
        return this;
    }

    public CMatrix with(int row, int column, Complex value) {
        return copy().set(row, column, value);
    }

    public CMatrix map(Mapper mapper) {
        return new CMatrix(getRowCount(), getColumnCount(), (row, column) -> {
            return mapper.getNewValue(row, column, get(row, column));
        });
    }

    public CMatrix mapAndSet(Mapper mapper) {
        for (int row = 0; row < getRowCount(); row++) {
            for (int column = 0; column < getColumnCount(); column++) {
                set(row, column, mapper.getNewValue(row, column, get(row, column)));
            }
        }
        return this;
    }

    public CMatrix mapRow(int row, CVector.Mapper mapper) {
        return new CMatrix(getRowCount(), getColumnCount(), (row1, column) -> {
            return row == row1 ? mapper.getNewValue(column, get(row, column)) : get(row1, column);
        });
    }

    public CMatrix mapRowAndSet(int row, CVector.Mapper mapper) {
        for (int column = 0; column < getColumnCount(); column++) {
            set(row, column, mapper.getNewValue(column, get(row, column)));
        }
        return this;
    }

    public CMatrix mapColumn(int column, CVector.Mapper mapper) {
        return new CMatrix(getRowCount(), getColumnCount(), (row, column1) -> {
            return column == column1 ? mapper.getNewValue(row, get(row, column)) : get(row, column1);
        });
    }

    public CMatrix mapColumnAndSet(int column, CVector.Mapper mapper) {
        for (int row = 0; row < getRowCount(); row++) {
            set(row, column, mapper.getNewValue(row, get(row, column)));
        }
        return this;
    }

    public CVector.View getRow(int row) {
        return new CVector.View(getColumnCount(), column -> {
            return get(row, column);
        }, (column2, value) -> {
            set(row, column2, value);
        });
    }

    public CVector.View getColumn(int column) {
        return new CVector.View(getRowCount(), row -> {
            return get(row, column);
        }, (row2, value) -> {
            set(row2, column, value);
        });
    }

    public CVector getRowCopy(int row) {
        return new CVector(getColumnCount(), i -> {
            return get(row, i);
        });
    }

    public CVector getColumnCopy(int column) {
        return new CVector(getRowCount(), i -> {
            return get(i, column);
        });
    }

    public CMatrix setRow(int row, CVector value) {
        return mapRowAndSet(row, (index, oldValue) -> {
            return value.get(index);
        });
    }

    public CMatrix setColumn(int column, CVector value) {
        return mapColumnAndSet(column, (index, oldValue) -> {
            return value.get(index);
        });
    }

    public CMatrix withRow(int row, CVector value) {
        return mapRow(row, value.toMapper());
    }

    public CMatrix withColumn(int column, CVector value) {
        return mapColumn(column, value.toMapper());
    }

    public CVector.View[] getRows() {
        CVector.View[] rows = new CVector.View[getRowCount()];
        for (int i = 0; i < rows.length; i++) {
            rows[i] = getRow(i);
        }
        return rows;
    }

    public CVector.View[] getColumns() {
        CVector.View[] columns = new CVector.View[getColumnCount()];
        for (int i = 0; i < columns.length; i++) {
            columns[i] = getColumn(i);
        }
        return columns;
    }

    public CVector[] getRowsCopy() {
        CVector[] rows = new CVector[getRowCount()];
        for (int i = 0; i < rows.length; i++) {
            rows[i] = getRowCopy(i);
        }
        return rows;
    }

    public CVector[] getColumnsCopy() {
        CVector[] columns = new CVector[getColumnCount()];
        for (int i = 0; i < columns.length; i++) {
            columns[i] = getColumnCopy(i);
        }
        return columns;
    }

    public CMatrix swap(int r1, int c1, int r2, int c2) {
        return map((row, column, oldValue) -> {
            if (row == r1 && column == c1) {
                row = r2;
                column = c2;
            } else if (row == r2 && column == c2) {
                row = r1;
                column = c1;
            }
            return get(row, column);
        });
    }

    public CMatrix swapRows(int r1, int r2) {
        return map((row, column, oldValue) -> {
            if (row == r1) {
                row = r2;
            } else if (row == r2) {
                row = r1;
            }
            return get(row, column);
        });
    }

    public CMatrix swapColumns(int c1, int c2) {
        return map((row, column, oldValue) -> {
            if (column == c1) {
                column = c2;
            } else if (column == c2) {
                column = c1;
            }
            return get(row, column);
        });
    }

    public CMatrix swapAndSet(int r1, int c1, int r2, int c2) {
        Complex oldValue = get(r1, c1);
        return set(r1, c1, get(r2, c2)).set(r2, c2, oldValue);
    }

    public CMatrix swapRowsAndSet(int r1, int r2) {
        CVector oldRow = getRowCopy(r1);
        return mapRowAndSet(r1, (index, oldValue) -> {
            return get(r2, index);
        }).mapRowAndSet(r2, oldRow.toMapper());
    }

    public CMatrix swapColumnsAndSet(int c1, int c2) {
        CVector oldColumn = getColumnCopy(c1);
        return mapColumnAndSet(c1, (index, oldValue) -> {
            return get(c2, index);
        }).mapColumnAndSet(c2, oldColumn.toMapper());
    }

    public CMatrix transpose() {
        return new CMatrix(getColumnCount(), getRowCount(), (row, column) -> {
            return get(column, row);
        });
    }

    public CMatrix transposeAndSet() {
        if (!isSquare()) {
            throw new IllegalStateException("Mutating a non-square matrix");
        }
        return mapAndSet((row, column, oldValue) -> {
            return get(column, row);
        });
    }

    public CMatrix add(CMatrix other) {
        if (getRowCount() != other.getRowCount() || getColumnCount() != other.getColumnCount()) {
            throw new IllegalArgumentException("Adding two matrices with different dimensions");
        }
        return map((row, column, oldValue) -> {
            return oldValue.add(other.get(row, column));
        });
    }

    public CMatrix addAndSet(CMatrix other) {
        if (getRowCount() != other.getRowCount() || getColumnCount() != other.getColumnCount()) {
            throw new IllegalArgumentException("Adding two matrices with different dimensions");
        }
        return mapAndSet((row, column, oldValue) -> {
            return oldValue.add(other.get(row, column));
        });
    }

    public CMatrix subtract(CMatrix other) {
        if (getRowCount() != other.getRowCount() || getColumnCount() != other.getColumnCount()) {
            throw new IllegalArgumentException("Adding two matrices with different dimensions");
        }
        return map((row, column, oldValue) -> {
            return oldValue.subtract(other.get(row, column));
        });
    }

    public CMatrix subtractAndSet(CMatrix other) {
        if (getRowCount() != other.getRowCount() || getColumnCount() != other.getColumnCount()) {
            throw new IllegalArgumentException("Adding two matrices with different dimensions");
        }
        return mapAndSet((row, column, oldValue) -> {
            return oldValue.subtract(other.get(row, column));
        });
    }

    public CMatrix multiply(CMatrix other) {
        if (getColumnCount() != other.getRowCount()) {
            throw new IllegalArgumentException("Multiplying two matrices with disallowed dimensions");
        }
        CVector[] rows = getRows();
        CVector[] columns = other.getColumns();
        return new CMatrix(rows.length, columns.length, (row, column) -> {
            return rows[row].dot(columns[column]);
        });
    }

    public CMatrix multiplyAndSet(CMatrix other) {
        if (getRowCount() != other.getRowCount() || getColumnCount() != other.getColumnCount()) {
            throw new IllegalArgumentException("Multiplying mutable matrix with disallowed dimensions");
        }
        CVector[] rows = getRows();
        CVector[] columns = other.getColumns();
        return mapAndSet((row, column, oldValue) -> {
            return rows[row].dot(columns[column]);
        });
    }

    public CVector multiply(CVector vector) {
        return vector.multiply(this);
    }

    public CVector multiplyAndSet(CVector vector) {
        return vector.multiplyAndSet(this);
    }

    public CMatrix multiply(Complex scalar) {
        return map((row, column, oldValue) -> {
            return get(row, column).multiply(scalar);
        });
    }

    public CMatrix multiplyAndSet(Complex scalar) {
        return mapAndSet((row, column, oldValue) -> {
            return get(row, column).multiply(scalar);
        });
    }

    public CMatrix divide(Complex scalar) {
        return map((row, column, oldValue) -> {
            return get(row, column).divide(scalar);
        });
    }

    public CMatrix divideAndSet(Complex scalar) {
        return mapAndSet((row, column, oldValue) -> {
            return get(row, column).divide(scalar);
        });
    }

    public CMatrix sub(int r1, int c1, int rowCount, int columnCount) {
        return new View(rowCount, columnCount, (row, column) -> {
            return get(r1 + row, c1 + column);
        }, (row2, column2, value) -> {
            set(r1 + row2, c1 + column2, value);
        });
    }

    public CMatrix subCopy(int r1, int c1, int rowCount, int columnCount) {
        return sub(r1, c1, rowCount, columnCount).copy();
    }

    public Augmented mergeToAugmented(CMatrix extra) {
        if (getRowCount() != extra.getRowCount()) {
            throw new UnsupportedOperationException("Merging two matrices with different row count");
        }
        return new Augmented(this, extra);
    }

    public Augmented splitToAugmented(int columnSplit) {
        return new Augmented(this, columnSplit);
    }

    public CMatrix copy() {
        return new CMatrix(getRowCount(), getColumnCount(), toGenerator());
    }

    public int hashCode() {
        int result = 1;
        for (int row = 0; row < getRowCount(); row++) {
            result = (31 * result) + getRow(row).hashCode();
        }
        return (getRowCount() * 961) + (getColumnCount() * 31) + result;
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof CMatrix)) {
            return false;
        }
        CMatrix matrix = (CMatrix) other;
        if (getRowCount() != matrix.getRowCount() || getColumnCount() != matrix.getColumnCount()) {
            return false;
        }
        for (int row = 0; row < getRowCount(); row++) {
            for (int column = 0; column < getColumnCount(); column++) {
                if (!get(row, column).equals(matrix.get(row, column))) {
                    return false;
                }
            }
        }
        return true;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        CVector[] rows = getRows();
        int i = 0;
        while (i < rows.length) {
            sb.append(rows[i].toString()).append(i < rows.length - 1 ? "\n" : "");
            i++;
        }
        return sb.toString();
    }

    public static class View extends CMatrix {
        private final int rows;
        private final int columns;
        private final Generator getter;
        private final Setter setter;

        @FunctionalInterface
        public interface Setter {
            void set(int i, int i2, Complex complex);
        }

        public View(int rows, int columns, Generator getter, Setter setter) {
            super(0, 0);
            this.rows = rows;
            this.columns = columns;
            this.getter = getter;
            this.setter = setter;
        }

        @Override
        public int getRowCount() {
            return this.rows;
        }

        @Override
        public int getColumnCount() {
            return this.columns;
        }

        @Override
        public Complex get(int row, int column) {
            return this.getter.getValue(row, column);
        }

        @Override
        public CMatrix set(int row, int column, Complex value) {
            this.setter.set(row, column, value);
            return this;
        }
    }

    public static class Augmented extends CMatrix {
        private final CMatrix base;
        private final CMatrix extra;
        private final int split;

        public Augmented(CMatrix base, CMatrix extra) {
            super(0, 0);
            this.base = base;
            this.extra = extra;
            this.split = base.getColumnCount();
        }

        public Augmented(CMatrix merged, int split) {
            this(merged.sub(0, 0, merged.getRowCount() - 1, split - 1), merged.sub(0, 0, merged.getRowCount() - 1, split - 1));
        }

        public CMatrix getBaseMatrix() {
            return this.base;
        }

        public CMatrix getExtraMatrix() {
            return this.extra;
        }

        public int getSplit() {
            return this.split;
        }

        @Override
        public int getRowCount() {
            return getBaseMatrix().getRowCount();
        }

        @Override
        public int getColumnCount() {
            return getBaseMatrix().getColumnCount() + getExtraMatrix().getColumnCount();
        }

        @Override
        public Complex get(int row, int column) {
            return column < getSplit() ? getBaseMatrix().get(row, column) : getExtraMatrix().get(row, column - getSplit());
        }

        @Override
        public CMatrix set(int row, int column, Complex value) {
            if (column < getSplit()) {
                getBaseMatrix().set(row, column, value);
            } else {
                getExtraMatrix().set(row, column - getSplit(), value);
            }
            return this;
        }
    }

    @FunctionalInterface
    public interface Generator {
        Complex getValue(int i, int i2);

        default CVector.Generator forRow(int row) {
            return index -> {
                return getValue(row, index);
            };
        }

        default CVector.Generator forColumn(int column) {
            return index -> {
                return getValue(index, column);
            };
        }

        default Mapper asMapper() {
            return (row, column, oldValue) -> {
                return getValue(row, column);
            };
        }
    }

    @FunctionalInterface
    public interface Mapper {
        Complex getNewValue(int i, int i2, Complex complex);

        default CVector.Mapper forRow(int row) {
            return (index, oldValue) -> {
                return getNewValue(row, index, oldValue);
            };
        }

        default CVector.Mapper forColumn(int column) {
            return (index, oldValue) -> {
                return getNewValue(index, column, oldValue);
            };
        }

        default Generator asGenerator() {
            return (row, column) -> {
                return getNewValue(row, column, null);
            };
        }
    }
}
