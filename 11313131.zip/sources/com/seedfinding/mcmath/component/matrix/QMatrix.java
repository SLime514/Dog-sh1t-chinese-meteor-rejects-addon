package com.seedfinding.mcmath.component.matrix;

import com.seedfinding.mcmath.arithmetic.Rational;
import com.seedfinding.mcmath.component.vector.QVector;
import com.seedfinding.mcmath.decomposition.LUDecomposition;

public class QMatrix {
    private final Rational[][] elements;

    protected QMatrix(int rows, int columns) {
        this.elements = new Rational[rows][columns];
    }

    public QMatrix(int size, Generator generator) {
        this(size, size, generator);
    }

    public QMatrix(int rows, int columns, Generator generator) {
        this(rows, columns);
        for (int row = 0; row < rows; row++) {
            for (int column = 0; column < columns; column++) {
                this.elements[row][column] = generator.getValue(row, column);
            }
        }
    }

    public QMatrix(QVector... rows) {
        this(rows.length, rows[0].getDimension(), (row, column) -> {
            return rows[row].get(column);
        });
    }

    public QMatrix(Rational[]... elements) {
        this(elements.length, elements[0].length, (row, column) -> {
            return elements[row][column];
        });
    }

    public static QMatrix zero(int rows, int columns) {
        return new QMatrix(rows, columns, (row, column) -> {
            return Rational.ZERO;
        });
    }

    public static QMatrix identity(int size) {
        return new QMatrix(size, size, (row, column) -> {
            return row == column ? Rational.ONE : Rational.ZERO;
        });
    }

    public int getRowCount() {
        return this.elements.length;
    }

    public int getColumnCount() {
        return this.elements[0].length;
    }

    public boolean isSquare() {
        return getRowCount() == getColumnCount();
    }

    public Generator toGenerator() {
        return this::get;
    }

    public Mapper toMapper() {
        return toGenerator().asMapper();
    }

    public Rational get(int row, int column) {
        return this.elements[row][column];
    }

    public QMatrix set(int row, int column, Rational value) {
        this.elements[row][column] = value;
        return this;
    }

    public QMatrix with(int row, int column, Rational value) {
        return copy().set(row, column, value);
    }

    public QMatrix map(Mapper mapper) {
        return new QMatrix(getRowCount(), getColumnCount(), (row, column) -> {
            return mapper.getNewValue(row, column, get(row, column));
        });
    }

    public QMatrix mapAndSet(Mapper mapper) {
        for (int row = 0; row < getRowCount(); row++) {
            for (int column = 0; column < getColumnCount(); column++) {
                set(row, column, mapper.getNewValue(row, column, get(row, column)));
            }
        }
        return this;
    }

    public QMatrix mapRow(int row, QVector.Mapper mapper) {
        return new QMatrix(getRowCount(), getColumnCount(), (row1, column) -> {
            return row == row1 ? mapper.getNewValue(column, get(row, column)) : get(row1, column);
        });
    }

    public QMatrix mapRowAndSet(int row, QVector.Mapper mapper) {
        for (int column = 0; column < getColumnCount(); column++) {
            set(row, column, mapper.getNewValue(column, get(row, column)));
        }
        return this;
    }

    public QMatrix mapColumn(int column, QVector.Mapper mapper) {
        return new QMatrix(getRowCount(), getColumnCount(), (row, column1) -> {
            return column == column1 ? mapper.getNewValue(row, get(row, column)) : get(row, column1);
        });
    }

    public QMatrix mapColumnAndSet(int column, QVector.Mapper mapper) {
        for (int row = 0; row < getRowCount(); row++) {
            set(row, column, mapper.getNewValue(row, get(row, column)));
        }
        return this;
    }

    public QVector.View getRow(int row) {
        return new QVector.View(getColumnCount(), column -> {
            return get(row, column);
        }, (column2, value) -> {
            set(row, column2, value);
        });
    }

    public QVector.View getColumn(int column) {
        return new QVector.View(getRowCount(), row -> {
            return get(row, column);
        }, (row2, value) -> {
            set(row2, column, value);
        });
    }

    public QVector getRowCopy(int row) {
        return new QVector(getColumnCount(), i -> {
            return get(row, i);
        });
    }

    public QVector getColumnCopy(int column) {
        return new QVector(getRowCount(), i -> {
            return get(i, column);
        });
    }

    public QMatrix setRow(int row, QVector value) {
        return mapRowAndSet(row, (index, oldValue) -> {
            return value.get(index);
        });
    }

    public QMatrix setColumn(int column, QVector value) {
        return mapColumnAndSet(column, (index, oldValue) -> {
            return value.get(index);
        });
    }

    public QMatrix withRow(int row, QVector value) {
        return mapRow(row, value.toMapper());
    }

    public QMatrix withColumn(int column, QVector value) {
        return mapColumn(column, value.toMapper());
    }

    public QVector.View[] getRows() {
        QVector.View[] rows = new QVector.View[getRowCount()];
        for (int i = 0; i < rows.length; i++) {
            rows[i] = getRow(i);
        }
        return rows;
    }

    public QVector.View[] getColumns() {
        QVector.View[] columns = new QVector.View[getColumnCount()];
        for (int i = 0; i < columns.length; i++) {
            columns[i] = getColumn(i);
        }
        return columns;
    }

    public QVector[] getRowsCopy() {
        QVector[] rows = new QVector[getRowCount()];
        for (int i = 0; i < rows.length; i++) {
            rows[i] = getRowCopy(i);
        }
        return rows;
    }

    public QVector[] getColumnsCopy() {
        QVector[] columns = new QVector[getColumnCount()];
        for (int i = 0; i < columns.length; i++) {
            columns[i] = getColumnCopy(i);
        }
        return columns;
    }

    public QMatrix swap(int r1, int c1, int r2, int c2) {
        return map((row, column, oldValue) -> {
            if (row == r1 && column == c1) {
                row = r2;
                column = c2;
            } else if (row == r2 && column == c2) {
                row = r1;
                column = c1;
            }
            return get(row, column);
        });
    }

    public QMatrix swapRows(int r1, int r2) {
        return map((row, column, oldValue) -> {
            if (row == r1) {
                row = r2;
            } else if (row == r2) {
                row = r1;
            }
            return get(row, column);
        });
    }

    public QMatrix swapColumns(int c1, int c2) {
        return map((row, column, oldValue) -> {
            if (column == c1) {
                column = c2;
            } else if (column == c2) {
                column = c1;
            }
            return get(row, column);
        });
    }

    public QMatrix swapAndSet(int r1, int c1, int r2, int c2) {
        Rational oldValue = get(r1, c1);
        return set(r1, c1, get(r2, c2)).set(r2, c2, oldValue);
    }

    public QMatrix swapRowsAndSet(int r1, int r2) {
        QVector oldRow = getRowCopy(r1);
        return mapRowAndSet(r1, (index, oldValue) -> {
            return get(r2, index);
        }).mapRowAndSet(r2, oldRow.toMapper());
    }

    public QMatrix swapColumnsAndSet(int c1, int c2) {
        QVector oldColumn = getColumnCopy(c1);
        return mapColumnAndSet(c1, (index, oldValue) -> {
            return get(c2, index);
        }).mapColumnAndSet(c2, oldColumn.toMapper());
    }

    public QMatrix transpose() {
        return new QMatrix(getColumnCount(), getRowCount(), (row, column) -> {
            return get(column, row);
        });
    }

    public QMatrix transposeAndSet() {
        if (!isSquare()) {
            throw new IllegalStateException("Mutating a non-square matrix");
        }
        return mapAndSet((row, column, oldValue) -> {
            return get(column, row);
        });
    }

    public QMatrix add(QMatrix other) {
        if (getRowCount() != other.getRowCount() || getColumnCount() != other.getColumnCount()) {
            throw new IllegalArgumentException("Adding two matrices with different dimensions");
        }
        return map((row, column, oldValue) -> {
            return oldValue.add(other.get(row, column));
        });
    }

    public QMatrix addAndSet(QMatrix other) {
        if (getRowCount() != other.getRowCount() || getColumnCount() != other.getColumnCount()) {
            throw new IllegalArgumentException("Adding two matrices with different dimensions");
        }
        return mapAndSet((row, column, oldValue) -> {
            return oldValue.add(other.get(row, column));
        });
    }

    public QMatrix subtract(QMatrix other) {
        if (getRowCount() != other.getRowCount() || getColumnCount() != other.getColumnCount()) {
            throw new IllegalArgumentException("Adding two matrices with different dimensions");
        }
        return map((row, column, oldValue) -> {
            return oldValue.subtract(other.get(row, column));
        });
    }

    public QMatrix subtractAndSet(QMatrix other) {
        if (getRowCount() != other.getRowCount() || getColumnCount() != other.getColumnCount()) {
            throw new IllegalArgumentException("Adding two matrices with different dimensions");
        }
        return mapAndSet((row, column, oldValue) -> {
            return oldValue.subtract(other.get(row, column));
        });
    }

    public QMatrix multiply(QMatrix other) {
        if (getColumnCount() != other.getRowCount()) {
            throw new IllegalArgumentException("Multiplying two matrices with disallowed dimensions");
        }
        QVector[] rows = getRows();
        QVector[] columns = other.getColumns();
        return new QMatrix(rows.length, columns.length, (row, column) -> {
            return rows[row].dot(columns[column]);
        });
    }

    public QMatrix multiplyAndSet(QMatrix other) {
        if (getRowCount() != other.getRowCount() || getColumnCount() != other.getColumnCount()) {
            throw new IllegalArgumentException("Multiplying mutable matrix with disallowed dimensions");
        }
        QVector[] rows = getRows();
        QVector[] columns = other.getColumns();
        return mapAndSet((row, column, oldValue) -> {
            return rows[row].dot(columns[column]);
        });
    }

    public QVector multiply(QVector vector) {
        return vector.multiply(this);
    }

    public QVector multiplyAndSet(QVector vector) {
        return vector.multiplyAndSet(this);
    }

    public QMatrix multiply(Rational scalar) {
        return map((row, column, oldValue) -> {
            return get(row, column).multiply(scalar);
        });
    }

    public QMatrix multiplyAndSet(Rational scalar) {
        return mapAndSet((row, column, oldValue) -> {
            return get(row, column).multiply(scalar);
        });
    }

    public QMatrix divide(Rational scalar) {
        return map((row, column, oldValue) -> {
            return get(row, column).divide(scalar);
        });
    }

    public QMatrix divideAndSet(Rational scalar) {
        return mapAndSet((row, column, oldValue) -> {
            return get(row, column).divide(scalar);
        });
    }

    public QMatrix invert() {
        return luDecompose().getInverse();
    }

    public QMatrix invertAndSet() {
        QMatrix inverse = invert();
        return mapAndSet((row, column, oldValue) -> {
            return inverse.get(row, column);
        });
    }

    public Rational getDeterminant() {
        return luDecompose().getDeterminant();
    }

    public LUDecomposition.C0162Q luDecompose() {
        return LUDecomposition.m39of(this);
    }

    public QMatrix sub(int r1, int c1, int rowCount, int columnCount) {
        return new View(rowCount, columnCount, (row, column) -> {
            return get(r1 + row, c1 + column);
        }, (row2, column2, value) -> {
            set(r1 + row2, c1 + column2, value);
        });
    }

    public QMatrix subCopy(int r1, int c1, int rowCount, int columnCount) {
        return sub(r1, c1, rowCount, columnCount).copy();
    }

    public Augmented mergeToAugmented(QMatrix extra) {
        if (getRowCount() != extra.getRowCount()) {
            throw new UnsupportedOperationException("Merging two matrices with different row count");
        }
        return new Augmented(this, extra);
    }

    public Augmented splitToAugmented(int columnSplit) {
        return new Augmented(this, columnSplit);
    }

    public QMatrix copy() {
        return new QMatrix(getRowCount(), getColumnCount(), toGenerator());
    }

    public int hashCode() {
        int result = 1;
        for (int row = 0; row < getRowCount(); row++) {
            result = (31 * result) + getRow(row).hashCode();
        }
        return (getRowCount() * 961) + (getColumnCount() * 31) + result;
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof QMatrix)) {
            return false;
        }
        QMatrix matrix = (QMatrix) other;
        if (getRowCount() != matrix.getRowCount() || getColumnCount() != matrix.getColumnCount()) {
            return false;
        }
        for (int row = 0; row < getRowCount(); row++) {
            for (int column = 0; column < getColumnCount(); column++) {
                if (!get(row, column).equals(matrix.get(row, column))) {
                    return false;
                }
            }
        }
        return true;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        QVector[] rows = getRows();
        int i = 0;
        while (i < rows.length) {
            sb.append(rows[i].toString()).append(i < rows.length - 1 ? "\n" : "");
            i++;
        }
        return sb.toString();
    }

    public static class View extends QMatrix {
        private final int rows;
        private final int columns;
        private final Generator getter;
        private final Setter setter;

        @FunctionalInterface
        public interface Setter {
            void set(int i, int i2, Rational rational);
        }

        public View(int rows, int columns, Generator getter, Setter setter) {
            super(0, 0);
            this.rows = rows;
            this.columns = columns;
            this.getter = getter;
            this.setter = setter;
        }

        @Override
        public int getRowCount() {
            return this.rows;
        }

        @Override
        public int getColumnCount() {
            return this.columns;
        }

        @Override
        public Rational get(int row, int column) {
            return this.getter.getValue(row, column);
        }

        @Override
        public QMatrix set(int row, int column, Rational value) {
            this.setter.set(row, column, value);
            return this;
        }
    }

    public static class Augmented extends QMatrix {
        private final QMatrix base;
        private final QMatrix extra;
        private final int split;

        public Augmented(QMatrix base, QMatrix extra) {
            super(0, 0);
            this.base = base;
            this.extra = extra;
            this.split = base.getColumnCount();
        }

        public Augmented(QMatrix merged, int split) {
            this(merged.sub(0, 0, merged.getRowCount() - 1, split - 1), merged.sub(0, 0, merged.getRowCount() - 1, split - 1));
        }

        public QMatrix getBaseMatrix() {
            return this.base;
        }

        public QMatrix getExtraMatrix() {
            return this.extra;
        }

        public int getSplit() {
            return this.split;
        }

        @Override
        public int getRowCount() {
            return getBaseMatrix().getRowCount();
        }

        @Override
        public int getColumnCount() {
            return getBaseMatrix().getColumnCount() + getExtraMatrix().getColumnCount();
        }

        @Override
        public Rational get(int row, int column) {
            return column < getSplit() ? getBaseMatrix().get(row, column) : getExtraMatrix().get(row, column - getSplit());
        }

        @Override
        public QMatrix set(int row, int column, Rational value) {
            if (column < getSplit()) {
                getBaseMatrix().set(row, column, value);
            } else {
                getExtraMatrix().set(row, column - getSplit(), value);
            }
            return this;
        }
    }

    @FunctionalInterface
    public interface Generator {
        Rational getValue(int i, int i2);

        default QVector.Generator forRow(int row) {
            return index -> {
                return getValue(row, index);
            };
        }

        default QVector.Generator forColumn(int column) {
            return index -> {
                return getValue(index, column);
            };
        }

        default Mapper asMapper() {
            return (row, column, oldValue) -> {
                return getValue(row, column);
            };
        }
    }

    @FunctionalInterface
    public interface Mapper {
        Rational getNewValue(int i, int i2, Rational rational);

        default QVector.Mapper forRow(int row) {
            return (index, oldValue) -> {
                return getNewValue(row, index, oldValue);
            };
        }

        default QVector.Mapper forColumn(int column) {
            return (index, oldValue) -> {
                return getNewValue(index, column, oldValue);
            };
        }

        default Generator asGenerator() {
            return (row, column) -> {
                return getNewValue(row, column, null);
            };
        }
    }
}
