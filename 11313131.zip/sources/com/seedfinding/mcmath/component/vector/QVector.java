package com.seedfinding.mcmath.component.vector;

import com.seedfinding.mcmath.arithmetic.Rational;
import com.seedfinding.mcmath.arithmetic.Real;
import com.seedfinding.mcmath.component.Norm;
import com.seedfinding.mcmath.component.matrix.QMatrix;
import java.math.BigInteger;
import java.util.Arrays;

public class QVector {
    public static final Norm<QVector, Rational> SUM = v -> {
        Rational sum = Rational.ZERO;
        for (int i = 0; i < v.getDimension(); i++) {
            sum = sum.add(v.get(i));
        }
        return sum;
    };
    public static final Norm<QVector, Rational> EUCLIDEAN_SQ = v -> {
        Rational sum = Rational.ZERO;
        for (int i = 0; i < v.getDimension(); i++) {
            sum = sum.add(v.get(i).multiply(v.get(i)));
        }
        return sum;
    };
    private final Rational[] elements;

    protected QVector(int dimension) {
        this.elements = new Rational[dimension];
    }

    public QVector(int dimension, Generator generator) {
        this(dimension);
        for (int i = 0; i < this.elements.length; i++) {
            this.elements[i] = generator.getValue(i);
        }
    }

    public QVector(Rational... elements) {
        this.elements = elements;
    }

    public QVector(BigInteger... elements) {
        this((Rational[]) Arrays.stream(elements).map(Rational::m32of).toArray(x$0 -> {
            return new Rational[x$0];
        }));
    }

    public QVector(long... elements) {
        this((Rational[]) Arrays.stream(elements).mapToObj(Rational::m34of).toArray(x$0 -> {
            return new Rational[x$0];
        }));
    }

    public static QVector zero(int dimension) {
        return new QVector(dimension, i -> {
            return Rational.ZERO;
        });
    }

    public static QVector basis(int dimension, int index) {
        return basis(dimension, index, Rational.ONE);
    }

    public static QVector basis(int dimension, int index, Rational scale) {
        return new QVector(dimension, i -> {
            return i == index ? scale : Rational.ZERO;
        });
    }

    public static QVector basis(int dimension, int index, BigInteger scale) {
        return basis(dimension, index, Rational.m32of(scale));
    }

    public static QVector basis(int dimension, int index, long scale) {
        return basis(dimension, index, Rational.m34of(scale));
    }

    public int getDimension() {
        return this.elements.length;
    }

    public Generator toGenerator() {
        return this::get;
    }

    public Mapper toMapper() {
        return toGenerator().asMapper();
    }

    public Rational get(int index) {
        return this.elements[index];
    }

    public QVector set(int index, Rational value) {
        this.elements[index] = value;
        return this;
    }

    public Rational[] getElements() {
        Rational[] elements = new Rational[getDimension()];
        for (int i = 0; i < getDimension(); i++) {
            elements[i] = get(i);
        }
        return elements;
    }

    public QVector with(int index, Rational value) {
        return copy().set(index, value);
    }

    public QVector map(Mapper mapper) {
        return new QVector(getDimension(), index -> {
            return mapper.getNewValue(index, get(index));
        });
    }

    public QVector mapAndSet(Mapper mapper) {
        for (int i = 0; i < getDimension(); i++) {
            set(i, mapper.getNewValue(i, get(i)));
        }
        return this;
    }

    protected void checkDimension(QVector other) {
        if (getDimension() != other.getDimension()) {
            throw new IllegalArgumentException("vectors don't have the same size");
        }
    }

    public Rational norm(Norm<QVector, Rational> norm) {
        return norm.get(this);
    }

    public Rational sum() {
        return norm(SUM);
    }

    public Rational magnitudeSq() {
        return norm(EUCLIDEAN_SQ);
    }

    public Rational raisedNorm(int p) {
        Rational rationalAdd;
        Rational sum = Rational.ZERO;
        for (int i = 0; i < getDimension(); i++) {
            Rational e = get(i);
            if (p == 1) {
                rationalAdd = sum.add(e);
            } else {
                rationalAdd = p == 2 ? sum.add(e.multiply(e)) : sum.add(e.pow(p));
            }
            sum = rationalAdd;
        }
        return sum;
    }

    public QVector normalize(Norm<QVector, Rational> norm) {
        Rational magnitude = norm.get(this);
        return magnitude.equals(Real.ZERO) ? copy() : map((index, oldValue) -> {
            return oldValue.divide(magnitude);
        });
    }

    public QVector normalizeAndSet(Norm<QVector, Rational> norm) {
        Rational magnitude = norm.get(this);
        return magnitude.equals(Real.ZERO) ? this : mapAndSet((index, oldValue) -> {
            return oldValue.divide(magnitude);
        });
    }

    public QVector swap(int i, int j) {
        return copy().set(i, get(j)).set(j, get(i));
    }

    public QVector swapAndSet(int i, int j) {
        Rational oldValue = get(i);
        return set(i, get(j)).set(j, oldValue);
    }

    public QVector add(QVector other) {
        checkDimension(other);
        return map((index, oldValue) -> {
            return oldValue.add(other.get(index));
        });
    }

    public QVector addAndSet(QVector other) {
        checkDimension(other);
        return mapAndSet((index, oldValue) -> {
            return oldValue.add(other.get(index));
        });
    }

    public QVector subtract(QVector other) {
        checkDimension(other);
        return map((index, oldValue) -> {
            return oldValue.subtract(other.get(index));
        });
    }

    public QVector subtractAndSet(QVector other) {
        checkDimension(other);
        return mapAndSet((index, oldValue) -> {
            return oldValue.subtract(other.get(index));
        });
    }

    public QVector scale(Rational scalar) {
        return map((index, oldValue) -> {
            return oldValue.multiply(scalar);
        });
    }

    public QVector scaleAndSet(Rational scalar) {
        return mapAndSet((index, oldValue) -> {
            return oldValue.multiply(scalar);
        });
    }

    public QVector scale(BigInteger scalar) {
        return map((index, oldValue) -> {
            return oldValue.multiply(scalar);
        });
    }

    public QVector scaleAndSet(BigInteger scalar) {
        return mapAndSet((index, oldValue) -> {
            return oldValue.multiply(scalar);
        });
    }

    public QVector scale(long scalar) {
        return map((index, oldValue) -> {
            return oldValue.multiply(scalar);
        });
    }

    public QVector scaleAndSet(long scalar) {
        return mapAndSet((index, oldValue) -> {
            return oldValue.multiply(scalar);
        });
    }

    public QVector multiply(QMatrix matrix) {
        if (matrix.getRowCount() != getDimension()) {
            throw new IllegalArgumentException("Vector length should equal the number of matrix columns");
        }
        return new QVector(getDimension(), i -> {
            return dot(matrix.getRow(i));
        });
    }

    public QVector multiplyAndSet(QMatrix matrix) {
        if (matrix.getRowCount() != getDimension()) {
            throw new IllegalArgumentException("Vector length should equal the number of matrix columns");
        }
        QVector original = copy();
        return mapAndSet((index, oldValue) -> {
            return original.dot(matrix.getRow(index));
        });
    }

    public QVector divide(Rational scalar) {
        return map((index, oldValue) -> {
            return oldValue.divide(scalar);
        });
    }

    public QVector divideAndSet(Rational scalar) {
        return mapAndSet((index, oldValue) -> {
            return oldValue.divide(scalar);
        });
    }

    public QVector divide(BigInteger scalar) {
        return map((index, oldValue) -> {
            return oldValue.divide(scalar);
        });
    }

    public QVector divideAndSet(BigInteger scalar) {
        return mapAndSet((index, oldValue) -> {
            return oldValue.divide(scalar);
        });
    }

    public QVector divideAndSet(long scalar) {
        return mapAndSet((index, oldValue) -> {
            return oldValue.divide(scalar);
        });
    }

    public Rational dot(QVector other) {
        checkDimension(other);
        return new QVector(getDimension(), index -> {
            return get(index).multiply(other.get(index));
        }).sum();
    }

    public QVector projectOnto(QVector other) {
        return other.scale(gramSchmidtCoefficient(other));
    }

    public QVector projectOnto(QMatrix other) {
        QMatrix transposed = other.transpose();
        return multiply(other.multiply(transposed.multiply(other).invert()).multiply(transposed));
    }

    public Rational gramSchmidtCoefficient(QVector other) {
        return dot(other).divide(other.magnitudeSq());
    }

    public QVector tensor(QVector other) {
        QVector res = new QVector(getDimension() * other.getDimension());
        for (int i = 0; i < getDimension(); i++) {
            for (int j = 0; j < other.getDimension(); j++) {
                int id = (i * other.getDimension()) + j;
                res.set(id, get(i).multiply(other.get(j)));
            }
        }
        return res;
    }

    public QMatrix toMatrixRow() {
        return new QMatrix(1, getDimension(), (row, column) -> {
            return get(column);
        });
    }

    public QMatrix toMatrixColumn() {
        return new QMatrix(getDimension(), 1, (row, column) -> {
            return get(row);
        });
    }

    public QVector copy() {
        return new QVector(getDimension(), toGenerator());
    }

    public int hashCode() {
        return (getDimension() * 31) + Arrays.hashCode(getElements());
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof QVector)) {
            return false;
        }
        QVector vector = (QVector) other;
        if (getDimension() != vector.getDimension()) {
            return false;
        }
        for (int i = 0; i < getDimension(); i++) {
            if (!get(i).equals(vector.get(i))) {
                return false;
            }
        }
        return true;
    }

    public String toString() {
        return Arrays.toString(getElements());
    }

    public static class View extends QVector {
        private final int dimension;
        private final Generator getter;
        private final Setter setter;

        @FunctionalInterface
        public interface Setter {
            void set(int i, Rational rational);
        }

        public View(int dimension, Generator getter, Setter setter) {
            super((Rational[]) null);
            this.dimension = dimension;
            this.getter = getter;
            this.setter = setter;
        }

        @Override
        public int getDimension() {
            return this.dimension;
        }

        @Override
        public Rational get(int index) {
            return this.getter.getValue(index);
        }

        @Override
        public QVector set(int index, Rational value) {
            this.setter.set(index, value);
            return this;
        }
    }

    @FunctionalInterface
    public interface Generator {
        Rational getValue(int i);

        default Mapper asMapper() {
            return (index, oldValue) -> {
                return getValue(index);
            };
        }
    }

    @FunctionalInterface
    public interface Mapper {
        Rational getNewValue(int i, Rational rational);

        default Generator asGenerator() {
            return index -> {
                return getNewValue(index, null);
            };
        }
    }
}
