package com.seedfinding.mcmath.component.vector;

import com.seedfinding.mcmath.arithmetic.Complex;
import com.seedfinding.mcmath.component.Norm;
import com.seedfinding.mcmath.component.matrix.CMatrix;
import java.math.BigInteger;
import java.util.Arrays;

public class CVector {
    public static final Norm<CVector, Complex> SUM = v -> {
        Complex sum = Complex.ZERO;
        for (int i = 0; i < v.getDimension(); i++) {
            sum = sum.add(v.get(i));
        }
        return sum;
    };
    private final Complex[] elements;

    protected CVector(int dimension) {
        this.elements = new Complex[dimension];
    }

    public CVector(int dimension, Generator generator) {
        this(dimension);
        for (int i = 0; i < this.elements.length; i++) {
            this.elements[i] = generator.getValue(i);
        }
    }

    public CVector(Complex... elements) {
        this.elements = elements;
    }

    public static CVector zero(int dimension) {
        return new CVector(dimension, i -> {
            return Complex.ZERO;
        });
    }

    public static CVector basis(int dimension, int index) {
        return basis(dimension, index, Complex.ONE);
    }

    public static CVector basis(int dimension, int index, Complex scale) {
        return new CVector(dimension, i -> {
            return i == index ? scale : Complex.ZERO;
        });
    }

    public static CVector basis(int dimension, int index, BigInteger scale) {
        return basis(dimension, index, Complex.m24of(scale));
    }

    public static CVector basis(int dimension, int index, long scale) {
        return basis(dimension, index, Complex.m26of(scale));
    }

    public int getDimension() {
        return this.elements.length;
    }

    public Generator toGenerator() {
        return this::get;
    }

    public Mapper toMapper() {
        return toGenerator().asMapper();
    }

    public Complex get(int index) {
        return this.elements[index];
    }

    public CVector set(int index, Complex value) {
        this.elements[index] = value;
        return this;
    }

    public Complex[] getElements() {
        Complex[] elements = new Complex[getDimension()];
        for (int i = 0; i < getDimension(); i++) {
            elements[i] = get(i);
        }
        return elements;
    }

    public CVector with(int index, Complex value) {
        return copy().set(index, value);
    }

    public CVector map(Mapper mapper) {
        return new CVector(getDimension(), index -> {
            return mapper.getNewValue(index, get(index));
        });
    }

    public CVector mapAndSet(Mapper mapper) {
        for (int i = 0; i < getDimension(); i++) {
            set(i, mapper.getNewValue(i, get(i)));
        }
        return this;
    }

    protected void checkDimension(CVector other) {
        if (getDimension() != other.getDimension()) {
            throw new IllegalArgumentException("vectors don't have the same size");
        }
    }

    public Complex norm(Norm<CVector, Complex> norm) {
        return norm.get(this);
    }

    public Complex sum() {
        return norm(SUM);
    }

    public CVector swap(int i, int j) {
        return copy().set(i, get(j)).set(j, get(i));
    }

    public CVector swapAndSet(int i, int j) {
        Complex oldValue = get(i);
        return set(i, get(j)).set(j, oldValue);
    }

    public CVector add(CVector other) {
        checkDimension(other);
        return map((index, oldValue) -> {
            return oldValue.add(other.get(index));
        });
    }

    public CVector addAndSet(CVector other) {
        checkDimension(other);
        return mapAndSet((index, oldValue) -> {
            return oldValue.add(other.get(index));
        });
    }

    public CVector subtract(CVector other) {
        checkDimension(other);
        return map((index, oldValue) -> {
            return oldValue.subtract(other.get(index));
        });
    }

    public CVector subtractAndSet(CVector other) {
        checkDimension(other);
        return mapAndSet((index, oldValue) -> {
            return oldValue.subtract(other.get(index));
        });
    }

    public CVector scale(Complex scalar) {
        return map((index, oldValue) -> {
            return oldValue.multiply(scalar);
        });
    }

    public CVector scaleAndSet(Complex scalar) {
        return mapAndSet((index, oldValue) -> {
            return oldValue.multiply(scalar);
        });
    }

    public CVector scale(BigInteger scalar) {
        return map((index, oldValue) -> {
            return oldValue.multiply(scalar);
        });
    }

    public CVector scaleAndSet(BigInteger scalar) {
        return mapAndSet((index, oldValue) -> {
            return oldValue.multiply(scalar);
        });
    }

    public CVector scale(long scalar) {
        return map((index, oldValue) -> {
            return oldValue.multiply(scalar);
        });
    }

    public CVector scaleAndSet(long scalar) {
        return mapAndSet((index, oldValue) -> {
            return oldValue.multiply(scalar);
        });
    }

    public CVector multiply(CMatrix matrix) {
        if (matrix.getRowCount() != getDimension()) {
            throw new IllegalArgumentException("Vector length should equal the number of matrix columns");
        }
        return new CVector(getDimension(), i -> {
            return dot(matrix.getRow(i));
        });
    }

    public CVector multiplyAndSet(CMatrix matrix) {
        if (matrix.getRowCount() != getDimension()) {
            throw new IllegalArgumentException("Vector length should equal the number of matrix columns");
        }
        CVector original = copy();
        return mapAndSet((index, oldValue) -> {
            return original.dot(matrix.getRow(index));
        });
    }

    public CVector divide(Complex scalar) {
        return map((index, oldValue) -> {
            return oldValue.divide(scalar);
        });
    }

    public CVector divideAndSet(Complex scalar) {
        return mapAndSet((index, oldValue) -> {
            return oldValue.divide(scalar);
        });
    }

    public CVector divide(BigInteger scalar) {
        return map((index, oldValue) -> {
            return oldValue.divide(scalar);
        });
    }

    public CVector divideAndSet(BigInteger scalar) {
        return mapAndSet((index, oldValue) -> {
            return oldValue.divide(scalar);
        });
    }

    public CVector divideAndSet(long scalar) {
        return mapAndSet((index, oldValue) -> {
            return oldValue.divide(scalar);
        });
    }

    public Complex dot(CVector other) {
        checkDimension(other);
        return new CVector(getDimension(), index -> {
            return get(index).multiply(other.get(index));
        }).sum();
    }

    public CVector tensor(CVector other) {
        CVector res = new CVector(getDimension() * other.getDimension());
        for (int i = 0; i < getDimension(); i++) {
            for (int j = 0; j < other.getDimension(); j++) {
                int id = (i * other.getDimension()) + j;
                res.set(id, get(i).multiply(other.get(j)));
            }
        }
        return res;
    }

    public CMatrix toMatrixRow() {
        return new CMatrix(1, getDimension(), (row, column) -> {
            return get(column);
        });
    }

    public CMatrix toMatrixColumn() {
        return new CMatrix(getDimension(), 1, (row, column) -> {
            return get(row);
        });
    }

    public CVector copy() {
        return new CVector(getDimension(), toGenerator());
    }

    public int hashCode() {
        return (getDimension() * 31) + Arrays.hashCode(getElements());
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof CVector)) {
            return false;
        }
        CVector vector = (CVector) other;
        if (getDimension() != vector.getDimension()) {
            return false;
        }
        for (int i = 0; i < getDimension(); i++) {
            if (!get(i).equals(vector.get(i))) {
                return false;
            }
        }
        return true;
    }

    public String toString() {
        return Arrays.toString(getElements());
    }

    public static class View extends CVector {
        private final int dimension;
        private final Generator getter;
        private final Setter setter;

        @FunctionalInterface
        public interface Setter {
            void set(int i, Complex complex);
        }

        public View(int dimension, Generator getter, Setter setter) {
            super((Complex[]) null);
            this.dimension = dimension;
            this.getter = getter;
            this.setter = setter;
        }

        @Override
        public int getDimension() {
            return this.dimension;
        }

        @Override
        public Complex get(int index) {
            return this.getter.getValue(index);
        }

        @Override
        public CVector set(int index, Complex value) {
            this.setter.set(index, value);
            return this;
        }
    }

    @FunctionalInterface
    public interface Generator {
        Complex getValue(int i);

        default Mapper asMapper() {
            return (index, oldValue) -> {
                return getValue(index);
            };
        }
    }

    @FunctionalInterface
    public interface Mapper {
        Complex getNewValue(int i, Complex complex);

        default Generator asGenerator() {
            return index -> {
                return getNewValue(index, null);
            };
        }
    }
}
