package com.seedfinding.mccore.util.math;

import com.seedfinding.mcseed.rand.JRand;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class NextLongReverser {
    public static void addSeedsToList(long structureSeed, List<Long> seedList) {
        long lowerBits = structureSeed & 4294967295L;
        long upperBits = structureSeed >>> 32;
        if ((lowerBits & 2147483648L) != 0) {
            upperBits++;
        }
        long lowMin = lowerBits << (16 - 1);
        long lowMax = ((lowerBits + 1) << (16 - 1)) - 1;
        long upperMin = ((upperBits << 16) - 107048004364969L) >> 1;
        long m1lv = Math.floorDiv((lowMax * (-33441)) + (upperMin * 17549), 1 << (31 - 1)) + 1;
        long m2lv = Math.floorDiv((lowMin * 46603) + (upperMin * 39761), 1 << (32 - 1)) + 1;
        long seed = ((-39761) * m1lv) + (35098 * m2lv);
        if (((((46603 * m1lv) + (66882 * m2lv)) + 107048004364969L) >>> 16) == upperBits && (seed >>> 16) == lowerBits) {
            seedList.add(Long.valueOf(((254681119335897L * seed) + 120305458776662L) & 281474976710655L));
        }
        long seed2 = ((-39761) * (m1lv + 1)) + (35098 * m2lv);
        if (((((46603 * (m1lv + 1)) + (66882 * m2lv)) + 107048004364969L) >>> 16) == upperBits && (seed2 >>> 16) == lowerBits) {
            seedList.add(Long.valueOf(((254681119335897L * seed2) + 120305458776662L) & 281474976710655L));
        }
        long seed3 = ((-39761) * m1lv) + (35098 * (m2lv + 1));
        if (((((46603 * m1lv) + (66882 * (m2lv + 1))) + 107048004364969L) >>> 16) == upperBits && (seed3 >>> 16) == lowerBits) {
            seedList.add(Long.valueOf(((254681119335897L * seed3) + 120305458776662L) & 281474976710655L));
        }
    }

    public static ArrayList<Long> getSeeds(long structureSeed) {
        ArrayList<Long> seeds = new ArrayList<>(2);
        addSeedsToList(structureSeed, seeds);
        return seeds;
    }

    public static void addNextLongEquivalents(long structureSeed, List<Long> nextLongs) {
        Iterator<Long> it = getSeeds(structureSeed).iterator();
        while (it.hasNext()) {
            long seed = it.next().longValue();
            nextLongs.add(Long.valueOf(new JRand(seed, false).nextLong()));
        }
    }

    public static ArrayList<Long> getNextLongEquivalents(long structureSeed) {
        ArrayList<Long> nextLongs = new ArrayList<>(2);
        addNextLongEquivalents(structureSeed, nextLongs);
        return nextLongs;
    }
}
