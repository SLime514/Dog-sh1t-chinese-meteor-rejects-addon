package com.seedfinding.mccore.util.math;

public class Vec3i {
    public static final Vec3i ZERO = new Vec3i(0, 0, 0);

    private final int f59x;

    private final int f60y;

    private final int f61z;

    public Vec3i(int x, int y, int z) {
        this.f59x = x;
        this.f60y = y;
        this.f61z = z;
    }

    public int getX() {
        return this.f59x;
    }

    public int getY() {
        return this.f60y;
    }

    public int getZ() {
        return this.f61z;
    }

    public double getMagnitude() {
        return distanceTo(ZERO, DistanceMetric.EUCLIDEAN);
    }

    public double getMagnitudeSq() {
        return distanceTo(ZERO, DistanceMetric.EUCLIDEAN_SQ);
    }

    public double distanceTo(Vec3i vec, DistanceMetric distance) {
        return distance.getDistance(getX() - vec.getX(), getY() - vec.getY(), getZ() - vec.getZ());
    }

    public Vec3i get2DMirrored() {
        return new Vec3i(this.f61z, this.f60y, this.f59x);
    }

    public Vec3i invert() {
        return new Vec3i(-this.f59x, -this.f60y, -this.f61z);
    }

    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof Vec3i)) {
            return false;
        }
        Vec3i pos = (Vec3i) o;
        return getX() == pos.getX() && getY() == pos.getY() && getZ() == pos.getZ();
    }

    public int hashCode() {
        return (getZ() * 961) + (getY() * 31) + getX();
    }

    public String toString() {
        return "Pos{x=" + this.f59x + ", y=" + this.f60y + ", z=" + this.f61z + '}';
    }
}
