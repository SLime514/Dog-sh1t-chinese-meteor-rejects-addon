package com.seedfinding.mccore.util.math;

import com.seedfinding.mcmath.util.Mth;

@FunctionalInterface
public interface DistanceMetric {
    public static final DistanceMetric EUCLIDEAN_SQ = (x, y, z) -> {
        return (x * x) + (y * y) + (z * z);
    };
    public static final DistanceMetric EUCLIDEAN = (x, y, z) -> {
        return Math.sqrt(EUCLIDEAN_SQ.getDistance(x, y, z));
    };
    public static final DistanceMetric MANHATTAN = (x, y, z) -> {
        return Math.abs(x) + Math.abs(y) + Math.abs(z);
    };
    public static final DistanceMetric CHEBYSHEV = (x, y, z) -> {
        return Mth.max(Math.abs(x), Math.abs(y), Math.abs(z));
    };

    double getDistance(int i, int i2, int i3);
}
