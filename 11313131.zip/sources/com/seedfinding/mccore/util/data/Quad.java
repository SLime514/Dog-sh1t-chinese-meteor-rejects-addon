package com.seedfinding.mccore.util.data;

import java.util.Objects;

public final class Quad<A, B, C, D> {

    private final A f46a;

    private final B f47b;

    private final C f48c;

    private final D f49d;

    public Quad(A a, B b, C c, D d) {
        this.f46a = a;
        this.f47b = b;
        this.f48c = c;
        this.f49d = d;
    }

    public Quad(Quad<? extends A, ? extends B, ? extends C, ? extends D> other) {
        this(other.f46a, other.f47b, other.f48c, other.f49d);
    }

    public A getFirst() {
        return this.f46a;
    }

    public B getSecond() {
        return this.f47b;
    }

    public C getThird() {
        return this.f48c;
    }

    public D getFourth() {
        return this.f49d;
    }

    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof Quad)) {
            return false;
        }
        Quad<?, ?, ?, ?> quad = (Quad) o;
        return Objects.equals(this.f46a, quad.f46a) && Objects.equals(this.f47b, quad.f47b) && Objects.equals(this.f48c, quad.f48c) && Objects.equals(this.f49d, quad.f49d);
    }

    public int hashCode() {
        return Objects.hash(this.f46a, this.f47b, this.f48c, this.f49d);
    }

    public String toString() {
        return "(" + this.f46a + ", " + this.f47b + ", " + this.f48c + ", " + this.f49d + ")";
    }
}
