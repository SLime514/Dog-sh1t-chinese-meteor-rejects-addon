package com.seedfinding.mccore.util.data;

import com.seedfinding.mccore.nbt.NBTType;
import com.seedfinding.mccore.util.math.Vec3i;
import java.util.Iterator;
import java.util.Spliterator;
import java.util.Spliterators;
import org.jetbrains.annotations.NotNull;

public class SpiralIterator<T extends Vec3i> implements Iterable<T> {
    private final T center;
    private final T lowerBound;
    private final T upperBound;
    private final int step;
    private final Builder<T> builder;

    @FunctionalInterface
    public interface Builder<T extends Vec3i> {
        T build(int i, int i2, int i3);
    }

    public SpiralIterator(T center, T lowerBound, T upperBound, int step, Builder<T> builder) {
        this.center = center;
        this.lowerBound = lowerBound;
        this.upperBound = upperBound;
        this.step = step;
        this.builder = builder;
    }

    public SpiralIterator(T center, T radius, int step, Builder<T> builder) {
        this(center, builder.build(center.getX() - radius.getX(), 0, center.getZ() - radius.getZ()), builder.build(center.getX() + radius.getX(), 0, center.getZ() + radius.getZ()), step, builder);
    }

    public SpiralIterator(T center, T radius, Builder<T> builder) {
        this(center, radius, 1, builder);
    }

    @Override
    @NotNull
    public Iterator<T> iterator() {
        return (Iterator<T>) new Iterator<T>() {

            private int f50x;

            private int f51z;

            private float f52n = 1.0f;

            private int f53i = 0;

            private int f54j = 0;

            {
                this.f50x = SpiralIterator.this.center.getX();
                this.f51z = SpiralIterator.this.center.getZ();
            }

            @Override
            public boolean hasNext() {
                return this.f50x >= SpiralIterator.this.lowerBound.getX() && this.f50x <= SpiralIterator.this.upperBound.getX() && this.f51z >= SpiralIterator.this.lowerBound.getZ() && this.f51z <= SpiralIterator.this.upperBound.getZ();
            }

            @Override
            public T next() {
                T t = (T) SpiralIterator.this.builder.build(this.f50x, 0, this.f51z);
                if (this.f54j < ((int) this.f52n)) {
                    switch (this.f53i % 4) {
                        case 0:
                            this.f51z += SpiralIterator.this.step;
                            break;
                        case 1:
                            this.f50x += SpiralIterator.this.step;
                            break;
                        case NBTType.SHORT:
                            this.f51z -= SpiralIterator.this.step;
                            break;
                        case 3:
                            this.f50x -= SpiralIterator.this.step;
                            break;
                    }
                    this.f54j++;
                    return t;
                }
                this.f54j = 0;
                this.f52n += 0.5f;
                this.f53i++;
                return (T) next();
            }
        };
    }

    @Override
    public Spliterator<T> spliterator() {
        return Spliterators.spliterator(iterator(), (((this.upperBound.getX() - this.lowerBound.getX()) / this.step) + 1) * (((this.upperBound.getZ() - this.lowerBound.getZ()) / this.step) + 1), 16);
    }
}
