package com.seedfinding.mccore.util.data;

import java.util.Objects;

public final class Pair<A, B> {

    private final A f44a;

    private final B f45b;

    public Pair(A a, B b) {
        this.f44a = a;
        this.f45b = b;
    }

    public Pair(Pair<? extends A, ? extends B> other) {
        this(other.f44a, other.f45b);
    }

    public A getFirst() {
        return this.f44a;
    }

    public B getSecond() {
        return this.f45b;
    }

    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof Pair)) {
            return false;
        }
        Pair<?, ?> pair = (Pair) o;
        return Objects.equals(this.f44a, pair.f44a) && Objects.equals(this.f45b, pair.f45b);
    }

    public int hashCode() {
        return Objects.hash(this.f44a, this.f45b);
    }

    public String toString() {
        return "(" + this.f44a + ", " + this.f45b + ")";
    }
}
