package com.seedfinding.mccore.util.data;

import java.util.Objects;

public final class Triplet<A, B, C> {

    private final A f56a;

    private final B f57b;

    private final C f58c;

    public Triplet(A a, B b, C c) {
        this.f56a = a;
        this.f57b = b;
        this.f58c = c;
    }

    public Triplet(Triplet<? extends A, ? extends B, ? extends C> other) {
        this(other.f56a, other.f57b, other.f58c);
    }

    public A getFirst() {
        return this.f56a;
    }

    public B getSecond() {
        return this.f57b;
    }

    public C getThird() {
        return this.f58c;
    }

    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof Triplet)) {
            return false;
        }
        Triplet<?, ?, ?> triplet = (Triplet) o;
        return Objects.equals(this.f56a, triplet.f56a) && Objects.equals(this.f57b, triplet.f57b) && Objects.equals(this.f58c, triplet.f58c);
    }

    public int hashCode() {
        return Objects.hash(this.f56a, this.f57b, this.f58c);
    }

    public String toString() {
        return "(" + this.f56a + ", " + this.f57b + ", " + this.f58c + ")";
    }
}
