package com.seedfinding.mccore.util.block;

import com.seedfinding.mccore.nbt.NBTType;
import com.seedfinding.mccore.util.block.BlockDirection;
import com.seedfinding.mccore.util.pos.BPos;
import com.seedfinding.mcseed.rand.JRand;
import java.util.Arrays;
import java.util.List;

public enum BlockRotation {
    NONE(BlockDirection.NORTH),
    CLOCKWISE_90(BlockDirection.EAST),
    CLOCKWISE_180(BlockDirection.SOUTH),
    COUNTERCLOCKWISE_90(BlockDirection.WEST);

    private final BlockDirection direction;

    BlockRotation(BlockDirection direction) {
        this.direction = direction;
    }

    public static BlockRotation getRandom(JRand rand) {
        return values()[rand.nextInt(values().length)];
    }

    public static List<BlockRotation> getShuffled(JRand rand) {
        List<BlockRotation> list = Arrays.asList(values());
        JRand.shuffle(list, rand);
        return list;
    }

    public BlockDirection getDirection() {
        return this.direction;
    }

    static class C00471 {
        static final int[] $SwitchMap$com$seedfinding$mccore$util$block$BlockRotation = new int[BlockRotation.values().length];

        static {
            try {
                $SwitchMap$com$seedfinding$mccore$util$block$BlockRotation[BlockRotation.CLOCKWISE_180.ordinal()] = 1;
            } catch (NoSuchFieldError e) {
            }
            try {
                $SwitchMap$com$seedfinding$mccore$util$block$BlockRotation[BlockRotation.COUNTERCLOCKWISE_90.ordinal()] = 2;
            } catch (NoSuchFieldError e2) {
            }
            try {
                $SwitchMap$com$seedfinding$mccore$util$block$BlockRotation[BlockRotation.CLOCKWISE_90.ordinal()] = 3;
            } catch (NoSuchFieldError e3) {
            }
        }
    }

    public BlockRotation getRotated(BlockRotation rotation) {
        switch (C00471.$SwitchMap$com$seedfinding$mccore$util$block$BlockRotation[rotation.ordinal()]) {
            case 1:
                return this.direction.getOpposite().getRotation();
            case NBTType.SHORT:
                return this.direction.getCounterClockWise().getRotation();
            case 3:
                return this.direction.getClockWise().getRotation();
            default:
                return this;
        }
    }

    public BlockDirection rotate(BlockDirection direction) {
        if (direction.getAxis() == BlockDirection.Axis.Y) {
            return direction;
        }
        switch (C00471.$SwitchMap$com$seedfinding$mccore$util$block$BlockRotation[ordinal()]) {
            case 1:
                return direction.getOpposite();
            case NBTType.SHORT:
                return direction.getCounterClockWise();
            case 3:
                return direction.getClockWise();
            default:
                return direction;
        }
    }

    public BPos rotate(BPos origin, BPos pivot) {
        int px = pivot.getX();
        int pz = pivot.getZ();
        switch (C00471.$SwitchMap$com$seedfinding$mccore$util$block$BlockRotation[ordinal()]) {
            case 1:
                return new BPos((px + px) - origin.getX(), origin.getY(), (pz + pz) - origin.getZ());
            case NBTType.SHORT:
                return new BPos((px - pz) + origin.getZ(), origin.getY(), (px + pz) - origin.getX());
            case 3:
                return new BPos((px + pz) - origin.getZ(), origin.getY(), (pz - px) + origin.getX());
            default:
                return origin;
        }
    }

    public BPos getSize(BPos size) {
        switch (C00471.$SwitchMap$com$seedfinding$mccore$util$block$BlockRotation[ordinal()]) {
            case NBTType.SHORT:
            case 3:
                return new BPos(size.getZ(), size.getY(), size.getX());
            default:
                return size;
        }
    }

    public int rotate(int anchor, int referent) {
        switch (C00471.$SwitchMap$com$seedfinding$mccore$util$block$BlockRotation[ordinal()]) {
            case 1:
                return (anchor + (referent / 2)) % referent;
            case NBTType.SHORT:
                return (anchor + ((referent * 3) / 4)) % referent;
            case 3:
                return (anchor + (referent / 4)) % referent;
            default:
                return anchor;
        }
    }

    @Override
    public String toString() {
        return "Rotation{direction=" + this.direction + '}';
    }
}
