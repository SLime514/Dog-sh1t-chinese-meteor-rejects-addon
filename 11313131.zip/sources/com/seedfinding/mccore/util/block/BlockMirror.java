package com.seedfinding.mccore.util.block;

import com.seedfinding.mccore.nbt.NBTType;
import com.seedfinding.mccore.util.block.BlockDirection;
import com.seedfinding.mccore.util.math.Vec3i;
import com.seedfinding.mccore.util.pos.BPos;

public enum BlockMirror {
    NONE(new Vec3i(0, 0, 0)),
    LEFT_RIGHT(new Vec3i(0, 0, 1)),
    FRONT_BACK(new Vec3i(1, 0, 0));

    private final Vec3i orientation;

    BlockMirror(Vec3i orientation) {
        this.orientation = orientation;
    }

    public int mirror(int anchor, int referent) {
        int middlePoint = referent / 2;
        int offset = anchor > middlePoint ? anchor - referent : anchor;
        switch (C00461.$SwitchMap$com$seedfinding$mccore$util$block$BlockMirror[ordinal()]) {
            case 1:
                return (referent - offset) % referent;
            case NBTType.SHORT:
                return ((middlePoint - offset) + referent) % referent;
            default:
                return anchor;
        }
    }

    static class C00461 {
        static final int[] $SwitchMap$com$seedfinding$mccore$util$block$BlockMirror = new int[BlockMirror.values().length];

        static {
            try {
                $SwitchMap$com$seedfinding$mccore$util$block$BlockMirror[BlockMirror.FRONT_BACK.ordinal()] = 1;
            } catch (NoSuchFieldError e) {
            }
            try {
                $SwitchMap$com$seedfinding$mccore$util$block$BlockMirror[BlockMirror.LEFT_RIGHT.ordinal()] = 2;
            } catch (NoSuchFieldError e2) {
            }
        }
    }

    public BlockRotation getRotation(BlockDirection blockDirection) {
        BlockDirection.Axis axis = blockDirection.getAxis();
        return ((this == LEFT_RIGHT && axis == BlockDirection.Axis.Z) || (this == FRONT_BACK && axis == BlockDirection.Axis.X)) ? BlockRotation.CLOCKWISE_180 : BlockRotation.NONE;
    }

    public BlockDirection mirror(BlockDirection blockDirection) {
        if (this == FRONT_BACK && blockDirection.getAxis() == BlockDirection.Axis.X) {
            return blockDirection.getOpposite();
        }
        return (this == LEFT_RIGHT && blockDirection.getAxis() == BlockDirection.Axis.Z) ? blockDirection.getOpposite() : blockDirection;
    }

    public BPos mirror(BPos pos) {
        switch (C00461.$SwitchMap$com$seedfinding$mccore$util$block$BlockMirror[ordinal()]) {
            case 1:
                return new BPos(-pos.getX(), pos.getY(), pos.getZ());
            case NBTType.SHORT:
                return new BPos(pos.getX(), pos.getY(), -pos.getZ());
            default:
                return new BPos(pos.getX(), pos.getY(), pos.getZ());
        }
    }

    public Vec3i getOrientation() {
        return this.orientation;
    }

    @Override
    public String toString() {
        return "Mirror{orientation=" + this.orientation + '}';
    }
}
