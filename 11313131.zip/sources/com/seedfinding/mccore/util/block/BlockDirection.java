package com.seedfinding.mccore.util.block;

import com.seedfinding.mccore.nbt.NBTType;
import com.seedfinding.mccore.util.math.Vec3i;
import com.seedfinding.mcseed.rand.JRand;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public enum BlockDirection {
    DOWN(Axis.Y, new Vec3i(0, -1, 0)),
    UP(Axis.Y, new Vec3i(0, 1, 0)),
    NORTH(Axis.Z, new Vec3i(0, 0, -1)),
    SOUTH(Axis.Z, new Vec3i(0, 0, 1)),
    WEST(Axis.X, new Vec3i(-1, 0, 0)),
    EAST(Axis.X, new Vec3i(1, 0, 0));

    private final Axis axis;
    private final Vec3i vec;
    private static final BlockDirection[] HORIZONTALS = {NORTH, EAST, SOUTH, WEST};
    private static final BlockDirection[] BY_2D_DATA = {SOUTH, WEST, NORTH, EAST};
    private static final Map<String, BlockDirection> STRING_TO_BLOCK_DIRECTION = (Map) Arrays.stream(values()).collect(Collectors.toMap((v0) -> {
        return v0.name();
    }, o -> {
        return o;
    }));

    BlockDirection(Axis axis, Vec3i vec) {
        this.axis = axis;
        this.vec = vec;
    }

    public static BlockDirection fromString(String name) {
        return STRING_TO_BLOCK_DIRECTION.get(name.toUpperCase());
    }

    public static BlockDirection randomHorizontal(JRand rand) {
        return HORIZONTALS[rand.nextInt(HORIZONTALS.length)];
    }

    public static BlockDirection getRandom(JRand rand) {
        return values()[rand.nextInt(values().length)];
    }

    public static BlockDirection random2D(JRand rand) {
        return BY_2D_DATA[rand.nextInt(BY_2D_DATA.length)];
    }

    public static BlockDirection[] getHorizontal() {
        return HORIZONTALS;
    }

    public static BlockDirection[] get2d() {
        return BY_2D_DATA;
    }

    public static List<BlockDirection> getShuffled(JRand rand) {
        List<BlockDirection> list = Arrays.asList(values());
        JRand.shuffle(list, rand);
        return list;
    }

    public BlockDirection getClockWise() {
        return getDirection(EAST, WEST, NORTH, SOUTH);
    }

    public BlockDirection getCounterClockWise() {
        return getDirection(WEST, EAST, SOUTH, NORTH);
    }

    public BlockDirection getOpposite() {
        return getDirection(SOUTH, NORTH, EAST, WEST);
    }

    private BlockDirection getDirection(BlockDirection dir1, BlockDirection dir2, BlockDirection dir3, BlockDirection dir4) {
        switch (C00451.$SwitchMap$com$seedfinding$mccore$util$block$BlockDirection[ordinal()]) {
            case 1:
                return dir1;
            case NBTType.SHORT:
                return dir2;
            case 3:
                return dir3;
            case 4:
                return dir4;
            default:
                throw new IllegalStateException("Unable to get facing of " + this);
        }
    }

    public Axis getAxis() {
        return this.axis;
    }

    public Vec3i getVector() {
        return this.vec;
    }

    public BlockRotation getRotation() {
        switch (C00451.$SwitchMap$com$seedfinding$mccore$util$block$BlockDirection[ordinal()]) {
            case 1:
                return BlockRotation.NONE;
            case NBTType.SHORT:
                return BlockRotation.CLOCKWISE_180;
            case 3:
                return BlockRotation.COUNTERCLOCKWISE_90;
            case 4:
                return BlockRotation.CLOCKWISE_90;
            default:
                throw new IllegalStateException("Unable to get direction of " + this);
        }
    }

    @Override
    public String toString() {
        return "Direction{axis=" + this.axis + ", vec=" + this.vec + '}';
    }

    static class C00451 {
        static final int[] $SwitchMap$com$seedfinding$mccore$util$block$BlockDirection;
        static final int[] $SwitchMap$com$seedfinding$mccore$util$block$BlockDirection$Axis = new int[Axis.values().length];

        static {
            try {
                $SwitchMap$com$seedfinding$mccore$util$block$BlockDirection$Axis[Axis.X.ordinal()] = 1;
            } catch (NoSuchFieldError e) {
            }
            try {
                $SwitchMap$com$seedfinding$mccore$util$block$BlockDirection$Axis[Axis.Z.ordinal()] = 2;
            } catch (NoSuchFieldError e2) {
            }
            $SwitchMap$com$seedfinding$mccore$util$block$BlockDirection = new int[BlockDirection.values().length];
            try {
                $SwitchMap$com$seedfinding$mccore$util$block$BlockDirection[BlockDirection.NORTH.ordinal()] = 1;
            } catch (NoSuchFieldError e3) {
            }
            try {
                $SwitchMap$com$seedfinding$mccore$util$block$BlockDirection[BlockDirection.SOUTH.ordinal()] = 2;
            } catch (NoSuchFieldError e4) {
            }
            try {
                $SwitchMap$com$seedfinding$mccore$util$block$BlockDirection[BlockDirection.WEST.ordinal()] = 3;
            } catch (NoSuchFieldError e5) {
            }
            try {
                $SwitchMap$com$seedfinding$mccore$util$block$BlockDirection[BlockDirection.EAST.ordinal()] = 4;
            } catch (NoSuchFieldError e6) {
            }
        }
    }

    public enum Axis {
        X,
        Y,
        Z;

        public Axis get2DRotated() {
            switch (C00451.$SwitchMap$com$seedfinding$mccore$util$block$BlockDirection$Axis[ordinal()]) {
                case 1:
                    return Z;
                case NBTType.SHORT:
                    return X;
                default:
                    return Y;
            }
        }
    }
}
