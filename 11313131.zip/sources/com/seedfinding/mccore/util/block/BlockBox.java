package com.seedfinding.mccore.util.block;

import com.seedfinding.mccore.nbt.NBTType;
import com.seedfinding.mccore.util.math.Vec3i;
import com.seedfinding.mccore.util.pos.BPos;
import java.util.Objects;

public class BlockBox {
    public int minX;
    public int minY;
    public int minZ;
    public int maxX;
    public int maxY;
    public int maxZ;

    public BlockBox(int minX, int minY, int minZ, int maxX, int maxY, int maxZ) {
        this.minX = minX;
        this.minY = minY;
        this.minZ = minZ;
        this.maxX = maxX;
        this.maxY = maxY;
        this.maxZ = maxZ;
    }

    public BlockBox(int xMin, int zMin, int xMax, int zMax) {
        this.minX = xMin;
        this.minZ = zMin;
        this.maxX = xMax;
        this.maxZ = zMax;
        this.minY = 1;
        this.maxY = 512;
    }

    public BlockBox(Vec3i v1, Vec3i v2) {
        this.minX = Math.min(v1.getX(), v2.getX());
        this.minY = Math.min(v1.getY(), v2.getY());
        this.minZ = Math.min(v1.getZ(), v2.getZ());
        this.maxX = Math.max(v1.getX(), v2.getX());
        this.maxY = Math.max(v1.getY(), v2.getY());
        this.maxZ = Math.max(v1.getZ(), v2.getZ());
    }

    public static BlockBox empty() {
        return new BlockBox(Integer.MAX_VALUE, Integer.MAX_VALUE, Integer.MAX_VALUE, Integer.MIN_VALUE, Integer.MIN_VALUE, Integer.MIN_VALUE);
    }

    public static BlockBox rotated(int x, int y, int z, int offsetX, int offsetY, int offsetZ, int sizeX, int sizeY, int sizeZ, BlockRotation rotation) {
        switch (C00441.$SwitchMap$com$seedfinding$mccore$util$block$BlockRotation[rotation.ordinal()]) {
            case 1:
                return new BlockBox((x - sizeZ) + 1 + offsetZ, y + offsetY, z + offsetX, x + offsetZ, ((y + sizeY) - 1) + offsetY, ((z + sizeX) - 1) + offsetX);
            case NBTType.SHORT:
                return new BlockBox(x + offsetZ, y + offsetY, z + offsetX, ((x + sizeZ) - 1) + offsetZ, ((y + sizeY) - 1) + offsetY, ((z + sizeX) - 1) + offsetX);
            case 3:
                return new BlockBox(x + offsetX, y + offsetY, z + offsetZ, ((x + sizeX) - 1) + offsetX, ((y + sizeY) - 1) + offsetY, ((z + sizeZ) - 1) + offsetZ);
            case 4:
                return new BlockBox(x + offsetX, y + offsetY, (z - sizeZ) + 1 + offsetZ, ((x + sizeX) - 1) + offsetX, ((y + sizeY) - 1) + offsetY, z + offsetZ);
            default:
                return null;
        }
    }

    public static BlockBox getBoundingBox(BPos anchor, BlockRotation rotation, BPos pivot, BlockMirror mirror, BPos size) {
        BPos rotationSize = rotation.getSize(size);
        int pivotX = pivot.getX();
        int pivotZ = pivot.getZ();
        int sizedRotationX = rotationSize.getX() - 1;
        int sizedRotationY = rotationSize.getY() - 1;
        int sizedRotationZ = rotationSize.getZ() - 1;
        BlockBox blockBox = new BlockBox(0, 0, 0, 0, 0, 0);
        switch (C00441.$SwitchMap$com$seedfinding$mccore$util$block$BlockRotation[rotation.ordinal()]) {
            case 1:
                blockBox = new BlockBox(pivotX - pivotZ, 0, (pivotX + pivotZ) - sizedRotationZ, (pivotX - pivotZ) + sizedRotationX, sizedRotationY, pivotX + pivotZ);
                break;
            case NBTType.SHORT:
                blockBox = new BlockBox((pivotX + pivotZ) - sizedRotationX, 0, pivotZ - pivotX, pivotX + pivotZ, sizedRotationY, (pivotZ - pivotX) + sizedRotationZ);
                break;
            case 3:
                blockBox = new BlockBox((pivotX + pivotX) - sizedRotationX, 0, (pivotZ + pivotZ) - sizedRotationZ, pivotX + pivotX, sizedRotationY, pivotZ + pivotZ);
                break;
            case 4:
                blockBox = new BlockBox(0, 0, 0, sizedRotationX, sizedRotationY, sizedRotationZ);
                break;
        }
        switch (C00441.$SwitchMap$com$seedfinding$mccore$util$block$BlockMirror[mirror.ordinal()]) {
            case 1:
                blockBox = mirrorAABB(rotation, sizedRotationZ, sizedRotationX, blockBox, BlockDirection.NORTH, BlockDirection.SOUTH);
                break;
            case NBTType.SHORT:
                blockBox = mirrorAABB(rotation, sizedRotationX, sizedRotationZ, blockBox, BlockDirection.WEST, BlockDirection.EAST);
                break;
        }
        return blockBox.offset(anchor.getX(), anchor.getY(), anchor.getZ());
    }

    static class C00441 {
        static final int[] $SwitchMap$com$seedfinding$mccore$util$block$BlockRotation;
        static final int[] $SwitchMap$com$seedfinding$mccore$util$block$BlockMirror = new int[BlockMirror.values().length];

        static {
            try {
                $SwitchMap$com$seedfinding$mccore$util$block$BlockMirror[BlockMirror.LEFT_RIGHT.ordinal()] = 1;
            } catch (NoSuchFieldError e) {
            }
            try {
                $SwitchMap$com$seedfinding$mccore$util$block$BlockMirror[BlockMirror.FRONT_BACK.ordinal()] = 2;
            } catch (NoSuchFieldError e2) {
            }
            try {
                $SwitchMap$com$seedfinding$mccore$util$block$BlockMirror[BlockMirror.NONE.ordinal()] = 3;
            } catch (NoSuchFieldError e3) {
            }
            $SwitchMap$com$seedfinding$mccore$util$block$BlockRotation = new int[BlockRotation.values().length];
            try {
                $SwitchMap$com$seedfinding$mccore$util$block$BlockRotation[BlockRotation.COUNTERCLOCKWISE_90.ordinal()] = 1;
            } catch (NoSuchFieldError e4) {
            }
            try {
                $SwitchMap$com$seedfinding$mccore$util$block$BlockRotation[BlockRotation.CLOCKWISE_90.ordinal()] = 2;
            } catch (NoSuchFieldError e5) {
            }
            try {
                $SwitchMap$com$seedfinding$mccore$util$block$BlockRotation[BlockRotation.CLOCKWISE_180.ordinal()] = 3;
            } catch (NoSuchFieldError e6) {
            }
            try {
                $SwitchMap$com$seedfinding$mccore$util$block$BlockRotation[BlockRotation.NONE.ordinal()] = 4;
            } catch (NoSuchFieldError e7) {
            }
        }
    }

    private static BlockBox mirrorAABB(BlockRotation rotation, int x, int z, BlockBox blockBox, BlockDirection blockDirection, BlockDirection blockDirection1) {
        BPos moveAmount;
        BPos moveAmount2 = BPos.ORIGIN;
        if (rotation != BlockRotation.CLOCKWISE_90 && rotation != BlockRotation.COUNTERCLOCKWISE_90) {
            if (rotation == BlockRotation.CLOCKWISE_180) {
                moveAmount = moveAmount2.relative(blockDirection1, x);
            } else {
                moveAmount = moveAmount2.relative(blockDirection, x);
            }
        } else {
            moveAmount = moveAmount2.relative(rotation.rotate(blockDirection), z);
        }
        return blockBox.offset(moveAmount.getX(), 0, moveAmount.getZ());
    }

    public BlockBox offset(int x, int y, int z) {
        return new BlockBox(this.minX + x, this.minY + y, this.minZ + z, this.maxX + x, this.maxY + y, this.maxZ + z);
    }

    public void move(int x, int y, int z) {
        this.minX += x;
        this.minY += y;
        this.minZ += z;
        this.maxX += x;
        this.maxY += y;
        this.maxZ += z;
    }

    public BPos getInside(BPos offset, BlockRotation rotation) {
        switch (C00441.$SwitchMap$com$seedfinding$mccore$util$block$BlockRotation[rotation.ordinal()]) {
            case 1:
                return new BPos(this.minX + offset.getZ(), this.minY + offset.getY(), this.minZ - offset.getX());
            case NBTType.SHORT:
                return new BPos(this.minX - offset.getZ(), this.minY + offset.getY(), this.minZ + offset.getX());
            case 3:
                return new BPos(this.minX - offset.getX(), this.minY + offset.getY(), this.minZ - offset.getZ());
            case 4:
                return new BPos(this.minX + offset.getX(), this.minY + offset.getY(), this.minZ + offset.getZ());
            default:
                return null;
        }
    }

    public BlockBox getRotated(BlockRotation rotation) {
        switch (C00441.$SwitchMap$com$seedfinding$mccore$util$block$BlockRotation[rotation.ordinal()]) {
            case 1:
                return new BlockBox(this.minX, this.minY, this.maxZ, this.maxX, this.maxY, this.minZ);
            case NBTType.SHORT:
                return new BlockBox(this.maxX, this.minY, this.minZ, this.minX, this.maxY, this.maxZ);
            case 3:
                return new BlockBox(this.maxX, this.minY, this.maxZ, this.minX, this.maxY, this.minZ);
            case 4:
                return this;
            default:
                return null;
        }
    }

    public boolean intersects(BlockBox box) {
        return this.maxX >= box.minX && this.minX <= box.maxX && this.maxZ >= box.minZ && this.minZ <= box.maxZ && this.maxY >= box.minY && this.minY <= box.maxY;
    }

    public boolean intersectsXZ(int minX, int minZ, int maxX, int maxZ) {
        return this.maxX >= minX && this.minX <= maxX && this.maxZ >= minZ && this.minZ <= maxZ;
    }

    public boolean contains(Vec3i v) {
        return v.getX() >= this.minX && v.getX() <= this.maxX && v.getZ() >= this.minZ && v.getZ() <= this.maxZ && v.getY() >= this.minY && v.getY() <= this.maxY;
    }

    public Vec3i getDimensions() {
        return new Vec3i(this.maxX - this.minX, this.maxY - this.minY, this.maxZ - this.minZ);
    }

    public void encompass(BlockBox box) {
        this.minX = Math.min(this.minX, box.minX);
        this.minY = Math.min(this.minY, box.minY);
        this.minZ = Math.min(this.minZ, box.minZ);
        this.maxX = Math.max(this.maxX, box.maxX);
        this.maxY = Math.max(this.maxY, box.maxY);
        this.maxZ = Math.max(this.maxZ, box.maxZ);
    }

    public int getXSpan() {
        return (this.maxX - this.minX) + 1;
    }

    public int getYSpan() {
        return (this.maxY - this.minY) + 1;
    }

    public int getZSpan() {
        return (this.maxZ - this.minZ) + 1;
    }

    public Vec3i getCenter() {
        return new Vec3i(this.minX + (getXSpan() / 2), this.minY + (getYSpan() / 2), this.minZ + (getZSpan() / 2));
    }

    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof BlockBox)) {
            return false;
        }
        BlockBox blockBox = (BlockBox) o;
        return this.minX == blockBox.minX && this.minY == blockBox.minY && this.minZ == blockBox.minZ && this.maxX == blockBox.maxX && this.maxY == blockBox.maxY && this.maxZ == blockBox.maxZ;
    }

    public int hashCode() {
        return Objects.hash(Integer.valueOf(this.minX), Integer.valueOf(this.minY), Integer.valueOf(this.minZ), Integer.valueOf(this.maxX), Integer.valueOf(this.maxY), Integer.valueOf(this.maxZ));
    }

    public String toString() {
        return "BlockBox{minX=" + this.minX + ", minY=" + this.minY + ", minZ=" + this.minZ + ", maxX=" + this.maxX + ", maxY=" + this.maxY + ", maxZ=" + this.maxZ + '}';
    }
}
