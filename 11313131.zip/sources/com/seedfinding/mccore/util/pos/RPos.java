package com.seedfinding.mccore.util.pos;

import com.seedfinding.mccore.util.data.SpiralIterator;
import com.seedfinding.mccore.util.math.Vec3i;

public class RPos extends Vec3i {
    private final int regionSize;

    public RPos(int x, int z, int regionSize) {
        super(x, 0, z);
        this.regionSize = regionSize;
    }

    public RPos add(CPos pos) {
        return add(pos.getX(), pos.getZ());
    }

    public RPos subtract(CPos pos) {
        return subtract(pos.getX(), pos.getZ());
    }

    public RPos shl(int amount) {
        return shl(amount, amount);
    }

    public RPos shr(int amount) {
        return shr(amount, amount);
    }

    public RPos add(int x, int z) {
        return new RPos(getX() + x, getZ() + z, this.regionSize);
    }

    public RPos subtract(int x, int z) {
        return new RPos(getX() - x, getZ() - z, this.regionSize);
    }

    public RPos shl(int bx, int bz) {
        return new RPos(getX() << bx, getZ() << bz, this.regionSize);
    }

    public RPos shr(int bx, int bz) {
        return new RPos(getX() >> bx, getZ() >> bz, this.regionSize);
    }

    public RPos changeRegionSize(int regionSize) {
        int x = getX() * this.regionSize;
        int x2 = x < 0 ? (x - regionSize) + 1 : x;
        int z = getZ() * this.regionSize;
        return new RPos(x2 / regionSize, (z < 0 ? (z - regionSize) + 1 : z) / regionSize, regionSize);
    }

    public int getRegionSize() {
        return this.regionSize;
    }

    public BPos toBlockPos() {
        return new BPos(getX() * getRegionSize(), 0, getZ() * getRegionSize());
    }

    public CPos toChunkPos() {
        return new CPos(getX() * getRegionSize(), getZ() * getRegionSize());
    }

    @FunctionalInterface
    public interface Builder {
        RPos create(int i, int i2);

        static SpiralIterator.Builder<RPos> create(int regionSize) {
            return (x, y, z) -> {
                return new RPos(x, z, regionSize);
            };
        }
    }
}
