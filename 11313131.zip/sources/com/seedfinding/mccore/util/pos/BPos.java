package com.seedfinding.mccore.util.pos;

import com.seedfinding.mccore.util.block.BlockDirection;
import com.seedfinding.mccore.util.block.BlockMirror;
import com.seedfinding.mccore.util.block.BlockRotation;
import com.seedfinding.mccore.util.math.Vec3i;

public class BPos extends Vec3i {
    public static final BPos ORIGIN = new BPos(0, 0, 0);

    public BPos(int x, int y, int z) {
        super(x, y, z);
    }

    public BPos(Vec3i vec3i) {
        super(vec3i.getX(), vec3i.getY(), vec3i.getZ());
    }

    public BPos add(BPos pos) {
        return add(pos.getX(), pos.getY(), pos.getZ());
    }

    public BPos subtract(BPos pos) {
        return subtract(pos.getX(), pos.getY(), pos.getZ());
    }

    public BPos shl(int amount) {
        return shl(amount, amount, amount);
    }

    public BPos shr(int amount) {
        return shr(amount, amount, amount);
    }

    public BPos add(int x, int y, int z) {
        return new BPos(getX() + x, getY() + y, getZ() + z);
    }

    public BPos subtract(int x, int y, int z) {
        return new BPos(getX() - x, getY() - y, getZ() - z);
    }

    public BPos shl(int bx, int by, int bz) {
        return new BPos(getX() << bx, getY() << by, getZ() << bz);
    }

    public BPos shr(int bx, int by, int bz) {
        return new BPos(getX() >> bx, getY() >> by, getZ() >> bz);
    }

    public BPos toChunkCorner() {
        return new BPos(getX() & (-16), getY(), getZ() & (-16));
    }

    public CPos toChunkPos() {
        return new CPos(getX() >> 4, getZ() >> 4);
    }

    public BPos relative(BlockDirection direction) {
        return new BPos(getX() + direction.getVector().getX(), getY() + direction.getVector().getY(), getZ() + direction.getVector().getZ());
    }

    public BPos relative(BlockDirection direction, int offset) {
        return offset == 0 ? this : new BPos(getX() + (direction.getVector().getX() * offset), getY() + (direction.getVector().getY() * offset), getZ() + (direction.getVector().getZ() * offset));
    }

    public BPos relative(BlockDirection.Axis axis, int offset) {
        if (offset == 0) {
            return this;
        }
        int i = axis == BlockDirection.Axis.X ? offset : 0;
        int j = axis == BlockDirection.Axis.Y ? offset : 0;
        int k = axis == BlockDirection.Axis.Z ? offset : 0;
        return new BPos(getX() + i, getY() + j, getZ() + k);
    }

    public RPos toRegionPos(int regionSize) {
        int x = getX() < 0 ? (getX() - regionSize) + 1 : getX();
        int z = getZ() < 0 ? (getZ() - regionSize) + 1 : getZ();
        return new RPos(x / regionSize, z / regionSize, regionSize);
    }

    public BPos transform(BlockMirror mirror, BlockRotation rotation, BPos pivot) {
        return rotation.rotate(mirror.mirror(this), pivot);
    }
}
