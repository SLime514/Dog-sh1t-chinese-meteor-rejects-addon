package com.seedfinding.mccore.util.pos;

import com.seedfinding.mccore.util.math.Vec3i;

public class CPos extends Vec3i {
    public CPos(int x, int z) {
        super(x, 0, z);
    }

    public CPos(Vec3i vec3i) {
        super(vec3i.getX(), vec3i.getY(), vec3i.getZ());
    }

    public CPos add(CPos pos) {
        return add(pos.getX(), pos.getZ());
    }

    public CPos subtract(CPos pos) {
        return subtract(pos.getX(), pos.getZ());
    }

    public CPos shl(int amount) {
        return shl(amount, amount);
    }

    public CPos shr(int amount) {
        return shr(amount, amount);
    }

    public CPos add(int x, int z) {
        return new CPos(getX() + x, getZ() + z);
    }

    public CPos subtract(int x, int z) {
        return new CPos(getX() - x, getZ() - z);
    }

    public CPos shl(int bx, int bz) {
        return new CPos(getX() << bx, getZ() << bz);
    }

    public CPos shr(int bx, int bz) {
        return new CPos(getX() >> bx, getZ() >> bz);
    }

    public BPos toBlockPos() {
        return toBlockPos(0);
    }

    public BPos toBlockPos(int y) {
        return new BPos(getX() << 4, y, getZ() << 4);
    }

    public RPos toRegionPos(int regionSize) {
        int x = getX() < 0 ? (getX() - regionSize) + 1 : getX();
        int z = getZ() < 0 ? (getZ() - regionSize) + 1 : getZ();
        return new RPos(x / regionSize, z / regionSize, regionSize);
    }

    @FunctionalInterface
    public interface Builder {
        CPos create(int i, int i2);

        static CPos create(int x, int y, int z) {
            return new CPos(x, z);
        }
    }
}
