package com.seedfinding.mccore.nbt;

import com.seedfinding.mccore.nbt.tag.NBTByte;
import com.seedfinding.mccore.nbt.tag.NBTByteArray;
import com.seedfinding.mccore.nbt.tag.NBTCompound;
import com.seedfinding.mccore.nbt.tag.NBTDouble;
import com.seedfinding.mccore.nbt.tag.NBTEnd;
import com.seedfinding.mccore.nbt.tag.NBTFloat;
import com.seedfinding.mccore.nbt.tag.NBTInt;
import com.seedfinding.mccore.nbt.tag.NBTIntArray;
import com.seedfinding.mccore.nbt.tag.NBTList;
import com.seedfinding.mccore.nbt.tag.NBTLong;
import com.seedfinding.mccore.nbt.tag.NBTLongArray;
import com.seedfinding.mccore.nbt.tag.NBTShort;
import com.seedfinding.mccore.nbt.tag.NBTString;
import com.seedfinding.mccore.nbt.tag.NBTTag;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Supplier;

public class NBTType {
    public static final byte END = 0;
    public static final byte BYTE = 1;
    public static final byte SHORT = 2;
    public static final byte INT = 3;
    public static final byte LONG = 4;
    public static final byte FLOAT = 5;
    public static final byte DOUBLE = 6;
    public static final byte BYTE_ARRAY = 7;
    public static final byte STRING = 8;
    public static final byte LIST = 9;
    public static final byte COMPOUND = 10;
    public static final byte INT_ARRAY = 11;
    public static final byte LONG_ARRAY = 12;
    public static final Map<Byte, Supplier<? extends NBTTag<?>>> REGISTRY = new HashMap();
    private static final Map<Class<? extends NBTTag<?>>, Byte> TYPE_REGISTRY = new HashMap();

    static {
        register(NBTEnd.class, 0, NBTEnd::new);
        register(NBTByte.class, 1, NBTByte::new);
        register(NBTShort.class, 2, NBTShort::new);
        register(NBTInt.class, 3, NBTInt::new);
        register(NBTLong.class, 4, NBTLong::new);
        register(NBTFloat.class, 5, NBTFloat::new);
        register(NBTDouble.class, 6, NBTDouble::new);
        register(NBTByteArray.class, 7, NBTByteArray::new);
        register(NBTString.class, 8, NBTString::new);
        register(NBTList.class, 9, NBTList::new);
        register(NBTCompound.class, 10, NBTCompound::new);
        register(NBTIntArray.class, 11, NBTIntArray::new);
        register(NBTLongArray.class, 12, NBTLongArray::new);
    }

    public static <T extends NBTTag<?>> void register(Class<T> tagClass, int type, Supplier<T> supplier) {
        if (REGISTRY.containsKey(Byte.valueOf((byte) type))) {
            throw new RuntimeException("Type " + type + " is already taken");
        }
        REGISTRY.put(Byte.valueOf((byte) type), supplier);
        TYPE_REGISTRY.put(tagClass, Byte.valueOf((byte) type));
    }

    public static byte getTypeOf(Class<? extends NBTTag<?>> tagClass) {
        return TYPE_REGISTRY.getOrDefault(tagClass, (byte) -1).byteValue();
    }

    public static NBTTag<?> createEmpty(byte type) {
        Supplier<? extends NBTTag<?>> supplier = REGISTRY.get(Byte.valueOf(type));
        if (supplier == null) {
            throw new RuntimeException("Deserializing unregistered tag of type " + ((int) type));
        }
        return supplier.get();
    }
}
