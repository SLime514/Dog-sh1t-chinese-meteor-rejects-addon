package com.seedfinding.mccore.nbt.tag;

import com.seedfinding.mccore.net.ByteBuffer;
import java.io.IOException;
import java.nio.ByteOrder;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class NBTIntArray extends NBTTag<int[]> {
    public static final NBTIntArray NULL = new NBTIntArray() {
        @Override
        public void readPayload(ByteBuffer buffer) {
            throw new NullPointerException();
        }

        @Override
        public void writePayload(ByteBuffer buffer) {
            throw new NullPointerException();
        }
    };

    public NBTIntArray() {
        this(0);
    }

    public NBTIntArray(int length) {
        this(new int[length]);
    }

    public NBTIntArray(int[] value) {
        super(value);
    }

    public int[] copyValue() {
        return (int[]) ((int[]) super.getValue()).clone();
    }

    public Stream<Integer> stream() {
        return Arrays.stream(getValue()).boxed();
    }

    public Integer[] toBoxed() {
        return (Integer[]) stream().toArray(x$0 -> {
            return new Integer[x$0];
        });
    }

    public List<Integer> toList() {
        return (List) stream().collect(Collectors.toList());
    }

    @Override
    public void readPayload(ByteBuffer buffer) throws IOException {
        setValue(new int[buffer.readInt(ByteOrder.BIG_ENDIAN)]);
        for (int i = 0; i < getValue().length; i++) {
            getValue()[i] = buffer.readInt(ByteOrder.BIG_ENDIAN);
        }
    }

    @Override
    public void writePayload(ByteBuffer buffer) throws IOException {
        buffer.writeInt(getValue().length, ByteOrder.BIG_ENDIAN);
        for (int v : getValue()) {
            buffer.writeInt(v, ByteOrder.BIG_ENDIAN);
        }
    }
}
