package com.seedfinding.mccore.nbt.tag;

import com.seedfinding.mccore.nbt.NBTType;
import com.seedfinding.mccore.net.ByteBuffer;
import java.io.IOException;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class NBTList extends NBTTag<List<NBTTag<?>>> {
    public static final NBTList NULL = new NBTList() {
        @Override
        public void readPayload(ByteBuffer buffer) {
            throw new NullPointerException();
        }

        @Override
        public void writePayload(ByteBuffer buffer) {
            throw new NullPointerException();
        }
    };
    private byte elementType;

    public NBTList() {
        this((byte) 0);
    }

    public NBTList(byte elementType) {
        this(elementType, ArrayList::new);
    }

    public NBTList(byte elementType, Supplier<List<NBTTag<?>>> supplier) {
        super(supplier.get());
        this.elementType = elementType;
    }

    public final byte getElementType() {
        return this.elementType;
    }

    @Override
    public void readPayload(ByteBuffer buffer) throws IOException {
        this.elementType = buffer.readByte();
        int length = buffer.readInt(ByteOrder.BIG_ENDIAN);
        if (this.elementType == 0 && length > 0) {
            throw new RuntimeException("List of length " + length + " with no type");
        }
        for (int i = 0; i < length; i++) {
            NBTTag<?> nbt = NBTType.createEmpty(this.elementType);
            nbt.readPayload(buffer);
            getValue().add(nbt);
        }
    }

    @Override
    public void writePayload(ByteBuffer buffer) throws IOException {
        buffer.writeByte(this.elementType);
        buffer.writeInt(getValue().size(), ByteOrder.BIG_ENDIAN);
        for (NBTTag<?> element : getValue()) {
            element.writePayload(buffer);
        }
    }

    public NBTList run(Consumer<NBTList> action) {
        action.accept(this);
        return this;
    }

    public boolean isEmpty() {
        return size() == 0;
    }

    public int size() {
        return getValue().size();
    }

    public NBTList add(NBTTag<?> tag) {
        if (tag != null) {
            if (tag.getType() != this.elementType) {
                throw new RuntimeException("Invalid tag of type " + ((int) tag.getType()) + " for list of type " + ((int) this.elementType));
            }
            getValue().add(tag);
        }
        return this;
    }

    public boolean contains(Object value) {
        Stream map = ((List) super.getValue()).stream().map((v0) -> {
            return v0.getValue();
        });
        Objects.requireNonNull(value);
        return map.anyMatch(value::equals);
    }

    public NBTTag<?> get(int i) {
        return getValue().get(i);
    }

    public <T extends NBTTag<?>> T get(int i, Class<T> tagClass) {
        T t = (T) getValue().get(i);
        if (tagClass.isAssignableFrom(t.getClass())) {
            return t;
        }
        return null;
    }

    public Object getElement(int i) {
        return getValue().get(i).getValue();
    }

    public <T> T getElement(int i, Class<T> cls) {
        NBTTag<?> nBTTag = getValue().get(i);
        if (cls.isAssignableFrom(nBTTag.getValue().getClass())) {
            return (T) nBTTag.getValue();
        }
        return null;
    }

    public <T extends NBTTag<?>> List<T> getValue(Class<T> tagClass) {
        return (List) IntStream.range(0, size()).mapToObj(i -> {
            return get(i, tagClass);
        }).filter((v0) -> {
            return Objects.nonNull(v0);
        }).collect(Collectors.toList());
    }

    public List<Object> getElements() {
        return (List) IntStream.range(0, size()).mapToObj(this::getElement).collect(Collectors.toList());
    }

    public <T> List<T> getElements(Class<T> elementClass) {
        return (List) IntStream.range(0, size()).mapToObj(i -> {
            return getElement(i, elementClass);
        }).filter(Objects::nonNull).collect(Collectors.toList());
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("[");
        Iterator<NBTTag<?>> it = getValue().iterator();
        while (it.hasNext()) {
            sb.append(it.next());
            sb.append(it.hasNext() ? ", " : "");
        }
        return sb.append("]").toString();
    }
}
