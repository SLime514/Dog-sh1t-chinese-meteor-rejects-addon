package com.seedfinding.mccore.nbt.tag;

import com.seedfinding.mccore.net.ByteBuffer;
import java.io.IOException;
import java.nio.ByteOrder;

public class NBTDouble extends NBTTag<Double> {
    public static final NBTDouble NULL = new NBTDouble() {
        @Override
        public void readPayload(ByteBuffer buffer) {
            throw new NullPointerException();
        }

        @Override
        public void writePayload(ByteBuffer buffer) {
            throw new NullPointerException();
        }
    };

    public NBTDouble() {
        this(0.0d);
    }

    public NBTDouble(double value) {
        super(Double.valueOf(value));
    }

    @Override
    public void readPayload(ByteBuffer buffer) throws IOException {
        setValue(Double.valueOf(buffer.readDouble(ByteOrder.BIG_ENDIAN)));
    }

    @Override
    public void writePayload(ByteBuffer buffer) throws IOException {
        buffer.writeDouble(getValue().doubleValue(), ByteOrder.BIG_ENDIAN);
    }
}
