package com.seedfinding.mccore.nbt.tag;

import com.seedfinding.mccore.nbt.NBTType;
import com.seedfinding.mccore.net.ByteBuffer;
import com.seedfinding.mccore.net.IByteSerializable;
import java.io.IOException;
import java.nio.ByteOrder;
import java.util.Objects;

public abstract class NBTTag<T> implements IByteSerializable {
    private String name = "";
    private T value;

    public abstract void readPayload(ByteBuffer byteBuffer) throws IOException;

    public abstract void writePayload(ByteBuffer byteBuffer) throws IOException;

    public NBTTag(T value) {
        setValue(value);
    }

    public static NBTTag<?> create(ByteBuffer buffer) throws IOException {
        NBTTag<?> tag = NBTType.createEmpty(buffer.readByte());
        tag.read(buffer);
        return tag;
    }

    public final String getName() {
        return this.name;
    }

    public T getValue() {
        return this.value;
    }

    public NBTTag<?> setValue(T value) {
        this.value = value;
        return this;
    }

    public final byte getType() {
        return NBTType.getTypeOf(getClass());
    }

    @Override
    public void read(ByteBuffer buffer) throws IOException {
        this.name = buffer.readASCII(ByteOrder.BIG_ENDIAN);
        readPayload(buffer);
    }

    @Override
    public void write(ByteBuffer buffer) throws IOException {
        if (getType() < 0) {
            throw new RuntimeException("Serializing unregistered tag " + getClass());
        }
        writePayload(buffer.writeByte(getType()).writeASCII(this.name, ByteOrder.BIG_ENDIAN));
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof NBTTag)) {
            return false;
        }
        NBTTag<?> that = (NBTTag) other;
        return getType() == that.getType() && getValue().equals(that.getValue());
    }

    public int hashCode() {
        return Objects.hash(getName(), getValue());
    }

    public String toString() {
        return this.value.toString();
    }
}
