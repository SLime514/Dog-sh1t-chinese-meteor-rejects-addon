package com.seedfinding.mccore.nbt.tag;

import com.seedfinding.mccore.net.ByteBuffer;
import java.io.IOException;
import java.nio.ByteOrder;

public class NBTLong extends NBTTag<Long> {
    public static final NBTLong NULL = new NBTLong() {
        @Override
        public void readPayload(ByteBuffer buffer) {
            throw new NullPointerException();
        }

        @Override
        public void writePayload(ByteBuffer buffer) {
            throw new NullPointerException();
        }
    };

    public NBTLong() {
        this(0L);
    }

    public NBTLong(long value) {
        super(Long.valueOf(value));
    }

    @Override
    public void readPayload(ByteBuffer buffer) throws IOException {
        setValue(Long.valueOf(buffer.readLong(ByteOrder.BIG_ENDIAN)));
    }

    @Override
    public void writePayload(ByteBuffer buffer) throws IOException {
        buffer.writeLong(getValue().longValue(), ByteOrder.BIG_ENDIAN);
    }
}
