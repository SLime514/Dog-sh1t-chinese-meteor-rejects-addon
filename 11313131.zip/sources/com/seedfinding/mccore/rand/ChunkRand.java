package com.seedfinding.mccore.rand;

import com.seedfinding.mccore.rand.seed.PositionSeed;
import com.seedfinding.mccore.rand.seed.RegionSeed;
import com.seedfinding.mccore.util.pos.BPos;
import com.seedfinding.mccore.version.MCVersion;
import com.seedfinding.mccore.version.UnsupportedVersion;
import com.seedfinding.mcmath.util.Mth;
import com.seedfinding.mcseed.lcg.LCG;
import com.seedfinding.mcseed.rand.JRand;
import java.util.Collection;

public class ChunkRand extends JRand {
    public ChunkRand() {
        super(0L, false);
    }

    public ChunkRand(long seed) {
        super(seed);
    }

    public ChunkRand(long seed, boolean scramble) {
        super(seed, scramble);
    }

    public Debugger asChunkRandDebugger() {
        return new Debugger(this);
    }

    public long setTerrainSeed(int chunkX, int chunkZ, MCVersion version) {
        long seed = (chunkX * RegionSeed.f35A) + (chunkZ * RegionSeed.f36B);
        setSeed(seed);
        return seed & Mth.MASK_48;
    }

    public long setPopulationSeed(long worldSeed, int x, int z, MCVersion version) {
        long a;
        long b;
        setSeed(worldSeed);
        if (version.isOlderThan(MCVersion.v1_13)) {
            a = ((nextLong() / 2) * 2) + 1;
            b = ((nextLong() / 2) * 2) + 1;
        } else {
            a = nextLong() | 1;
            b = nextLong() | 1;
        }
        long seed = ((x * a) + (z * b)) ^ worldSeed;
        setSeed(seed);
        return seed & Mth.MASK_48;
    }

    public long setDecoratorSeed(long populationSeed, int index, int step, MCVersion version) {
        return setDecoratorSeed(populationSeed, index + (10000 * step), version);
    }

    public long setDecoratorSeed(long populationSeed, int salt, MCVersion version) {
        if (version.isOlderThan(MCVersion.v1_13)) {
            throw new UnsupportedVersion(version, "decorator seed");
        }
        long seed = populationSeed + salt;
        setSeed(seed);
        return seed & Mth.MASK_48;
    }

    public long setDecoratorSeed(long worldSeed, int blockX, int blockZ, int index, int step, MCVersion version) {
        long populationSeed = setPopulationSeed(worldSeed, blockX, blockZ, version);
        return setDecoratorSeed(populationSeed, index, step, version);
    }

    public long setDecoratorSeed(long worldSeed, int blockX, int blockZ, int salt, MCVersion version) {
        long populationSeed = setPopulationSeed(worldSeed, blockX, blockZ, version);
        return setDecoratorSeed(populationSeed, salt, version);
    }

    public long setCarverSeed(long worldSeed, int chunkX, int chunkZ, MCVersion version) {
        setSeed(worldSeed);
        long a = nextLong();
        long b = nextLong();
        long seed = ((chunkX * a) ^ (chunkZ * b)) ^ worldSeed;
        setSeed(seed);
        return seed & Mth.MASK_48;
    }

    public long setRegionSeed(long worldSeed, int regionX, int regionZ, int salt, MCVersion version) {
        long seed = (regionX * RegionSeed.f35A) + (regionZ * RegionSeed.f36B) + worldSeed + salt;
        setSeed(seed);
        return seed & Mth.MASK_48;
    }

    public long setWeakSeed(long worldSeed, int chunkX, int chunkZ, MCVersion version) {
        int sX = chunkX >> 4;
        int sZ = chunkZ >> 4;
        long seed = (sX ^ (sZ << 4)) ^ worldSeed;
        setSeed(seed);
        return seed & Mth.MASK_48;
    }

    public long setSlimeSeed(long worldSeed, int chunkX, int chunkZ, long scrambler, MCVersion version) {
        long seed = ((((worldSeed + ((chunkX * chunkX) * 4987142)) + (chunkX * 5947611)) + ((chunkZ * chunkZ) * 4392871)) + (chunkZ * 389711)) ^ scrambler;
        setSeed(seed);
        return seed & Mth.MASK_48;
    }

    public long setSlimeSeed(long worldSeed, int chunkX, int chunkZ, MCVersion version) {
        return setSlimeSeed(worldSeed, chunkX, chunkZ, 987234911L, version);
    }

    public long setPositionSeed(int x, int y, int z, MCVersion version) {
        long seed = PositionSeed.getPositionSeed(x, y, z);
        setSeed(seed);
        return seed & Mth.MASK_48;
    }

    public long setPositionSeed(BPos pos, MCVersion version) {
        return setPositionSeed(pos.getX(), pos.getY(), pos.getZ(), version);
    }

    public long setBaseStoneSeed(long worldSeed, int x, int y, int z) {
        setSeed(worldSeed);
        long a = nextLong();
        long b = nextLong();
        nextLong();
        long seed = (((x * a) ^ (y * b)) ^ (z * z)) ^ worldSeed;
        setSeed(seed);
        return seed;
    }

    public <T> T getRandom(Collection<T> collection) {
        return (T) getRandom(collection.toArray(), this);
    }

    public <T> T getRandom(T[] tArr) {
        return (T) getRandom(tArr, this);
    }

    public static <T> T getRandom(T[] list, ChunkRand rand) {
        return list[rand.nextInt(list.length)];
    }

    public int getInt(int minimum, int maximum) {
        return getInt(this, minimum, maximum);
    }

    public static int getInt(ChunkRand rand, int minimum, int maximum) {
        return minimum >= maximum ? minimum : rand.nextInt((maximum - minimum) + 1) + minimum;
    }

    public static final class Debugger extends ChunkRand {
        public JRand.Debugger debugger;

        public Debugger(JRand delegate) {
            this.debugger = delegate.asDebugger();
        }

        @Override
        public long nextSeed() {
            return this.debugger.nextSeed();
        }

        @Override
        public void advance(long calls) {
            this.debugger.advance(calls);
        }

        @Override
        public int nextInt(int bound) {
            return this.debugger.nextInt(bound);
        }

        @Override
        public int next(int bits) {
            return this.debugger.next(bits);
        }

        @Override
        public void advance(LCG lcg) {
            this.debugger.advance(lcg);
        }

        @Override
        public long getSeed() {
            return this.debugger.getSeed();
        }

        @Override
        public void setSeed(long seed) {
            this.debugger.setSeed(seed);
        }

        public long getGlobalCounter() {
            return this.debugger.getGlobalCounter();
        }

        public long getNextIntSkip() {
            return this.debugger.getNextIntSkip();
        }
    }
}
