package com.seedfinding.mccore.rand.seed;

import com.seedfinding.mcmath.util.Mth;
import com.seedfinding.mcseed.lcg.LCG;

public class SeedMixer {

    public static final long f37A = LCG.MMIX.multiplier;

    public static final long f38B = LCG.MMIX.addend;
    public static final long MAGIC = (-f38B) * Mth.modInverse(f37A);
    public final long salt;
    public final int steps;

    public SeedMixer(long salt) {
        this(salt, 1);
    }

    protected SeedMixer(long salt, int steps) {
        this.salt = salt;
        this.steps = steps;
    }

    public static long getOtherSolution(long seed) {
        return MAGIC - seed;
    }

    public static long mixSeed(long seed, long salt) {
        return (seed * ((seed * f37A) + f38B)) + salt;
    }

    public static long unmixSeed(long seed, long salt, Solution solution) {
        if (((seed - salt) & 1) == 1) {
            throw new UnsupportedOperationException("Seed " + seed + " is unreachable with salt " + salt);
        }
        long r = solution.ordinal();
        int i = 1;
        while (true) {
            int j = i;
            if (j < 64) {
                r -= (((((f37A * r) * r) + (f38B * r)) + salt) - seed) * Mth.modInverse(((2 * f37A) * r) + f38B, 64);
                i = j << 1;
            } else {
                return r;
            }
        }
    }

    public long nextSeed(long seed) {
        if (this.steps >= 0) {
            for (int i = 0; i < this.steps; i++) {
                seed = mixSeed(seed, this.salt);
            }
        } else {
            for (int i2 = 0; i2 < (-this.steps); i2++) {
                seed = unmixSeed(seed, this.salt, Solution.EVEN);
            }
        }
        return seed;
    }

    public SeedMixer combine(int steps) {
        return new SeedMixer(this.salt, steps);
    }

    public enum Solution {
        EVEN,
        ODD;

        public static Solution m9of(long n) {
            return values()[(int) (n & 1)];
        }
    }
}
