package com.seedfinding.mccore.rand.seed;

public final class RegionSeed {

    public static final long f35A = 341873128712L;

    public static final long f36B = 132897987541L;

    public static long getIncrement(int dRegionX, int dRegionZ) {
        return (f35A * dRegionX) + (f36B * dRegionZ);
    }

    public static long toWorldSeed(long regionSeed, int regionX, int regionZ, int salt) {
        return translate(regionSeed, regionX, regionZ) - salt;
    }

    public static long translate(long regionSeed, int dRegionX, int dRegionZ) {
        return regionSeed - getIncrement(dRegionX, dRegionZ);
    }

    public static long getNeighbor(long regionSeed, int dRegionX, int dRegionZ) {
        return regionSeed + getIncrement(dRegionX, dRegionZ);
    }

    public static boolean areNeighbors(long regionSeed1, long regionSeed2, int dRegionX, int dRegionZ) {
        return areNeighbors(regionSeed1, regionSeed2, 0, 0, dRegionX, dRegionZ);
    }

    public static boolean areNeighbors(long regionSeed1, long regionSeed2, int salt1, int salt2, int dRegionX, int dRegionZ) {
        return getIncrement(dRegionX, dRegionZ) == (regionSeed2 - ((long) salt2)) - (regionSeed1 - ((long) salt1));
    }
}
