package com.seedfinding.mccore.rand.seed;

import com.seedfinding.mccore.util.data.SeedIterator;
import com.seedfinding.mcmath.util.Mth;
import com.seedfinding.mcseed.lcg.LCG;
import com.seedfinding.mcseed.rand.JRand;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public final class PillarSeed {
    private static final LCG SKIP_2 = LCG.JAVA.combine(2);
    private static final LCG BACK_2 = LCG.JAVA.combine(-2);

    public static long fromStructureSeed(long structureSeed) {
        return (SKIP_2.nextSeed(structureSeed ^ LCG.JAVA.multiplier) >>> 16) & Mth.MASK_16;
    }

    public static SeedIterator getStructureSeeds(long pillarSeed) {
        return new SeedIterator(0L, 4294967296L, partialStructureSeed -> {
            long currentSeed = (partialStructureSeed & (Mth.MASK_32 - Mth.MASK_16)) << 16;
            return BACK_2.nextSeed((currentSeed | (partialStructureSeed & Mth.MASK_16)) | (pillarSeed << 16)) ^ LCG.JAVA.multiplier;
        });
    }

    public static int[] getPillarHeights(long pillarSeed) {
        int[] heights = new int[10];
        for (int i = 0; i < 10; i++) {
            heights[i] = 76 + (i * 3);
        }
        JRand rand = new JRand(pillarSeed);
        for (int i2 = heights.length; i2 > 1; i2--) {
            int a = i2 - 1;
            int b = rand.nextInt(i2);
            int temp = heights[a];
            heights[a] = heights[b];
            heights[b] = temp;
        }
        return heights;
    }

    public static List<Long> fromPillarHeights(int[] heights) {
        List<Long> seeds = new ArrayList<>();
        iterator().forEachRemaining(pillarSeed -> {
            if (Arrays.equals(getPillarHeights(pillarSeed), heights)) {
                seeds.add(Long.valueOf(pillarSeed));
            }
        });
        return seeds;
    }

    public static SeedIterator iterator() {
        return new SeedIterator(0L, 65536L);
    }
}
