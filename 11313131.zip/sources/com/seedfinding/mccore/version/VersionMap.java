package com.seedfinding.mccore.version;

import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class VersionMap<V> extends AbstractMap<MCVersion, V> {
    protected List<Entry<V>> entries = new ArrayList();

    @Override
    public Object put(Object obj, Object obj2) {
        return put((MCVersion) obj, (MCVersion) obj2);
    }

    @Override
    public Set<Map.Entry<MCVersion, V>> entrySet() {
        return new LinkedHashSet(this.entries);
    }

    public VersionMap<V> add(MCVersion key, V value) {
        put(key, (MCVersion) value);
        return this;
    }

    public V put(MCVersion key, V value) {
        for (Entry<V> e : this.entries) {
            if (e.getKey() == key) {
                return e.setValue(value);
            }
        }
        this.entries.add(new Entry<>(key, value));
        sort();
        return null;
    }

    public <E, K> Map<E, K> getMapUntil(MCVersion mCVersion) {
        Map<E, K> map = null;
        ArrayList arrayList = new ArrayList(this.entries);
        arrayList.sort((a, b) -> {
            return b.getKey().compareTo(a.getKey());
        });
        Iterator<E> it = arrayList.iterator();
        while (it.hasNext()) {
            Entry entry = (Entry) it.next();
            if (!entry.getKey().isNewerThan(mCVersion)) {
                if (map == null) {
                    map = (Map) entry.getValue();
                } else {
                    for (Map.Entry<K, V> entry2 : ((Map) entry.getValue()).entrySet()) {
                        map.put(entry2.getKey(), entry2.getValue());
                    }
                }
            }
        }
        return map;
    }

    public V getAsOf(MCVersion version) {
        V value = null;
        for (Entry<V> e : this.entries) {
            if (e.getKey().isNewerThan(version)) {
                break;
            }
            value = e.getValue();
        }
        return value;
    }

    public V getLatest() {
        if (isEmpty()) {
            return null;
        }
        return this.entries.get(this.entries.size() - 1).getValue();
    }

    public MCVersion getLatestVersion() {
        if (isEmpty()) {
            return null;
        }
        return this.entries.get(this.entries.size() - 1).getKey();
    }

    public V getOldest() {
        if (isEmpty()) {
            return null;
        }
        return this.entries.get(0).getValue();
    }

    public MCVersion getOldestVersion() {
        if (isEmpty()) {
            return null;
        }
        return this.entries.get(0).getKey();
    }

    protected void sort() {
        this.entries.sort((o1, o2) -> {
            if (o1.getKey().isOlderThan(o2.getKey())) {
                return -1;
            }
            return o1.getKey().isEqualTo(o2.getKey()) ? 0 : 1;
        });
    }

    public static class Entry<V> implements Map.Entry<MCVersion, V> {
        private final MCVersion key;
        private V value;

        public Entry(MCVersion key, V value) {
            this.key = key;
            this.value = value;
        }

        @Override
        public MCVersion getKey() {
            return this.key;
        }

        @Override
        public V getValue() {
            return this.value;
        }

        @Override
        public V setValue(V value) {
            V old = getValue();
            this.value = value;
            return old;
        }

        @Override
        public boolean equals(Object o) {
            return false;
        }

        @Override
        public int hashCode() {
            return (this.key.hashCode() * 31) + this.value.hashCode();
        }
    }
}
