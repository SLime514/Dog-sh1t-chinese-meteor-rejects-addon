package com.seedfinding.mccore.state;

import java.util.Arrays;
import java.util.Map;
import java.util.stream.Collectors;

public enum Dimension {
    OVERWORLD("overworld", 0),
    NETHER("the_nether", -1),
    END("the_end", 1);


    private final int f39id;
    private final String name;
    private static final Map<String, Dimension> STRING_TO_DIMENSION = (Map) Arrays.stream(values()).collect(Collectors.toMap((v0) -> {
        return v0.toString();
    }, o -> {
        return o;
    }));
    private static final Map<Integer, Dimension> ID_TO_DIMENSION = (Map) Arrays.stream(values()).collect(Collectors.toMap((v0) -> {
        return v0.getId();
    }, o -> {
        return o;
    }));

    Dimension(String name, int id) {
        this.name = name;
        this.f39id = id;
    }

    public static Dimension fromString(String name) {
        return STRING_TO_DIMENSION.get(name);
    }

    public static Dimension fromId(int id) {
        return ID_TO_DIMENSION.get(Integer.valueOf(id));
    }

    public int getId() {
        return this.f39id;
    }

    @Override
    public String toString() {
        return this.name;
    }

    public String getName() {
        return this.name;
    }
}
