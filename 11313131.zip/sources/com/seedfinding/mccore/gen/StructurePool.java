package com.seedfinding.mccore.gen;

public class StructurePool {
    private final String poolId;
    private final String terminatorId;

    public StructurePool(String poolId, String terminatorId) {
        this.poolId = poolId;
        this.terminatorId = terminatorId;
    }
}
