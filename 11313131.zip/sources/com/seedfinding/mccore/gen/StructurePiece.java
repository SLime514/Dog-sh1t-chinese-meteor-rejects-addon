package com.seedfinding.mccore.gen;

import com.seedfinding.mccore.block.Blocks;
import com.seedfinding.mccore.block.Tile;
import com.seedfinding.mccore.util.data.Identifier;
import com.seedfinding.mccore.util.math.Vec3i;
import com.seedfinding.mccore.util.pos.BPos;
import com.seedfinding.mcseed.rand.JRand;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class StructurePiece {
    private final PieceInfo info;
    private BPos position;
    private StructurePlacement placement;

    public StructurePiece(PieceInfo info) {
        this.info = info;
    }

    public PieceInfo getInfo() {
        return this.info;
    }

    public void generate(JRand rand) {
        List<Tile> jigsaws = getJigsaws(rand);
        for (Tile jigsaw : jigsaws) {
            Vec3i facing = JigsawHelper.getFacing(jigsaw.getBlockState()).getVector();
            BPos nextPieceStart = jigsaw.getPos().add(facing.getX(), facing.getY(), facing.getZ());
            new Identifier(jigsaw.getBlockEntity().getString("pool"));
            this.placement.box.contains(nextPieceStart);
        }
    }

    public List<Tile> getJigsaws(JRand rand) {
        int paletteId = rand.nextInt(this.info.getPalettes().size());
        Stream<R> map = this.info.getTiles().stream().sorted(PieceInfo.TILE_SORTER).filter(tile -> {
            return tile.getBlockState(paletteId).getBlock().getId() == Blocks.JIGSAW.getId();
        }).map(tile2 -> {
            return tile2.copy(paletteId);
        });
        StructurePlacement structurePlacement = this.placement;
        Objects.requireNonNull(structurePlacement);
        List<Tile> tiles = (List) map.map(structurePlacement::transformAndSet).peek(tile3 -> {
            tile3.setPos(tile3.getPos().add(this.position));
        }).filter(tile4 -> {
            return this.placement.box.contains(tile4.getPos());
        }).peek(tile5 -> {
            JigsawHelper.rotate(tile5.getBlockState(), this.placement.rotation);
        }).collect(Collectors.toList());
        rand.shuffle(tiles);
        return tiles;
    }
}
