package com.seedfinding.mccore.net;

import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteOrder;

public class ByteBuffer {

    protected final InputStream f34in;
    protected final OutputStream out;

    public ByteBuffer(InputStream in) {
        this(in, null);
    }

    public ByteBuffer(OutputStream out) {
        this(null, out);
    }

    public ByteBuffer(InputStream in, OutputStream out) {
        this.f34in = in;
        this.out = out;
    }

    public int read() throws IOException {
        return this.f34in.read();
    }

    public ByteBuffer write(int b) throws IOException {
        this.out.write(b);
        return this;
    }

    private boolean readBoolean() throws IOException {
        int v = read();
        if (v < 0) {
            throw new EOFException();
        }
        return v != 0;
    }

    public ByteBuffer writeBoolean(boolean v) throws IOException {
        this.out.write(v ? 1 : 0);
        return this;
    }

    public int readUnsignedByte() throws IOException {
        int v = this.f34in.read();
        if (v < 0) {
            throw new EOFException();
        }
        return v;
    }

    public byte readByte() throws IOException {
        return (byte) readUnsignedByte();
    }

    public ByteBuffer writeByte(int v) throws IOException {
        this.out.write(v);
        return this;
    }

    public int readUnsignedShort(ByteOrder order) throws IOException {
        int a = this.f34in.read();
        int b = this.f34in.read();
        if ((a | b) < 0) {
            throw new EOFException();
        }
        return order == ByteOrder.BIG_ENDIAN ? (a << 8) + b : (b << 8) + a;
    }

    public short readShort(ByteOrder order) throws IOException {
        return (short) readUnsignedShort(order);
    }

    public ByteBuffer writeShort(short v, ByteOrder order) throws IOException {
        if (order == ByteOrder.BIG_ENDIAN) {
            this.out.write((v >>> 8) & 255);
            this.out.write(v & 255);
        } else {
            this.out.write(v & 255);
            this.out.write((v >>> 8) & 255);
        }
        return this;
    }

    public char readChar(ByteOrder order) throws IOException {
        return (char) readUnsignedShort(order);
    }

    public ByteBuffer writeChar(char v, ByteOrder order) throws IOException {
        if (order == ByteOrder.BIG_ENDIAN) {
            this.out.write((v >>> '\b') & 255);
            this.out.write(v & 255);
        } else {
            this.out.write(v & 255);
            this.out.write((v >>> '\b') & 255);
        }
        return this;
    }

    public int readInt(ByteOrder order) throws IOException {
        int a = this.f34in.read();
        int b = this.f34in.read();
        int c = this.f34in.read();
        int d = this.f34in.read();
        if ((a | b | c | d) < 0) {
            throw new EOFException();
        }
        if (order == ByteOrder.BIG_ENDIAN) {
            return (a << 24) + (b << 16) + (c << 8) + d;
        }
        return (d << 24) + (c << 16) + (b << 8) + a;
    }

    public ByteBuffer writeInt(int v, ByteOrder order) throws IOException {
        if (order == ByteOrder.BIG_ENDIAN) {
            this.out.write((v >>> 24) & 255);
            this.out.write((v >>> 16) & 255);
            this.out.write((v >>> 8) & 255);
            this.out.write(v & 255);
        } else {
            this.out.write(v & 255);
            this.out.write((v >>> 8) & 255);
            this.out.write((v >>> 16) & 255);
            this.out.write((v >>> 24) & 255);
        }
        return this;
    }

    public long readLong(ByteOrder order) throws IOException {
        byte a = readByte();
        byte b = readByte();
        byte c = readByte();
        byte d = readByte();
        byte e = readByte();
        byte f = readByte();
        byte g = readByte();
        byte h = readByte();
        if (order == ByteOrder.BIG_ENDIAN) {
            return (a << 56) + (b << 48) + (c << 40) + (d << 32) + (e << 24) + (f << 16) + (g << 8) + h;
        }
        return (h << 56) + (g << 48) + (f << 40) + (e << 32) + (d << 24) + (c << 16) + (b << 8) + a;
    }

    public ByteBuffer writeLong(long v, ByteOrder order) throws IOException {
        if (order == ByteOrder.BIG_ENDIAN) {
            this.out.write((byte) (v >>> 56));
            this.out.write((byte) (v >>> 48));
            this.out.write((byte) (v >>> 40));
            this.out.write((byte) (v >>> 32));
            this.out.write((byte) (v >>> 24));
            this.out.write((byte) (v >>> 16));
            this.out.write((byte) (v >>> 8));
            this.out.write((byte) v);
        } else {
            this.out.write((byte) v);
            this.out.write((byte) (v >>> 8));
            this.out.write((byte) (v >>> 16));
            this.out.write((byte) (v >>> 24));
            this.out.write((byte) (v >>> 56));
            this.out.write((byte) (v >>> 48));
            this.out.write((byte) (v >>> 40));
            this.out.write((byte) (v >>> 32));
        }
        return this;
    }

    public float readFloat(ByteOrder order) throws IOException {
        return Float.intBitsToFloat(readInt(order));
    }

    public ByteBuffer writeFloat(float v, ByteOrder order) throws IOException {
        return writeInt(Float.floatToIntBits(v), order);
    }

    public double readDouble(ByteOrder order) throws IOException {
        return Double.longBitsToDouble(readLong(order));
    }

    public ByteBuffer writeDouble(double v, ByteOrder order) throws IOException {
        return writeLong(Double.doubleToLongBits(v), order);
    }

    public String readASCII(ByteOrder order) throws IOException {
        char[] arr = new char[readUnsignedShort(order)];
        for (int i = 0; i < arr.length; i++) {
            arr[i] = (char) readByte();
        }
        return new String(arr);
    }

    public ByteBuffer writeASCII(String v, ByteOrder order) throws IOException {
        writeShort((short) v.length(), order);
        for (int i = 0; i < v.length(); i++) {
            writeByte(v.charAt(i));
        }
        return this;
    }
}
