package com.seedfinding.mcfeature.decorator;

import com.seedfinding.mcbiome.biome.Biome;
import com.seedfinding.mcbiome.source.BiomeSource;
import com.seedfinding.mccore.rand.ChunkRand;
import com.seedfinding.mccore.version.MCVersion;
import com.seedfinding.mcfeature.Feature;
import com.seedfinding.mcfeature.decorator.Decorator.Config;
import com.seedfinding.mcfeature.decorator.Decorator.Data;
import java.util.HashMap;
import java.util.Map;

public abstract class Decorator<C extends Config, D extends Data<?>> extends Feature<C, D> {
    public abstract boolean isValidBiome(Biome biome);

    public abstract D getData(long j, int i, int i2, Biome biome, ChunkRand chunkRand);

    public Decorator(C config, MCVersion version) {
        super(config, version);
    }

    public int getIndex() {
        return getConfig().index;
    }

    public int getStep() {
        return getConfig().step;
    }

    public int getDefaultSalt() {
        return getConfig().salt;
    }

    public int getSalt(Biome biome) {
        return getConfig().getSalt(biome);
    }

    protected void setDecoratorSeed(long structureSeed, int chunkX, int chunkZ, Biome biome, ChunkRand rand) {
        rand.setDecoratorSeed(structureSeed, chunkX << 4, chunkZ << 4, getSalt(biome), getVersion());
    }

    @Override
    public boolean canStart(D data, long structureSeed, ChunkRand rand) {
        setDecoratorSeed(structureSeed, data.chunkX, data.chunkZ, data.biome, rand);
        return true;
    }

    @Override
    public boolean canSpawn(D data, BiomeSource source) {
        Biome biomeForNoiseGen;
        if (getVersion().isOlderThan(MCVersion.v1_16)) {
            biomeForNoiseGen = source.getBiome((data.chunkX << 4) + 8, 0, (data.chunkZ << 4) + 8);
        } else {
            biomeForNoiseGen = source.getBiomeForNoiseGen((data.chunkX << 2) + 2, 0, (data.chunkZ << 2) + 2);
        }
        Biome biome = biomeForNoiseGen;
        if (isValidBiome(biome)) {
            return data.biome == null || getSalt(biome) == getSalt(biome);
        }
        return false;
    }

    public boolean canSpawn(int chunkX, int chunkZ, BiomeSource source) {
        if (getVersion().isOlderThan(MCVersion.v1_16)) {
            return isValidBiome(source.getBiome((chunkX << 4) + 8, 0, (chunkZ << 4) + 8));
        }
        return isValidBiome(source.getBiomeForNoiseGen((chunkX << 2) + 2, 0, (chunkZ << 2) + 2));
    }

    public static class Config extends Feature.Config {
        public final int index;
        public final int step;
        public final int salt;
        private final Map<Biome, Config> overrides = new HashMap();

        public Config(int index, int step) {
            this.index = index;
            this.step = step;
            this.salt = (this.step * 10000) + this.index;
        }

        public int getSalt(Biome biome) {
            return this.overrides.getOrDefault(biome, this).salt;
        }

        public Config add(int index, int step, Biome... biomes) {
            for (Biome biome : biomes) {
                this.overrides.put(biome, new Config(index, step));
            }
            return this;
        }
    }

    public static class Data<T extends Decorator<?, ?>> extends Feature.Data<T> {
        public final Biome biome;

        public Data(T feature, int chunkX, int chunkZ, Biome biome) {
            super(feature, chunkX, chunkZ);
            this.biome = biome;
        }
    }
}
