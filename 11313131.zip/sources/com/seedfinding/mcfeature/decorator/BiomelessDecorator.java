package com.seedfinding.mcfeature.decorator;

import com.seedfinding.mcbiome.biome.Biome;
import com.seedfinding.mccore.rand.ChunkRand;
import com.seedfinding.mccore.version.MCVersion;
import com.seedfinding.mcfeature.decorator.BiomelessDecorator.Config;
import com.seedfinding.mcfeature.decorator.BiomelessDecorator.Data;
import com.seedfinding.mcfeature.decorator.Decorator;

public abstract class BiomelessDecorator<C extends Config, D extends Data<?>> extends Decorator<C, D> {
    public abstract D getData(long j, int i, int i2, ChunkRand chunkRand);

    public BiomelessDecorator(C config, MCVersion version) {
        super(config, version);
    }

    @Override
    public int getSalt(Biome biome) {
        return getDefaultSalt();
    }

    @Override
    protected void setDecoratorSeed(long structureSeed, int chunkX, int chunkZ, Biome biome, ChunkRand rand) {
        setDecoratorSeed(structureSeed, chunkX, chunkZ, rand);
    }

    protected void setDecoratorSeed(long structureSeed, int chunkX, int chunkZ, ChunkRand rand) {
        rand.setDecoratorSeed(structureSeed, chunkX << 4, chunkZ << 4, getDefaultSalt(), getVersion());
    }

    @Override
    public final D getData(long j, int i, int i2, Biome biome, ChunkRand chunkRand) {
        return (D) getData(j, i, i2, chunkRand);
    }

    public static class Config extends Decorator.Config {
        public Config(int index, int step) {
            super(index, step);
        }

        @Override
        public Decorator.Config add(int index, int step, Biome... biomes) {
            throw new UnsupportedOperationException("BiomelessDecorator shouldn't use biome overrides");
        }
    }

    public static class Data<T extends Decorator<?, ?>> extends Decorator.Data<T> {
        public Data(T feature, int chunkX, int chunkZ) {
            super(feature, chunkX, chunkZ, null);
        }
    }
}
