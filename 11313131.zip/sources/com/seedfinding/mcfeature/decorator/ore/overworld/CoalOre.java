package com.seedfinding.mcfeature.decorator.ore.overworld;

import com.seedfinding.mccore.block.Blocks;
import com.seedfinding.mccore.version.MCVersion;
import com.seedfinding.mccore.version.VersionMap;
import com.seedfinding.mcfeature.decorator.ore.HeightProvider;
import com.seedfinding.mcfeature.decorator.ore.OreDecorator;
import com.seedfinding.mcfeature.decorator.ore.RegularOreDecorator;

public class CoalOre extends RegularOreDecorator<OreDecorator.Config, OreDecorator.Data<CoalOre>> {
    public static final VersionMap<OreDecorator.Config> CONFIGS = new VersionMap().add(MCVersion.v1_13, new OreDecorator.Config(5, 4, 17, 20, HeightProvider.range(0, 0, 128), Blocks.COAL_ORE, BASE_STONE_OVERWORLD)).add(MCVersion.v1_16, new OreDecorator.Config(5, 6, 17, 20, HeightProvider.range(0, 0, 128), Blocks.COAL_ORE, BASE_STONE_OVERWORLD)).add(MCVersion.v1_17, new OreDecorator.Config(7, 6, 17, 20, HeightProvider.uniformRange(0, 127), Blocks.COAL_ORE, BASE_STONE_OVERWORLD));

    public CoalOre(MCVersion version) {
        super(CONFIGS.getAsOf(version), version);
    }

    @Override
    public String getName() {
        return name();
    }

    public static String name() {
        return "coal_ore";
    }
}
