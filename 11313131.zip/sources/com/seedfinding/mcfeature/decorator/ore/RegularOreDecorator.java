package com.seedfinding.mcfeature.decorator.ore;

import com.seedfinding.mcbiome.biome.Biome;
import com.seedfinding.mccore.block.Blocks;
import com.seedfinding.mccore.state.Dimension;
import com.seedfinding.mccore.util.pos.BPos;
import com.seedfinding.mccore.version.MCVersion;
import com.seedfinding.mcfeature.decorator.ore.OreDecorator;
import com.seedfinding.mcfeature.decorator.ore.OreDecorator.Config;
import com.seedfinding.mcfeature.decorator.ore.OreDecorator.Data;
import com.seedfinding.mcnoise.utils.MathHelper;
import com.seedfinding.mcseed.rand.JRand;
import com.seedfinding.mcterrain.TerrainGenerator;
import java.util.ArrayList;
import java.util.BitSet;
import java.util.Collections;
import java.util.List;

public abstract class RegularOreDecorator<C extends OreDecorator.Config, D extends OreDecorator.Data<?>> extends OreDecorator<C, D> {
    public RegularOreDecorator(C config, MCVersion version) {
        super(config, version);
    }

    @Override
    public Dimension getValidDimension() {
        return Dimension.OVERWORLD;
    }

    @Override
    protected List<BPos> generateOrePositions(BPos bPos, Biome biome, TerrainGenerator generator, JRand rand) {
        float angle = rand.nextFloat() * 3.1415927f;
        float size = getSize(biome) / 8.0f;
        int amortizedSize = ceil((((getSize(biome) / 16.0f) * 2.0f) + 1.0f) / 2.0f);
        double offsetXPos = bPos.getX() + (Math.sin(angle) * size);
        double offsetXNeg = bPos.getX() - (Math.sin(angle) * size);
        double offsetZPos = bPos.getZ() + (Math.cos(angle) * size);
        double offsetZNeg = bPos.getZ() - (Math.cos(angle) * size);
        double offsetYPos = (bPos.getY() + rand.nextInt(3)) - 2;
        double offsetYNeg = (bPos.getY() + rand.nextInt(3)) - 2;
        int startX = (bPos.getX() - ceil(size)) - amortizedSize;
        int startY = (bPos.getY() - 2) - amortizedSize;
        int startZ = (bPos.getZ() - ceil(size)) - amortizedSize;
        int oreSize = 2 * (ceil(size) + amortizedSize);
        int radius = 2 * (2 + amortizedSize);
        for (int x = startX; x <= startX + oreSize; x++) {
            for (int z = startZ; z <= startZ + oreSize; z++) {
                if (startY <= generator.getFirstHeightInColumn(x, z, TerrainGenerator.OCEAN_FLOOR_WG)) {
                    return generateVeinPart(generator, biome, rand, offsetXPos, offsetXNeg, offsetZPos, offsetZNeg, offsetYPos, offsetYNeg, startX, startY, startZ, oreSize, radius);
                }
            }
        }
        return Collections.emptyList();
    }

    private List<BPos> generateVeinPart(TerrainGenerator generator, Biome biome, JRand rand, double offsetXPos, double offsetXNeg, double offsetZPos, double offsetZNeg, double offsetYPos, double offsetYNeg, int startX, int startY, int startZ, int oreSize, int radius) {
        List<BPos> poses = new ArrayList<>();
        BitSet bitSet = new BitSet(oreSize * radius * oreSize);
        int size = getSize(biome);
        double[] store = new double[size * 4];
        for (int i = 0; i < size; i++) {
            float percent = i / size;
            double x = MathHelper.lerp(percent, offsetXPos, offsetXNeg);
            double y = MathHelper.lerp(percent, offsetYPos, offsetYNeg);
            double z = MathHelper.lerp(percent, offsetZPos, offsetZNeg);
            double length = (rand.nextDouble() * size) / 16.0d;
            double offset = (((Math.sin(3.1415927f * percent) + 1.0d) * length) + 1.0d) / 2.0d;
            store[i * 4] = x;
            store[(i * 4) + 1] = y;
            store[(i * 4) + 2] = z;
            store[(i * 4) + 3] = offset;
        }
        for (int i2 = 0; i2 < size - 1; i2++) {
            if (store[(i2 * 4) + 3] > 0.0d) {
                for (int j = i2 + 1; j < size; j++) {
                    if (store[(j * 4) + 3] > 0.0d) {
                        double diffX = store[i2 * 4] - store[j * 4];
                        double diffY = store[(i2 * 4) + 1] - store[(j * 4) + 1];
                        double diffZ = store[(i2 * 4) + 2] - store[(j * 4) + 2];
                        double offset2 = store[(i2 * 4) + 3] - store[(j * 4) + 3];
                        if (offset2 * offset2 > (diffX * diffX) + (diffY * diffY) + (diffZ * diffZ)) {
                            if (offset2 > 0.0d) {
                                store[(j * 4) + 3] = -1.0d;
                            } else {
                                store[(i2 * 4) + 3] = -1.0d;
                            }
                        }
                    }
                }
            }
        }
        for (int i3 = 0; i3 < size; i3++) {
            double offset3 = store[(i3 * 4) + 3];
            if (offset3 >= 0.0d) {
                double x2 = store[i3 * 4];
                double y2 = store[(i3 * 4) + 1];
                double z2 = store[(i3 * 4) + 2];
                int minX = Math.max(MathHelper.floor(x2 - offset3), startX);
                int minY = Math.max(MathHelper.floor(y2 - offset3), startY);
                int minZ = Math.max(MathHelper.floor(z2 - offset3), startZ);
                int maxX = Math.max(MathHelper.floor(x2 + offset3), minX);
                int maxY = Math.max(MathHelper.floor(y2 + offset3), minY);
                int maxZ = Math.max(MathHelper.floor(z2 + offset3), minZ);
                for (int X = minX; X <= maxX; X++) {
                    double xSlide = ((X + 0.5d) - x2) / offset3;
                    if (xSlide * xSlide < 1.0d) {
                        for (int Y = minY; Y <= maxY; Y++) {
                            double ySlide = ((Y + 0.5d) - y2) / offset3;
                            if ((xSlide * xSlide) + (ySlide * ySlide) < 1.0d) {
                                for (int Z = minZ; Z <= maxZ; Z++) {
                                    double zSlide = ((Z + 0.5d) - z2) / offset3;
                                    if ((xSlide * xSlide) + (ySlide * ySlide) + (zSlide * zSlide) < 1.0d) {
                                        int area = (X - startX) + ((Y - startY) * oreSize) + ((Z - startZ) * oreSize * radius);
                                        if (!bitSet.get(area)) {
                                            bitSet.set(area);
                                            BPos pos = new BPos(X, Y, Z);
                                            if (getReplaceBlocks(biome).contains(generator.getBlockAt(pos).orElse(Blocks.AIR))) {
                                                poses.add(pos);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        return poses;
    }

    private static int ceil(float f) {
        int i = (int) f;
        return f > ((float) i) ? i + 1 : i;
    }
}
