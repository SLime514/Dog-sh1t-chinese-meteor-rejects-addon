package com.seedfinding.mcfeature.decorator.ore;

import com.seedfinding.mcbiome.biome.Biome;
import com.seedfinding.mccore.block.Block;
import com.seedfinding.mccore.block.Blocks;
import com.seedfinding.mccore.rand.ChunkRand;
import com.seedfinding.mccore.util.pos.BPos;
import com.seedfinding.mccore.version.MCVersion;
import com.seedfinding.mcfeature.decorator.Decorator;
import com.seedfinding.mcfeature.decorator.ore.OreDecorator.Config;
import com.seedfinding.mcfeature.decorator.ore.OreDecorator.Data;
import com.seedfinding.mcseed.rand.JRand;
import com.seedfinding.mcterrain.TerrainGenerator;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public abstract class OreDecorator<C extends Config, D extends Data<?>> extends Decorator<C, D> {
    protected static final Set<Block> BASE_STONE_OVERWORLD = new HashSet();
    protected static final Set<Block> BASE_STONE_NETHER = new HashSet();
    protected static final Set<Block> STONE = new HashSet();
    protected static final Set<Block> NETHERRACK = new HashSet();
    protected static final Set<Block> DIRT_CLAY = new HashSet();
    protected static final Set<Block> DIRT_GRASS = new HashSet();

    protected abstract List<BPos> generateOrePositions(BPos bPos, Biome biome, TerrainGenerator terrainGenerator, JRand jRand);

    static {
        BASE_STONE_OVERWORLD.addAll(Arrays.asList(Blocks.STONE, Blocks.GRANITE, Blocks.DIORITE, Blocks.ANDESITE, Blocks.DEEPSLATE, Blocks.TUFF));
        BASE_STONE_NETHER.addAll(Arrays.asList(Blocks.NETHERRACK, Blocks.BASALT, Blocks.BLACKSTONE));
        STONE.addAll(Collections.singletonList(Blocks.STONE));
        NETHERRACK.addAll(Collections.singletonList(Blocks.NETHERRACK));
        DIRT_CLAY.addAll(Arrays.asList(Blocks.DIRT, Blocks.CLAY));
        DIRT_GRASS.addAll(Arrays.asList(Blocks.DIRT, Blocks.GRASS_BLOCK));
    }

    public OreDecorator(C config, MCVersion version) {
        super(config, version);
    }

    public int getDefaultSize() {
        return getConfig().size;
    }

    public int getSize(Biome biome) {
        return getConfig().getSize(biome);
    }

    public int getDefaultRepeatCount() {
        return getConfig().repeatCount;
    }

    public int getRepeatCount(Biome biome) {
        return getConfig().getRepeatCount(biome);
    }

    public HeightProvider getDefaultHeightProvider() {
        return getConfig().heightProvider;
    }

    public HeightProvider getHeightProvider(Biome biome) {
        return getConfig().getHeightProvider(biome);
    }

    public Block getDefaultOreBlock() {
        return getConfig().oreBlock;
    }

    public Block getOreBlock(Biome biome) {
        return getConfig().getOreBlock(biome);
    }

    public Set<Block> getDefaultReplaceBlocks() {
        return getConfig().replaceBlocks;
    }

    public Set<Block> getReplaceBlocks(Biome biome) {
        return getConfig().getReplaceBlocks(biome);
    }

    @Override
    public boolean canGenerate(D data, TerrainGenerator generator) {
        return true;
    }

    public D generate(long j, int i, int i2, Biome biome, ChunkRand chunkRand, TerrainGenerator terrainGenerator) {
        setDecoratorSeed(j, i, i2, biome, chunkRand);
        HashSet hashSet = new HashSet();
        for (int i3 = 0; i3 < getRepeatCount(biome); i3++) {
            hashSet.addAll(generateOrePositions(generateBasePosition(i, i2, biome, chunkRand), biome, terrainGenerator, chunkRand));
        }
        return (D) new Data(this, new BPos(i << 4, 0, i2 << 4), hashSet, biome);
    }

    @Override
    public D getData(long j, int i, int i2, Biome biome, ChunkRand chunkRand) {
        setDecoratorSeed(j, i, i2, biome, chunkRand);
        return (D) new Data(this, new BPos(i << 4, 0, i2 << 4), Collections.emptySet(), biome);
    }

    protected BPos generateBasePosition(int chunkX, int chunkZ, Biome biome, JRand rand) {
        if (getVersion().isNewerOrEqualTo(MCVersion.v1_15)) {
            int blockX = (chunkX << 4) + rand.nextInt(16);
            int blockZ = (chunkZ << 4) + rand.nextInt(16);
            int blockY = getHeightProvider(biome).getY(rand);
            return new BPos(blockX, blockY, blockZ);
        }
        int blockX2 = (chunkX << 4) + rand.nextInt(16);
        int blockY2 = getHeightProvider(biome).getY(rand);
        int blockZ2 = (chunkZ << 4) + rand.nextInt(16);
        return new BPos(blockX2, blockY2, blockZ2);
    }

    @Override
    public boolean isValidBiome(Biome biome) {
        return getValidDimension().equals(biome.getDimension());
    }

    public static class Config extends Decorator.Config {
        public final int size;
        public final int repeatCount;
        public final HeightProvider heightProvider;
        public final Block oreBlock;
        public final Set<Block> replaceBlocks;
        private final Map<Biome, Config> overrides;

        public Config(int index, int step, int size, int repeatCount, HeightProvider heightProvider, Block oreBlock, Set<Block> replaceBlocks) {
            super(index, step);
            this.overrides = new HashMap();
            this.size = size;
            this.repeatCount = repeatCount;
            this.heightProvider = heightProvider;
            this.oreBlock = oreBlock;
            this.replaceBlocks = replaceBlocks;
        }

        public int getSize(Biome biome) {
            return this.overrides.getOrDefault(biome, this).size;
        }

        public int getRepeatCount(Biome biome) {
            return this.overrides.getOrDefault(biome, this).repeatCount;
        }

        public HeightProvider getHeightProvider(Biome biome) {
            return this.overrides.getOrDefault(biome, this).heightProvider;
        }

        public Block getOreBlock(Biome biome) {
            return this.overrides.getOrDefault(biome, this).oreBlock;
        }

        public Set<Block> getReplaceBlocks(Biome biome) {
            return this.overrides.getOrDefault(biome, this).replaceBlocks;
        }

        @Override
        public Config add(int index, int step, Biome... biomes) {
            super.add(index, step, biomes);
            return this;
        }

        public Config add(int index, int step, int size, int repeatCount, Biome... biomes) {
            return add(index, step, size, repeatCount, this.heightProvider, biomes);
        }

        public Config add(int index, int step, int size, int repeatCount, HeightProvider heightProvider, Biome... biomes) {
            return add(index, step, size, repeatCount, heightProvider, this.oreBlock, this.replaceBlocks, biomes);
        }

        public Config add(int index, int step, int size, int repeatCount, HeightProvider heightProvider, Block oreBlock, Set<Block> replaceBlocks, Biome... biomes) {
            super.add(index, step, biomes);
            for (Biome biome : biomes) {
                this.overrides.put(biome, new Config(index, step, size, repeatCount, heightProvider, oreBlock, replaceBlocks));
            }
            return this;
        }
    }

    public static class Data<T extends Decorator<?, ?>> extends Decorator.Data<T> {
        public BPos basePos;
        public Set<BPos> positions;

        public Data(T feature, BPos basePos, Set<BPos> positions, Biome biome) {
            super(feature, basePos.getX() >> 4, basePos.getZ() >> 4, biome);
            this.basePos = basePos;
            this.positions = positions;
        }
    }
}
