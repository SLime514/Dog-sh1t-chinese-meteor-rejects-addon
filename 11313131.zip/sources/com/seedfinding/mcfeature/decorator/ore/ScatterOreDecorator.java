package com.seedfinding.mcfeature.decorator.ore;

import com.seedfinding.mcbiome.biome.Biome;
import com.seedfinding.mccore.block.Blocks;
import com.seedfinding.mccore.state.Dimension;
import com.seedfinding.mccore.util.block.BlockDirection;
import com.seedfinding.mccore.util.pos.BPos;
import com.seedfinding.mccore.version.MCVersion;
import com.seedfinding.mcfeature.decorator.ore.OreDecorator;
import com.seedfinding.mcfeature.decorator.ore.OreDecorator.Config;
import com.seedfinding.mcfeature.decorator.ore.OreDecorator.Data;
import com.seedfinding.mcseed.rand.JRand;
import com.seedfinding.mcterrain.TerrainGenerator;
import java.util.ArrayList;
import java.util.List;

public abstract class ScatterOreDecorator<C extends OreDecorator.Config, D extends OreDecorator.Data<?>> extends OreDecorator<C, D> {
    public ScatterOreDecorator(C config, MCVersion version) {
        super(config, version);
    }

    @Override
    public Dimension getValidDimension() {
        return Dimension.NETHER;
    }

    @Override
    protected List<BPos> generateOrePositions(BPos bPos, Biome biome, TerrainGenerator generator, JRand rand) {
        List<BPos> poses = new ArrayList<>();
        int count = rand.nextInt(getSize(biome) + 1);
        for (int i = 0; i < count; i++) {
            BPos startPos = getStartPos(rand, bPos, Math.min(i, 7));
            if (getReplaceBlocks(biome).contains(generator.getBlockAt(startPos).orElse(Blocks.AIR)) && !checkAir(generator, startPos)) {
                poses.add(startPos);
            }
        }
        return poses;
    }

    private BPos getStartPos(JRand rand, BPos pos, int size) {
        int x = randomCoord(rand, size);
        int y = randomCoord(rand, size);
        int z = randomCoord(rand, size);
        return pos.add(x, y, z);
    }

    private int randomCoord(JRand rand, int size) {
        return Math.round((rand.nextFloat() - rand.nextFloat()) * size);
    }

    private boolean checkAir(TerrainGenerator generator, BPos pos) {
        for (BlockDirection direction : BlockDirection.values()) {
            BPos rel = pos.relative(direction);
            if (Blocks.AIR.equals(generator.getBlockAt(rel).orElse(Blocks.AIR))) {
                return true;
            }
        }
        return false;
    }
}
