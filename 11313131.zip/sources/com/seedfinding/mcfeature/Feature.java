package com.seedfinding.mcfeature;

import com.seedfinding.mcbiome.source.BiomeSource;
import com.seedfinding.mccore.rand.ChunkRand;
import com.seedfinding.mccore.state.Dimension;
import com.seedfinding.mccore.version.MCVersion;
import com.seedfinding.mcfeature.Feature.Config;
import com.seedfinding.mcfeature.Feature.Data;
import com.seedfinding.mcfeature.GenerationContext;
import com.seedfinding.mcterrain.TerrainGenerator;

public abstract class Feature<C extends Config, D extends Data<?>> implements GenerationContext {
    private GenerationContext.Context context = null;
    private final C config;
    private final MCVersion version;

    public static class Config {
    }

    public abstract String getName();

    public abstract boolean canStart(D d, long j, ChunkRand chunkRand);

    public abstract boolean canSpawn(D d, BiomeSource biomeSource);

    public abstract boolean canGenerate(D d, TerrainGenerator terrainGenerator);

    public abstract Dimension getValidDimension();

    public Feature(C config, MCVersion version) {
        this.config = config;
        this.version = version;
    }

    public C getConfig() {
        return this.config;
    }

    public MCVersion getVersion() {
        return this.version;
    }

    public static String name() {
        return "unknown";
    }

    public boolean isValidDimension(Dimension dimension) {
        return getValidDimension() == dimension;
    }

    @Override
    public GenerationContext.Context getContext(long worldSeed) {
        if (getContext() == null || getContext().getWorldSeed().longValue() != worldSeed) {
            setContext(super.getContext(worldSeed));
        }
        return getContext();
    }

    public void setContext(GenerationContext.Context context) {
        this.context = context;
    }

    public GenerationContext.Context getContext() {
        return this.context;
    }

    public static class Data<T extends Feature> {
        public final T feature;
        public final int chunkX;
        public final int chunkZ;

        public Data(T feature, int chunkX, int chunkZ) {
            this.feature = feature;
            this.chunkX = chunkX;
            this.chunkZ = chunkZ;
        }

        public boolean testStart(long structureSeed, ChunkRand rand) {
            return this.feature.canStart(this, structureSeed, rand);
        }

        public boolean testBiome(BiomeSource source) {
            return this.feature.canSpawn(this, source);
        }

        public boolean testGenerate(TerrainGenerator generator) {
            return this.feature.canGenerate(this, generator);
        }
    }
}
