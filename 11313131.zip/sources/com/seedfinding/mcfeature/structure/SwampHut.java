package com.seedfinding.mcfeature.structure;

import com.seedfinding.mcbiome.biome.Biome;
import com.seedfinding.mcbiome.biome.Biomes;
import com.seedfinding.mccore.state.Dimension;
import com.seedfinding.mccore.version.MCVersion;
import com.seedfinding.mccore.version.VersionMap;
import com.seedfinding.mcfeature.structure.OldStructure;
import com.seedfinding.mcfeature.structure.RegionStructure;

public class SwampHut extends OldStructure<SwampHut> {
    public static final VersionMap<OldStructure.Config> CONFIGS = new VersionMap().add(MCVersion.v1_8, new OldStructure.Config(14357617)).add(MCVersion.v1_13, new OldStructure.Config(14357620));

    public SwampHut(MCVersion version) {
        this(CONFIGS.getAsOf(version), version);
    }

    public SwampHut(RegionStructure.Config config, MCVersion version) {
        super(config, version);
    }

    public static String name() {
        return "swamp_hut";
    }

    @Override
    public Dimension getValidDimension() {
        return Dimension.OVERWORLD;
    }

    @Override
    public boolean isValidBiome(Biome biome) {
        return biome == Biomes.SWAMP;
    }
}
