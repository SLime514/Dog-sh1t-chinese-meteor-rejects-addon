package com.seedfinding.mcfeature.structure;

import com.seedfinding.mccore.rand.ChunkRand;
import com.seedfinding.mccore.util.pos.CPos;
import com.seedfinding.mccore.version.MCVersion;
import com.seedfinding.mcfeature.structure.RegionStructure;
import com.seedfinding.mcfeature.structure.TriangularStructure;

public abstract class TriangularStructure<T extends TriangularStructure<T>> extends RegionStructure<RegionStructure.Config, RegionStructure.Data<T>> {
    private final int peak;

    public TriangularStructure(RegionStructure.Config config, MCVersion version) {
        super(config, version);
        this.peak = getSpacing() - getSeparation();
    }

    public static String name() {
        return "triangular_structure";
    }

    public int getPeak() {
        return this.peak;
    }

    @Override
    public boolean canStart(RegionStructure.Data<T> data, long structureSeed, ChunkRand rand) {
        rand.setSeed(data.baseRegionSeed + structureSeed);
        return (rand.nextInt(this.peak) + rand.nextInt(this.peak)) / 2 == data.offsetX && (rand.nextInt(this.peak) + rand.nextInt(this.peak)) / 2 == data.offsetZ;
    }

    @Override
    public CPos getInRegion(long structureSeed, int regionX, int regionZ, ChunkRand rand) {
        rand.setRegionSeed(structureSeed, regionX, regionZ, getSalt(), getVersion());
        return new CPos((regionX * getSpacing()) + ((rand.nextInt(this.peak) + rand.nextInt(this.peak)) / 2), (regionZ * getSpacing()) + ((rand.nextInt(this.peak) + rand.nextInt(this.peak)) / 2));
    }
}
