package com.seedfinding.mcfeature.structure;

import com.seedfinding.mccore.rand.ChunkRand;
import com.seedfinding.mccore.util.pos.CPos;
import com.seedfinding.mccore.version.MCVersion;
import com.seedfinding.mcfeature.structure.RegionStructure;
import com.seedfinding.mcfeature.structure.UniformStructure;

public abstract class UniformStructure<T extends UniformStructure<T>> extends RegionStructure<RegionStructure.Config, RegionStructure.Data<T>> {
    private final int offset;

    public UniformStructure(RegionStructure.Config config, MCVersion version) {
        super(config, version);
        this.offset = getSpacing() - getSeparation();
    }

    public static String name() {
        return "uniform_structure";
    }

    public int getOffset() {
        return this.offset;
    }

    @Override
    public boolean canStart(RegionStructure.Data<T> data, long structureSeed, ChunkRand rand) {
        rand.setSeed(data.baseRegionSeed + structureSeed);
        return rand.nextInt(this.offset) == data.offsetX && rand.nextInt(this.offset) == data.offsetZ;
    }

    @Override
    public CPos getInRegion(long structureSeed, int regionX, int regionZ, ChunkRand rand) {
        rand.setRegionSeed(structureSeed, regionX, regionZ, getSalt(), getVersion());
        return new CPos((regionX * getSpacing()) + rand.nextInt(getOffset()), (regionZ * getSpacing()) + rand.nextInt(getOffset()));
    }
}
