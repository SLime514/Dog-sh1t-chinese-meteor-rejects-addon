package com.seedfinding.mcfeature.structure;

import com.seedfinding.mcbiome.biome.Biome;
import com.seedfinding.mcbiome.biome.Biomes;
import com.seedfinding.mccore.rand.ChunkRand;
import com.seedfinding.mccore.state.Dimension;
import com.seedfinding.mccore.util.block.BlockRotation;
import com.seedfinding.mccore.util.pos.CPos;
import com.seedfinding.mccore.version.MCVersion;
import com.seedfinding.mccore.version.VersionMap;
import com.seedfinding.mcfeature.structure.OldStructure;
import com.seedfinding.mcfeature.structure.RegionStructure;

public class Village extends OldStructure<Village> {
    public static final VersionMap<OldStructure.Config> CONFIGS = new VersionMap().add(MCVersion.v1_8, new OldStructure.Config(10387312));

    public Village(MCVersion version) {
        this(CONFIGS.getAsOf(version), version);
    }

    public Village(RegionStructure.Config config, MCVersion version) {
        super(config, version);
    }

    public static String name() {
        return "village";
    }

    public boolean isZombieVillage(long structureSeed, CPos cPos, ChunkRand rand) {
        rand.setCarverSeed(structureSeed, cPos.getX(), cPos.getZ(), getVersion());
        rand.advance(1L);
        if (getVersion().isNewerOrEqualTo(MCVersion.v1_10) && getVersion().isOlderThan(MCVersion.v1_14)) {
            rand.getInt(2 + 0, 4 + (0 * 2));
            rand.getInt(0 + 0, 1 + 0);
            rand.getInt(0 + 0, 2 + 0);
            rand.getInt(2 + 0, 5 + (0 * 3));
            rand.getInt(0 + 0, 2 + 0);
            rand.getInt(1 + 0, 4 + 0);
            rand.getInt(2 + 0, 4 + (0 * 2));
            rand.getInt(0, 1 + 0);
            rand.getInt(0 + 0, 3 + (0 * 2));
            BlockRotation.getRandom(rand);
            return rand.nextInt(50) == 0;
        }
        if (!getVersion().isNewerOrEqualTo(MCVersion.v1_14) || this.biome == null) {
            return false;
        }
        return Biomes.PLAINS.equals(this.biome) ? rand.nextInt(204) >= 200 : Biomes.DESERT.equals(this.biome) ? rand.nextInt(250) >= 245 : Biomes.SAVANNA.equals(this.biome) ? rand.nextInt(459) >= 450 : Biomes.TAIGA.equals(this.biome) ? rand.nextInt(100) >= 98 : Biomes.SNOWY_TUNDRA.equals(this.biome) && rand.nextInt(306) >= 300;
    }

    @Override
    public Dimension getValidDimension() {
        return Dimension.OVERWORLD;
    }

    @Override
    public boolean isValidBiome(Biome biome) {
        if (biome == Biomes.PLAINS || biome == Biomes.DESERT || biome == Biomes.SAVANNA) {
            return true;
        }
        if (biome == Biomes.TAIGA && getVersion().isNewerOrEqualTo(MCVersion.v1_10)) {
            return true;
        }
        return biome == Biomes.SNOWY_TUNDRA && getVersion().isNewerOrEqualTo(MCVersion.v1_14);
    }
}
