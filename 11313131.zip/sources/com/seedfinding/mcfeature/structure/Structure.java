package com.seedfinding.mcfeature.structure;

import com.seedfinding.mcbiome.biome.Biome;
import com.seedfinding.mcbiome.source.BiomeSource;
import com.seedfinding.mccore.util.pos.CPos;
import com.seedfinding.mccore.version.MCVersion;
import com.seedfinding.mcfeature.Feature;
import com.seedfinding.mcfeature.Feature.Config;
import com.seedfinding.mcfeature.Feature.Data;
import com.seedfinding.mcterrain.TerrainGenerator;
import java.util.HashMap;
import java.util.Map;

public abstract class Structure<C extends Feature.Config, D extends Feature.Data<?>> extends Feature<C, D> {
    protected Biome biome;
    public static Map<Class<? extends Structure>, String> CLASS_TO_NAME = new HashMap();

    public abstract boolean isValidBiome(Biome biome);

    static {
        CLASS_TO_NAME.put(BastionRemnant.class, "bastion_remnant");
        CLASS_TO_NAME.put(BuriedTreasure.class, "buried_treasure");
        CLASS_TO_NAME.put(DesertPyramid.class, "desert_pyramid");
        CLASS_TO_NAME.put(EndCity.class, "end_city");
        CLASS_TO_NAME.put(Fortress.class, "fortress");
        CLASS_TO_NAME.put(Igloo.class, "igloo");
        CLASS_TO_NAME.put(JunglePyramid.class, "jungle_pyramid");
        CLASS_TO_NAME.put(Mansion.class, "mansion");
        CLASS_TO_NAME.put(Mineshaft.class, "mineshaft");
        CLASS_TO_NAME.put(Monument.class, "monument");
        CLASS_TO_NAME.put(NetherFossil.class, "nether_fossil");
        CLASS_TO_NAME.put(OceanRuin.class, "ocean_ruin");
        CLASS_TO_NAME.put(PillagerOutpost.class, "pillager_outpost");
        CLASS_TO_NAME.put(RuinedPortal.class, "ruined_portal");
        CLASS_TO_NAME.put(Shipwreck.class, "shipwreck");
        CLASS_TO_NAME.put(Stronghold.class, "stronghold");
        CLASS_TO_NAME.put(SwampHut.class, "swamp_hut");
        CLASS_TO_NAME.put(Village.class, "village");
    }

    public Structure(C config, MCVersion version) {
        super(config, version);
    }

    public static String getName(Class<? extends Structure> structure) {
        return CLASS_TO_NAME.get(structure);
    }

    public static String name() {
        return "structure";
    }

    @Override
    public String getName() {
        return getName(getClass());
    }

    public Biome getBiome() {
        return this.biome;
    }

    @Override
    public final boolean canSpawn(D data, BiomeSource source) {
        return canSpawn(data.chunkX, data.chunkZ, source);
    }

    public boolean canSpawn(CPos cPos, BiomeSource source) {
        return canSpawn(cPos.getX(), cPos.getZ(), source);
    }

    public boolean canSpawn(int chunkX, int chunkZ, BiomeSource source) {
        if (getVersion().isOlderThan(MCVersion.v1_16)) {
            this.biome = source.getBiome((chunkX << 4) + 9, 0, (chunkZ << 4) + 9);
        } else {
            this.biome = source.getBiomeForNoiseGen((chunkX << 2) + 2, 0, (chunkZ << 2) + 2);
        }
        return isValidBiome(this.biome);
    }

    @Override
    public final boolean canGenerate(D data, TerrainGenerator generator) {
        return canGenerate(data.chunkX, data.chunkZ, generator);
    }

    public boolean canGenerate(CPos cPos, TerrainGenerator generator) {
        return canGenerate(cPos.getX(), cPos.getZ(), generator);
    }

    public boolean canGenerate(int chunkX, int chunkZ, TerrainGenerator generator) {
        return isValidTerrain(generator, chunkX, chunkZ);
    }

    public boolean isValidTerrain(TerrainGenerator generator, int chunkX, int chunkZ) {
        return true;
    }
}
