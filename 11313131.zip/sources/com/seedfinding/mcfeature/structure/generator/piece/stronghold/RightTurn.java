package com.seedfinding.mcfeature.structure.generator.piece.stronghold;

import com.seedfinding.mccore.util.block.BlockBox;
import com.seedfinding.mccore.util.block.BlockDirection;
import com.seedfinding.mccore.util.pos.BPos;
import com.seedfinding.mcfeature.structure.Stronghold;
import com.seedfinding.mcfeature.structure.generator.structure.StrongholdGenerator;
import com.seedfinding.mcseed.rand.JRand;
import java.util.List;

public class RightTurn extends Stronghold.Piece {
    public RightTurn(int pieceId, JRand rand, BlockBox boundingBox, BlockDirection facing) {
        super(pieceId);
        setOrientation(facing);
        rand.nextInt(5);
        this.boundingBox = boundingBox;
    }

    public static RightTurn createPiece(List<Stronghold.Piece> pieces, JRand rand, int x, int y, int z, BlockDirection facing, int pieceId) {
        BlockBox box = BlockBox.rotated(x, y, z, -1, -1, 0, 5, 5, 5, facing.getRotation());
        if (Stronghold.Piece.isHighEnough(box) && Stronghold.Piece.getNextIntersectingPiece(pieces, box) == null) {
            return new RightTurn(pieceId, rand, box, facing);
        }
        return null;
    }

    @Override
    public void populatePieces(StrongholdGenerator gen, Start start, List<Stronghold.Piece> pieces, JRand rand) {
        BlockDirection facing = getFacing();
        if (facing != BlockDirection.NORTH && facing != BlockDirection.EAST) {
            generateSmallDoorChildrenLeft(gen, start, pieces, rand, 1, 1);
        } else {
            generateSmallDoorChildRight(gen, start, pieces, rand, 1, 1);
        }
    }

    @Override
    public boolean process(JRand rand, BPos pos) {
        skipWithRandomized(rand, 0, 0, 0, 4, 4, 4, true);
        return true;
    }
}
