package com.seedfinding.mcfeature.structure.generator.piece.stronghold;

import com.seedfinding.mccore.util.block.BlockBox;
import com.seedfinding.mccore.util.block.BlockDirection;
import com.seedfinding.mccore.util.pos.BPos;
import com.seedfinding.mcfeature.structure.Stronghold;
import com.seedfinding.mcfeature.structure.generator.structure.StrongholdGenerator;
import com.seedfinding.mcseed.rand.JRand;
import java.util.List;

public class PortalRoom extends Stronghold.Piece {
    private final boolean[] eyes;

    public PortalRoom(int pieceId, BlockBox boundingBox, BlockDirection facing) {
        super(pieceId);
        this.eyes = new boolean[12];
        setOrientation(facing);
        this.boundingBox = boundingBox;
    }

    public static PortalRoom createPiece(List<Stronghold.Piece> pieces, int x, int y, int z, BlockDirection facing, int pieceId) {
        BlockBox box = BlockBox.rotated(x, y, z, -4, -1, 0, 11, 8, 16, facing.getRotation());
        if (Stronghold.Piece.isHighEnough(box) && Stronghold.Piece.getNextIntersectingPiece(pieces, box) == null) {
            return new PortalRoom(pieceId, box, facing);
        }
        return null;
    }

    @Override
    public void populatePieces(StrongholdGenerator gen, Start start, List<Stronghold.Piece> pieces, JRand rand) {
        if (start != null) {
            start.portalRoom = this;
        }
    }

    @Override
    public boolean process(JRand rand, BPos pos) {
        skipWithRandomized(rand, 0, 0, 0, 10, 7, 15, false);
        skipWithRandomized(rand, 1, 6, 1, 1, 6, 14, false);
        skipWithRandomized(rand, 9, 6, 1, 9, 6, 14, false);
        skipWithRandomized(rand, 2, 6, 1, 8, 6, 2, false);
        skipWithRandomized(rand, 2, 6, 14, 8, 6, 14, false);
        skipWithRandomized(rand, 1, 1, 1, 2, 1, 4, false);
        skipWithRandomized(rand, 8, 1, 1, 9, 1, 4, false);
        skipWithRandomized(rand, 3, 1, 8, 7, 1, 12, false);
        skipWithRandomized(rand, 4, 1, 5, 6, 1, 7, false);
        skipWithRandomized(rand, 4, 2, 6, 6, 2, 7, false);
        skipWithRandomized(rand, 4, 3, 7, 6, 3, 7, false);
        for (int i = 0; i < this.eyes.length; i++) {
            this.eyes[i] = rand.nextFloat() > 0.9f;
        }
        return true;
    }

    public boolean[] getEyes() {
        return this.eyes;
    }
}
