package com.seedfinding.mcfeature.structure.generator;

import com.seedfinding.mcbiome.source.BiomeSource;
import com.seedfinding.mccore.rand.ChunkRand;
import com.seedfinding.mccore.state.Dimension;
import com.seedfinding.mccore.util.data.Pair;
import com.seedfinding.mccore.util.pos.BPos;
import com.seedfinding.mccore.util.pos.CPos;
import com.seedfinding.mccore.version.MCVersion;
import com.seedfinding.mcfeature.loot.ChestContent;
import com.seedfinding.mcfeature.loot.LootTable;
import com.seedfinding.mcfeature.loot.entry.ItemEntry;
import com.seedfinding.mcfeature.loot.item.Item;
import com.seedfinding.mcterrain.TerrainGenerator;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public abstract class Generator {
    protected final MCVersion version;
    public static final ConcurrentHashMap<String, LootTable> LOOT_TABLE_CACHE = new ConcurrentHashMap<>();

    @FunctionalInterface
    public interface GeneratorFactory<T extends Generator> {
        T create(MCVersion mCVersion);
    }

    public abstract boolean generate(TerrainGenerator terrainGenerator, int i, int i2, ChunkRand chunkRand);

    public abstract List<Pair<ILootType, BPos>> getChestsPos();

    public abstract List<Pair<ILootType, BPos>> getLootPos();

    public abstract ILootType[] getLootTypes();

    public Generator(MCVersion version) {
        this.version = version;
    }

    public MCVersion getVersion() {
        return this.version;
    }

    public boolean generate(long worldSeed, Dimension dimension, int chunkX, int chunkZ) {
        BiomeSource biomeSource = BiomeSource.m8of(dimension, getVersion(), worldSeed);
        TerrainGenerator generator = TerrainGenerator.m41of(dimension, biomeSource);
        return generate(generator, chunkX, chunkZ);
    }

    public boolean generate(TerrainGenerator generator, CPos cPos) {
        return generate(generator, cPos, new ChunkRand());
    }

    public boolean generate(TerrainGenerator generator, int chunkX, int chunkZ) {
        return generate(generator, chunkX, chunkZ, new ChunkRand());
    }

    public boolean generate(TerrainGenerator generator, CPos cPos, ChunkRand rand) {
        return generate(generator, cPos.getX(), cPos.getZ(), rand);
    }

    public List<Pair<ILootType, CPos>> getChestsChunkPos() {
        return (List) getChestsPos().stream().map(e -> {
            return new Pair((ILootType) e.getFirst(), ((BPos) e.getSecond()).toChunkPos());
        }).collect(Collectors.toList());
    }

    public interface ILootType {
        LootTable getLootTableUncached(MCVersion mCVersion);

        ChestContent.ChestType getChestType();

        default LootTable getLootTable(MCVersion version) {
            String className = getClass().getCanonicalName();
            String enumName = ((Enum) this).name();
            return Generator.LOOT_TABLE_CACHE.computeIfAbsent(className + enumName + version.name(), ignored -> {
                return getLootTableUncached(version);
            });
        }
    }

    public Set<Item> getPossibleLootItems() {
        Set<Item> items = new HashSet<>();
        ILootType[] lootTypes = getLootTypes();
        for (ILootType lootType : lootTypes) {
            LootTable lootTable = lootType.getLootTable(getVersion());
            if (lootTable != null) {
                items.addAll((Collection) Arrays.stream(lootTable.lootPools).map(e -> {
                    return e.lootEntries;
                }).flatMap((v0) -> {
                    return Stream.of(v0);
                }).filter(e2 -> {
                    return e2 instanceof ItemEntry;
                }).map(e3 -> {
                    return ((ItemEntry) e3).item;
                }).collect(Collectors.toList()));
            }
        }
        return items;
    }
}
