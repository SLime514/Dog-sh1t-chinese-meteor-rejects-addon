package com.seedfinding.mcfeature.structure.device.node;

import com.seedfinding.mccore.rand.seed.RegionSeed;
import com.seedfinding.mcfeature.structure.RegionStructure;
import com.seedfinding.mcfeature.structure.TriangularStructure;
import com.seedfinding.mcfeature.structure.device.CoordChecker;
import com.seedfinding.mcfeature.structure.device.ParentInfo;
import com.seedfinding.mcfeature.structure.device.node.Node;
import com.seedfinding.mcmath.util.Mth;
import com.seedfinding.mcseed.lcg.LCG;
import java.util.Set;

public class TriangularNode extends Node<RegionStructure.Config> {
    private final int peak;
    private final Analyser analyser;

    protected TriangularNode(RegionStructure.Config config, int regionX, int regionZ, CoordChecker checker) {
        super(config, regionX, regionZ, checker);
        this.peak = ((RegionStructure.Config) this.config).spacing - ((RegionStructure.Config) this.config).separation;
        this.analyser = new Analyser(this);
    }

    protected TriangularNode(TriangularStructure<?> structure, int regionX, int regionZ, CoordChecker checker) {
        this((RegionStructure.Config) structure.getConfig(), regionX, regionZ, checker);
    }

    public static TriangularNode head(TriangularStructure<?> structure, int regionX, int regionZ, CoordChecker.Head checker) {
        return new TriangularNode(structure, regionX, regionZ, checker);
    }

    public static TriangularNode head(RegionStructure.Config config, int regionX, int regionZ, CoordChecker.Head checker) {
        return new TriangularNode(config, regionX, regionZ, checker);
    }

    public static TriangularNode node(TriangularStructure<?> structure, int regionX, int regionZ, CoordChecker checker) {
        return new TriangularNode(structure, regionX, regionZ, checker);
    }

    public static TriangularNode node(RegionStructure.Config config, int regionX, int regionZ, CoordChecker checker) {
        return new TriangularNode(config, regionX, regionZ, checker);
    }

    public int getPeak() {
        return this.peak;
    }

    @Override
    public Set<Integer> getLiftingPoints() {
        Set<Integer> points = super.getLiftingPoints();
        if (this.analyser.canLift()) {
            points.add(Integer.valueOf(17 + this.analyser.getBits()));
        }
        return points;
    }

    @Override
    public boolean test(long structureSeed, int bits, ParentInfo parent) {
        long regionSeed = structureSeed + (RegionSeed.f35A * this.regionX) + (RegionSeed.f36B * this.regionZ) + ((RegionStructure.Config) this.config).salt;
        int mask = bits == 48 ? (int) Mth.MASK_32 : this.analyser.getMask();
        long regionSeed2 = LCG.JAVA.nextSeed(regionSeed ^ LCG.JAVA.multiplier);
        int x = (((int) (regionSeed2 >>> 17)) % getPeak()) & mask;
        long regionSeed3 = LCG.JAVA.nextSeed(regionSeed2);
        int x2 = (x + ((((int) (regionSeed3 >>> 17)) % getPeak()) & mask)) / 2;
        long regionSeed4 = LCG.JAVA.nextSeed(regionSeed3);
        int z = (((((int) (regionSeed4 >>> 17)) % getPeak()) & mask) + ((((int) (LCG.JAVA.nextSeed(regionSeed4) >>> 17)) % getPeak()) & mask)) / 2;
        if (bits != 48) {
            x2 &= this.analyser.getMask();
            z &= this.analyser.getMask();
        }
        if (this.checker.test(x2, z, mask, parent)) {
            return super.test(structureSeed, bits, new ParentInfo(parent, x2, z, true));
        }
        return false;
    }

    public static class Analyser extends Node.Analyser<TriangularNode> {
        private boolean canLift;
        private int bits;
        private int mask;

        public Analyser(TriangularNode node) {
            super(node);
            if (Mth.isPowerOf2(((TriangularNode) this.node).getPeak())) {
                return;
            }
            this.bits = Long.numberOfTrailingZeros(((TriangularNode) this.node).getPeak());
            if (this.bits == 0) {
                return;
            }
            this.mask = (1 << this.bits) - 1;
            this.canLift = true;
        }

        public boolean canLift() {
            return this.canLift;
        }

        public int getBits() {
            return this.bits;
        }

        public int getMask() {
            return this.mask;
        }
    }
}
