package com.seedfinding.mcfeature.structure.device;

public class ParentInfo {
    public final ParentInfo parent;

    public final int f62x;

    public final int f63z;
    public final boolean present;

    public ParentInfo(ParentInfo parent, int x, int z, boolean present) {
        this.parent = parent;
        this.f62x = x;
        this.f63z = z;
        this.present = present;
    }
}
