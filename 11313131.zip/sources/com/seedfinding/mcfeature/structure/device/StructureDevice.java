package com.seedfinding.mcfeature.structure.device;

import com.seedfinding.mccore.util.data.ThreadPool;
import com.seedfinding.mcfeature.Feature;
import com.seedfinding.mcfeature.structure.device.node.Node;
import com.seedfinding.mcmath.util.Mth;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.function.LongConsumer;

public class StructureDevice {
    public final List<Node<?>> heads;
    private final ThreadPool pool;

    public StructureDevice() {
        this(1);
    }

    public StructureDevice(int threadCount) {
        this.heads = new ArrayList();
        this.pool = new ThreadPool(threadCount);
    }

    public <C extends Feature.Config> Node<C> addBranch(Node<C> node) {
        this.heads.add(node);
        return node;
    }

    public void findSeeds(LongConsumer onSeedFound, int bits) throws InterruptedException {
        List<BitGroup> groups = groupRestrictions();
        BitGroup entry = groups.get(0);
        if (entry.bits < 48) {
            search(entry, 0L, 0, onSeedFound, bits);
            this.pool.awaitCompletion();
            this.pool.shutdown();
            return;
        }
        throw new UnsupportedOperationException();
    }

    public void search(BitGroup group, long baseSeed, int bits, LongConsumer onSeedFound, int totalBits) throws InterruptedException {
        System.out.println("[" + baseSeed + "] is good for the lowest " + bits + " bits! Lifting the next " + (group.bits - bits) + " bits...");
        long searchSpace = Mth.getPow2(group.bits - bits);
        long j = 0;
        while (true) {
            long i = j;
            if (i < searchSpace) {
                long seed = baseSeed | (i << bits);
                if (group.testSeed(seed)) {
                    if (group.next == null || group.bits >= totalBits) {
                        onSeedFound.accept(seed);
                    } else {
                        this.pool.run(() -> {
                            search(group.next, seed, group.bits, onSeedFound, totalBits);
                        });
                        this.pool.awaitFreeThread();
                    }
                }
                j = i + 1;
            } else {
                return;
            }
        }
    }

    private List<BitGroup> groupRestrictions() {
        Map<Integer, BitGroup> raw = new TreeMap<>((Comparator<? super Integer>) (v0, v1) -> {
            return Integer.compare(v0, v1);
        });
        for (Node<?> head : this.heads) {
            Iterator<Integer> it = head.getLiftingPoints().iterator();
            while (it.hasNext()) {
                int bitPoint = it.next().intValue();
                raw.computeIfAbsent(Integer.valueOf(bitPoint), i -> {
                    return new BitGroup(i.intValue(), new ArrayList());
                }).heads.add(head);
            }
        }
        List<BitGroup> result = new ArrayList<>(raw.values());
        for (int i2 = 0; i2 < result.size() - 1; i2++) {
            result.get(i2).next = result.get(i2 + 1);
        }
        return result;
    }

    public static final class BitGroup {
        public final int bits;
        public final List<Node<?>> heads;
        public BitGroup next;

        public BitGroup(int bits, List<Node<?>> heads) {
            this.bits = bits;
            this.heads = heads;
        }

        public boolean testSeed(long seed) {
            for (Node<?> head : this.heads) {
                if (head.test(seed, this.bits, null)) {
                    return true;
                }
            }
            return false;
        }

        public String toString() {
            return "lift " + this.bits + " bits: " + this.heads;
        }
    }
}
