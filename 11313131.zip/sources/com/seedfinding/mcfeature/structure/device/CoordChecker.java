package com.seedfinding.mcfeature.structure.device;

@FunctionalInterface
public interface CoordChecker {
    boolean test(int i, int i2, long j, ParentInfo parentInfo);

    @FunctionalInterface
    public interface Head extends CoordChecker {
        boolean test(int i, int i2, long j);

        @Override
        default boolean test(int x, int z, long mask, ParentInfo parent) {
            return test(x, z, mask);
        }
    }
}
