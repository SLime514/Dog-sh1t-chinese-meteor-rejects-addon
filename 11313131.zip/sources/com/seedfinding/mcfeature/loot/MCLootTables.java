package com.seedfinding.mcfeature.loot;

import com.seedfinding.mcbiome.biome.Biomes;
import com.seedfinding.mccore.version.MCVersion;
import com.seedfinding.mcfeature.loot.condition.BiomeCondition;
import com.seedfinding.mcfeature.loot.condition.OpenWaterCondition;
import com.seedfinding.mcfeature.loot.effect.Effects;
import com.seedfinding.mcfeature.loot.entry.EmptyEntry;
import com.seedfinding.mcfeature.loot.entry.ItemEntry;
import com.seedfinding.mcfeature.loot.entry.TableEntry;
import com.seedfinding.mcfeature.loot.function.ApplyDamageFunction;
import com.seedfinding.mcfeature.loot.function.EffectFunction;
import com.seedfinding.mcfeature.loot.function.EnchantRandomlyFunction;
import com.seedfinding.mcfeature.loot.function.EnchantWithLevelsFunction;
import com.seedfinding.mcfeature.loot.function.SetCountFunction;
import com.seedfinding.mcfeature.loot.item.Items;
import com.seedfinding.mcfeature.loot.roll.ConstantRoll;
import com.seedfinding.mcfeature.loot.roll.UniformRoll;
import java.util.function.Supplier;

public class MCLootTables {
    public static final Supplier<LootTable> NULL = () -> {
        return new LootTable(new LootPool[0]);
    };
    public static final Supplier<LootTable> ABANDONED_MINESHAFT_CHEST = () -> {
        return new LootTable(new LootPool(new ConstantRoll(1), new ItemEntry(Items.GOLDEN_APPLE, 20), new ItemEntry(Items.ENCHANTED_GOLDEN_APPLE), new ItemEntry(Items.NAME_TAG, 30), new ItemEntry(Items.ENCHANTED_BOOK, 10).apply(version -> {
            return new EnchantRandomlyFunction(Items.ENCHANTED_BOOK).apply(version);
        }), new ItemEntry(Items.IRON_PICKAXE, 5), new EmptyEntry(5)), new LootPool(new UniformRoll(2.0f, 4.0f), new ItemEntry(Items.IRON_INGOT, 10).apply(version2 -> {
            return SetCountFunction.uniform(1.0f, 5.0f);
        }), new ItemEntry(Items.GOLD_INGOT, 5).apply(version3 -> {
            return SetCountFunction.uniform(1.0f, 3.0f);
        }), new ItemEntry(Items.REDSTONE, 5).apply(version4 -> {
            return SetCountFunction.uniform(4.0f, 9.0f);
        }), new ItemEntry(Items.LAPIS_LAZULI, 5).apply(version5 -> {
            return SetCountFunction.uniform(4.0f, 9.0f);
        }), new ItemEntry(Items.DIAMOND, 3).apply(version6 -> {
            return SetCountFunction.uniform(1.0f, 2.0f);
        }), new ItemEntry(Items.COAL, 10).apply(version7 -> {
            return SetCountFunction.uniform(3.0f, 8.0f);
        }), new ItemEntry(Items.BREAD, 15).apply(version8 -> {
            return SetCountFunction.uniform(1.0f, 3.0f);
        }), new ItemEntry(Items.GLOW_BERRIES, 15).apply(version9 -> {
            return SetCountFunction.uniform(3.0f, 6.0f);
        }).introducedVersion(MCVersion.v1_17), new ItemEntry(Items.MELON_SEEDS, 10).apply(version10 -> {
            return SetCountFunction.uniform(2.0f, 4.0f);
        }), new ItemEntry(Items.PUMPKIN_SEEDS, 10).apply(version11 -> {
            return SetCountFunction.uniform(2.0f, 4.0f);
        }), new ItemEntry(Items.BEETROOT_SEEDS, 10).apply(version12 -> {
            return SetCountFunction.uniform(2.0f, 4.0f);
        })), new LootPool(new ConstantRoll(3), new ItemEntry(Items.RAIL, 20).apply(version13 -> {
            return SetCountFunction.uniform(4.0f, 8.0f);
        }), new ItemEntry(Items.POWERED_RAIL, 5).apply(version14 -> {
            return SetCountFunction.uniform(1.0f, 4.0f);
        }), new ItemEntry(Items.DETECTOR_RAIL, 5).apply(version15 -> {
            return SetCountFunction.uniform(1.0f, 4.0f);
        }), new ItemEntry(Items.ACTIVATOR_RAIL, 5).apply(version16 -> {
            return SetCountFunction.uniform(1.0f, 4.0f);
        }), new ItemEntry(Items.TORCH, 15).apply(version17 -> {
            return SetCountFunction.uniform(1.0f, 16.0f);
        })));
    };
    public static final Supplier<LootTable> BASTION_BRIDGE_CHEST = () -> {
        return new LootTable(new LootPool(new ConstantRoll(1), new ItemEntry(Items.LODESTONE).apply(version -> {
            return SetCountFunction.constant(1);
        })), new LootPool(new UniformRoll(1.0f, 2.0f), new ItemEntry(Items.CROSSBOW).apply(version2 -> {
            return new ApplyDamageFunction();
        }, version3 -> {
            return new EnchantRandomlyFunction(Items.CROSSBOW).apply(version3);
        }), new ItemEntry(Items.SPECTRAL_ARROW).apply(version4 -> {
            return SetCountFunction.uniform(2.0f, 12.0f);
        }), new ItemEntry(Items.GILDED_BLACKSTONE).apply(version5 -> {
            return SetCountFunction.uniform(5.0f, 8.0f);
        }), new ItemEntry(Items.CRYING_OBSIDIAN).apply(version6 -> {
            return SetCountFunction.uniform(3.0f, 8.0f);
        }), new ItemEntry(Items.GOLD_BLOCK).apply(version7 -> {
            return SetCountFunction.constant(1);
        }), new ItemEntry(Items.GOLD_INGOT).apply(version8 -> {
            return SetCountFunction.uniform(2.0f, 8.0f);
        }), new ItemEntry(Items.IRON_INGOT).apply(version9 -> {
            return SetCountFunction.uniform(2.0f, 8.0f);
        }), new ItemEntry(Items.GOLDEN_SWORD).apply(version10 -> {
            return SetCountFunction.constant(1);
        }), new ItemEntry(Items.GOLDEN_CHESTPLATE).apply(version11 -> {
            return SetCountFunction.constant(1);
        }).apply(version12 -> {
            return new EnchantRandomlyFunction(Items.GOLDEN_CHESTPLATE).apply(version12);
        }), new ItemEntry(Items.GOLDEN_HELMET).apply(version13 -> {
            return SetCountFunction.constant(1);
        }).apply(version14 -> {
            return new EnchantRandomlyFunction(Items.GOLDEN_HELMET).apply(version14);
        }), new ItemEntry(Items.GOLDEN_LEGGINGS).apply(version15 -> {
            return SetCountFunction.constant(1);
        }).apply(version16 -> {
            return new EnchantRandomlyFunction(Items.GOLDEN_LEGGINGS).apply(version16);
        }), new ItemEntry(Items.GOLDEN_BOOTS).apply(version17 -> {
            return SetCountFunction.constant(1);
        }).apply(version18 -> {
            return new EnchantRandomlyFunction(Items.GOLDEN_BOOTS).apply(version18);
        })), new LootPool(new UniformRoll(2.0f, 4.0f), new ItemEntry(Items.STRING).apply(version19 -> {
            return SetCountFunction.uniform(1.0f, 6.0f);
        }), new ItemEntry(Items.LEATHER).apply(version20 -> {
            return SetCountFunction.uniform(1.0f, 3.0f);
        }), new ItemEntry(Items.ARROW).apply(version21 -> {
            return SetCountFunction.uniform(5.0f, 17.0f);
        }), new ItemEntry(Items.IRON_NUGGET).apply(version22 -> {
            return SetCountFunction.uniform(2.0f, 6.0f);
        }), new ItemEntry(Items.GOLD_NUGGET).apply(version23 -> {
            return SetCountFunction.uniform(2.0f, 6.0f);
        })));
    };
    public static final Supplier<LootTable> BASTION_HOGLIN_STABLE_CHEST = () -> {
        return new LootTable(new LootPool(new ConstantRoll(1), new ItemEntry(Items.DIAMOND_SHOVEL, 5).apply(version -> {
            return new ApplyDamageFunction();
        }, version2 -> {
            return new EnchantRandomlyFunction(Items.DIAMOND_SHOVEL).apply(version2);
        }), new ItemEntry(Items.NETHERITE_SCRAP, 2).apply(version3 -> {
            return SetCountFunction.constant(1);
        }), new ItemEntry(Items.ANCIENT_DEBRIS, 3).apply(version4 -> {
            return SetCountFunction.constant(1);
        }), new ItemEntry(Items.SADDLE, 10).apply(version5 -> {
            return SetCountFunction.constant(1);
        }), new ItemEntry(Items.GOLD_BLOCK, 25).apply(version6 -> {
            return SetCountFunction.uniform(2.0f, 4.0f);
        }), new ItemEntry(Items.GOLDEN_HOE, 15).apply(version7 -> {
            return SetCountFunction.constant(1);
        }).apply(version8 -> {
            return new EnchantRandomlyFunction(Items.GOLDEN_HOE).apply(version8);
        }), new EmptyEntry(45)), new LootPool(new UniformRoll(3.0f, 4.0f), new ItemEntry(Items.GLOWSTONE).apply(version9 -> {
            return SetCountFunction.uniform(1.0f, 5.0f);
        }), new ItemEntry(Items.GILDED_BLACKSTONE).apply(version10 -> {
            return SetCountFunction.uniform(1.0f, 5.0f);
        }), new ItemEntry(Items.SOUL_SAND).apply(version11 -> {
            return SetCountFunction.uniform(2.0f, 7.0f);
        }), new ItemEntry(Items.CRIMSON_NYLIUM).apply(version12 -> {
            return SetCountFunction.uniform(2.0f, 7.0f);
        }), new ItemEntry(Items.GOLD_NUGGET).apply(version13 -> {
            return SetCountFunction.uniform(2.0f, 8.0f);
        }), new ItemEntry(Items.LEATHER).apply(version14 -> {
            return SetCountFunction.uniform(1.0f, 3.0f);
        }), new ItemEntry(Items.ARROW).apply(version15 -> {
            return SetCountFunction.uniform(5.0f, 17.0f);
        }), new ItemEntry(Items.STRING).apply(version16 -> {
            return SetCountFunction.uniform(3.0f, 8.0f);
        }), new ItemEntry(Items.PORKCHOP).apply(version17 -> {
            return SetCountFunction.uniform(2.0f, 5.0f);
        }), new ItemEntry(Items.COOKED_PORKCHOP).apply(version18 -> {
            return SetCountFunction.uniform(2.0f, 5.0f);
        }), new ItemEntry(Items.CRIMSON_FUNGUS).apply(version19 -> {
            return SetCountFunction.uniform(2.0f, 7.0f);
        }), new ItemEntry(Items.CRIMSON_ROOTS).apply(version20 -> {
            return SetCountFunction.uniform(2.0f, 7.0f);
        })));
    };
    public static final Supplier<LootTable> BASTION_OTHER_CHEST = () -> {
        return new LootTable(new LootPool(new ConstantRoll(1), new ItemEntry(Items.CROSSBOW, 12).apply(version -> {
            return new ApplyDamageFunction();
        }, version2 -> {
            return new EnchantRandomlyFunction(Items.CROSSBOW).apply(version2);
        }), new ItemEntry(Items.ANCIENT_DEBRIS, 2).apply(version3 -> {
            return SetCountFunction.constant(1);
        }), new ItemEntry(Items.NETHERITE_SCRAP, 2).apply(version4 -> {
            return SetCountFunction.constant(1);
        }), new ItemEntry(Items.SPECTRAL_ARROW, 16).apply(version5 -> {
            return SetCountFunction.uniform(2.0f, 15.0f);
        }), new ItemEntry(Items.PIGLIN_BANNER_PATTERN, 5).apply(version6 -> {
            return SetCountFunction.constant(1);
        }), new ItemEntry(Items.MUSIC_DISC_PIGSTEP, 3).apply(version7 -> {
            return SetCountFunction.constant(1);
        }), new ItemEntry(Items.ENCHANTED_BOOK, 10).apply(version8 -> {
            return new EnchantRandomlyFunction(Items.ENCHANTED_BOOK, true, false).apply(version8);
        }), new EmptyEntry(50)), new LootPool(new ConstantRoll(2), new ItemEntry(Items.GOLDEN_BOOTS).apply(version9 -> {
            return SetCountFunction.constant(1);
        }).apply(version10 -> {
            return new EnchantRandomlyFunction(Items.GOLDEN_BOOTS, true, false).apply(version10);
        }), new ItemEntry(Items.GOLD_BLOCK).apply(version11 -> {
            return SetCountFunction.constant(1);
        }), new ItemEntry(Items.CROSSBOW).apply(version12 -> {
            return SetCountFunction.constant(1);
        }), new ItemEntry(Items.GOLD_INGOT).apply(version13 -> {
            return SetCountFunction.uniform(1.0f, 6.0f);
        }), new ItemEntry(Items.IRON_INGOT).apply(version14 -> {
            return SetCountFunction.uniform(1.0f, 6.0f);
        }), new ItemEntry(Items.GOLDEN_SWORD).apply(version15 -> {
            return SetCountFunction.constant(1);
        }), new ItemEntry(Items.GOLDEN_CHESTPLATE).apply(version16 -> {
            return SetCountFunction.constant(1);
        }), new ItemEntry(Items.GOLDEN_HELMET).apply(version17 -> {
            return SetCountFunction.constant(1);
        }), new ItemEntry(Items.GOLDEN_LEGGINGS).apply(version18 -> {
            return SetCountFunction.constant(1);
        }), new ItemEntry(Items.GOLDEN_BOOTS).apply(version19 -> {
            return SetCountFunction.constant(1);
        }), new EmptyEntry(2)), new LootPool(new UniformRoll(3.0f, 5.0f), new ItemEntry(Items.CRYING_OBSIDIAN).apply(version20 -> {
            return SetCountFunction.uniform(1.0f, 5.0f);
        }), new ItemEntry(Items.GILDED_BLACKSTONE).apply(version21 -> {
            return SetCountFunction.uniform(1.0f, 5.0f);
        }), new ItemEntry(Items.CHAIN).apply(version22 -> {
            return SetCountFunction.uniform(2.0f, 10.0f);
        }), new ItemEntry(Items.MAGMA_CREAM).apply(version23 -> {
            return SetCountFunction.uniform(2.0f, 6.0f);
        }), new ItemEntry(Items.BONE_BLOCK).apply(version24 -> {
            return SetCountFunction.uniform(3.0f, 6.0f);
        }), new ItemEntry(Items.IRON_NUGGET).apply(version25 -> {
            return SetCountFunction.uniform(2.0f, 8.0f);
        }), new ItemEntry(Items.OBSIDIAN).apply(version26 -> {
            return SetCountFunction.uniform(4.0f, 6.0f);
        }), new ItemEntry(Items.GOLD_NUGGET).apply(version27 -> {
            return SetCountFunction.uniform(2.0f, 8.0f);
        }), new ItemEntry(Items.STRING).apply(version28 -> {
            return SetCountFunction.uniform(4.0f, 6.0f);
        }), new ItemEntry(Items.ARROW, 2).apply(version29 -> {
            return SetCountFunction.uniform(5.0f, 17.0f);
        })));
    };
    public static final Supplier<LootTable> BASTION_TREASURE_CHEST = () -> {
        return new LootTable(new LootPool(new UniformRoll(1.0f, 2.0f), new ItemEntry(Items.NETHERITE_INGOT, 10).apply(version -> {
            return SetCountFunction.constant(1);
        }), new ItemEntry(Items.ANCIENT_DEBRIS, 14).apply(version2 -> {
            return SetCountFunction.constant(1);
        }), new ItemEntry(Items.NETHERITE_SCRAP, 10).apply(version3 -> {
            return SetCountFunction.constant(1);
        }), new ItemEntry(Items.ANCIENT_DEBRIS).apply(version4 -> {
            return SetCountFunction.constant(2);
        }), new ItemEntry(Items.DIAMOND_SWORD, 10).apply(version5 -> {
            return new ApplyDamageFunction();
        }, version6 -> {
            return new EnchantRandomlyFunction(Items.DIAMOND_SWORD).apply(version6);
        }), new ItemEntry(Items.DIAMOND_CHESTPLATE, 6).apply(version7 -> {
            return new ApplyDamageFunction();
        }, version8 -> {
            return new EnchantRandomlyFunction(Items.DIAMOND_CHESTPLATE).apply(version8);
        }), new ItemEntry(Items.DIAMOND_HELMET, 6).apply(version9 -> {
            return new ApplyDamageFunction();
        }, version10 -> {
            return new EnchantRandomlyFunction(Items.DIAMOND_HELMET).apply(version10);
        }), new ItemEntry(Items.DIAMOND_LEGGINGS, 6).apply(version11 -> {
            return new ApplyDamageFunction();
        }, version12 -> {
            return new EnchantRandomlyFunction(Items.DIAMOND_LEGGINGS).apply(version12);
        }), new ItemEntry(Items.DIAMOND_BOOTS, 6).apply(version13 -> {
            return new ApplyDamageFunction();
        }, version14 -> {
            return new EnchantRandomlyFunction(Items.DIAMOND_BOOTS).apply(version14);
        }), new ItemEntry(Items.DIAMOND_SWORD, 6).apply(version15 -> {
            return new ApplyDamageFunction();
        }), new ItemEntry(Items.DIAMOND_CHESTPLATE, 5).apply(version16 -> {
            return new ApplyDamageFunction();
        }), new ItemEntry(Items.DIAMOND_HELMET, 5).apply(version17 -> {
            return new ApplyDamageFunction();
        }), new ItemEntry(Items.DIAMOND_BOOTS, 5).apply(version18 -> {
            return new ApplyDamageFunction();
        }), new ItemEntry(Items.DIAMOND_LEGGINGS, 5).apply(version19 -> {
            return new ApplyDamageFunction();
        }), new ItemEntry(Items.DIAMOND, 5).apply(version20 -> {
            return SetCountFunction.uniform(1.0f, 3.0f);
        })), new LootPool(new UniformRoll(2.0f, 4.0f), new ItemEntry(Items.SPECTRAL_ARROW).apply(version21 -> {
            return SetCountFunction.uniform(5.0f, 21.0f);
        }), new ItemEntry(Items.GOLD_BLOCK).apply(version22 -> {
            return SetCountFunction.uniform(2.0f, 5.0f);
        }), new ItemEntry(Items.GOLD_INGOT).apply(version23 -> {
            return SetCountFunction.uniform(3.0f, 9.0f);
        }), new ItemEntry(Items.IRON_INGOT).apply(version24 -> {
            return SetCountFunction.uniform(3.0f, 9.0f);
        }), new ItemEntry(Items.CRYING_OBSIDIAN).apply(version25 -> {
            return SetCountFunction.uniform(1.0f, 5.0f);
        }), new ItemEntry(Items.QUARTZ).apply(version26 -> {
            return SetCountFunction.uniform(8.0f, 23.0f);
        }), new ItemEntry(Items.GILDED_BLACKSTONE).apply(version27 -> {
            return SetCountFunction.uniform(1.0f, 5.0f);
        }), new ItemEntry(Items.MAGMA_CREAM).apply(version28 -> {
            return SetCountFunction.uniform(2.0f, 8.0f);
        }), new ItemEntry(Items.IRON_NUGGET).apply(version29 -> {
            return SetCountFunction.uniform(8.0f, 16.0f);
        })));
    };
    public static final Supplier<LootTable> BURIED_TREASURE_CHEST = () -> {
        return new LootTable(new LootPool(new ConstantRoll(1), new ItemEntry(Items.HEART_OF_THE_SEA)), new LootPool(new UniformRoll(5.0f, 8.0f), new ItemEntry(Items.IRON_INGOT, 20).apply(version -> {
            return SetCountFunction.uniform(1.0f, 4.0f);
        }), new ItemEntry(Items.GOLD_INGOT, 10).apply(version2 -> {
            return SetCountFunction.uniform(1.0f, 4.0f);
        }), new ItemEntry(Items.TNT, 5).apply(version3 -> {
            return SetCountFunction.uniform(1.0f, 2.0f);
        })), new LootPool(new UniformRoll(1.0f, 3.0f), new ItemEntry(Items.EMERALD, 5).apply(version4 -> {
            return SetCountFunction.uniform(4.0f, 8.0f);
        }), new ItemEntry(Items.DIAMOND, 5).apply(version5 -> {
            return SetCountFunction.uniform(1.0f, 2.0f);
        }), new ItemEntry(Items.PRISMARINE_CRYSTALS, 5).apply(version6 -> {
            return SetCountFunction.uniform(1.0f, 5.0f);
        })), new LootPool(new UniformRoll(0.0f, 1.0f), new ItemEntry(Items.LEATHER_CHESTPLATE), new ItemEntry(Items.IRON_SWORD)), new LootPool(new ConstantRoll(2), new ItemEntry(Items.COOKED_COD).apply(version7 -> {
            return SetCountFunction.uniform(2.0f, 4.0f);
        }), new ItemEntry(Items.COOKED_SALMON).apply(version8 -> {
            return SetCountFunction.uniform(2.0f, 4.0f);
        })));
    };
    public static final Supplier<LootTable> DESERT_PYRAMID_CHEST = () -> {
        return new LootTable(new LootPool(new UniformRoll(2.0f, 4.0f), new ItemEntry(Items.DIAMOND, 5).apply(version -> {
            return SetCountFunction.uniform(1.0f, 3.0f);
        }), new ItemEntry(Items.IRON_INGOT, 15).apply(version2 -> {
            return SetCountFunction.uniform(1.0f, 5.0f);
        }), new ItemEntry(Items.GOLD_INGOT, 15).apply(version3 -> {
            return SetCountFunction.uniform(2.0f, 7.0f);
        }), new ItemEntry(Items.EMERALD, 15).apply(version4 -> {
            return SetCountFunction.uniform(1.0f, 3.0f);
        }), new ItemEntry(Items.BONE, 25).apply(version5 -> {
            return SetCountFunction.uniform(4.0f, 6.0f);
        }), new ItemEntry(Items.SPIDER_EYE, 25).apply(version6 -> {
            return SetCountFunction.uniform(1.0f, 3.0f);
        }), new ItemEntry(Items.ROTTEN_FLESH, 25).apply(version7 -> {
            return SetCountFunction.uniform(3.0f, 7.0f);
        }), new ItemEntry(Items.SADDLE, 20), new ItemEntry(Items.IRON_HORSE_ARMOR, 15), new ItemEntry(Items.GOLDEN_HORSE_ARMOR, 10), new ItemEntry(Items.DIAMOND_HORSE_ARMOR, 5), new ItemEntry(Items.ENCHANTED_BOOK, 20).apply(version8 -> {
            return new EnchantRandomlyFunction(Items.ENCHANTED_BOOK).apply(version8);
        }), new ItemEntry(Items.GOLDEN_APPLE, 20), new ItemEntry(Items.ENCHANTED_GOLDEN_APPLE, 2), new EmptyEntry(15)), new LootPool(new ConstantRoll(4), new ItemEntry(Items.BONE, 10).apply(version9 -> {
            return SetCountFunction.uniform(1.0f, 8.0f);
        }), new ItemEntry(Items.GUNPOWDER, 10).apply(version10 -> {
            return SetCountFunction.uniform(1.0f, 8.0f);
        }), new ItemEntry(Items.ROTTEN_FLESH, 10).apply(version11 -> {
            return SetCountFunction.uniform(1.0f, 8.0f);
        }), new ItemEntry(Items.STRING, 10).apply(version12 -> {
            return SetCountFunction.uniform(1.0f, 8.0f);
        }), new ItemEntry(Items.SAND, 10).apply(version13 -> {
            return SetCountFunction.uniform(1.0f, 8.0f);
        })));
    };
    public static final Supplier<LootTable> END_CITY_TREASURE_CHEST = () -> {
        return new LootTable(new LootPool(new UniformRoll(2.0f, 6.0f), new ItemEntry(Items.DIAMOND, 5).apply(version -> {
            return SetCountFunction.uniform(2.0f, 7.0f);
        }), new ItemEntry(Items.IRON_INGOT, 10).apply(version2 -> {
            return SetCountFunction.uniform(4.0f, 8.0f);
        }), new ItemEntry(Items.GOLD_INGOT, 15).apply(version3 -> {
            return SetCountFunction.uniform(2.0f, 7.0f);
        }), new ItemEntry(Items.EMERALD, 2).apply(version4 -> {
            return SetCountFunction.uniform(2.0f, 6.0f);
        }), new ItemEntry(Items.BEETROOT_SEEDS, 5).apply(version5 -> {
            return SetCountFunction.uniform(1.0f, 10.0f);
        }), new ItemEntry(Items.SADDLE, 3), new ItemEntry(Items.IRON_HORSE_ARMOR), new ItemEntry(Items.GOLDEN_HORSE_ARMOR), new ItemEntry(Items.DIAMOND_HORSE_ARMOR), new ItemEntry(Items.DIAMOND_SWORD, 3).apply(version6 -> {
            return new EnchantWithLevelsFunction(Items.DIAMOND_SWORD, 20, 39, true).apply(version6);
        }), new ItemEntry(Items.DIAMOND_BOOTS, 3).apply(version7 -> {
            return new EnchantWithLevelsFunction(Items.DIAMOND_BOOTS, 20, 39, true).apply(version7);
        }), new ItemEntry(Items.DIAMOND_CHESTPLATE, 3).apply(version8 -> {
            return new EnchantWithLevelsFunction(Items.DIAMOND_CHESTPLATE, 20, 39, true).apply(version8);
        }), new ItemEntry(Items.DIAMOND_LEGGINGS, 3).apply(version9 -> {
            return new EnchantWithLevelsFunction(Items.DIAMOND_LEGGINGS, 20, 39, true).apply(version9);
        }), new ItemEntry(Items.DIAMOND_HELMET, 3).apply(version10 -> {
            return new EnchantWithLevelsFunction(Items.DIAMOND_HELMET, 20, 39, true).apply(version10);
        }), new ItemEntry(Items.DIAMOND_PICKAXE, 3).apply(version11 -> {
            return new EnchantWithLevelsFunction(Items.DIAMOND_PICKAXE, 20, 39, true).apply(version11);
        }), new ItemEntry(Items.DIAMOND_SHOVEL, 3).apply(version12 -> {
            return new EnchantWithLevelsFunction(Items.DIAMOND_SHOVEL, 20, 39, true).apply(version12);
        }), new ItemEntry(Items.IRON_SWORD, 3).apply(version13 -> {
            return new EnchantWithLevelsFunction(Items.IRON_SWORD, 20, 39, true).apply(version13);
        }), new ItemEntry(Items.IRON_BOOTS, 3).apply(version14 -> {
            return new EnchantWithLevelsFunction(Items.IRON_BOOTS, 20, 39, true).apply(version14);
        }), new ItemEntry(Items.IRON_CHESTPLATE, 3).apply(version15 -> {
            return new EnchantWithLevelsFunction(Items.IRON_CHESTPLATE, 20, 39, true).apply(version15);
        }), new ItemEntry(Items.IRON_LEGGINGS, 3).apply(version16 -> {
            return new EnchantWithLevelsFunction(Items.IRON_LEGGINGS, 20, 39, true).apply(version16);
        }), new ItemEntry(Items.IRON_HELMET, 3).apply(version17 -> {
            return new EnchantWithLevelsFunction(Items.IRON_HELMET, 20, 39, true).apply(version17);
        }), new ItemEntry(Items.IRON_PICKAXE, 3).apply(version18 -> {
            return new EnchantWithLevelsFunction(Items.IRON_PICKAXE, 20, 39, true).apply(version18);
        }), new ItemEntry(Items.IRON_SHOVEL, 3).apply(version19 -> {
            return new EnchantWithLevelsFunction(Items.IRON_SHOVEL, 20, 39, true).apply(version19);
        })));
    };
    public static final Supplier<LootTable> IGLOO_CHEST_CHEST = () -> {
        return new LootTable(new LootPool(new UniformRoll(2.0f, 8.0f), new ItemEntry(Items.APPLE, 15).apply(version -> {
            return SetCountFunction.uniform(1.0f, 3.0f);
        }), new ItemEntry(Items.COAL, 15).apply(version2 -> {
            return SetCountFunction.uniform(1.0f, 4.0f);
        }), new ItemEntry(Items.GOLD_NUGGET, 10).apply(version3 -> {
            return SetCountFunction.uniform(1.0f, 3.0f);
        }), new ItemEntry(Items.STONE_AXE, 2), new ItemEntry(Items.ROTTEN_FLESH, 10), new ItemEntry(Items.EMERALD), new ItemEntry(Items.WHEAT, 10).apply(version4 -> {
            return SetCountFunction.uniform(2.0f, 3.0f);
        })), new LootPool(new ConstantRoll(1), new ItemEntry(Items.GOLDEN_APPLE)));
    };
    public static final Supplier<LootTable> JUNGLE_TEMPLE_CHEST = () -> {
        return new LootTable(new LootPool(new UniformRoll(2.0f, 6.0f), new ItemEntry(Items.DIAMOND, 3).apply(version -> {
            return SetCountFunction.uniform(1.0f, 3.0f);
        }), new ItemEntry(Items.IRON_INGOT, 10).apply(version2 -> {
            return SetCountFunction.uniform(1.0f, 5.0f);
        }), new ItemEntry(Items.GOLD_INGOT, 15).apply(version3 -> {
            return SetCountFunction.uniform(2.0f, 7.0f);
        }), new ItemEntry(Items.BAMBOO, 15).apply(version4 -> {
            return SetCountFunction.uniform(1.0f, 3.0f);
        }), new ItemEntry(Items.EMERALD, 2).apply(version5 -> {
            return SetCountFunction.uniform(1.0f, 3.0f);
        }), new ItemEntry(Items.BONE, 20).apply(version6 -> {
            return SetCountFunction.uniform(4.0f, 6.0f);
        }), new ItemEntry(Items.ROTTEN_FLESH, 16).apply(version7 -> {
            return SetCountFunction.uniform(3.0f, 7.0f);
        }), new ItemEntry(Items.SADDLE, 3), new ItemEntry(Items.IRON_HORSE_ARMOR), new ItemEntry(Items.GOLDEN_HORSE_ARMOR), new ItemEntry(Items.DIAMOND_HORSE_ARMOR), new ItemEntry(Items.BOOK).apply(version8 -> {
            return new EnchantWithLevelsFunction(Items.BOOK, 30, 30, true).apply(version8);
        })));
    };
    public static final Supplier<LootTable> JUNGLE_TEMPLE_DISPENSER_CHEST = () -> {
        return new LootTable(new LootPool(new UniformRoll(1.0f, 2.0f), new ItemEntry(Items.ARROW, 30).apply(version -> {
            return SetCountFunction.uniform(2.0f, 7.0f);
        })));
    };
    public static final Supplier<LootTable> NETHER_BRIDGE_CHEST = () -> {
        return new LootTable(new LootPool(new UniformRoll(2.0f, 4.0f), new ItemEntry(Items.DIAMOND, 5).apply(version -> {
            return SetCountFunction.uniform(1.0f, 3.0f);
        }), new ItemEntry(Items.IRON_INGOT, 5).apply(version2 -> {
            return SetCountFunction.uniform(1.0f, 5.0f);
        }), new ItemEntry(Items.GOLD_INGOT, 15).apply(version3 -> {
            return SetCountFunction.uniform(1.0f, 3.0f);
        }), new ItemEntry(Items.GOLDEN_SWORD, 5), new ItemEntry(Items.GOLDEN_CHESTPLATE, 5), new ItemEntry(Items.FLINT_AND_STEEL, 5), new ItemEntry(Items.NETHER_WART, 5).apply(version4 -> {
            return SetCountFunction.uniform(3.0f, 7.0f);
        }), new ItemEntry(Items.SADDLE, 10), new ItemEntry(Items.GOLDEN_HORSE_ARMOR, 8), new ItemEntry(Items.IRON_HORSE_ARMOR, 5), new ItemEntry(Items.DIAMOND_HORSE_ARMOR, 3), new ItemEntry(Items.OBSIDIAN, 2).apply(version5 -> {
            return SetCountFunction.uniform(2.0f, 4.0f);
        })));
    };
    public static final Supplier<LootTable> PILLAGER_OUTPOST_CHEST = () -> {
        return new LootTable(new LootPool(new UniformRoll(0.0f, 1.0f), new ItemEntry(Items.CROSSBOW)), new LootPool(new UniformRoll(2.0f, 3.0f), new ItemEntry(Items.WHEAT, 7).apply(version -> {
            return SetCountFunction.uniform(3.0f, 5.0f);
        }), new ItemEntry(Items.POTATO, 5).apply(version2 -> {
            return SetCountFunction.uniform(2.0f, 5.0f);
        }), new ItemEntry(Items.CARROT, 5).apply(version3 -> {
            return SetCountFunction.uniform(3.0f, 5.0f);
        })), new LootPool(new UniformRoll(1.0f, 3.0f), new ItemEntry(Items.DARK_OAK_LOG).apply(version4 -> {
            return SetCountFunction.uniform(2.0f, 3.0f);
        })), new LootPool(new UniformRoll(2.0f, 3.0f), new ItemEntry(Items.EXPERIENCE_BOTTLE, 7), new ItemEntry(Items.STRING, 4).apply(version5 -> {
            return SetCountFunction.uniform(1.0f, 6.0f);
        }), new ItemEntry(Items.ARROW, 4).apply(version6 -> {
            return SetCountFunction.uniform(2.0f, 7.0f);
        }), new ItemEntry(Items.TRIPWIRE_HOOK, 3).apply(version7 -> {
            return SetCountFunction.uniform(1.0f, 3.0f);
        }), new ItemEntry(Items.IRON_INGOT, 3).apply(version8 -> {
            return SetCountFunction.uniform(1.0f, 3.0f);
        }), new ItemEntry(Items.ENCHANTED_BOOK).apply(version9 -> {
            return new EnchantRandomlyFunction(Items.ENCHANTED_BOOK).apply(version9);
        })));
    };
    public static final Supplier<LootTable> RUINED_PORTAL_CHEST = () -> {
        return new LootTable(new LootPool(new UniformRoll(4.0f, 8.0f), new ItemEntry(Items.OBSIDIAN, 40).apply(version -> {
            return SetCountFunction.uniform(1.0f, 2.0f);
        }), new ItemEntry(Items.FLINT, 40).apply(version2 -> {
            return SetCountFunction.uniform(1.0f, 4.0f);
        }), new ItemEntry(Items.IRON_NUGGET, 40).apply(version3 -> {
            return SetCountFunction.uniform(9.0f, 18.0f);
        }), new ItemEntry(Items.FLINT_AND_STEEL, 40), new ItemEntry(Items.FIRE_CHARGE, 40), new ItemEntry(Items.GOLDEN_APPLE, 15), new ItemEntry(Items.GOLD_NUGGET, 15).apply(version4 -> {
            return SetCountFunction.uniform(4.0f, 24.0f);
        }), new ItemEntry(Items.GOLDEN_SWORD, 15).apply(version5 -> {
            return new EnchantRandomlyFunction(Items.GOLDEN_SWORD, true).apply(version5);
        }), new ItemEntry(Items.GOLDEN_AXE, 15).apply(version6 -> {
            return new EnchantRandomlyFunction(Items.GOLDEN_AXE, true).apply(version6);
        }), new ItemEntry(Items.GOLDEN_HOE, 15).apply(version7 -> {
            return new EnchantRandomlyFunction(Items.GOLDEN_HOE, true).apply(version7);
        }), new ItemEntry(Items.GOLDEN_SHOVEL, 15).apply(version8 -> {
            return new EnchantRandomlyFunction(Items.GOLDEN_SHOVEL, true).apply(version8);
        }), new ItemEntry(Items.GOLDEN_PICKAXE, 15).apply(version9 -> {
            return new EnchantRandomlyFunction(Items.GOLDEN_PICKAXE, true).apply(version9);
        }), new ItemEntry(Items.GOLDEN_BOOTS, 15).apply(version10 -> {
            return new EnchantRandomlyFunction(Items.GOLDEN_BOOTS, true).apply(version10);
        }), new ItemEntry(Items.GOLDEN_CHESTPLATE, 15).apply(version11 -> {
            return new EnchantRandomlyFunction(Items.GOLDEN_CHESTPLATE, true).apply(version11);
        }), new ItemEntry(Items.GOLDEN_HELMET, 15).apply(version12 -> {
            return new EnchantRandomlyFunction(Items.GOLDEN_HELMET, true).apply(version12);
        }), new ItemEntry(Items.GOLDEN_LEGGINGS, 15).apply(version13 -> {
            return new EnchantRandomlyFunction(Items.GOLDEN_LEGGINGS, true).apply(version13);
        }), new ItemEntry(Items.GLISTERING_MELON_SLICE, 5).apply(version14 -> {
            return SetCountFunction.uniform(4.0f, 12.0f);
        }), new ItemEntry(Items.GOLDEN_HORSE_ARMOR, 5), new ItemEntry(Items.LIGHT_WEIGHTED_PRESSURE_PLATE, 5), new ItemEntry(Items.GOLDEN_CARROT, 5).apply(version15 -> {
            return SetCountFunction.uniform(4.0f, 12.0f);
        }), new ItemEntry(Items.CLOCK, 5), new ItemEntry(Items.GOLD_INGOT, 5).apply(version16 -> {
            return SetCountFunction.uniform(2.0f, 8.0f);
        }), new ItemEntry(Items.BELL), new ItemEntry(Items.ENCHANTED_GOLDEN_APPLE), new ItemEntry(Items.GOLD_BLOCK).apply(version17 -> {
            return SetCountFunction.uniform(1.0f, 2.0f);
        })));
    };
    public static final Supplier<LootTable> SHIPWRECK_MAP_CHEST = () -> {
        return new LootTable(new LootPool(new ConstantRoll(1), new ItemEntry(Items.FILLED_MAP)), new LootPool(new ConstantRoll(3), new ItemEntry(Items.COMPASS), new ItemEntry(Items.MAP), new ItemEntry(Items.CLOCK), new ItemEntry(Items.PAPER, 20).apply(version -> {
            return SetCountFunction.uniform(1.0f, 10.0f);
        }), new ItemEntry(Items.FEATHER, 10).apply(version2 -> {
            return SetCountFunction.uniform(1.0f, 5.0f);
        }), new ItemEntry(Items.BOOK, 5).apply(version3 -> {
            return SetCountFunction.uniform(1.0f, 5.0f);
        })));
    };
    public static final Supplier<LootTable> SHIPWRECK_SUPPLY_CHEST = () -> {
        return new LootTable(new LootPool(new UniformRoll(3.0f, 10.0f), new ItemEntry(Items.PAPER, 8).apply(version -> {
            return SetCountFunction.uniform(1.0f, 12.0f);
        }), new ItemEntry(Items.POTATO, 7).apply(version2 -> {
            return SetCountFunction.uniform(2.0f, 6.0f);
        }), new ItemEntry(Items.MOSS_BLOCK, 7).apply(version3 -> {
            return SetCountFunction.uniform(1.0f, 4.0f);
        }).introducedVersion(MCVersion.v1_17), new ItemEntry(Items.POISONOUS_POTATO, 7).apply(version4 -> {
            return SetCountFunction.uniform(2.0f, 6.0f);
        }), new ItemEntry(Items.CARROT, 7).apply(version5 -> {
            return SetCountFunction.uniform(4.0f, 8.0f);
        }), new ItemEntry(Items.WHEAT, 7).apply(version6 -> {
            return SetCountFunction.uniform(8.0f, 21.0f);
        }), new ItemEntry(Items.SUSPICIOUS_STEW, 10).apply(version7 -> {
            return EffectFunction.builder().apply(Effects.BLINDNESS, 5.0f, 7.0f).apply(Effects.SATURATION, 7.0f, 10.0f).apply(Effects.NIGHT_VISION, 7.0f, 10.0f).apply(Effects.JUMP, 7.0f, 10.0f).apply(Effects.POISON, 10.0f, 20.0f).apply(Effects.WEAKNESS, 6.0f, 8.0f);
        }), new ItemEntry(Items.COAL, 6).apply(version8 -> {
            return SetCountFunction.uniform(2.0f, 8.0f);
        }), new ItemEntry(Items.ROTTEN_FLESH, 5).apply(version9 -> {
            return SetCountFunction.uniform(5.0f, 24.0f);
        }), new ItemEntry(Items.PUMPKIN, 2).apply(version10 -> {
            return SetCountFunction.uniform(1.0f, 3.0f);
        }), new ItemEntry(Items.BAMBOO, 2).apply(version11 -> {
            return SetCountFunction.uniform(1.0f, 3.0f);
        }), new ItemEntry(Items.GUNPOWDER, 3).apply(version12 -> {
            return SetCountFunction.uniform(1.0f, 5.0f);
        }), new ItemEntry(Items.TNT).apply(version13 -> {
            return SetCountFunction.uniform(1.0f, 2.0f);
        }), new ItemEntry(Items.LEATHER_HELMET, 3).apply(version14 -> {
            return new EnchantRandomlyFunction(Items.LEATHER_HELMET).apply(version14);
        }), new ItemEntry(Items.LEATHER_CHESTPLATE, 3).apply(version15 -> {
            return new EnchantRandomlyFunction(Items.LEATHER_CHESTPLATE).apply(version15);
        }), new ItemEntry(Items.LEATHER_LEGGINGS, 3).apply(version16 -> {
            return new EnchantRandomlyFunction(Items.LEATHER_LEGGINGS).apply(version16);
        }), new ItemEntry(Items.LEATHER_BOOTS, 3).apply(version17 -> {
            return new EnchantRandomlyFunction(Items.LEATHER_BOOTS).apply(version17);
        })));
    };
    public static final Supplier<LootTable> SHIPWRECK_TREASURE_CHEST = () -> {
        return new LootTable(new LootPool(new UniformRoll(3.0f, 6.0f), new ItemEntry(Items.IRON_INGOT, 90).apply(version -> {
            return SetCountFunction.uniform(1.0f, 5.0f);
        }), new ItemEntry(Items.GOLD_INGOT, 10).apply(version2 -> {
            return SetCountFunction.uniform(1.0f, 5.0f);
        }), new ItemEntry(Items.EMERALD, 40).apply(version3 -> {
            return SetCountFunction.uniform(1.0f, 5.0f);
        }), new ItemEntry(Items.DIAMOND, 5), new ItemEntry(Items.EXPERIENCE_BOTTLE, 5)), new LootPool(new UniformRoll(2.0f, 5.0f), new ItemEntry(Items.IRON_NUGGET, 50).apply(version4 -> {
            return SetCountFunction.uniform(1.0f, 10.0f);
        }), new ItemEntry(Items.GOLD_NUGGET, 10).apply(version5 -> {
            return SetCountFunction.uniform(1.0f, 10.0f);
        }), new ItemEntry(Items.LAPIS_LAZULI, 20).apply(version6 -> {
            return SetCountFunction.uniform(1.0f, 10.0f);
        })));
    };
    public static final Supplier<LootTable> SIMPLE_DUNGEON_CHEST = () -> {
        return new LootTable(new LootPool(new UniformRoll(1.0f, 3.0f), new ItemEntry(Items.SADDLE, 20), new ItemEntry(Items.GOLDEN_APPLE, 15), new ItemEntry(Items.ENCHANTED_GOLDEN_APPLE, 2), new ItemEntry(Items.MUSIC_DISC_13, 15), new ItemEntry(Items.MUSIC_DISC_CAT, 15), new ItemEntry(Items.NAME_TAG, 20), new ItemEntry(Items.GOLDEN_HORSE_ARMOR, 10), new ItemEntry(Items.IRON_HORSE_ARMOR, 15), new ItemEntry(Items.DIAMOND_HORSE_ARMOR, 5), new ItemEntry(Items.ENCHANTED_BOOK, 10).apply(version -> {
            return new EnchantRandomlyFunction(Items.ENCHANTED_BOOK).apply(version);
        })), new LootPool(new UniformRoll(1.0f, 4.0f), new ItemEntry(Items.IRON_INGOT, 10).apply(version2 -> {
            return SetCountFunction.uniform(1.0f, 4.0f);
        }), new ItemEntry(Items.GOLD_INGOT, 5).apply(version3 -> {
            return SetCountFunction.uniform(1.0f, 4.0f);
        }), new ItemEntry(Items.BREAD, 20), new ItemEntry(Items.WHEAT, 20).apply(version4 -> {
            return SetCountFunction.uniform(1.0f, 4.0f);
        }), new ItemEntry(Items.BUCKET, 10), new ItemEntry(Items.REDSTONE, 15).apply(version5 -> {
            return SetCountFunction.uniform(1.0f, 4.0f);
        }), new ItemEntry(Items.COAL, 15).apply(version6 -> {
            return SetCountFunction.uniform(1.0f, 4.0f);
        }), new ItemEntry(Items.MELON_SEEDS, 10).apply(version7 -> {
            return SetCountFunction.uniform(2.0f, 4.0f);
        }), new ItemEntry(Items.PUMPKIN_SEEDS, 10).apply(version8 -> {
            return SetCountFunction.uniform(2.0f, 4.0f);
        }), new ItemEntry(Items.BEETROOT_SEEDS, 10).apply(version9 -> {
            return SetCountFunction.uniform(2.0f, 4.0f);
        })), new LootPool(new ConstantRoll(3), new ItemEntry(Items.BONE, 10).apply(version10 -> {
            return SetCountFunction.uniform(1.0f, 8.0f);
        }), new ItemEntry(Items.GUNPOWDER, 10).apply(version11 -> {
            return SetCountFunction.uniform(1.0f, 8.0f);
        }), new ItemEntry(Items.ROTTEN_FLESH, 10).apply(version12 -> {
            return SetCountFunction.uniform(1.0f, 8.0f);
        }), new ItemEntry(Items.STRING, 10).apply(version13 -> {
            return SetCountFunction.uniform(1.0f, 8.0f);
        })));
    };
    public static final Supplier<LootTable> SPAWN_BONUS_CHEST_CHEST = () -> {
        return new LootTable(new LootPool(new ConstantRoll(1), new ItemEntry(Items.STONE_AXE), new ItemEntry(Items.WOODEN_AXE, 3)), new LootPool(new ConstantRoll(1), new ItemEntry(Items.STONE_PICKAXE), new ItemEntry(Items.WOODEN_PICKAXE, 3)), new LootPool(new ConstantRoll(3), new ItemEntry(Items.APPLE, 5).apply(version -> {
            return SetCountFunction.uniform(1.0f, 2.0f);
        }), new ItemEntry(Items.BREAD, 3).apply(version2 -> {
            return SetCountFunction.uniform(1.0f, 2.0f);
        }), new ItemEntry(Items.SALMON, 3).apply(version3 -> {
            return SetCountFunction.uniform(1.0f, 2.0f);
        })), new LootPool(new ConstantRoll(4), new ItemEntry(Items.STICK, 10).apply(version4 -> {
            return SetCountFunction.uniform(1.0f, 12.0f);
        }), new ItemEntry(Items.OAK_PLANKS, 10).apply(version5 -> {
            return SetCountFunction.uniform(1.0f, 12.0f);
        }), new ItemEntry(Items.OAK_LOG, 3).apply(version6 -> {
            return SetCountFunction.uniform(1.0f, 3.0f);
        }), new ItemEntry(Items.SPRUCE_LOG, 3).apply(version7 -> {
            return SetCountFunction.uniform(1.0f, 3.0f);
        }), new ItemEntry(Items.BIRCH_LOG, 3).apply(version8 -> {
            return SetCountFunction.uniform(1.0f, 3.0f);
        }), new ItemEntry(Items.JUNGLE_LOG, 3).apply(version9 -> {
            return SetCountFunction.uniform(1.0f, 3.0f);
        }), new ItemEntry(Items.ACACIA_LOG, 3).apply(version10 -> {
            return SetCountFunction.uniform(1.0f, 3.0f);
        }), new ItemEntry(Items.DARK_OAK_LOG, 3).apply(version11 -> {
            return SetCountFunction.uniform(1.0f, 3.0f);
        })));
    };
    public static final Supplier<LootTable> STRONGHOLD_CORRIDOR_CHEST = () -> {
        return new LootTable(new LootPool(new UniformRoll(2.0f, 3.0f), new ItemEntry(Items.ENDER_PEARL, 10), new ItemEntry(Items.DIAMOND, 3).apply(version -> {
            return SetCountFunction.uniform(1.0f, 3.0f);
        }), new ItemEntry(Items.IRON_INGOT, 10).apply(version2 -> {
            return SetCountFunction.uniform(1.0f, 5.0f);
        }), new ItemEntry(Items.GOLD_INGOT, 5).apply(version3 -> {
            return SetCountFunction.uniform(1.0f, 3.0f);
        }), new ItemEntry(Items.REDSTONE, 5).apply(version4 -> {
            return SetCountFunction.uniform(4.0f, 9.0f);
        }), new ItemEntry(Items.BREAD, 15).apply(version5 -> {
            return SetCountFunction.uniform(1.0f, 3.0f);
        }), new ItemEntry(Items.APPLE, 15).apply(version6 -> {
            return SetCountFunction.uniform(1.0f, 3.0f);
        }), new ItemEntry(Items.IRON_PICKAXE, 5), new ItemEntry(Items.IRON_SWORD, 5), new ItemEntry(Items.IRON_CHESTPLATE, 5), new ItemEntry(Items.IRON_HELMET, 5), new ItemEntry(Items.IRON_LEGGINGS, 5), new ItemEntry(Items.IRON_BOOTS, 5), new ItemEntry(Items.GOLDEN_APPLE), new ItemEntry(Items.SADDLE), new ItemEntry(Items.IRON_HORSE_ARMOR), new ItemEntry(Items.GOLDEN_HORSE_ARMOR), new ItemEntry(Items.DIAMOND_HORSE_ARMOR), new ItemEntry(Items.BOOK).apply(version7 -> {
            return new EnchantWithLevelsFunction(Items.BOOK, 30, 30, true).apply(version7);
        })));
    };
    public static final Supplier<LootTable> STRONGHOLD_CROSSING_CHEST = () -> {
        return new LootTable(new LootPool(new UniformRoll(1.0f, 4.0f), new ItemEntry(Items.IRON_INGOT, 10).apply(version -> {
            return SetCountFunction.uniform(1.0f, 5.0f);
        }), new ItemEntry(Items.GOLD_INGOT, 5).apply(version2 -> {
            return SetCountFunction.uniform(1.0f, 3.0f);
        }), new ItemEntry(Items.REDSTONE, 5).apply(version3 -> {
            return SetCountFunction.uniform(4.0f, 9.0f);
        }), new ItemEntry(Items.COAL, 10).apply(version4 -> {
            return SetCountFunction.uniform(3.0f, 8.0f);
        }), new ItemEntry(Items.BREAD, 15).apply(version5 -> {
            return SetCountFunction.uniform(1.0f, 3.0f);
        }), new ItemEntry(Items.APPLE, 15).apply(version6 -> {
            return SetCountFunction.uniform(1.0f, 3.0f);
        }), new ItemEntry(Items.IRON_PICKAXE), new ItemEntry(Items.BOOK).apply(version7 -> {
            return new EnchantWithLevelsFunction(Items.BOOK, 30, 30, true).apply(version7);
        })));
    };
    public static final Supplier<LootTable> STRONGHOLD_LIBRARY_CHEST = () -> {
        return new LootTable(new LootPool(new UniformRoll(2.0f, 10.0f), new ItemEntry(Items.BOOK, 20).apply(version -> {
            return SetCountFunction.uniform(1.0f, 3.0f);
        }), new ItemEntry(Items.PAPER, 20).apply(version2 -> {
            return SetCountFunction.uniform(2.0f, 7.0f);
        }), new ItemEntry(Items.MAP), new ItemEntry(Items.COMPASS), new ItemEntry(Items.BOOK, 10).apply(version3 -> {
            return new EnchantWithLevelsFunction(Items.BOOK, 30, 30, true).apply(version3);
        })));
    };
    public static final Supplier<LootTable> UNDERWATER_RUIN_BIG_CHEST = () -> {
        return new LootTable(new LootPool(new UniformRoll(2.0f, 8.0f), new ItemEntry(Items.COAL, 10).apply(version -> {
            return SetCountFunction.uniform(1.0f, 4.0f);
        }), new ItemEntry(Items.GOLD_NUGGET, 10).apply(version2 -> {
            return SetCountFunction.uniform(1.0f, 3.0f);
        }), new ItemEntry(Items.EMERALD), new ItemEntry(Items.WHEAT, 10).apply(version3 -> {
            return SetCountFunction.uniform(2.0f, 3.0f);
        })), new LootPool(new ConstantRoll(1), new ItemEntry(Items.GOLDEN_APPLE), new ItemEntry(Items.ENCHANTED_BOOK, 5).apply(version4 -> {
            return new EnchantRandomlyFunction(Items.ENCHANTED_BOOK).apply(version4);
        }), new ItemEntry(Items.LEATHER_CHESTPLATE), new ItemEntry(Items.GOLDEN_HELMET), new ItemEntry(Items.FISHING_ROD, 5).apply(version5 -> {
            return new EnchantRandomlyFunction(Items.FISHING_ROD).apply(version5);
        }), new ItemEntry(Items.MAP, 10)));
    };
    public static final Supplier<LootTable> UNDERWATER_RUIN_SMALL_CHEST = () -> {
        return new LootTable(new LootPool(new UniformRoll(2.0f, 8.0f), new ItemEntry(Items.COAL, 10).apply(version -> {
            return SetCountFunction.uniform(1.0f, 4.0f);
        }), new ItemEntry(Items.STONE_AXE, 2), new ItemEntry(Items.ROTTEN_FLESH, 5), new ItemEntry(Items.EMERALD), new ItemEntry(Items.WHEAT, 10).apply(version2 -> {
            return SetCountFunction.uniform(2.0f, 3.0f);
        })), new LootPool(new ConstantRoll(1), new ItemEntry(Items.LEATHER_CHESTPLATE), new ItemEntry(Items.GOLDEN_HELMET), new ItemEntry(Items.FISHING_ROD, 5).apply(version3 -> {
            return new EnchantRandomlyFunction(Items.FISHING_ROD).apply(version3);
        }), new ItemEntry(Items.MAP, 5)));
    };
    public static final Supplier<LootTable> VILLAGE_ARMORER_CHEST = () -> {
        return new LootTable(new LootPool(new UniformRoll(1.0f, 5.0f), new ItemEntry(Items.IRON_INGOT, 2).apply(version -> {
            return SetCountFunction.uniform(1.0f, 3.0f);
        }), new ItemEntry(Items.BREAD, 4).apply(version2 -> {
            return SetCountFunction.uniform(1.0f, 4.0f);
        }), new ItemEntry(Items.IRON_HELMET), new ItemEntry(Items.EMERALD)));
    };
    public static final Supplier<LootTable> VILLAGE_BUTCHER_CHEST = () -> {
        return new LootTable(new LootPool(new UniformRoll(1.0f, 5.0f), new ItemEntry(Items.EMERALD), new ItemEntry(Items.PORKCHOP, 6).apply(version -> {
            return SetCountFunction.uniform(1.0f, 3.0f);
        }), new ItemEntry(Items.WHEAT, 6).apply(version2 -> {
            return SetCountFunction.uniform(1.0f, 3.0f);
        }), new ItemEntry(Items.BEEF, 6).apply(version3 -> {
            return SetCountFunction.uniform(1.0f, 3.0f);
        }), new ItemEntry(Items.MUTTON, 6).apply(version4 -> {
            return SetCountFunction.uniform(1.0f, 3.0f);
        }), new ItemEntry(Items.COAL, 3).apply(version5 -> {
            return SetCountFunction.uniform(1.0f, 3.0f);
        })));
    };
    public static final Supplier<LootTable> VILLAGE_CARTOGRAPHER_CHEST = () -> {
        return new LootTable(new LootPool(new UniformRoll(1.0f, 5.0f), new ItemEntry(Items.MAP, 10).apply(version -> {
            return SetCountFunction.uniform(1.0f, 3.0f);
        }), new ItemEntry(Items.PAPER, 15).apply(version2 -> {
            return SetCountFunction.uniform(1.0f, 5.0f);
        }), new ItemEntry(Items.COMPASS, 5), new ItemEntry(Items.BREAD, 15).apply(version3 -> {
            return SetCountFunction.uniform(1.0f, 4.0f);
        }), new ItemEntry(Items.STICK, 5).apply(version4 -> {
            return SetCountFunction.uniform(1.0f, 2.0f);
        })));
    };
    public static final Supplier<LootTable> VILLAGE_DESERT_HOUSE_CHEST = () -> {
        return new LootTable(new LootPool(new UniformRoll(3.0f, 8.0f), new ItemEntry(Items.CLAY_BALL), new ItemEntry(Items.GREEN_DYE), new ItemEntry(Items.CACTUS, 10).apply(version -> {
            return SetCountFunction.uniform(1.0f, 4.0f);
        }), new ItemEntry(Items.WHEAT, 10).apply(version2 -> {
            return SetCountFunction.uniform(1.0f, 7.0f);
        }), new ItemEntry(Items.BREAD, 10).apply(version3 -> {
            return SetCountFunction.uniform(1.0f, 4.0f);
        }), new ItemEntry(Items.BOOK), new ItemEntry(Items.DEAD_BUSH, 2).apply(version4 -> {
            return SetCountFunction.uniform(1.0f, 3.0f);
        }), new ItemEntry(Items.EMERALD).apply(version5 -> {
            return SetCountFunction.uniform(1.0f, 3.0f);
        })));
    };
    public static final Supplier<LootTable> VILLAGE_FISHER_CHEST = () -> {
        return new LootTable(new LootPool(new UniformRoll(1.0f, 5.0f), new ItemEntry(Items.EMERALD), new ItemEntry(Items.COD, 2).apply(version -> {
            return SetCountFunction.uniform(1.0f, 3.0f);
        }), new ItemEntry(Items.SALMON).apply(version2 -> {
            return SetCountFunction.uniform(1.0f, 3.0f);
        }), new ItemEntry(Items.WATER_BUCKET).apply(version3 -> {
            return SetCountFunction.uniform(1.0f, 3.0f);
        }), new ItemEntry(Items.BARREL).apply(version4 -> {
            return SetCountFunction.uniform(1.0f, 3.0f);
        }), new ItemEntry(Items.WHEAT_SEEDS, 3).apply(version5 -> {
            return SetCountFunction.uniform(1.0f, 3.0f);
        }), new ItemEntry(Items.COAL, 2).apply(version6 -> {
            return SetCountFunction.uniform(1.0f, 3.0f);
        })));
    };
    public static final Supplier<LootTable> VILLAGE_FLETCHER_CHEST = () -> {
        return new LootTable(new LootPool(new UniformRoll(1.0f, 5.0f), new ItemEntry(Items.EMERALD), new ItemEntry(Items.ARROW, 2).apply(version -> {
            return SetCountFunction.uniform(1.0f, 3.0f);
        }), new ItemEntry(Items.FEATHER, 6).apply(version2 -> {
            return SetCountFunction.uniform(1.0f, 3.0f);
        }), new ItemEntry(Items.EGG, 2).apply(version3 -> {
            return SetCountFunction.uniform(1.0f, 3.0f);
        }), new ItemEntry(Items.FLINT, 6).apply(version4 -> {
            return SetCountFunction.uniform(1.0f, 3.0f);
        }), new ItemEntry(Items.STICK, 6).apply(version5 -> {
            return SetCountFunction.uniform(1.0f, 3.0f);
        })));
    };
    public static final Supplier<LootTable> VILLAGE_MASON_CHEST = () -> {
        return new LootTable(new LootPool(new UniformRoll(1.0f, 5.0f), new ItemEntry(Items.CLAY_BALL).apply(version -> {
            return SetCountFunction.uniform(1.0f, 3.0f);
        }), new ItemEntry(Items.FLOWER_POT), new ItemEntry(Items.STONE, 2), new ItemEntry(Items.STONE_BRICKS, 2), new ItemEntry(Items.BREAD, 4).apply(version2 -> {
            return SetCountFunction.uniform(1.0f, 4.0f);
        }), new ItemEntry(Items.YELLOW_DYE), new ItemEntry(Items.SMOOTH_STONE), new ItemEntry(Items.EMERALD)));
    };
    public static final Supplier<LootTable> VILLAGE_PLAINS_HOUSE_CHEST = () -> {
        return new LootTable(new LootPool(new UniformRoll(3.0f, 8.0f), new ItemEntry(Items.GOLD_NUGGET).apply(version -> {
            return SetCountFunction.uniform(1.0f, 3.0f);
        }), new ItemEntry(Items.DANDELION, 2), new ItemEntry(Items.POPPY), new ItemEntry(Items.POTATO, 10).apply(version2 -> {
            return SetCountFunction.uniform(1.0f, 7.0f);
        }), new ItemEntry(Items.BREAD, 10).apply(version3 -> {
            return SetCountFunction.uniform(1.0f, 4.0f);
        }), new ItemEntry(Items.APPLE, 10).apply(version4 -> {
            return SetCountFunction.uniform(1.0f, 5.0f);
        }), new ItemEntry(Items.BOOK), new ItemEntry(Items.FEATHER), new ItemEntry(Items.EMERALD, 2).apply(version5 -> {
            return SetCountFunction.uniform(1.0f, 4.0f);
        }), new ItemEntry(Items.OAK_SAPLING, 5).apply(version6 -> {
            return SetCountFunction.uniform(1.0f, 2.0f);
        })));
    };
    public static final Supplier<LootTable> VILLAGE_SAVANNA_HOUSE_CHEST = () -> {
        return new LootTable(new LootPool(new UniformRoll(3.0f, 8.0f), new ItemEntry(Items.GOLD_NUGGET).apply(version -> {
            return SetCountFunction.uniform(1.0f, 3.0f);
        }), new ItemEntry(Items.GRASS, 5), new ItemEntry(Items.TALL_GRASS, 5), new ItemEntry(Items.BREAD, 10).apply(version2 -> {
            return SetCountFunction.uniform(1.0f, 4.0f);
        }), new ItemEntry(Items.WHEAT_SEEDS, 10).apply(version3 -> {
            return SetCountFunction.uniform(1.0f, 5.0f);
        }), new ItemEntry(Items.EMERALD, 2).apply(version4 -> {
            return SetCountFunction.uniform(1.0f, 4.0f);
        }), new ItemEntry(Items.ACACIA_SAPLING, 10).apply(version5 -> {
            return SetCountFunction.uniform(1.0f, 2.0f);
        }), new ItemEntry(Items.SADDLE), new ItemEntry(Items.TORCH).apply(version6 -> {
            return SetCountFunction.uniform(1.0f, 2.0f);
        }), new ItemEntry(Items.BUCKET)));
    };
    public static final Supplier<LootTable> VILLAGE_SHEPHERD_CHEST = () -> {
        return new LootTable(new LootPool(new UniformRoll(1.0f, 5.0f), new ItemEntry(Items.WHITE_WOOL, 6).apply(version -> {
            return SetCountFunction.uniform(1.0f, 8.0f);
        }), new ItemEntry(Items.BLACK_WOOL, 3).apply(version2 -> {
            return SetCountFunction.uniform(1.0f, 3.0f);
        }), new ItemEntry(Items.GRAY_WOOL, 2).apply(version3 -> {
            return SetCountFunction.uniform(1.0f, 3.0f);
        }), new ItemEntry(Items.BROWN_WOOL, 2).apply(version4 -> {
            return SetCountFunction.uniform(1.0f, 3.0f);
        }), new ItemEntry(Items.LIGHT_GRAY_WOOL, 2).apply(version5 -> {
            return SetCountFunction.uniform(1.0f, 3.0f);
        }), new ItemEntry(Items.EMERALD), new ItemEntry(Items.SHEARS), new ItemEntry(Items.WHEAT, 6).apply(version6 -> {
            return SetCountFunction.uniform(1.0f, 6.0f);
        })));
    };
    public static final Supplier<LootTable> VILLAGE_SNOWY_HOUSE_CHEST = () -> {
        return new LootTable(new LootPool(new UniformRoll(3.0f, 8.0f), new ItemEntry(Items.BLUE_ICE), new ItemEntry(Items.SNOW_BLOCK, 4), new ItemEntry(Items.POTATO, 10).apply(version -> {
            return SetCountFunction.uniform(1.0f, 7.0f);
        }), new ItemEntry(Items.BREAD, 10).apply(version2 -> {
            return SetCountFunction.uniform(1.0f, 4.0f);
        }), new ItemEntry(Items.BEETROOT_SEEDS, 10).apply(version3 -> {
            return SetCountFunction.uniform(1.0f, 5.0f);
        }), new ItemEntry(Items.BEETROOT_SOUP), new ItemEntry(Items.FURNACE), new ItemEntry(Items.EMERALD).apply(version4 -> {
            return SetCountFunction.uniform(1.0f, 4.0f);
        }), new ItemEntry(Items.SNOWBALL, 10).apply(version5 -> {
            return SetCountFunction.uniform(1.0f, 7.0f);
        }), new ItemEntry(Items.COAL, 5).apply(version6 -> {
            return SetCountFunction.uniform(1.0f, 4.0f);
        })));
    };
    public static final Supplier<LootTable> VILLAGE_TAIGA_HOUSE_CHEST = () -> {
        return new LootTable(new LootPool(new UniformRoll(3.0f, 8.0f), new ItemEntry(Items.IRON_NUGGET).apply(version -> {
            return SetCountFunction.uniform(1.0f, 5.0f);
        }), new ItemEntry(Items.FERN, 2), new ItemEntry(Items.LARGE_FERN, 2), new ItemEntry(Items.POTATO, 10).apply(version2 -> {
            return SetCountFunction.uniform(1.0f, 7.0f);
        }), new ItemEntry(Items.SWEET_BERRIES, 5).apply(version3 -> {
            return SetCountFunction.uniform(1.0f, 7.0f);
        }), new ItemEntry(Items.BREAD, 10).apply(version4 -> {
            return SetCountFunction.uniform(1.0f, 4.0f);
        }), new ItemEntry(Items.PUMPKIN_SEEDS, 5).apply(version5 -> {
            return SetCountFunction.uniform(1.0f, 5.0f);
        }), new ItemEntry(Items.PUMPKIN_PIE), new ItemEntry(Items.EMERALD, 2).apply(version6 -> {
            return SetCountFunction.uniform(1.0f, 4.0f);
        }), new ItemEntry(Items.SPRUCE_SAPLING, 5).apply(version7 -> {
            return SetCountFunction.uniform(1.0f, 5.0f);
        }), new ItemEntry(Items.SPRUCE_SIGN), new ItemEntry(Items.SPRUCE_LOG, 10).apply(version8 -> {
            return SetCountFunction.uniform(1.0f, 5.0f);
        })));
    };
    public static final Supplier<LootTable> VILLAGE_TANNERY_CHEST = () -> {
        return new LootTable(new LootPool(new UniformRoll(1.0f, 5.0f), new ItemEntry(Items.LEATHER).apply(version -> {
            return SetCountFunction.uniform(1.0f, 3.0f);
        }), new ItemEntry(Items.LEATHER_CHESTPLATE, 2), new ItemEntry(Items.LEATHER_BOOTS, 2), new ItemEntry(Items.LEATHER_HELMET, 2), new ItemEntry(Items.BREAD, 5).apply(version2 -> {
            return SetCountFunction.uniform(1.0f, 4.0f);
        }), new ItemEntry(Items.LEATHER_LEGGINGS, 2), new ItemEntry(Items.SADDLE), new ItemEntry(Items.EMERALD).apply(version3 -> {
            return SetCountFunction.uniform(1.0f, 4.0f);
        })));
    };
    public static final Supplier<LootTable> VILLAGE_TEMPLE_CHEST = () -> {
        return new LootTable(new LootPool(new UniformRoll(3.0f, 8.0f), new ItemEntry(Items.REDSTONE, 2).apply(version -> {
            return SetCountFunction.uniform(1.0f, 4.0f);
        }), new ItemEntry(Items.BREAD, 7).apply(version2 -> {
            return SetCountFunction.uniform(1.0f, 4.0f);
        }), new ItemEntry(Items.ROTTEN_FLESH, 7).apply(version3 -> {
            return SetCountFunction.uniform(1.0f, 4.0f);
        }), new ItemEntry(Items.LAPIS_LAZULI).apply(version4 -> {
            return SetCountFunction.uniform(1.0f, 4.0f);
        }), new ItemEntry(Items.GOLD_INGOT).apply(version5 -> {
            return SetCountFunction.uniform(1.0f, 4.0f);
        }), new ItemEntry(Items.EMERALD).apply(version6 -> {
            return SetCountFunction.uniform(1.0f, 4.0f);
        })));
    };
    public static final Supplier<LootTable> VILLAGE_TOOLSMITH_CHEST = () -> {
        return new LootTable(new LootPool(new UniformRoll(3.0f, 8.0f), new ItemEntry(Items.DIAMOND).apply(version -> {
            return SetCountFunction.uniform(1.0f, 3.0f);
        }), new ItemEntry(Items.IRON_INGOT, 5).apply(version2 -> {
            return SetCountFunction.uniform(1.0f, 5.0f);
        }), new ItemEntry(Items.GOLD_INGOT).apply(version3 -> {
            return SetCountFunction.uniform(1.0f, 3.0f);
        }), new ItemEntry(Items.BREAD, 15).apply(version4 -> {
            return SetCountFunction.uniform(1.0f, 3.0f);
        }), new ItemEntry(Items.IRON_PICKAXE, 5), new ItemEntry(Items.COAL).apply(version5 -> {
            return SetCountFunction.uniform(1.0f, 3.0f);
        }), new ItemEntry(Items.STICK, 20).apply(version6 -> {
            return SetCountFunction.uniform(1.0f, 3.0f);
        }), new ItemEntry(Items.IRON_SHOVEL, 5)));
    };
    public static final Supplier<LootTable> VILLAGE_WEAPONSMITH_CHEST = () -> {
        return new LootTable(new LootPool(new UniformRoll(3.0f, 8.0f), new ItemEntry(Items.DIAMOND, 3).apply(version -> {
            return SetCountFunction.uniform(1.0f, 3.0f);
        }), new ItemEntry(Items.IRON_INGOT, 10).apply(version2 -> {
            return SetCountFunction.uniform(1.0f, 5.0f);
        }), new ItemEntry(Items.GOLD_INGOT, 5).apply(version3 -> {
            return SetCountFunction.uniform(1.0f, 3.0f);
        }), new ItemEntry(Items.BREAD, 15).apply(version4 -> {
            return SetCountFunction.uniform(1.0f, 3.0f);
        }), new ItemEntry(Items.APPLE, 15).apply(version5 -> {
            return SetCountFunction.uniform(1.0f, 3.0f);
        }), new ItemEntry(Items.IRON_PICKAXE, 5), new ItemEntry(Items.IRON_SWORD, 5), new ItemEntry(Items.IRON_CHESTPLATE, 5), new ItemEntry(Items.IRON_HELMET, 5), new ItemEntry(Items.IRON_LEGGINGS, 5), new ItemEntry(Items.IRON_BOOTS, 5), new ItemEntry(Items.OBSIDIAN, 5).apply(version6 -> {
            return SetCountFunction.uniform(3.0f, 7.0f);
        }), new ItemEntry(Items.OAK_SAPLING, 5).apply(version7 -> {
            return SetCountFunction.uniform(3.0f, 7.0f);
        }), new ItemEntry(Items.SADDLE, 3), new ItemEntry(Items.IRON_HORSE_ARMOR), new ItemEntry(Items.GOLDEN_HORSE_ARMOR), new ItemEntry(Items.DIAMOND_HORSE_ARMOR)));
    };
    public static final Supplier<LootTable> WOODLAND_MANSION_CHEST = () -> {
        return new LootTable(new LootPool(new UniformRoll(1.0f, 3.0f), new ItemEntry(Items.LEAD, 20), new ItemEntry(Items.GOLDEN_APPLE, 15), new ItemEntry(Items.ENCHANTED_GOLDEN_APPLE, 2), new ItemEntry(Items.MUSIC_DISC_13, 15), new ItemEntry(Items.MUSIC_DISC_CAT, 15), new ItemEntry(Items.NAME_TAG, 20), new ItemEntry(Items.CHAINMAIL_CHESTPLATE, 10), new ItemEntry(Items.DIAMOND_HOE, 15), new ItemEntry(Items.DIAMOND_CHESTPLATE, 5), new ItemEntry(Items.ENCHANTED_BOOK, 10).apply(version -> {
            return new EnchantRandomlyFunction(Items.ENCHANTED_BOOK).apply(version);
        })), new LootPool(new UniformRoll(1.0f, 4.0f), new ItemEntry(Items.IRON_INGOT, 10).apply(version2 -> {
            return SetCountFunction.uniform(1.0f, 4.0f);
        }), new ItemEntry(Items.GOLD_INGOT, 5).apply(version3 -> {
            return SetCountFunction.uniform(1.0f, 4.0f);
        }), new ItemEntry(Items.BREAD, 20), new ItemEntry(Items.WHEAT, 20).apply(version4 -> {
            return SetCountFunction.uniform(1.0f, 4.0f);
        }), new ItemEntry(Items.BUCKET, 10), new ItemEntry(Items.REDSTONE, 15).apply(version5 -> {
            return SetCountFunction.uniform(1.0f, 4.0f);
        }), new ItemEntry(Items.COAL, 15).apply(version6 -> {
            return SetCountFunction.uniform(1.0f, 4.0f);
        }), new ItemEntry(Items.MELON_SEEDS, 10).apply(version7 -> {
            return SetCountFunction.uniform(2.0f, 4.0f);
        }), new ItemEntry(Items.PUMPKIN_SEEDS, 10).apply(version8 -> {
            return SetCountFunction.uniform(2.0f, 4.0f);
        }), new ItemEntry(Items.BEETROOT_SEEDS, 10).apply(version9 -> {
            return SetCountFunction.uniform(2.0f, 4.0f);
        })), new LootPool(new ConstantRoll(3), new ItemEntry(Items.BONE, 10).apply(version10 -> {
            return SetCountFunction.uniform(1.0f, 8.0f);
        }), new ItemEntry(Items.GUNPOWDER, 10).apply(version11 -> {
            return SetCountFunction.uniform(1.0f, 8.0f);
        }), new ItemEntry(Items.ROTTEN_FLESH, 10).apply(version12 -> {
            return SetCountFunction.uniform(1.0f, 8.0f);
        }), new ItemEntry(Items.STRING, 10).apply(version13 -> {
            return SetCountFunction.uniform(1.0f, 8.0f);
        })));
    };
    public static final Supplier<LootTable> FISHING_FISH = () -> {
        return new LootTable(new LootPool(new ConstantRoll(1), new ItemEntry(Items.COD, 60), new ItemEntry(Items.SALMON, 25), new ItemEntry(Items.TROPICAL_FISH, 2), new ItemEntry(Items.PUFFERFISH, 13)));
    };
    public static final Supplier<LootTable> FISHING_JUNK = () -> {
        return new LootTable(new LootPool(new ConstantRoll(1), new ItemEntry(Items.LILY_PAD, 17), new ItemEntry(Items.LEATHER_BOOTS, 10).apply(version -> {
            return new ApplyDamageFunction();
        }), new ItemEntry(Items.LEATHER, 10), new ItemEntry(Items.BONE, 10), new ItemEntry(Items.POTION, 10), new ItemEntry(Items.STRING, 5), new ItemEntry(Items.FISHING_ROD, 2).apply(version2 -> {
            return new ApplyDamageFunction();
        }), new ItemEntry(Items.BOWL, 10), new ItemEntry(Items.STICK, 5), new ItemEntry(Items.INK_SAC, 1).apply(version3 -> {
            return SetCountFunction.constant(10);
        }), new ItemEntry(Items.TRIPWIRE_HOOK, 10), new ItemEntry(Items.ROTTEN_FLESH, 10), new ItemEntry(Items.BAMBOO, 10).when(version4 -> {
            if (version4.isNewerOrEqualTo(MCVersion.v1_18)) {
                return new BiomeCondition(Biomes.JUNGLE, Biomes.BAMBOO_JUNGLE);
            }
            return new BiomeCondition(Biomes.JUNGLE, Biomes.JUNGLE_HILLS, Biomes.JUNGLE_EDGE, Biomes.BAMBOO_JUNGLE, Biomes.MODIFIED_JUNGLE, Biomes.MODIFIED_JUNGLE_EDGE, Biomes.BAMBOO_JUNGLE_HILLS);
        })));
    };
    public static final Supplier<LootTable> FISHING_TREASURE = () -> {
        return new LootTable(new LootPool(new ConstantRoll(1), new ItemEntry(Items.NAME_TAG), new ItemEntry(Items.SADDLE), new ItemEntry(Items.BOW).apply(version -> {
            return new ApplyDamageFunction();
        }, version2 -> {
            return new EnchantWithLevelsFunction(Items.BOW, 30, 30, true).apply(version2);
        }), new ItemEntry(Items.FISHING_ROD).apply(version3 -> {
            return new ApplyDamageFunction();
        }, version4 -> {
            return new EnchantWithLevelsFunction(Items.FISHING_ROD, 30, 30, true).apply(version4);
        }), new ItemEntry(Items.BOOK).apply(version5 -> {
            return new EnchantWithLevelsFunction(Items.BOOK, 30, 30, true).apply(version5);
        }), new ItemEntry(Items.NAUTILUS_SHELL)));
    };
    public static final Supplier<LootTable> FISHING = () -> {
        return new LootTable(new LootPool(new ConstantRoll(1), new TableEntry(FISHING_JUNK, 10, -2), new TableEntry(FISHING_TREASURE, 5, 2).when(version -> {
            return new OpenWaterCondition(true);
        }), new TableEntry(FISHING_FISH, 85, -1)));
    };
}
