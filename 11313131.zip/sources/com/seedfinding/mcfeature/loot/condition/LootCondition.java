package com.seedfinding.mcfeature.loot.condition;

import com.seedfinding.mcfeature.loot.LootContext;

public interface LootCondition {
    boolean is_valid(LootContext lootContext);

    static LootCondition combine(LootCondition[] lootConditions) {
        return context -> {
            boolean condition = true;
            for (LootCondition lootFunction : lootConditions) {
                condition &= lootFunction.is_valid(context);
            }
            return condition;
        };
    }
}
