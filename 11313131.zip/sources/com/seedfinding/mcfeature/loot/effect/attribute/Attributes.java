package com.seedfinding.mcfeature.loot.effect.attribute;

import java.util.LinkedHashMap;

public class Attributes {
    private static final LinkedHashMap<String, Attribute> ATTRIBUTES = new LinkedHashMap<>();
    public static final Attribute MAX_HEALTH = register("generic.max_health", new RangedAttribute("attribute.name.generic.max_health", 20.0d, 1.0d, 1024.0d).setSyncable(true));
    public static final Attribute FOLLOW_RANGE = register("generic.follow_range", new RangedAttribute("attribute.name.generic.follow_range", 32.0d, 0.0d, 2048.0d));
    public static final Attribute KNOCKBACK_RESISTANCE = register("generic.knockback_resistance", new RangedAttribute("attribute.name.generic.knockback_resistance", 0.0d, 0.0d, 1.0d));
    public static final Attribute MOVEMENT_SPEED = register("generic.movement_speed", new RangedAttribute("attribute.name.generic.movement_speed", 0.699999988079071d, 0.0d, 1024.0d).setSyncable(true));
    public static final Attribute FLYING_SPEED = register("generic.flying_speed", new RangedAttribute("attribute.name.generic.flying_speed", 0.4000000059604645d, 0.0d, 1024.0d).setSyncable(true));
    public static final Attribute ATTACK_DAMAGE = register("generic.attack_damage", new RangedAttribute("attribute.name.generic.attack_damage", 2.0d, 0.0d, 2048.0d));
    public static final Attribute ATTACK_KNOCKBACK = register("generic.attack_knockback", new RangedAttribute("attribute.name.generic.attack_knockback", 0.0d, 0.0d, 5.0d));
    public static final Attribute ATTACK_SPEED = register("generic.attack_speed", new RangedAttribute("attribute.name.generic.attack_speed", 4.0d, 0.0d, 1024.0d).setSyncable(true));
    public static final Attribute ARMOR = register("generic.armor", new RangedAttribute("attribute.name.generic.armor", 0.0d, 0.0d, 30.0d).setSyncable(true));
    public static final Attribute ARMOR_TOUGHNESS = register("generic.armor_toughness", new RangedAttribute("attribute.name.generic.armor_toughness", 0.0d, 0.0d, 20.0d).setSyncable(true));
    public static final Attribute LUCK = register("generic.luck", new RangedAttribute("attribute.name.generic.luck", 0.0d, -1024.0d, 1024.0d).setSyncable(true));
    public static final Attribute SPAWN_REINFORCEMENTS_CHANCE = register("zombie.spawn_reinforcements", new RangedAttribute("attribute.name.zombie.spawn_reinforcements", 0.0d, 0.0d, 1.0d));
    public static final Attribute JUMP_STRENGTH = register("horse.jump_strength", new RangedAttribute("attribute.name.horse.jump_strength", 0.7d, 0.0d, 2.0d).setSyncable(true));

    private static Attribute register(String name, Attribute attribute) {
        ATTRIBUTES.put(name, attribute);
        return attribute;
    }

    public static LinkedHashMap<String, Attribute> getAttributes() {
        return ATTRIBUTES;
    }
}
