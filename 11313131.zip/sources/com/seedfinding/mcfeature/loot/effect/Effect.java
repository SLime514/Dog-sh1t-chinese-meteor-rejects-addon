package com.seedfinding.mcfeature.loot.effect;

import com.seedfinding.mcfeature.loot.effect.attribute.Attribute;
import com.seedfinding.mcfeature.loot.effect.attribute.AttributeModifier;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.function.Supplier;

public class Effect {
    private final Map<Attribute, AttributeModifier> attributeModifiers = new HashMap();
    private final EffectType category;
    private final int color;
    private String description;

    public enum EffectType {
        BENEFICIAL,
        HARMFUL,
        NEUTRAL
    }

    protected Effect(EffectType effectType, int color) {
        this.category = effectType;
        this.color = color;
    }

    public EffectType getCategory() {
        return this.category;
    }

    public int getColor() {
        return this.color;
    }

    public Map<Attribute, AttributeModifier> getAttributeModifiers() {
        return this.attributeModifiers;
    }

    public String getDescription() {
        if (this.description == null) {
            this.description = (String) Effects.getEffects().entrySet().stream().filter(e -> {
                return ((Effect) e.getValue()).equals(this);
            }).map((v0) -> {
                return v0.getKey();
            }).map((v0) -> {
                return v0.getSecond();
            }).findFirst().orElse(null);
        }
        return this.description;
    }

    public boolean isInstantenous() {
        return false;
    }

    public Effect addAttributeModifier(Attribute attribute, String name, double amount, AttributeModifier.Operation operation) {
        AttributeModifier attributemodifier = new AttributeModifier(UUID.fromString(name), (Supplier<String>) this::getDescription, amount, operation);
        this.attributeModifiers.put(attribute, attributemodifier);
        return this;
    }

    public String toString() {
        return "Effect{category=" + this.category + ", description='" + getDescription() + "'}";
    }

    public static class InstantEffect extends Effect {
        public InstantEffect(EffectType effectType, int color) {
            super(effectType, color);
        }

        @Override
        public boolean isInstantenous() {
            return true;
        }
    }

    public static class HealthBoostEffect extends Effect {
        public HealthBoostEffect(EffectType effectType, int color) {
            super(effectType, color);
        }
    }

    public static class AbsorptionEffect extends Effect {
        protected AbsorptionEffect(EffectType effectType, int color) {
            super(effectType, color);
        }
    }

    public static class AttackDamageEffect extends Effect {
        protected final double multiplier;

        protected AttackDamageEffect(EffectType effectType, int color, double multiplier) {
            super(effectType, color);
            this.multiplier = multiplier;
        }
    }
}
