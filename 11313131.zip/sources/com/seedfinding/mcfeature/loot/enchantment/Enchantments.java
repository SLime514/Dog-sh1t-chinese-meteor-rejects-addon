package com.seedfinding.mcfeature.loot.enchantment;

import com.seedfinding.mccore.version.MCVersion;
import com.seedfinding.mcfeature.loot.item.ItemStack;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;

public class Enchantments {
    private static final HashSet<String> ARMOR_TYPES = new HashSet<>(Arrays.asList("NETHERITE", "DIAMOND", "GOLDEN", "IRON", "LEATHER", "CHAINMAIL"));
    private static final HashSet<String> TOOL_TYPES = new HashSet<>(Arrays.asList("NETHERITE", "DIAMOND", "GOLDEN", "IRON", "STONE", "WOODEN"));
    private static final HashSet<String> BOOKS = new HashSet<>(Arrays.asList("ENCHANTED_BOOK", "BOOK"));
    public static final HashSet<String> ARMOR_HEAD = new HashSet<String>() {
        {
            Iterator it = Enchantments.ARMOR_TYPES.iterator();
            while (it.hasNext()) {
                String type = (String) it.next();
                add(type + "_HELMET");
            }
            addAll(Enchantments.BOOKS);
            add("TURTLE_HELMET");
        }
    };
    public static final HashSet<String> ARMOR_CHEST = new HashSet<String>() {
        {
            Iterator it = Enchantments.ARMOR_TYPES.iterator();
            while (it.hasNext()) {
                String type = (String) it.next();
                add(type + "_CHESTPLATE");
            }
            addAll(Enchantments.BOOKS);
            add("ELYTRA");
        }
    };
    public static final HashSet<String> ARMOR_LEGGINGS = new HashSet<String>() {
        {
            Iterator it = Enchantments.ARMOR_TYPES.iterator();
            while (it.hasNext()) {
                String type = (String) it.next();
                add(type + "_LEGGINGS");
            }
            addAll(Enchantments.BOOKS);
        }
    };
    public static final HashSet<String> ARMOR_FEET = new HashSet<String>() {
        {
            Iterator it = Enchantments.ARMOR_TYPES.iterator();
            while (it.hasNext()) {
                String type = (String) it.next();
                add(type + "_BOOTS");
            }
            addAll(Enchantments.BOOKS);
        }
    };
    public static final HashSet<String> ARMOR = new HashSet<String>() {
        {
            addAll(Enchantments.ARMOR_HEAD);
            addAll(Enchantments.ARMOR_CHEST);
            addAll(Enchantments.ARMOR_LEGGINGS);
            addAll(Enchantments.ARMOR_FEET);
        }
    };
    public static final HashSet<String> SWORDS = new HashSet<String>() {
        {
            Iterator it = Enchantments.TOOL_TYPES.iterator();
            while (it.hasNext()) {
                String type = (String) it.next();
                add(type + "_SWORD");
            }
        }
    };
    public static final HashSet<String> AXES = new HashSet<String>() {
        {
            Iterator it = Enchantments.TOOL_TYPES.iterator();
            while (it.hasNext()) {
                String type = (String) it.next();
                add(type + "_AXE");
            }
        }
    };
    public static final HashSet<String> HOES = new HashSet<String>() {
        {
            Iterator it = Enchantments.TOOL_TYPES.iterator();
            while (it.hasNext()) {
                String type = (String) it.next();
                add(type + "_HOE");
            }
        }
    };
    public static final HashSet<String> PICKAXES = new HashSet<String>() {
        {
            Iterator it = Enchantments.TOOL_TYPES.iterator();
            while (it.hasNext()) {
                String type = (String) it.next();
                add(type + "_PICKAXE");
            }
        }
    };
    public static final HashSet<String> SHOVELS = new HashSet<String>() {
        {
            Iterator it = Enchantments.TOOL_TYPES.iterator();
            while (it.hasNext()) {
                String type = (String) it.next();
                add(type + "_SHOVEL");
            }
        }
    };
    public static final HashSet<String> BOW = new HashSet<String>() {
        {
            add("BOW");
            addAll(Enchantments.BOOKS);
        }
    };
    public static final HashSet<String> CROSSBOW = new HashSet<String>() {
        {
            add("CROSSBOW");
            addAll(Enchantments.BOOKS);
        }
    };
    public static final HashSet<String> FISHING_ROD = new HashSet<String>() {
        {
            add("FISHING_ROD");
            addAll(Enchantments.BOOKS);
        }
    };
    public static final HashSet<String> TRIDENT = new HashSet<String>() {
        {
            add("TRIDENT");
            addAll(Enchantments.BOOKS);
        }
    };
    public static final HashSet<String> BREAKABLE = new HashSet<String>() {
        {
            addAll(Enchantments.CROSSBOW);
            addAll(Enchantments.BOW);
            addAll(Enchantments.TRIDENT);
            addAll(Enchantments.FISHING_ROD);
            addAll(Enchantments.ARMOR);
            addAll(Enchantments.SWORDS);
            addAll(Enchantments.AXES);
            addAll(Enchantments.HOES);
            addAll(Enchantments.PICKAXES);
            addAll(Enchantments.SHOVELS);
        }
    };
    public static final HashSet<String> DIGGER = new HashSet<String>() {
        {
            addAll(Enchantments.HOES);
            addAll(Enchantments.PICKAXES);
            addAll(Enchantments.AXES);
            addAll(Enchantments.SHOVELS);
            addAll(Enchantments.BOOKS);
        }
    };
    public static final HashSet<String> WEAPON = new HashSet<String>() {
        {
            addAll(Enchantments.SWORDS);
            addAll(Enchantments.BOOKS);
        }
    };
    public static final HashSet<String> DAMAGE = new HashSet<String>() {
        {
            addAll(Enchantments.SWORDS);
            addAll(Enchantments.AXES);
            addAll(Enchantments.BOOKS);
        }
    };
    public static final HashSet<String> THORNS = new HashSet<String>() {
        {
            addAll(Enchantments.ARMOR_CHEST);
            remove("ELYTRA");
        }
    };
    public static final HashSet<String> VANISHABLE = new HashSet<String>() {
        {
            addAll(Enchantments.BREAKABLE);
        }
    };
    public static final HashSet<String> SingleEnchants = new HashSet<>(Arrays.asList("aqua_affinity", "binding_curse", "channeling", "silk_touch", "flame", "infinity", "multishot", "mending", "vanishing_curse"));
    public static final List<HashSet<String>> allCategories = new ArrayList(Arrays.asList(ARMOR, ARMOR_HEAD, ARMOR_CHEST, ARMOR_FEET, BOW, BREAKABLE, CROSSBOW, DIGGER, DAMAGE, FISHING_ROD, TRIDENT, WEAPON, VANISHABLE, THORNS));
    private static final Integer COMMON = 10;
    private static final Integer UNCOMMON = 5;
    private static final Integer RARE = 2;
    private static final Integer VERY_RARE = 1;
    public static final ConcurrentHashMap<MCVersion, List<Enchantment>> CACHE_ENCHANTMENT_REGISTRY = new ConcurrentHashMap<>();

    public static boolean canApply(Enchantment enchantment, ItemStack item) {
        return enchantment.getCategory().contains(item.getItem().getName().toUpperCase());
    }

    public static List<Enchantment> removeAllNull(List<Enchantment> list) {
        list.removeIf((v0) -> {
            return Objects.isNull(v0);
        });
        return list;
    }

    public static List<Enchantment> getFor(MCVersion version) {
        return CACHE_ENCHANTMENT_REGISTRY.computeIfAbsent(version, key -> {
            return apply(new ArrayList(), version);
        });
    }

    public static List<Enchantment> apply(List<Enchantment> enchantments, MCVersion version) {
        enchantments.clear();
        enchantments.add(new Enchantment("protection", COMMON, ARMOR, 1, 4, (i, n) -> {
            return n.intValue() < 1 + ((i.intValue() - 1) * 11);
        }, (i2, n2) -> {
            return n2.intValue() > (1 + ((i2.intValue() - 1) * 11)) + 11;
        }, new HashSet(Arrays.asList("protection", "fire_protection", "projectile_protection", "blast_protection"))));
        enchantments.add(new Enchantment("fire_protection", UNCOMMON, ARMOR, 1, 4, (i3, n3) -> {
            return n3.intValue() < 10 + ((i3.intValue() - 1) * 8);
        }, (i4, n4) -> {
            return n4.intValue() > (10 + ((i4.intValue() - 1) * 8)) + 8;
        }, new HashSet(Arrays.asList("protection", "fire_protection", "projectile_protection", "blast_protection"))));
        enchantments.add(new Enchantment("feather_falling", UNCOMMON, ARMOR_FEET, 1, 4, (i5, n5) -> {
            return n5.intValue() < 5 + ((i5.intValue() - 1) * 6);
        }, (i6, n6) -> {
            return n6.intValue() > (5 + ((i6.intValue() - 1) * 6)) + 6;
        }, new HashSet(Collections.singletonList("feather_falling"))));
        enchantments.add(new Enchantment("blast_protection", RARE, ARMOR, 1, 4, (i7, n7) -> {
            return n7.intValue() < 5 + ((i7.intValue() - 1) * 8);
        }, (i8, n8) -> {
            return n8.intValue() > (5 + ((i8.intValue() - 1) * 8)) + 8;
        }, new HashSet(Arrays.asList("protection", "fire_protection", "projectile_protection", "blast_protection"))));
        enchantments.add(new Enchantment("projectile_protection", UNCOMMON, ARMOR, 1, 4, (i9, n9) -> {
            return n9.intValue() < 3 + ((i9.intValue() - 1) * 6);
        }, (i10, n10) -> {
            return n10.intValue() > (3 + ((i10.intValue() - 1) * 6)) + 6;
        }, new HashSet(Arrays.asList("protection", "fire_protection", "projectile_protection", "blast_protection"))));
        enchantments.add(new Enchantment("respiration", RARE, ARMOR_HEAD, 1, 3, (i11, n11) -> {
            return n11.intValue() < 10 * i11.intValue();
        }, (i12, n12) -> {
            return n12.intValue() > (10 * i12.intValue()) + 30;
        }, new HashSet(Collections.singletonList("respiration"))));
        enchantments.add(new Enchantment("aqua_affinity", RARE, ARMOR_HEAD, 1, 1, (i13, n13) -> {
            return n13.intValue() < 1;
        }, (i14, n14) -> {
            return n14.intValue() > 41;
        }, new HashSet(Collections.singletonList("aqua_affinity"))));
        enchantments.add(new Enchantment("thorns", VERY_RARE, THORNS, 1, 3, (i15, n15) -> {
            return n15.intValue() < 10 + (20 * (i15.intValue() - 1));
        }, (i16, n16) -> {
            return n16.intValue() > (10 + (20 * (i16.intValue() - 1))) + 50;
        }, new HashSet(Collections.singletonList("thorns"))));
        if (version.isNewerOrEqualTo(MCVersion.v1_8)) {
            enchantments.add(new Enchantment("depth_strider", RARE, ARMOR_FEET, 1, 3, (i17, n17) -> {
                return n17.intValue() < i17.intValue() * 10;
            }, (i18, n18) -> {
                return n18.intValue() > (i18.intValue() * 10) + 15;
            }, new HashSet(Arrays.asList("frost_walker", "depth_strider"))));
        }
        if (version.isNewerOrEqualTo(MCVersion.v1_9)) {
            enchantments.add(new Enchantment("frost_walker", RARE, ARMOR_FEET, 1, 2, (i19, n19) -> {
                return n19.intValue() < i19.intValue() * 10;
            }, (i20, n20) -> {
                return n20.intValue() > (i20.intValue() * 10) + 15;
            }, new HashSet(Arrays.asList("frost_walker", "depth_strider")), true));
        }
        if (version.isNewerOrEqualTo(MCVersion.v1_11)) {
            enchantments.add(new Enchantment("binding_curse", VERY_RARE, ARMOR, 1, 1, (i21, n21) -> {
                return n21.intValue() < 25;
            }, (i22, n22) -> {
                return n22.intValue() > 50;
            }, new HashSet(Collections.singletonList("binding_curse")), true));
        }
        if (version.isNewerOrEqualTo(MCVersion.v1_16)) {
            enchantments.add(new Enchantment("soul_speed", VERY_RARE, ARMOR_FEET, 1, 3, (i23, n23) -> {
                return n23.intValue() < i23.intValue() * 10;
            }, (i24, n24) -> {
                return n24.intValue() > (i24.intValue() * 10) + 15;
            }, new HashSet(Collections.singletonList("soul_speed")), true, false));
        }
        enchantments.add(new Enchantment("sharpness", COMMON, DAMAGE, 1, 5, (i25, n25) -> {
            return n25.intValue() < 1 + ((i25.intValue() - 1) * 11);
        }, (i26, n26) -> {
            return n26.intValue() > (1 + ((i26.intValue() - 1) * 11)) + 20;
        }, new HashSet(Arrays.asList("sharpness", "smite", "bane_of_arthropods"))));
        enchantments.add(new Enchantment("smite", UNCOMMON, DAMAGE, 1, 5, (i27, n27) -> {
            return n27.intValue() < 5 + ((i27.intValue() - 1) * 8);
        }, (i28, n28) -> {
            return n28.intValue() > (5 + ((i28.intValue() - 1) * 8)) + 20;
        }, new HashSet(Arrays.asList("sharpness", "smite", "bane_of_arthropods"))));
        enchantments.add(new Enchantment("bane_of_arthropods", UNCOMMON, DAMAGE, 1, 5, (i29, n29) -> {
            return n29.intValue() < 5 + ((i29.intValue() - 1) * 8);
        }, (i30, n30) -> {
            return n30.intValue() > (5 + ((i30.intValue() - 1) * 8)) + 20;
        }, new HashSet(Arrays.asList("sharpness", "smite", "bane_of_arthropods"))));
        enchantments.add(new Enchantment("knockback", UNCOMMON, WEAPON, 1, 2, (i31, n31) -> {
            return n31.intValue() < 5 + (20 * (i31.intValue() - 1));
        }, (i32, n32) -> {
            return n32.intValue() > (1 + (i32.intValue() * 10)) + 50;
        }, new HashSet(Collections.singletonList("knockback"))));
        enchantments.add(new Enchantment("fire_aspect", RARE, WEAPON, 1, 2, (i33, n33) -> {
            return n33.intValue() < 10 + (20 * (i33.intValue() - 1));
        }, (i34, n34) -> {
            return n34.intValue() > (1 + (i34.intValue() * 10)) + 50;
        }, new HashSet(Collections.singletonList("fire_aspect"))));
        enchantments.add(new Enchantment("looting", RARE, WEAPON, 1, 3, (i35, n35) -> {
            return n35.intValue() < 15 + ((i35.intValue() - 1) * 9);
        }, (i36, n36) -> {
            return n36.intValue() > (1 + (i36.intValue() * 10)) + 50;
        }, new HashSet(Arrays.asList("looting", "silk_touch"))));
        if (version.isNewerOrEqualTo(MCVersion.v1_11_1)) {
            enchantments.add(new Enchantment("sweeping", RARE, WEAPON, 1, 3, (i37, n37) -> {
                return n37.intValue() < 5 + ((i37.intValue() - 1) * 9);
            }, (i38, n38) -> {
                return n38.intValue() > (5 + ((i38.intValue() - 1) * 9)) + 15;
            }, new HashSet(Collections.singletonList("sweeping"))));
        }
        enchantments.add(new Enchantment("efficiency", COMMON, DIGGER, 1, 5, (i39, n39) -> {
            return n39.intValue() < 1 + (10 * (i39.intValue() - 1));
        }, (i40, n40) -> {
            return n40.intValue() > (1 + (i40.intValue() * 10)) + 50;
        }, new HashSet(Collections.singletonList("efficiency"))));
        enchantments.add(new Enchantment("silk_touch", VERY_RARE, DIGGER, 1, 1, (i41, n41) -> {
            return n41.intValue() < 15;
        }, (i42, n42) -> {
            return n42.intValue() > (1 + (i42.intValue() * 10)) + 50;
        }, new HashSet(Arrays.asList("fortune", "silk_touch"))));
        enchantments.add(new Enchantment("unbreaking", UNCOMMON, BREAKABLE, 1, 3, (i43, n43) -> {
            return n43.intValue() < 5 + ((i43.intValue() - 1) * 8);
        }, (i44, n44) -> {
            return n44.intValue() > (1 + (i44.intValue() * 10)) + 50;
        }, new HashSet(Collections.singletonList("unbreaking"))));
        enchantments.add(new Enchantment("fortune", RARE, DIGGER, 1, 3, (i45, n45) -> {
            return n45.intValue() < 15 + ((i45.intValue() - 1) * 9);
        }, (i46, n46) -> {
            return n46.intValue() > (1 + (i46.intValue() * 10)) + 50;
        }, new HashSet(Arrays.asList("fortune", "silk_touch"))));
        enchantments.add(new Enchantment("power", COMMON, BOW, 1, 5, (i47, n47) -> {
            return n47.intValue() < 1 + ((i47.intValue() - 1) * 10);
        }, (i48, n48) -> {
            return n48.intValue() > (1 + ((i48.intValue() - 1) * 10)) + 15;
        }, new HashSet(Collections.singletonList("power"))));
        enchantments.add(new Enchantment("punch", RARE, BOW, 1, 2, (i49, n49) -> {
            return n49.intValue() < 12 + ((i49.intValue() - 1) * 20);
        }, (i50, n50) -> {
            return n50.intValue() > (12 + ((i50.intValue() - 1) * 20)) + 25;
        }, new HashSet(Collections.singletonList("punch"))));
        enchantments.add(new Enchantment("flame", RARE, BOW, 1, 1, (i51, n51) -> {
            return n51.intValue() < 20;
        }, (i52, n52) -> {
            return n52.intValue() > 50;
        }, new HashSet(Collections.singletonList("flame"))));
        enchantments.add(new Enchantment("infinity", VERY_RARE, BOW, 1, 1, (i53, n53) -> {
            return n53.intValue() < 20;
        }, (i54, n54) -> {
            return n54.intValue() > 50;
        }, new HashSet(Arrays.asList("mending", "infinity"))));
        if (version.isNewerOrEqualTo(MCVersion.v1_7_2)) {
            enchantments.add(new Enchantment("luck_of_the_sea", RARE, FISHING_ROD, 1, 3, (i55, n55) -> {
                return n55.intValue() < 15 + ((i55.intValue() - 1) * 9);
            }, (i56, n56) -> {
                return n56.intValue() > (1 + (i56.intValue() * 10)) + 50;
            }, new HashSet(Arrays.asList("luck_of_the_sea", "silk_touch"))));
        }
        if (version.isNewerOrEqualTo(MCVersion.v1_7_2)) {
            enchantments.add(new Enchantment("lure", RARE, FISHING_ROD, 1, 3, (i57, n57) -> {
                return n57.intValue() < 15 + ((i57.intValue() - 1) * 9);
            }, (i58, n58) -> {
                return n58.intValue() > (1 + (i58.intValue() * 10)) + 50;
            }, new HashSet(Collections.singletonList("lure"))));
        }
        if (version.isNewerOrEqualTo(MCVersion.v1_13)) {
            enchantments.add(new Enchantment("loyalty", UNCOMMON, TRIDENT, 1, 3, (i59, n59) -> {
                return n59.intValue() < 5 + (i59.intValue() * 7);
            }, (i60, n60) -> {
                return n60.intValue() > 50;
            }, new HashSet(Arrays.asList("loyalty", "riptide"))));
        }
        if (version.isNewerOrEqualTo(MCVersion.v1_13)) {
            enchantments.add(new Enchantment("impaling", RARE, TRIDENT, 1, 5, (i61, n61) -> {
                return n61.intValue() < 1 + ((i61.intValue() - 1) * 8);
            }, (i62, n62) -> {
                return n62.intValue() > (1 + ((i62.intValue() - 1) * 8)) + 20;
            }, new HashSet(Collections.singletonList("impaling"))));
        }
        if (version.isNewerOrEqualTo(MCVersion.v1_13)) {
            enchantments.add(new Enchantment("riptide", RARE, TRIDENT, 1, 3, (i63, n63) -> {
                return n63.intValue() < 10 + (i63.intValue() * 7);
            }, (i64, n64) -> {
                return n64.intValue() > 50;
            }, new HashSet(Arrays.asList("riptide", "loyalty", "channeling"))));
        }
        if (version.isNewerOrEqualTo(MCVersion.v1_13)) {
            enchantments.add(new Enchantment("channeling", VERY_RARE, TRIDENT, 1, 1, (i65, n65) -> {
                return n65.intValue() < 25;
            }, (i66, n66) -> {
                return n66.intValue() > 50;
            }, new HashSet(Arrays.asList("channeling", "riptide"))));
        }
        if (version.isNewerOrEqualTo(MCVersion.v1_14)) {
            enchantments.add(new Enchantment("multishot", RARE, CROSSBOW, 1, 1, (i67, n67) -> {
                return n67.intValue() < 20;
            }, (i68, n68) -> {
                return n68.intValue() > 50;
            }, new HashSet(Arrays.asList("multishot", "piercing"))));
        }
        if (version.isNewerOrEqualTo(MCVersion.v1_14)) {
            enchantments.add(new Enchantment("quick_charge", UNCOMMON, CROSSBOW, 1, 3, (i69, n69) -> {
                return n69.intValue() < 12 + ((i69.intValue() - 1) * 20);
            }, (i70, n70) -> {
                return n70.intValue() > 50;
            }, new HashSet(Collections.singletonList("quick_charge"))));
        }
        if (version.isNewerOrEqualTo(MCVersion.v1_14)) {
            enchantments.add(new Enchantment("piercing", COMMON, CROSSBOW, 1, 4, (i71, n71) -> {
                return n71.intValue() < 1 + ((i71.intValue() - 1) * 10);
            }, (i72, n72) -> {
                return n72.intValue() > 50;
            }, new HashSet(Arrays.asList("multishot", "piercing"))));
        }
        enchantments.add(new Enchantment("mending", RARE, BREAKABLE, 1, 1, (i73, n73) -> {
            return n73.intValue() < i73.intValue() * 25;
        }, (i74, n74) -> {
            return n74.intValue() > (i74.intValue() * 25) + 50;
        }, new HashSet(Arrays.asList("mending", "infinity")), true));
        enchantments.add(new Enchantment("vanishing_curse", VERY_RARE, VANISHABLE, 1, 1, (i75, n75) -> {
            return n75.intValue() < 25;
        }, (i76, n76) -> {
            return n76.intValue() > 50;
        }, new HashSet(Collections.singletonList("vanishing_curse")), true));
        return enchantments;
    }

    public static HashSet<HashSet<String>> getCategories(ItemStack baseStack) {
        HashSet<HashSet<String>> applicableCategories = new HashSet<>();
        for (HashSet<String> category : allCategories) {
            if (category.contains(baseStack.getItem().getName().toUpperCase())) {
                applicableCategories.add(category);
            }
        }
        return applicableCategories;
    }

    public static List<Enchantment> getApplicableEnchantments(List<Enchantment> enchantments, HashSet<HashSet<String>> applicableCategories) {
        return getApplicableEnchantments(enchantments, applicableCategories, false, true);
    }

    public static List<Enchantment> getApplicableEnchantments(List<Enchantment> enchantments, HashSet<HashSet<String>> applicableCategories, boolean isTreasure) {
        return getApplicableEnchantments(enchantments, applicableCategories, isTreasure, true);
    }

    public static List<Enchantment> getApplicableEnchantments(List<Enchantment> enchantments, HashSet<HashSet<String>> applicableCategories, boolean isTreasure, boolean isDiscoverable) {
        List<Enchantment> applicableEnchantments = new ArrayList<>();
        List<String> applicableEnchantmentNames = new ArrayList<>();
        for (Enchantment currentEnchantment : enchantments) {
            if (!currentEnchantment.isTreasure() || isTreasure) {
                if (currentEnchantment.isDiscoverable() == isDiscoverable && applicableCategories.contains(currentEnchantment.getCategory()) && !applicableEnchantmentNames.contains(currentEnchantment.getName())) {
                    applicableEnchantments.add(currentEnchantment);
                    applicableEnchantmentNames.add(currentEnchantment.getName());
                }
            }
        }
        return applicableEnchantments;
    }

    public static void filterCompatibleEnchantments(ArrayList<EnchantmentInstance> list, EnchantmentInstance instance) {
        list.removeIf(e -> {
            return e.getIncompatible().contains(instance.getName()) || instance.getIncompatible().contains(e.getName());
        });
    }

    public Enchantment getEnchantment(List<Enchantment> enchantments, String name) {
        for (Enchantment enchantment : enchantments) {
            if (enchantment.getName().equals(name)) {
                return enchantment;
            }
        }
        return null;
    }
}
