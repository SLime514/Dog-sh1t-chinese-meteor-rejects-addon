package com.seedfinding.mcfeature.loot;

import com.seedfinding.mcbiome.biome.Biome;
import com.seedfinding.mccore.rand.ChunkRand;
import com.seedfinding.mccore.version.MCVersion;

public class LootContext extends ChunkRand {
    public static final int DEFAULT_LUCK = 1;
    private final MCVersion version;
    private int luck;
    private Biome biome;
    private boolean inOpenWater;

    public LootContext(long lootTableSeed) {
        super(lootTableSeed);
        this.luck = 1;
        this.biome = null;
        this.inOpenWater = false;
        this.version = MCVersion.latest();
    }

    public LootContext(long lootTableSeed, MCVersion version) {
        super(lootTableSeed);
        this.luck = 1;
        this.biome = null;
        this.inOpenWater = false;
        this.version = version;
    }

    public int getLuck() {
        return this.luck;
    }

    public Biome getBiome() {
        return this.biome;
    }

    public boolean isInOpenWater() {
        return this.inOpenWater;
    }

    public LootContext withLuck(int luck) {
        this.luck = luck;
        return this;
    }

    public LootContext withBiome(Biome biome) {
        this.biome = biome;
        return this;
    }

    public LootContext withOpenWater(boolean openWater) {
        this.inOpenWater = openWater;
        return this;
    }

    public MCVersion getVersion() {
        return this.version;
    }
}
