package com.seedfinding.mcfeature.loot;

import com.seedfinding.mccore.version.MCVersion;
import com.seedfinding.mcfeature.loot.function.LootFunction;
import com.seedfinding.mcfeature.loot.item.Item;
import com.seedfinding.mcfeature.loot.item.ItemStack;
import com.seedfinding.mcfeature.loot.roll.UniformRoll;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class LootTable extends LootGenerator {
    public final LootPool[] lootPools;
    private boolean hasVersionApplied;
    private Integer luck;

    public LootTable(LootPool... lootPools) {
        this(Arrays.asList(lootPools), null);
    }

    public LootTable(Collection<LootPool> lootPools, Collection<Function<MCVersion, LootFunction>> lootFunctions) {
        this.hasVersionApplied = false;
        this.luck = null;
        this.lootPools = (LootPool[]) lootPools.toArray(new LootPool[0]);
        apply(lootFunctions);
    }

    @Override
    public LootTable apply(MCVersion version) {
        return apply(version, 1);
    }

    public LootTable apply(MCVersion version, int luck) {
        for (LootPool lootPool : this.lootPools) {
            lootPool.apply(version).processWeights(luck, null);
        }
        this.hasVersionApplied = true;
        this.luck = Integer.valueOf(luck);
        return this;
    }

    public LootTable apply(MCVersion version, int luck, LootContext lootContext) {
        for (LootPool lootPool : this.lootPools) {
            lootPool.apply(version).processWeights(luck, lootContext);
        }
        this.hasVersionApplied = true;
        this.luck = Integer.valueOf(luck);
        return this;
    }

    private LootTable apply(int luck) {
        if (!this.hasVersionApplied) {
            System.err.println("Version was not applied, we default to latest " + MCVersion.latest());
            return apply(MCVersion.latest(), luck);
        }
        for (LootPool lootPool : this.lootPools) {
            lootPool.processWeights(luck, null);
        }
        this.luck = Integer.valueOf(luck);
        return this;
    }

    public static LinkedList<ItemStack> shuffleItems(LootContext context, LinkedList<ItemStack> items) {
        List<Integer> container = (List) IntStream.range(0, 27).boxed().collect(Collectors.toList());
        context.shuffle(container);
        List<ItemStack> list = new ArrayList<>();
        Iterator<ItemStack> iterator = items.iterator();
        int size = container.size();
        while (iterator.hasNext()) {
            ItemStack itemstack = iterator.next();
            if (itemstack.isEmpty()) {
                iterator.remove();
            } else if (itemstack.getCount() > 1) {
                list.add(itemstack);
                iterator.remove();
            }
        }
        while ((size - items.size()) - list.size() > 0 && !list.isEmpty()) {
            ItemStack itemstack2 = list.remove(new UniformRoll(0.0f, list.size() - 1).getCount(context));
            int half = itemstack2.getCount() / 2;
            int i = new UniformRoll(1.0f, half).getCount(context);
            ItemStack itemstack1 = itemstack2.split(i);
            if (itemstack2.getCount() > 1 && context.nextBoolean()) {
                list.add(itemstack2);
            } else {
                items.add(itemstack2);
            }
            if (itemstack1.getCount() > 1 && context.nextBoolean()) {
                list.add(itemstack1);
            } else {
                items.add(itemstack1);
            }
        }
        items.addAll(list);
        context.shuffle(items);
        HashMap<Integer, ItemStack> positions = new HashMap<>();
        int len = container.size();
        Iterator<ItemStack> it = items.iterator();
        while (it.hasNext()) {
            ItemStack itemstack3 = it.next();
            if (container.isEmpty()) {
                return items;
            }
            if (itemstack3.isEmpty()) {
                positions.put(container.remove(container.size() - 1), ItemStack.EMPTY);
            } else {
                positions.put(container.remove(container.size() - 1), itemstack3);
            }
        }
        LinkedList<ItemStack> result = new LinkedList<>();
        for (int i2 = 0; i2 < len; i2++) {
            result.add(positions.getOrDefault(Integer.valueOf(i2), ItemStack.EMPTY));
        }
        return result;
    }

    @Override
    public void generate(LootContext context, Consumer<ItemStack> stackConsumer) {
        if (!this.hasVersionApplied) {
            apply(context.getVersion(), context.getLuck(), context);
        } else if (this.luck == null || this.luck.intValue() != context.getLuck()) {
            apply(context.getLuck());
        }
        Consumer<ItemStack> stackConsumer2 = LootFunction.stack(stackConsumer, this.combinedLootFunction, context);
        for (LootPool lootPool : this.lootPools) {
            lootPool.generate(context, stackConsumer2);
        }
    }

    public LinkedList<ItemStack> generateIndexed(LootContext context) {
        LinkedList<ItemStack> itemStacks = new LinkedList<>();
        Objects.requireNonNull(itemStacks);
        generate(context, (v1) -> {
            r2.add(v1);
        });
        return shuffleItems(context, itemStacks);
    }

    public List<ItemStack> generate(LootContext context) {
        Map<Item, Integer> itemCounts = new HashMap<>();
        generate(context, stack -> {
            int oldCount = ((Integer) itemCounts.getOrDefault(stack.getItem(), 0)).intValue();
            itemCounts.put(stack.getItem(), Integer.valueOf(oldCount + stack.getCount()));
        });
        return (List) itemCounts.entrySet().stream().map(e -> {
            return new ItemStack((Item) e.getKey(), ((Integer) e.getValue()).intValue());
        }).collect(Collectors.toList());
    }
}
