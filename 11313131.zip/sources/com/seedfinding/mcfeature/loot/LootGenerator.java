package com.seedfinding.mcfeature.loot;

import com.seedfinding.mccore.version.MCVersion;
import com.seedfinding.mcfeature.loot.condition.LootCondition;
import com.seedfinding.mcfeature.loot.function.LootFunction;
import com.seedfinding.mcfeature.loot.item.ItemStack;
import java.util.Collection;
import java.util.function.Consumer;
import java.util.function.Function;

public abstract class LootGenerator {
    public LootFunction[] lootFunctions;
    public LootFunction combinedLootFunction;
    public LootCondition[] lootConditions;
    public LootCondition combinedLootCondition;
    public Function<MCVersion, LootFunction>[] supplierLootFunctions = null;
    public Function<MCVersion, LootCondition>[] supplierLootConditions = null;

    public abstract void generate(LootContext lootContext, Consumer<ItemStack> consumer);

    public LootGenerator() {
        apply((Collection<Function<MCVersion, LootFunction>>) null);
    }

    public LootGenerator apply(Collection<Function<MCVersion, LootFunction>> lootFunctions) {
        if (lootFunctions != null) {
            this.supplierLootFunctions = (Function[]) lootFunctions.toArray(new Function[0]);
        } else {
            this.lootFunctions = new LootFunction[0];
            this.combinedLootFunction = (baseStack, context) -> {
                return baseStack;
            };
        }
        return this;
    }

    public LootGenerator when(Collection<Function<MCVersion, LootCondition>> lootConditions) {
        if (this.lootFunctions != null) {
            this.supplierLootConditions = (Function[]) lootConditions.toArray(new Function[0]);
        } else {
            this.lootConditions = new LootCondition[0];
            this.combinedLootCondition = context -> {
                return true;
            };
        }
        return this;
    }

    public LootGenerator apply(MCVersion version) {
        if (this.supplierLootFunctions != null) {
            this.lootFunctions = new LootFunction[this.supplierLootFunctions.length];
            int i = 0;
            for (Function<MCVersion, LootFunction> function : this.supplierLootFunctions) {
                int i2 = i;
                i++;
                this.lootFunctions[i2] = function.apply(version);
            }
            this.combinedLootFunction = LootFunction.combine(this.lootFunctions);
        }
        if (this.supplierLootConditions != null) {
            this.lootConditions = new LootCondition[this.supplierLootConditions.length];
            int i3 = 0;
            for (Function<MCVersion, LootCondition> function2 : this.supplierLootConditions) {
                int i4 = i3;
                i3++;
                this.lootConditions[i4] = function2.apply(version);
            }
            this.combinedLootCondition = LootCondition.combine(this.lootConditions);
        }
        return this;
    }
}
