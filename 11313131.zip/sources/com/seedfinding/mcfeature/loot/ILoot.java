package com.seedfinding.mcfeature.loot;

import com.seedfinding.mccore.rand.ChunkRand;
import com.seedfinding.mccore.util.data.Pair;
import com.seedfinding.mccore.util.pos.BPos;
import com.seedfinding.mccore.util.pos.CPos;
import com.seedfinding.mccore.version.MCVersion;
import com.seedfinding.mcfeature.Feature;
import com.seedfinding.mcfeature.GenerationContext;
import com.seedfinding.mcfeature.loot.item.ItemStack;
import com.seedfinding.mcfeature.structure.generator.Generator;
import com.seedfinding.mcfeature.structure.generator.Generators;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

public interface ILoot {

    @FunctionalInterface
    public interface SpecificCalls {
        void run(Generator generator, ChunkRand chunkRand);
    }

    int getDecorationSalt();

    boolean isCorrectGenerator(Generator generator);

    MCVersion getVersion();

    SpecificCalls getSpecificCalls();

    default List<ChestContent> getLoot(long structureSeed, Generator generator, boolean indexed) {
        return getLoot(structureSeed, generator, new ChunkRand(), indexed);
    }

    default List<ChestContent> getLoot(long structureSeed, Generator generator, ChunkRand rand, boolean indexed) {
        if (!isCorrectGenerator(generator)) {
            return null;
        }
        List<Pair<Generator.ILootType, BPos>> lootPositions = generator.getLootPos();
        HashMap<CPos, LinkedList<Pair<Generator.ILootType, BPos>>> posLinkedListHashMap = new HashMap<>();
        for (Pair<Generator.ILootType, BPos> lootPos : lootPositions) {
            if (lootPos.getFirst().getLootTable(getVersion()) != null) {
                BPos pos = lootPos.getSecond();
                posLinkedListHashMap.computeIfAbsent(pos.toChunkPos(), k -> {
                    return new LinkedList();
                }).add(lootPos);
            }
        }
        HashMap<Generator.ILootType, List<ChestData>> chestDataHashMap = new HashMap<>();
        for (CPos cPos : posLinkedListHashMap.keySet()) {
            LinkedList<Pair<Generator.ILootType, BPos>> lootTypes = posLinkedListHashMap.get(cPos);
            int index = 0;
            Iterator<Pair<Generator.ILootType, BPos>> it = lootTypes.iterator();
            while (it.hasNext()) {
                Pair<Generator.ILootType, BPos> lootType = it.next();
                chestDataHashMap.computeIfAbsent(lootType.getFirst(), k2 -> {
                    return new ArrayList();
                }).add(new ChestData(index, cPos, lootType.getSecond(), lootTypes.size()));
                index++;
            }
        }
        List<ChestContent> result = new ArrayList<>();
        for (Generator.ILootType lootType2 : chestDataHashMap.keySet()) {
            List<ChestData> chests = chestDataHashMap.get(lootType2);
            for (ChestData chestData : chests) {
                CPos chunkChestPos = chestData.getChunkPos();
                rand.setDecoratorSeed(structureSeed, chunkChestPos.getX() * 16, chunkChestPos.getZ() * 16, getDecorationSalt(), getVersion());
                SpecificCalls calls = getSpecificCalls();
                if (calls != null) {
                    calls.run(generator, rand);
                }
                if (shouldAdvanceInChunks()) {
                    rand.advance(chestData.getNumberInChunk() * 2);
                }
                rand.advance(chestData.getIndex() * 2);
                LootContext context = new LootContext(rand.nextLong(), getVersion());
                LootTable lootTable = lootType2.getLootTable(getVersion());
                List<ItemStack> loot = indexed ? lootTable.generateIndexed(context) : lootTable.generate(context);
                result.add(new ChestContent(lootType2, loot, chestData.getPos(), indexed));
            }
        }
        return result;
    }

    default List<ChestContent> getLootAtPos(long worldSeed, CPos pos, ChunkRand rand, boolean indexed) {
        Generator generator;
        GenerationContext.Context context;
        if (!(this instanceof Feature)) {
            return null;
        }
        Feature<?, ?> feature = (Feature) this;
        Generator.GeneratorFactory<?> factory = Generators.get(feature.getClass());
        if (factory == null || (generator = factory.create(getVersion())) == null || (context = feature.getContext(worldSeed)) == null || !generator.generate(context.getGenerator(), pos)) {
            return null;
        }
        return getLoot(worldSeed, generator, rand, indexed);
    }

    @Deprecated
    default HashMap<Generator.ILootType, List<List<ItemStack>>> getLootEx(long structureSeed, Generator generator, ChunkRand rand, boolean indexed) {
        HashMap<Generator.ILootType, List<List<ItemStack>>> res = new HashMap<>();
        for (ChestContent chestContent : getLoot(structureSeed, generator, rand, indexed)) {
            res.computeIfAbsent(chestContent.getLootType(), e -> {
                return new ArrayList();
            }).add(chestContent.getItems());
        }
        return res;
    }

    default boolean shouldAdvanceInChunks() {
        return true;
    }

    public static class ChestData {
        private final int index;
        private final CPos chunkPos;
        private final BPos pos;
        private final int numberInChunk;

        public ChestData(int index, CPos chunkPos, BPos pos, int numberInChunk) {
            this.index = index;
            this.chunkPos = chunkPos;
            this.pos = pos;
            this.numberInChunk = numberInChunk;
        }

        public BPos getPos() {
            return this.pos;
        }

        public CPos getChunkPos() {
            return this.chunkPos;
        }

        public int getIndex() {
            return this.index;
        }

        public int getNumberInChunk() {
            return this.numberInChunk;
        }

        public String toString() {
            return "ChestData{index=" + this.index + ", cPos=" + this.chunkPos + ", bpos=" + this.pos + ", numberInChunk=" + this.numberInChunk + '}';
        }
    }
}
