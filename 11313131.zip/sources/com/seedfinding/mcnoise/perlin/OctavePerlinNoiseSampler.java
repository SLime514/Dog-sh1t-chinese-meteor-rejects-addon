package com.seedfinding.mcnoise.perlin;

import com.seedfinding.mccore.util.data.Pair;
import com.seedfinding.mccore.util.data.Quad;
import com.seedfinding.mcnoise.noise.NoiseSampler;
import com.seedfinding.mcnoise.utils.MathHelper;
import com.seedfinding.mcseed.rand.JRand;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class OctavePerlinNoiseSampler implements NoiseSampler {
    public final double lacunarity;
    public final double persistence;
    private final PerlinNoiseSampler[] octaveSamplers;
    private final List<Double> amplitudes;

    public OctavePerlinNoiseSampler(JRand random, int octaveCount) {
        this.amplitudes = null;
        this.octaveSamplers = new PerlinNoiseSampler[octaveCount];
        for (int i = 0; i < octaveCount; i++) {
            this.octaveSamplers[i] = new PerlinNoiseSampler(random);
        }
        this.lacunarity = 1.0d;
        this.persistence = 1.0d;
    }

    public int getCount() {
        return this.octaveSamplers.length;
    }

    public OctavePerlinNoiseSampler(JRand rand, IntStream octaves) {
        this(rand, (List<Integer>) octaves.boxed().collect(Collectors.toList()));
    }

    public static Pair<Integer, List<Double>> makeAmplitudes(List<Integer> octaves) {
        Quad<Integer, Integer, Integer, List<Integer>> processedOctaves = processOctaves(octaves);
        int start = processedOctaves.getFirst().intValue();
        List<Double> octavePlaces = new ArrayList<>();
        Iterator<Integer> it = processedOctaves.getFourth().iterator();
        while (it.hasNext()) {
            int octave = it.next().intValue();
            octavePlaces.set(octave + start, Double.valueOf(1.0d));
        }
        return new Pair<>(Integer.valueOf(start), octavePlaces);
    }

    public OctavePerlinNoiseSampler(JRand rand, Pair<Integer, List<Double>> octaveParams) {
        this.amplitudes = octaveParams.getSecond();
        PerlinNoiseSampler perlin = new PerlinNoiseSampler(rand);
        int length = this.amplitudes.size();
        int start = octaveParams.getFirst().intValue();
        this.octaveSamplers = new PerlinNoiseSampler[length];
        if (start >= 0 && start < length) {
            double d0 = this.amplitudes.get(start).doubleValue();
            if (d0 != 0.0d) {
                this.octaveSamplers[start] = perlin;
            }
        }
        for (int idx = start - 1; idx >= 0; idx--) {
            if (idx < length) {
                double d1 = this.amplitudes.get(idx).doubleValue();
                if (d1 != 0.0d) {
                    this.octaveSamplers[idx] = new PerlinNoiseSampler(rand);
                } else {
                    rand.advance(SKIP_262);
                }
            } else {
                rand.advance(SKIP_262);
            }
        }
        if (start < length - 1) {
            long noiseSeed = (long) (perlin.sample(0.0d, 0.0d, 0.0d, 0.0d, 0.0d) * 9.223372036854776E18d);
            rand.setSeed(noiseSeed);
            for (int l = start + 1; l < length; l++) {
                if (l >= 0) {
                    double d2 = this.amplitudes.get(l).doubleValue();
                    if (d2 != 0.0d) {
                        this.octaveSamplers[l] = new PerlinNoiseSampler(rand);
                    } else {
                        rand.advance(SKIP_262);
                    }
                } else {
                    rand.advance(SKIP_262);
                }
            }
        }
        this.persistence = Math.pow(2.0d, -start);
        this.lacunarity = Math.pow(2.0d, length - 1) / (Math.pow(2.0d, length) - 1.0d);
    }

    private static Quad<Integer, Integer, Integer, List<Integer>> processOctaves(List<Integer> octaves) {
        List<Integer> octaves2 = (List) octaves.stream().sorted((v0, v1) -> {
            return v0.compareTo(v1);
        }).collect(Collectors.toList());
        if (octaves2.isEmpty()) {
            throw new IllegalArgumentException("Need some octaves!");
        }
        int start = -octaves2.get(0).intValue();
        int end = octaves2.get(octaves2.size() - 1).intValue();
        int length = start + end + 1;
        if (length < 1) {
            throw new IllegalArgumentException("Total number of octaves needs to be >= 1");
        }
        return new Quad<>(Integer.valueOf(start), Integer.valueOf(end), Integer.valueOf(length), octaves2);
    }

    public OctavePerlinNoiseSampler(JRand rand, List<Integer> octaves) {
        this.amplitudes = null;
        Quad<Integer, Integer, Integer, List<Integer>> processedOctaves = processOctaves(octaves);
        int end = processedOctaves.getSecond().intValue();
        int length = processedOctaves.getThird().intValue();
        PerlinNoiseSampler perlin = new PerlinNoiseSampler(rand);
        this.octaveSamplers = new PerlinNoiseSampler[length];
        if (end >= 0 && end < length && octaves.contains(0)) {
            this.octaveSamplers[end] = perlin;
        }
        for (int idx = end + 1; idx < length; idx++) {
            if (idx >= 0 && octaves.contains(Integer.valueOf(end - idx))) {
                this.octaveSamplers[idx] = new PerlinNoiseSampler(rand);
            } else {
                rand.advance(SKIP_262);
            }
        }
        if (end > 0) {
            long noiseSeed = (long) (perlin.sample(0.0d, 0.0d, 0.0d, 0.0d, 0.0d) * 9.223372036854776E18d);
            rand.setSeed(noiseSeed);
            for (int index = end - 1; index >= 0; index--) {
                if (index < length && octaves.contains(Integer.valueOf(end - index))) {
                    this.octaveSamplers[index] = new PerlinNoiseSampler(rand);
                } else {
                    rand.advance(SKIP_262);
                }
            }
        }
        this.persistence = Math.pow(2.0d, end);
        this.lacunarity = 1.0d / (Math.pow(2.0d, length) - 1.0d);
    }

    public double sample(double x, double y, double z) {
        return sample(x, y, z, 0.0d, 0.0d, false);
    }

    public double sample(double x, double y, double z, double yAmplification, double minY, boolean useDefaultY) {
        double noise = 0.0d;
        double persistence = this.persistence;
        double lacunarity = this.lacunarity;
        for (int idx = 0; idx < this.octaveSamplers.length; idx++) {
            PerlinNoiseSampler sampler = this.octaveSamplers[idx];
            if (sampler != null) {
                double sample = sampler.sample(MathHelper.maintainPrecision(x * persistence), useDefaultY ? -sampler.originY : MathHelper.maintainPrecision(y * persistence), MathHelper.maintainPrecision(z * persistence), yAmplification * persistence, minY * persistence) * lacunarity;
                noise += (this.amplitudes != null ? this.amplitudes.get(idx).doubleValue() : 1.0d) * sample;
            }
            persistence /= 2.0d;
            lacunarity *= 2.0d;
        }
        return noise;
    }

    public PerlinNoiseSampler getOctave(int octave) {
        return this.octaveSamplers[octave];
    }

    @Override
    public double sample(double x, double y, double yAmplification, double minY) {
        return sample(x, y, 0.0d, yAmplification, minY, false);
    }
}
