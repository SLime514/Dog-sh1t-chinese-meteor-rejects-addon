package com.seedfinding.mcnoise.simplex;

import com.seedfinding.mcnoise.noise.Noise;
import com.seedfinding.mcnoise.utils.MathHelper;
import com.seedfinding.mcseed.rand.JRand;

public class SimplexNoiseSampler extends Noise {
    private static final double SQRT_3 = Math.sqrt(3.0d);
    private static final double SKEW_FACTOR_2D = 0.5d * (SQRT_3 - 1.0d);
    private static final double UNSKEW_FACTOR_2D = (3.0d - SQRT_3) / 6.0d;

    private static final double f73F3 = 0.3333333333333333d;

    private static final double f74G3 = 0.16666666666666666d;

    public SimplexNoiseSampler(JRand rand) {
        super(rand);
    }

    public double sample2D(double x, double y) {
        byte offsetSecondCornerX;
        byte offsetSecondCornerZ;
        double hairyFactor = (x + y) * SKEW_FACTOR_2D;
        int hairyX = MathHelper.floor(x + hairyFactor);
        int hairyZ = MathHelper.floor(y + hairyFactor);
        double mixedHairyXz = (hairyX + hairyZ) * UNSKEW_FACTOR_2D;
        double diffXToXz = hairyX - mixedHairyXz;
        double diffZToXz = hairyZ - mixedHairyXz;
        double x0 = x - diffXToXz;
        double y0 = y - diffZToXz;
        if (x0 > y0) {
            offsetSecondCornerX = 1;
            offsetSecondCornerZ = 0;
        } else {
            offsetSecondCornerX = 0;
            offsetSecondCornerZ = 1;
        }
        double x1 = (x0 - offsetSecondCornerX) + UNSKEW_FACTOR_2D;
        double y1 = (y0 - offsetSecondCornerZ) + UNSKEW_FACTOR_2D;
        double x3 = (x0 - 1.0d) + (2.0d * UNSKEW_FACTOR_2D);
        double y3 = (y0 - 1.0d) + (2.0d * UNSKEW_FACTOR_2D);
        int ii = hairyX & 255;
        int jj = hairyZ & 255;
        int gi0 = lookup(ii + lookup(jj)) % 12;
        int gi1 = lookup((ii + offsetSecondCornerX) + lookup(jj + offsetSecondCornerZ)) % 12;
        int gi2 = lookup((ii + 1) + lookup(jj + 1)) % 12;
        double t0 = cornerNoise3d(gi0, x0, y0, 0.0d, 0.5d);
        double t1 = cornerNoise3d(gi1, x1, y1, 0.0d, 0.5d);
        double t2 = cornerNoise3d(gi2, x3, y3, 0.0d, 0.5d);
        return 70.0d * (t0 + t1 + t2);
    }

    public double sample3D(double x, double y, double z) {
        byte i1;
        byte j1;
        byte k1;
        byte i2;
        byte j2;
        byte k2;
        double skewFactor = (x + y + z) * f73F3;
        int i = MathHelper.floor(x + skewFactor);
        int j = MathHelper.floor(y + skewFactor);
        int k = MathHelper.floor(z + skewFactor);
        double unskewFactor = (i + j + k) * f74G3;
        double x0 = i - unskewFactor;
        double y0 = j - unskewFactor;
        double z0 = k - unskewFactor;
        double x02 = x - x0;
        double y02 = y - y0;
        double z02 = z - z0;
        if (x02 >= y02) {
            if (y02 >= z02) {
                i1 = 1;
                j1 = 0;
                k1 = 0;
                i2 = 1;
                j2 = 1;
                k2 = 0;
            } else if (x02 >= z02) {
                i1 = 1;
                j1 = 0;
                k1 = 0;
                i2 = 1;
                j2 = 0;
                k2 = 1;
            } else {
                i1 = 0;
                j1 = 0;
                k1 = 1;
                i2 = 1;
                j2 = 0;
                k2 = 1;
            }
        } else if (y02 < z02) {
            i1 = 0;
            j1 = 0;
            k1 = 1;
            i2 = 0;
            j2 = 1;
            k2 = 1;
        } else if (x02 < z02) {
            i1 = 0;
            j1 = 1;
            k1 = 0;
            i2 = 0;
            j2 = 1;
            k2 = 1;
        } else {
            i1 = 0;
            j1 = 1;
            k1 = 0;
            i2 = 1;
            j2 = 1;
            k2 = 0;
        }
        double x1 = (x02 - i1) + f74G3;
        double y1 = (y02 - j1) + f74G3;
        double z1 = (z02 - k1) + f74G3;
        double x2 = (x02 - i2) + f73F3;
        double y2 = (y02 - j2) + f73F3;
        double z2 = (z02 - k2) + f73F3;
        double x3 = (x02 - 1.0d) + 0.5d;
        double y3 = (y02 - 1.0d) + 0.5d;
        double z3 = (z02 - 1.0d) + 0.5d;
        int ii = i & 255;
        int jj = j & 255;
        int kk = k & 255;
        int gi0 = lookup(ii + lookup(jj + lookup(kk))) % 12;
        int gi1 = lookup((ii + i1) + lookup((jj + j1) + lookup(kk + k1))) % 12;
        int gi2 = lookup((ii + i2) + lookup((jj + j2) + lookup(kk + k2))) % 12;
        int gi3 = lookup((ii + 1) + lookup((jj + 1) + lookup(kk + 1))) % 12;
        double t0 = cornerNoise3d(gi0, x02, y02, z02, 0.6d);
        double t1 = cornerNoise3d(gi1, x1, y1, z1, 0.6d);
        double t2 = cornerNoise3d(gi2, x2, y2, z2, 0.6d);
        double t3 = cornerNoise3d(gi3, x3, y3, z3, 0.6d);
        return 32.0d * (t0 + t1 + t2 + t3);
    }

    private double cornerNoise3d(int hash, double x, double y, double z, double max) {
        double result;
        double contribution = ((max - (x * x)) - (y * y)) - (z * z);
        if (contribution < 0.0d) {
            result = 0.0d;
        } else {
            double contribution2 = contribution * contribution;
            result = contribution2 * contribution2 * MathHelper.grad(hash, x, y, z);
        }
        return result;
    }
}
