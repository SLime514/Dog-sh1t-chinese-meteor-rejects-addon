package com.seedfinding.mcnoise.simplex;

import com.seedfinding.mcnoise.noise.NoiseSampler;
import com.seedfinding.mcseed.rand.JRand;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class OctaveSimplexNoiseSampler implements NoiseSampler {
    public final double lacunarity;
    public final double persistence;
    private final SimplexNoiseSampler[] octaveSamplers;

    public OctaveSimplexNoiseSampler(JRand random, int octaveCount) {
        this.octaveSamplers = new SimplexNoiseSampler[octaveCount];
        for (int i = 0; i < octaveCount; i++) {
            this.octaveSamplers[i] = new SimplexNoiseSampler(random);
        }
        this.lacunarity = 1.0d;
        this.persistence = 1.0d;
    }

    public OctaveSimplexNoiseSampler(JRand rand, IntStream octaves) {
        this(rand, (List<Integer>) octaves.boxed().collect(Collectors.toList()));
    }

    public OctaveSimplexNoiseSampler(JRand rand, List<Integer> octaves) {
        List<Integer> octaves2 = (List) octaves.stream().sorted((v0, v1) -> {
            return v0.compareTo(v1);
        }).collect(Collectors.toList());
        if (octaves2.isEmpty()) {
            throw new IllegalArgumentException("Need some octaves!");
        }
        int start = -octaves2.get(0).intValue();
        int end = octaves2.get(octaves2.size() - 1).intValue();
        int length = start + end + 1;
        if (length < 1) {
            throw new IllegalArgumentException("Total number of octaves needs to be >= 1");
        }
        SimplexNoiseSampler simplex = new SimplexNoiseSampler(rand);
        this.octaveSamplers = new SimplexNoiseSampler[length];
        if (end >= 0 && end < length && octaves2.contains(0)) {
            this.octaveSamplers[end] = simplex;
        }
        for (int idx = end + 1; idx < length; idx++) {
            if (idx >= 0 && octaves2.contains(Integer.valueOf(end - idx))) {
                this.octaveSamplers[idx] = new SimplexNoiseSampler(rand);
            } else {
                rand.advance(SKIP_262);
            }
        }
        if (end > 0) {
            long noiseSeed = (long) (simplex.sample3D(simplex.originX, simplex.originY, simplex.originZ) * 9.223372036854776E18d);
            rand.setSeed(noiseSeed);
            for (int index = end - 1; index >= 0; index--) {
                if (index < length && octaves2.contains(Integer.valueOf(end - index))) {
                    this.octaveSamplers[index] = new SimplexNoiseSampler(rand);
                } else {
                    rand.advance(SKIP_262);
                }
            }
        }
        this.persistence = Math.pow(2.0d, end);
        this.lacunarity = 1.0d / (Math.pow(2.0d, length) - 1.0d);
    }

    public double sample(double x, double y) {
        return sample(x, y, false);
    }

    public double sample(double x, double y, boolean useRandomOffset) {
        double noise = 0.0d;
        double persistence = this.persistence;
        double lacunarity = this.lacunarity;
        for (SimplexNoiseSampler sampler : this.octaveSamplers) {
            if (sampler != null) {
                noise += sampler.sample2D((x * persistence) + (useRandomOffset ? sampler.originX : 0.0d), (y * persistence) + (useRandomOffset ? sampler.originY : 0.0d)) * lacunarity;
            }
            persistence /= 2.0d;
            lacunarity *= 2.0d;
        }
        return noise;
    }

    @Override
    public double sample(double x, double y, double notUsed, double notUsed2) {
        return sample(x, y, true) * 0.55d;
    }
}
