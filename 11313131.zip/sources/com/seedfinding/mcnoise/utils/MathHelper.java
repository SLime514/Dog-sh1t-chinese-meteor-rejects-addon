package com.seedfinding.mcnoise.utils;

import com.seedfinding.mccore.nbt.NBTType;

public class MathHelper {
    public static final int[][] GRADIENTS = {new int[]{1, 1, 0}, new int[]{-1, 1, 0}, new int[]{1, -1, 0}, new int[]{-1, -1, 0}, new int[]{1, 0, 1}, new int[]{-1, 0, 1}, new int[]{1, 0, -1}, new int[]{-1, 0, -1}, new int[]{0, 1, 1}, new int[]{0, -1, 1}, new int[]{0, 1, -1}, new int[]{0, -1, -1}, new int[]{1, 1, 0}, new int[]{0, -1, 1}, new int[]{-1, 1, 0}, new int[]{0, -1, -1}};

    public static double grad(int hash, double x, double y, double z) {
        switch (hash & 15) {
            case 0:
                return x + y;
            case 1:
                return (-x) + y;
            case NBTType.SHORT:
                return x - y;
            case 3:
                return (-x) - y;
            case 4:
                return x + z;
            case NBTType.FLOAT:
                return (-x) + z;
            case 6:
                return x - z;
            case NBTType.BYTE_ARRAY:
                return (-x) - z;
            case 8:
                return y + z;
            case 9:
            case 13:
                return (-y) + z;
            case NBTType.COMPOUND:
                return y - z;
            case NBTType.INT_ARRAY:
            case 15:
                return (-y) - z;
            case NBTType.LONG_ARRAY:
                return y + x;
            case 14:
                return y - x;
            default:
                return 0.0d;
        }
    }

    public static long lfloor(double d) {
        long l = (long) d;
        return d < ((double) l) ? l - 1 : l;
    }

    public static double dot(int[] g, double x, double y, double z) {
        return (g[0] * x) + (g[1] * y) + (g[2] * z);
    }

    public static double lerp3(double deltaX, double deltaY, double deltaZ, double val000, double val100, double val010, double val110, double val001, double val101, double val011, double val111) {
        return lerp(deltaZ, lerp2(deltaX, deltaY, val000, val100, val010, val110), lerp2(deltaX, deltaY, val001, val101, val011, val111));
    }

    public static double lerp2(double deltaX, double deltaY, double val00, double val10, double val01, double val11) {
        return lerp(deltaY, lerp(deltaX, val00, val10), lerp(deltaX, val01, val11));
    }

    public static double lerp(double delta, double start, double end) {
        return start + (delta * (end - start));
    }

    public static double smoothStep(double d) {
        return d * d * d * ((d * ((d * 6.0d) - 15.0d)) + 10.0d);
    }

    public static int floor(double d) {
        int i = (int) d;
        return d < ((double) i) ? i - 1 : i;
    }

    public static double maintainPrecision(double d) {
        return d - (lfloor((d / 3.3554432E7d) + 0.5d) * 3.3554432E7d);
    }
}
