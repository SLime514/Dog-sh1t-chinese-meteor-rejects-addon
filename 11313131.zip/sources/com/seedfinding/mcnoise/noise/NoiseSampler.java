package com.seedfinding.mcnoise.noise;

import com.seedfinding.mcseed.lcg.LCG;

public interface NoiseSampler {
    public static final LCG SKIP_262 = LCG.JAVA.combine(262);

    double sample(double d, double d2, double d3, double d4);
}
