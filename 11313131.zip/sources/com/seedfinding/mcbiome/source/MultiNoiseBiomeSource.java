package com.seedfinding.mcbiome.source;

import com.seedfinding.mcbiome.biome.Biome;
import com.seedfinding.mcbiome.biome.BiomePoint;
import com.seedfinding.mcbiome.biome.Biomes;
import com.seedfinding.mcbiome.layer.IntBiomeLayer;
import com.seedfinding.mcbiome.layer.composite.VoronoiLayer;
import com.seedfinding.mcbiome.layer.noise.MultiNoiseLayer17;
import com.seedfinding.mccore.state.Dimension;
import com.seedfinding.mccore.util.pos.BPos;
import com.seedfinding.mccore.version.MCVersion;

public abstract class MultiNoiseBiomeSource extends LayeredBiomeSource<IntBiomeLayer> {
    protected final BiomePoint[] biomePoints;
    public MultiNoiseLayer17 full;
    public VoronoiLayer voronoi;
    protected boolean threeDimensional;

    @Override
    public abstract Dimension getDimension();

    protected abstract void build();

    public MultiNoiseBiomeSource(MCVersion version, long worldSeed, BiomePoint... biomePoints) {
        super(version, worldSeed);
        this.biomePoints = biomePoints;
        build();
    }

    public MultiNoiseBiomeSource addDimension() {
        this.threeDimensional = true;
        this.full = null;
        this.layers.clear();
        build();
        return this;
    }

    public boolean is3D() {
        return this.threeDimensional;
    }

    public BiomePoint[] getBiomePoints() {
        return this.biomePoints;
    }

    @Override
    public Biome getBiome(BPos bpos) {
        return Biomes.REGISTRY.get(Integer.valueOf(this.voronoi.get(bpos.getX(), bpos.getY(), bpos.getZ())));
    }

    @Override
    public Biome getBiome(int x, int y, int z) {
        return Biomes.REGISTRY.get(Integer.valueOf(this.voronoi.get(x, y, z)));
    }

    @Override
    public Biome getBiomeForNoiseGen(int x, int y, int z) {
        return Biomes.REGISTRY.get(Integer.valueOf(this.full.get(x, y, z)));
    }
}
