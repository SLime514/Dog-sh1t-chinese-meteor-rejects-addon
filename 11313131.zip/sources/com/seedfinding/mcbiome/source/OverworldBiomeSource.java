package com.seedfinding.mcbiome.source;

import com.seedfinding.mcbiome.biome.Biome;
import com.seedfinding.mcbiome.biome.Biomes;
import com.seedfinding.mcbiome.layer.IntBiomeLayer;
import com.seedfinding.mcbiome.layer.LayerStack;
import com.seedfinding.mcbiome.layer.composite.VoronoiLayer;
import com.seedfinding.mcbiome.layer.land.BambooJungleLayer;
import com.seedfinding.mcbiome.layer.land.BaseBiomesLayer;
import com.seedfinding.mcbiome.layer.land.ContinentLayer;
import com.seedfinding.mcbiome.layer.land.HillsLayer;
import com.seedfinding.mcbiome.layer.land.IslandLayer;
import com.seedfinding.mcbiome.layer.land.LandLayer;
import com.seedfinding.mcbiome.layer.land.MushroomLayer;
import com.seedfinding.mcbiome.layer.land.SunflowerPlainsLayer;
import com.seedfinding.mcbiome.layer.noise.NoiseLayer;
import com.seedfinding.mcbiome.layer.scale.ScaleLayer;
import com.seedfinding.mcbiome.layer.scale.SmoothScaleLayer;
import com.seedfinding.mcbiome.layer.shore.EaseEdgeLayer;
import com.seedfinding.mcbiome.layer.shore.EdgeBiomesLayer;
import com.seedfinding.mcbiome.layer.temperature.ClimateLayer;
import com.seedfinding.mcbiome.layer.water.DeepOceanLayer;
import com.seedfinding.mcbiome.layer.water.NoiseToRiverLayer;
import com.seedfinding.mcbiome.layer.water.OceanTemperatureLayer;
import com.seedfinding.mcbiome.layer.water.OldRiverInBiomes;
import com.seedfinding.mcbiome.layer.water.RiverLayer;
import com.seedfinding.mccore.state.Dimension;
import com.seedfinding.mccore.util.pos.BPos;
import com.seedfinding.mccore.version.MCVersion;
import com.seedfinding.mccore.version.UnsupportedVersion;
import java.util.function.BiFunction;

public class OverworldBiomeSource extends LayeredBiomeSource<IntBiomeLayer> {
    public int biomeSize;
    public int riverSize;
    public boolean useDefault1_1;
    public static final int DEFAULT_BIOME_SIZE = 4;
    public static final int LARGE_BIOME_SIZE = 6;
    public static final int DEFAULT_RIVER_SIZE = 4;
    public IntBiomeLayer base;
    public IntBiomeLayer ocean;
    public IntBiomeLayer noise;
    public IntBiomeLayer variants;
    public IntBiomeLayer biomes;
    public IntBiomeLayer river;
    public IntBiomeLayer full;
    public VoronoiLayer voronoi;
    public IntBiomeLayer debug;

    public OverworldBiomeSource(MCVersion version, long worldSeed) {
        this(version, worldSeed, 4, 4);
    }

    public OverworldBiomeSource(MCVersion version, long worldSeed, int biomeSize, int riverSize) {
        this(version, worldSeed, biomeSize, riverSize, false);
    }

    public OverworldBiomeSource(MCVersion version, long worldSeed, int biomeSize, int riverSize, boolean useDefault1_1) {
        super(version, worldSeed);
        if (getVersion().isOlderThan(MCVersion.vb1_8_1)) {
            throw new UnsupportedVersion(getVersion(), "overworld biomes");
        }
        if (getVersion().isOlderThan(MCVersion.vb1_8_1)) {
            System.out.println("WARNING USING TEMPORARY BIOME STACK (NOT VERIFIED)");
        }
        this.biomeSize = biomeSize;
        this.riverSize = riverSize;
        this.useDefault1_1 = useDefault1_1;
        build();
    }

    public void setBiomeSize(int biomeSize) {
        this.biomeSize = biomeSize;
        build();
    }

    public void setRiverSize(int riverSize) {
        this.riverSize = riverSize;
        build();
    }

    public void setUseDefault1_1(boolean useDefault1_1) {
        this.useDefault1_1 = useDefault1_1;
        build();
    }

    public void setLargeBiomeSize() {
        this.biomeSize = 6;
        build();
    }

    @Override
    public Dimension getDimension() {
        return Dimension.OVERWORLD;
    }

    protected void build() {
        this.layers.clear();
        BiFunction<Long, IntBiomeLayer, IntBiomeLayer> NORMAL_SCALE = (salt, parent) -> {
            return new ScaleLayer(getVersion(), getWorldSeed(), salt.longValue(), ScaleLayer.Type.NORMAL, parent);
        };
        LayerStack<T> layerStack = this.layers;
        ContinentLayer continentLayer = new ContinentLayer(getVersion(), getWorldSeed(), 1L);
        this.base = continentLayer;
        layerStack.add((LayerStack<T>) continentLayer);
        LayerStack<T> layerStack2 = this.layers;
        ScaleLayer scaleLayer = new ScaleLayer(getVersion(), getWorldSeed(), 2000L, ScaleLayer.Type.FUZZY, this.base);
        this.base = scaleLayer;
        layerStack2.add((LayerStack<T>) scaleLayer);
        LayerStack<T> layerStack3 = this.layers;
        LandLayer landLayer = new LandLayer(getVersion(), getWorldSeed(), 1L, this.base);
        this.base = landLayer;
        layerStack3.add((LayerStack<T>) landLayer);
        LayerStack<T> layerStack4 = this.layers;
        ScaleLayer scaleLayer2 = new ScaleLayer(getVersion(), getWorldSeed(), 2001L, ScaleLayer.Type.NORMAL, this.base);
        this.base = scaleLayer2;
        layerStack4.add((LayerStack<T>) scaleLayer2);
        LayerStack<T> layerStack5 = this.layers;
        LandLayer landLayer2 = new LandLayer(getVersion(), getWorldSeed(), 2L, this.base);
        this.base = landLayer2;
        layerStack5.add((LayerStack<T>) landLayer2);
        if (getVersion().isNewerOrEqualTo(MCVersion.v1_7_2)) {
            LayerStack<T> layerStack6 = this.layers;
            LandLayer landLayer3 = new LandLayer(getVersion(), getWorldSeed(), 50L, this.base);
            this.base = landLayer3;
            layerStack6.add((LayerStack<T>) landLayer3);
            LayerStack<T> layerStack7 = this.layers;
            LandLayer landLayer4 = new LandLayer(getVersion(), getWorldSeed(), 70L, this.base);
            this.base = landLayer4;
            layerStack7.add((LayerStack<T>) landLayer4);
            LayerStack<T> layerStack8 = this.layers;
            IslandLayer islandLayer = new IslandLayer(getVersion(), getWorldSeed(), 2L, this.base);
            this.base = islandLayer;
            layerStack8.add((LayerStack<T>) islandLayer);
        }
        if (getVersion().isNewerOrEqualTo(MCVersion.v1_0)) {
            LayerStack<T> layerStack9 = this.layers;
            ClimateLayer.Cold cold = new ClimateLayer.Cold(getVersion(), getWorldSeed(), 2L, this.base);
            this.base = cold;
            layerStack9.add((LayerStack<T>) cold);
        }
        if (getVersion().isNewerOrEqualTo(MCVersion.v1_7_2)) {
            LayerStack<T> layerStack10 = this.layers;
            LandLayer landLayer5 = new LandLayer(getVersion(), getWorldSeed(), 3L, this.base);
            this.base = landLayer5;
            layerStack10.add((LayerStack<T>) landLayer5);
            LayerStack<T> layerStack11 = this.layers;
            ClimateLayer.Temperate temperate = new ClimateLayer.Temperate(getVersion(), getWorldSeed(), 2L, this.base);
            this.base = temperate;
            layerStack11.add((LayerStack<T>) temperate);
            LayerStack<T> layerStack12 = this.layers;
            ClimateLayer.Cool cool = new ClimateLayer.Cool(getVersion(), getWorldSeed(), 2L, this.base);
            this.base = cool;
            layerStack12.add((LayerStack<T>) cool);
            LayerStack<T> layerStack13 = this.layers;
            ClimateLayer.Special special = new ClimateLayer.Special(getVersion(), getWorldSeed(), 3L, this.base);
            this.base = special;
            layerStack13.add((LayerStack<T>) special);
        }
        LayerStack<T> layerStack14 = this.layers;
        ScaleLayer scaleLayer3 = new ScaleLayer(getVersion(), getWorldSeed(), 2002L, ScaleLayer.Type.NORMAL, this.base);
        this.base = scaleLayer3;
        layerStack14.add((LayerStack<T>) scaleLayer3);
        if (getVersion().isOlderOrEqualTo(MCVersion.v1_6_4)) {
            LayerStack<T> layerStack15 = this.layers;
            LandLayer landLayer6 = new LandLayer(getVersion(), getWorldSeed(), 3L, this.base);
            this.base = landLayer6;
            layerStack15.add((LayerStack<T>) landLayer6);
        }
        LayerStack<T> layerStack16 = this.layers;
        ScaleLayer scaleLayer4 = new ScaleLayer(getVersion(), getWorldSeed(), 2003L, ScaleLayer.Type.NORMAL, this.base);
        this.base = scaleLayer4;
        layerStack16.add((LayerStack<T>) scaleLayer4);
        LayerStack<T> layerStack17 = this.layers;
        LandLayer landLayer7 = new LandLayer(getVersion(), getWorldSeed(), getVersion().isNewerOrEqualTo(MCVersion.v1_0) ? 4L : 3L, this.base);
        this.base = landLayer7;
        layerStack17.add((LayerStack<T>) landLayer7);
        if (getVersion().isNewerOrEqualTo(MCVersion.v1_0)) {
            LayerStack<T> layerStack18 = this.layers;
            MushroomLayer mushroomLayer = new MushroomLayer(getVersion(), getWorldSeed(), 5L, this.base);
            this.base = mushroomLayer;
            layerStack18.add((LayerStack<T>) mushroomLayer);
        } else {
            LayerStack<T> layerStack19 = this.layers;
            ScaleLayer scaleLayer5 = new ScaleLayer(getVersion(), getWorldSeed(), 2004L, ScaleLayer.Type.NORMAL, this.base);
            this.base = scaleLayer5;
            layerStack19.add((LayerStack<T>) scaleLayer5);
            LayerStack<T> layerStack20 = this.layers;
            LandLayer landLayer8 = new LandLayer(getVersion(), getWorldSeed(), 3L, this.base);
            this.base = landLayer8;
            layerStack20.add((LayerStack<T>) landLayer8);
        }
        if (getVersion().isNewerOrEqualTo(MCVersion.v1_7_2)) {
            LayerStack<T> layerStack21 = this.layers;
            DeepOceanLayer deepOceanLayer = new DeepOceanLayer(getVersion(), getWorldSeed(), 4L, this.base);
            this.base = deepOceanLayer;
            layerStack21.add((LayerStack<T>) deepOceanLayer);
        }
        LayerStack<T> layerStack22 = this.layers;
        BaseBiomesLayer default1_1 = new BaseBiomesLayer(getVersion(), getWorldSeed(), 200L, this.base).setDefault1_1(this.useDefault1_1);
        this.biomes = default1_1;
        layerStack22.add((LayerStack<T>) default1_1);
        if (getVersion().isNewerOrEqualTo(MCVersion.v1_14)) {
            LayerStack<T> layerStack23 = this.layers;
            BambooJungleLayer bambooJungleLayer = new BambooJungleLayer(getVersion(), getWorldSeed(), 1001L, this.biomes);
            this.biomes = bambooJungleLayer;
            layerStack23.add((LayerStack<T>) bambooJungleLayer);
        }
        this.biomes = stack(1000L, NORMAL_SCALE, this.biomes, 2);
        if (getVersion().isNewerOrEqualTo(MCVersion.v1_7_2)) {
            LayerStack<T> layerStack24 = this.layers;
            EaseEdgeLayer easeEdgeLayer = new EaseEdgeLayer(getVersion(), getWorldSeed(), 1000L, this.biomes);
            this.biomes = easeEdgeLayer;
            layerStack24.add((LayerStack<T>) easeEdgeLayer);
        }
        LayerStack<T> layerStack25 = this.layers;
        NoiseLayer noiseLayer = new NoiseLayer(getVersion(), getWorldSeed(), 100L, this.base);
        this.noise = noiseLayer;
        layerStack25.add((LayerStack<T>) noiseLayer);
        if (getVersion().isOlderThan(MCVersion.v1_13)) {
            this.river = stack(1000L, NORMAL_SCALE, this.noise, 2);
            LayerStack<T> layerStack26 = this.layers;
            ScaleLayer scaleLayer6 = new ScaleLayer(getVersion(), 0L, 0L, ScaleLayer.Type.NORMAL, this.noise);
            this.noise = scaleLayer6;
            layerStack26.add((LayerStack<T>) scaleLayer6);
            LayerStack<T> layerStack27 = this.layers;
            ScaleLayer scaleLayer7 = new ScaleLayer(getVersion(), 0L, 0L, ScaleLayer.Type.NORMAL, this.noise);
            this.noise = scaleLayer7;
            layerStack27.add((LayerStack<T>) scaleLayer7);
        } else {
            LayerStack<T> layerStack28 = this.layers;
            ScaleLayer scaleLayer8 = new ScaleLayer(getVersion(), getWorldSeed(), 1000L, ScaleLayer.Type.NORMAL, this.noise);
            this.noise = scaleLayer8;
            layerStack28.add((LayerStack<T>) scaleLayer8);
            LayerStack<T> layerStack29 = this.layers;
            ScaleLayer scaleLayer9 = new ScaleLayer(getVersion(), getWorldSeed(), 1001L, ScaleLayer.Type.NORMAL, this.noise);
            this.noise = scaleLayer9;
            layerStack29.add((LayerStack<T>) scaleLayer9);
        }
        if (getVersion().isNewerOrEqualTo(MCVersion.v1_1)) {
            LayerStack<T> layerStack30 = this.layers;
            HillsLayer hillsLayer = new HillsLayer(getVersion(), getWorldSeed(), 1000L, this.biomes, this.noise);
            this.variants = hillsLayer;
            layerStack30.add((LayerStack<T>) hillsLayer);
        } else {
            this.variants = this.biomes;
        }
        if (getVersion().isNewerOrEqualTo(MCVersion.v1_7_2)) {
            LayerStack<T> layerStack31 = this.layers;
            SunflowerPlainsLayer sunflowerPlainsLayer = new SunflowerPlainsLayer(getVersion(), getWorldSeed(), 1001L, this.variants);
            this.variants = sunflowerPlainsLayer;
            layerStack31.add((LayerStack<T>) sunflowerPlainsLayer);
        }
        for (int i = 0; i < this.biomeSize; i++) {
            LayerStack<T> layerStack32 = this.layers;
            ScaleLayer scaleLayer10 = new ScaleLayer(getVersion(), getWorldSeed(), 1000 + i, ScaleLayer.Type.NORMAL, this.variants);
            this.variants = scaleLayer10;
            layerStack32.add((LayerStack<T>) scaleLayer10);
            if (i == 0) {
                LayerStack<T> layerStack33 = this.layers;
                LandLayer landLayer9 = new LandLayer(getVersion(), getWorldSeed(), 3L, this.variants);
                this.variants = landLayer9;
                layerStack33.add((LayerStack<T>) landLayer9);
            }
            if ((getVersion().isNewerOrEqualTo(MCVersion.v1_1) && (i == 1 || (this.biomeSize == 1 && getVersion().isNewerOrEqualTo(MCVersion.v1_8)))) || (getVersion().isOlderOrEqualTo(MCVersion.v1_0) && i == 0 && getVersion().isNewerOrEqualTo(MCVersion.v1_0))) {
                LayerStack<T> layerStack34 = this.layers;
                EdgeBiomesLayer edgeBiomesLayer = new EdgeBiomesLayer(getVersion(), getWorldSeed(), 1000L, this.variants);
                this.variants = edgeBiomesLayer;
                layerStack34.add((LayerStack<T>) edgeBiomesLayer);
            }
            if (i == 1 && getVersion().isBetween(MCVersion.v1_1, MCVersion.v1_6_4)) {
                LayerStack<T> layerStack35 = this.layers;
                OldRiverInBiomes oldRiverInBiomes = new OldRiverInBiomes(getVersion(), getWorldSeed(), 1000L, this.variants);
                this.variants = oldRiverInBiomes;
                layerStack35.add((LayerStack<T>) oldRiverInBiomes);
            }
        }
        LayerStack<T> layerStack36 = this.layers;
        SmoothScaleLayer smoothScaleLayer = new SmoothScaleLayer(getVersion(), getWorldSeed(), 1000L, this.variants);
        this.variants = smoothScaleLayer;
        layerStack36.add((LayerStack<T>) smoothScaleLayer);
        this.river = stack(getVersion().isNewerOrEqualTo(MCVersion.v1_7_2) ? 1000L : 1002L, NORMAL_SCALE, getVersion().isOlderThan(MCVersion.v1_13) ? this.river : this.noise, getVersion().isNewerOrEqualTo(MCVersion.v1_8) ? this.riverSize : this.biomeSize);
        LayerStack<T> layerStack37 = this.layers;
        NoiseToRiverLayer noiseToRiverLayer = new NoiseToRiverLayer(getVersion(), getWorldSeed(), 1L, this.river);
        this.river = noiseToRiverLayer;
        layerStack37.add((LayerStack<T>) noiseToRiverLayer);
        LayerStack<T> layerStack38 = this.layers;
        SmoothScaleLayer smoothScaleLayer2 = new SmoothScaleLayer(getVersion(), getWorldSeed(), 1000L, this.river);
        this.river = smoothScaleLayer2;
        layerStack38.add((LayerStack<T>) smoothScaleLayer2);
        LayerStack<T> layerStack39 = this.layers;
        RiverLayer riverLayer = new RiverLayer(getVersion(), getWorldSeed(), 100L, this.variants, this.river);
        this.full = riverLayer;
        layerStack39.add((LayerStack<T>) riverLayer);
        if (getVersion().isNewerOrEqualTo(MCVersion.v1_13)) {
            LayerStack<T> layerStack40 = this.layers;
            OceanTemperatureLayer oceanTemperatureLayer = new OceanTemperatureLayer(getVersion(), getWorldSeed(), 2L);
            this.ocean = oceanTemperatureLayer;
            layerStack40.add((LayerStack<T>) oceanTemperatureLayer);
            this.ocean = stack(2001L, NORMAL_SCALE, this.ocean, 6);
            LayerStack<T> layerStack41 = this.layers;
            OceanTemperatureLayer.Apply apply = new OceanTemperatureLayer.Apply(getVersion(), getWorldSeed(), 100L, this.full, this.ocean);
            this.full = apply;
            layerStack41.add((LayerStack<T>) apply);
        }
        LayerStack<T> layerStack42 = this.layers;
        VoronoiLayer voronoiLayer = new VoronoiLayer(getVersion(), getWorldSeed(), false, this.full);
        this.voronoi = voronoiLayer;
        layerStack42.add((LayerStack<T>) voronoiLayer);
        this.layers.setScales();
    }

    public IntBiomeLayer stack(long salt, BiFunction<Long, IntBiomeLayer, IntBiomeLayer> layer, IntBiomeLayer parent, int count) {
        for (int i = 0; i < count; i++) {
            LayerStack<T> layerStack = this.layers;
            IntBiomeLayer intBiomeLayerApply = layer.apply(Long.valueOf(salt + i), parent);
            parent = intBiomeLayerApply;
            layerStack.add((LayerStack<T>) intBiomeLayerApply);
        }
        return parent;
    }

    @Override
    public Biome getBiome(BPos bpos) {
        return Biomes.REGISTRY.get(Integer.valueOf(this.voronoi.get(bpos.getX(), 0, bpos.getZ())));
    }

    @Override
    public Biome getBiome(int x, int y, int z) {
        return Biomes.REGISTRY.get(Integer.valueOf(this.voronoi.get(x, 0, z)));
    }

    @Override
    public Biome getBiomeForNoiseGen(int x, int y, int z) {
        return Biomes.REGISTRY.get(Integer.valueOf(this.full.get(x, 0, z)));
    }
}
