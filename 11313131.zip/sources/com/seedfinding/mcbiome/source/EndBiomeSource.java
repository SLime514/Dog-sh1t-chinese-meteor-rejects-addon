package com.seedfinding.mcbiome.source;

import com.seedfinding.mcbiome.biome.Biome;
import com.seedfinding.mcbiome.biome.Biomes;
import com.seedfinding.mcbiome.layer.BiomeLayer;
import com.seedfinding.mcbiome.layer.LayerStack;
import com.seedfinding.mcbiome.layer.composite.VoronoiLayer;
import com.seedfinding.mcbiome.layer.end.EndBiomeLayer;
import com.seedfinding.mcbiome.layer.end.EndHeightLayer;
import com.seedfinding.mcbiome.layer.end.EndSimplexLayer;
import com.seedfinding.mccore.state.Dimension;
import com.seedfinding.mccore.util.pos.BPos;
import com.seedfinding.mccore.version.MCVersion;

public class EndBiomeSource extends LayeredBiomeSource<BiomeLayer> {
    public EndSimplexLayer simplex;
    public EndHeightLayer height;
    public EndBiomeLayer full;
    public VoronoiLayer voronoi;

    public EndBiomeSource(MCVersion version, long worldSeed) {
        super(version, worldSeed);
        build();
    }

    @Override
    public Dimension getDimension() {
        return Dimension.END;
    }

    protected void build() {
        LayerStack<T> layerStack = this.layers;
        EndSimplexLayer endSimplexLayer = new EndSimplexLayer(getVersion(), getWorldSeed());
        this.simplex = endSimplexLayer;
        layerStack.add((LayerStack<T>) endSimplexLayer);
        LayerStack<T> layerStack2 = this.layers;
        EndHeightLayer endHeightLayer = new EndHeightLayer(getVersion(), this.simplex);
        this.height = endHeightLayer;
        layerStack2.add((LayerStack<T>) endHeightLayer);
        LayerStack<T> layerStack3 = this.layers;
        EndBiomeLayer endBiomeLayer = new EndBiomeLayer(getVersion(), this.height);
        this.full = endBiomeLayer;
        layerStack3.add((LayerStack<T>) endBiomeLayer);
        LayerStack<T> layerStack4 = this.layers;
        VoronoiLayer voronoiLayer = new VoronoiLayer(getVersion(), getWorldSeed(), false, this.full) {
            @Override
            public int sample(int x, int y, int z) {
                return getVersion().isOlderThan(MCVersion.v1_13) ? Biomes.THE_END.getId() : super.sample(x, y, z);
            }
        };
        this.voronoi = voronoiLayer;
        layerStack4.add((LayerStack<T>) voronoiLayer);
        this.layers.setScales();
    }

    @Override
    public Biome getBiome(BPos bpos) {
        return Biomes.REGISTRY.get(Integer.valueOf(this.voronoi.get(bpos.getX(), 0, bpos.getZ())));
    }

    @Override
    public Biome getBiome(int x, int y, int z) {
        return Biomes.REGISTRY.get(Integer.valueOf(this.voronoi.get(x, 0, z)));
    }

    public Biome getBiome3D(int x, int y, int z) {
        return Biomes.REGISTRY.get(Integer.valueOf(this.voronoi.get(x, y, z)));
    }

    @Override
    public Biome getBiomeForNoiseGen(int x, int y, int z) {
        return Biomes.REGISTRY.get(Integer.valueOf(this.full.get(x, 0, z)));
    }
}
