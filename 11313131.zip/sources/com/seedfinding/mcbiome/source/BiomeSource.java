package com.seedfinding.mcbiome.source;

import com.seedfinding.mcbiome.biome.Biome;
import com.seedfinding.mccore.state.Dimension;
import com.seedfinding.mccore.util.pos.BPos;
import com.seedfinding.mccore.version.MCVersion;
import com.seedfinding.mcseed.rand.JRand;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;
import java.util.function.Predicate;

public abstract class BiomeSource {
    private final StaticNoiseSource staticNoiseSource;
    private final MCVersion version;
    private final long worldSeed;

    @FunctionalInterface
    public interface Factory {
        BiomeSource create(MCVersion mCVersion, long j);
    }

    public abstract Dimension getDimension();

    public abstract Biome getBiome(BPos bPos);

    public abstract Biome getBiome(int i, int i2, int i3);

    public abstract Biome getBiomeForNoiseGen(int i, int i2, int i3);

    public BiomeSource(MCVersion version, long worldSeed) {
        this.version = version;
        this.worldSeed = worldSeed;
        this.staticNoiseSource = new StaticNoiseSource(worldSeed);
    }

    public StaticNoiseSource getStaticNoiseSource() {
        return this.staticNoiseSource;
    }

    public static Factory factory(Dimension dimension) {
        if (dimension == Dimension.OVERWORLD) {
            return OverworldBiomeSource::new;
        }
        if (dimension == Dimension.NETHER) {
            return NetherBiomeSource::new;
        }
        if (dimension == Dimension.END) {
            return EndBiomeSource::new;
        }
        return null;
    }

    public static BiomeSource m8of(Dimension dimension, MCVersion version, long worldSeed) {
        Factory factory = factory(dimension);
        if (factory == null) {
            return null;
        }
        return factory.create(version, worldSeed);
    }

    public MCVersion getVersion() {
        return this.version;
    }

    public long getWorldSeed() {
        return this.worldSeed;
    }

    public boolean iterateUniqueBiomes(int x, int y, int z, int radius, Predicate<Biome> shouldContinue) {
        int i = (x - radius) >> 2;
        int j = (y - radius) >> 2;
        int k = (z - radius) >> 2;
        int l = (x + radius) >> 2;
        int m = (y + radius) >> 2;
        int n = (z + radius) >> 2;
        int o = (l - i) + 1;
        int p = (m - j) + 1;
        int q = (n - k) + 1;
        Set<Integer> set = new HashSet<>();
        for (int r = 0; r < q; r++) {
            for (int s = 0; s < o; s++) {
                for (int t = 0; t < p; t++) {
                    int u = i + s;
                    int v = j + t;
                    int w = k + r;
                    Biome b = getBiomeForNoiseGen(u, v, w);
                    if (!set.contains(Integer.valueOf(b.getId())) && !shouldContinue.test(b)) {
                        return false;
                    }
                    set.add(Integer.valueOf(b.getId()));
                }
            }
        }
        return true;
    }

    public boolean iterateUniqueBiomes(int x, int z, int radius, Predicate<Biome> shouldContinue) {
        int i = (x - radius) >> 2;
        int k = (z - radius) >> 2;
        int l = (x + radius) >> 2;
        int n = (z + radius) >> 2;
        int o = (l - i) + 1;
        int q = (n - k) + 1;
        Set<Integer> set = new HashSet<>();
        for (int r = 0; r < q; r++) {
            for (int s = 0; s < o; s++) {
                int u = i + s;
                int w = k + r;
                Biome b = getBiomeForNoiseGen(u, 0, w);
                if (!set.contains(Integer.valueOf(b.getId())) && !shouldContinue.test(b)) {
                    return false;
                }
                set.add(Integer.valueOf(b.getId()));
            }
        }
        return true;
    }

    public BPos locateNearestBiome(int centerX, int centerY, int centerZ, int radius, Collection<Biome> biomes, JRand rand) {
        return locateBiome(centerX, centerY, centerZ, radius, 1, biomes, rand, true);
    }

    public BPos locateBiome(int centerX, int centerY, int centerZ, int radius, Collection<Biome> biomes, JRand rand) {
        return locateBiome(centerX, centerY, centerZ, radius, 1, biomes, rand, false);
    }

    public com.seedfinding.mccore.util.pos.BPos locateBiome(int r8, int r9, int r10, int r11, int r12, java.util.Collection<com.seedfinding.mcbiome.biome.Biome> r13, com.seedfinding.mcseed.rand.JRand r14, boolean r15) {
        throw new UnsupportedOperationException("Method not decompiled: com.seedfinding.mcbiome.source.BiomeSource.locateBiome(int, int, int, int, int, java.util.Collection, com.seedfinding.mcseed.rand.JRand, boolean):com.seedfinding.mccore.util.pos.BPos");
    }

    public BPos locateBiome12(int posX, int posZ, int radius, Collection<Biome> biomes, JRand rand) {
        int lowerX = (posX - radius) >> 2;
        int lowerZ = (posZ - radius) >> 2;
        int upperX = (posX + radius) >> 2;
        int upperZ = (posZ + radius) >> 2;
        int counter = 0;
        BPos pos = null;
        for (int z = lowerZ; z <= upperZ; z++) {
            for (int x = lowerX; x <= upperX; x++) {
                Biome biome = getBiomeForNoiseGen(x, 0, z);
                if (biomes.contains(biome) && (pos == null || rand.nextInt(counter + 1) == 0)) {
                    pos = new BPos(x << 2, 0, z << 2);
                    counter++;
                }
            }
        }
        return pos;
    }
}
