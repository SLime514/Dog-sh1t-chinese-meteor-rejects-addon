package com.seedfinding.mcbiome.source;

import com.seedfinding.mcbiome.biome.BiomePoint;
import com.seedfinding.mcbiome.biome.Biomes;
import com.seedfinding.mcbiome.layer.LayerStack;
import com.seedfinding.mcbiome.layer.composite.VoronoiLayer;
import com.seedfinding.mcbiome.layer.noise.MultiNoiseLayer17;
import com.seedfinding.mccore.state.Dimension;
import com.seedfinding.mccore.version.MCVersion;

public class NetherBiomeSource extends MultiNoiseBiomeSource {
    private static final BiomePoint[] DEFAULT_BIOME_POINTS = {new BiomePoint(Biomes.NETHER_WASTES, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f), new BiomePoint(Biomes.SOUL_SAND_VALLEY, 0.0f, -0.5f, 0.0f, 0.0f, 0.0f), new BiomePoint(Biomes.CRIMSON_FOREST, 0.4f, 0.0f, 0.0f, 0.0f, 0.0f), new BiomePoint(Biomes.WARPED_FOREST, 0.0f, 0.5f, 0.0f, 0.0f, 0.375f), new BiomePoint(Biomes.BASALT_DELTAS, -0.5f, 0.0f, 0.0f, 0.0f, 0.175f)};

    public NetherBiomeSource(MCVersion version, long worldSeed) {
        super(version, worldSeed, DEFAULT_BIOME_POINTS);
    }

    @Override
    public Dimension getDimension() {
        return Dimension.NETHER;
    }

    @Override
    protected void build() {
        if (getVersion().isNewerOrEqualTo(MCVersion.v1_16)) {
            LayerStack<T> layerStack = this.layers;
            MultiNoiseLayer17 multiNoiseLayer17 = new MultiNoiseLayer17(getVersion(), getWorldSeed(), this.threeDimensional, this.biomePoints);
            this.full = multiNoiseLayer17;
            layerStack.add((LayerStack<T>) multiNoiseLayer17);
            LayerStack<T> layerStack2 = this.layers;
            VoronoiLayer voronoiLayer = new VoronoiLayer(getVersion(), getWorldSeed(), true, this.full);
            this.voronoi = voronoiLayer;
            layerStack2.add((LayerStack<T>) voronoiLayer);
        } else {
            LayerStack<T> layerStack3 = this.layers;
            MultiNoiseLayer17 multiNoiseLayer172 = new MultiNoiseLayer17(getVersion(), getWorldSeed(), this.threeDimensional, this.biomePoints) {
                @Override
                public int sample(int x, int y, int z) {
                    return Biomes.NETHER_WASTES.getId();
                }
            };
            this.full = multiNoiseLayer172;
            layerStack3.add((LayerStack<T>) multiNoiseLayer172);
            LayerStack<T> layerStack4 = this.layers;
            VoronoiLayer voronoiLayer2 = new VoronoiLayer(getVersion(), getWorldSeed(), false, this.full) {
                @Override
                public int sample(int x, int y, int z) {
                    return Biomes.NETHER_WASTES.getId();
                }
            };
            this.voronoi = voronoiLayer2;
            layerStack4.add((LayerStack<T>) voronoiLayer2);
        }
        this.layers.setScales();
    }
}
