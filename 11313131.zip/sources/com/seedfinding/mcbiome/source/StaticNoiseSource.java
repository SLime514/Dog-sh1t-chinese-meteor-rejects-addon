package com.seedfinding.mcbiome.source;

import com.seedfinding.mcbiome.biome.surface.builder.BadlandsSurfaceBuilder;
import com.seedfinding.mcbiome.biome.surface.builder.BasaltDeltasSurfaceBuilder;
import com.seedfinding.mcbiome.biome.surface.builder.SoulSandValleySurfaceBuilder;
import com.seedfinding.mcbiome.layer.cache.FloatLayerCache;
import com.seedfinding.mccore.block.Block;
import com.seedfinding.mccore.util.data.Pair;
import com.seedfinding.mccore.util.data.Quad;
import com.seedfinding.mccore.util.data.Triplet;
import com.seedfinding.mcnoise.perlin.OctavePerlinNoiseSampler;
import com.seedfinding.mcnoise.simplex.OctaveSimplexNoiseSampler;
import com.seedfinding.mcseed.rand.JRand;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class StaticNoiseSource {
    public static final OctaveSimplexNoiseSampler TEMPERATURE_NOISE = new OctaveSimplexNoiseSampler(new JRand(1234), IntStream.of(0));
    public static final OctaveSimplexNoiseSampler FROZEN_TEMPERATURE_NOISE = new OctaveSimplexNoiseSampler(new JRand(3456), IntStream.of(-2, -1, 0));
    public static final OctaveSimplexNoiseSampler BIOME_INFO_NOISE = new OctaveSimplexNoiseSampler(new JRand(2345), IntStream.of(0));
    public static final FloatLayerCache TEMPERATURE_CACHE = new FloatLayerCache(1024);
    private static final int THRESHOLD_VALLEY = (Runtime.getRuntime().availableProcessors() * 4) * 2;
    private static final HashMap<Long, OctavePerlinNoiseSampler> CACHED_VALLEY_NOISE = new HashMap<>(THRESHOLD_VALLEY);
    private static final int THRESHOLD_PATCH = (Runtime.getRuntime().availableProcessors() * 2) * 2;
    private static final HashMap<Long, OctavePerlinNoiseSampler> CACHED_PATCH_NOISE = new HashMap<>(THRESHOLD_PATCH);
    private final long worldSeed;
    private Quad<Block[], OctaveSimplexNoiseSampler, OctaveSimplexNoiseSampler, OctaveSimplexNoiseSampler> badlandsSurface = null;
    private Pair<OctaveSimplexNoiseSampler, OctaveSimplexNoiseSampler> noises = null;
    private OctavePerlinNoiseSampler netherForestsNoise = null;
    private OctavePerlinNoiseSampler netherNoise = null;
    private List<OctavePerlinNoiseSampler> valleyNoise = null;
    private List<OctavePerlinNoiseSampler> patchNoise = null;

    public StaticNoiseSource(long worldSeed) {
        this.worldSeed = worldSeed;
    }

    public long getWorldSeed() {
        return this.worldSeed;
    }

    public Pair<OctaveSimplexNoiseSampler, OctaveSimplexNoiseSampler> getNoises() {
        if (this.noises == null) {
            JRand rand = new JRand(getWorldSeed());
            OctaveSimplexNoiseSampler noise = new OctaveSimplexNoiseSampler(rand, IntStream.rangeClosed(-3, 0));
            OctaveSimplexNoiseSampler roofNoise = new OctaveSimplexNoiseSampler(rand, (List<Integer>) Collections.singletonList(0));
            this.noises = new Pair<>(noise, roofNoise);
        }
        return this.noises;
    }

    public List<OctavePerlinNoiseSampler> getValleyNoise() {
        if (this.valleyNoise == null) {
            int maxBlocksFloor = Math.max(BasaltDeltasSurfaceBuilder.FLOOR_BLOCK_STATES.size(), SoulSandValleySurfaceBuilder.FLOOR_BLOCK_STATES.size());
            int maxBlocksCeiling = Math.max(BasaltDeltasSurfaceBuilder.CEILING_BLOCK_STATES.size(), SoulSandValleySurfaceBuilder.CEILING_BLOCK_STATES.size());
            this.valleyNoise = new ArrayList();
            for (int i = 0; i < maxBlocksFloor + maxBlocksCeiling; i++) {
                OctavePerlinNoiseSampler sampler = CACHED_VALLEY_NOISE.computeIfAbsent(Long.valueOf(getWorldSeed() + i), key -> {
                    return new OctavePerlinNoiseSampler(new JRand(key.longValue()), (List<Integer>) Collections.singletonList(-4));
                });
                this.valleyNoise.add(sampler);
            }
            purgeCache(THRESHOLD_VALLEY);
        }
        return this.valleyNoise;
    }

    public List<OctavePerlinNoiseSampler> getPatchNoise() {
        if (this.patchNoise == null) {
            int souldSandSize = SoulSandValleySurfaceBuilder.FLOOR_BLOCK_STATES.size() + SoulSandValleySurfaceBuilder.CEILING_BLOCK_STATES.size();
            int basaltSize = BasaltDeltasSurfaceBuilder.FLOOR_BLOCK_STATES.size() + BasaltDeltasSurfaceBuilder.CEILING_BLOCK_STATES.size();
            this.patchNoise = new ArrayList();
            this.patchNoise.add(CACHED_PATCH_NOISE.computeIfAbsent(Long.valueOf(getWorldSeed() + souldSandSize), key -> {
                return new OctavePerlinNoiseSampler(new JRand(key.longValue()), (List<Integer>) Collections.singletonList(0));
            }));
            this.patchNoise.add(CACHED_PATCH_NOISE.computeIfAbsent(Long.valueOf(getWorldSeed() + basaltSize), key2 -> {
                return new OctavePerlinNoiseSampler(new JRand(key2.longValue()), (List<Integer>) Collections.singletonList(0));
            }));
            purgeCache(THRESHOLD_PATCH);
        }
        return this.patchNoise;
    }

    private void purgeCache(int treshold) {
        if (CACHED_VALLEY_NOISE.size() > treshold) {
            List<Long> worldSeeds = (List) CACHED_VALLEY_NOISE.keySet().stream().filter(e -> {
                return e.longValue() < getWorldSeed();
            }).collect(Collectors.toList());
            HashMap<Long, OctavePerlinNoiseSampler> map = CACHED_VALLEY_NOISE;
            Objects.requireNonNull(map);
            worldSeeds.forEach((v1) -> {
                r1.remove(v1);
            });
            if (CACHED_VALLEY_NOISE.size() > treshold) {
                List<Long> worldSeeds2 = (List) CACHED_VALLEY_NOISE.keySet().stream().filter(e2 -> {
                    return e2.longValue() > getWorldSeed() + ((long) treshold);
                }).collect(Collectors.toList());
                HashMap<Long, OctavePerlinNoiseSampler> map2 = CACHED_VALLEY_NOISE;
                Objects.requireNonNull(map2);
                worldSeeds2.forEach((v1) -> {
                    r1.remove(v1);
                });
            }
        }
    }

    public Quad<Block[], OctaveSimplexNoiseSampler, OctaveSimplexNoiseSampler, OctaveSimplexNoiseSampler> getBadlandsSurface() {
        if (this.badlandsSurface == null) {
            Pair<Block[], OctaveSimplexNoiseSampler> bands = BadlandsSurfaceBuilder.generateBands(getWorldSeed());
            Pair<OctaveSimplexNoiseSampler, OctaveSimplexNoiseSampler> noises = getNoises();
            this.badlandsSurface = new Quad<>(bands.getFirst(), noises.getFirst(), noises.getSecond(), bands.getSecond());
        }
        return this.badlandsSurface;
    }

    public Pair<OctaveSimplexNoiseSampler, OctaveSimplexNoiseSampler> getFrozenOceanSurface() {
        return getNoises();
    }

    public OctavePerlinNoiseSampler getNetherForestsNoise() {
        if (this.netherForestsNoise == null) {
            JRand rand = new JRand(getWorldSeed());
            this.netherForestsNoise = new OctavePerlinNoiseSampler(rand, (List<Integer>) Collections.singletonList(0));
        }
        return this.netherForestsNoise;
    }

    public OctavePerlinNoiseSampler getNetherNoise() {
        if (this.netherNoise == null) {
            JRand rand = new JRand(getWorldSeed());
            this.netherNoise = new OctavePerlinNoiseSampler(rand, IntStream.rangeClosed(-3, 0));
        }
        return this.netherNoise;
    }

    public Triplet<List<OctavePerlinNoiseSampler>, List<OctavePerlinNoiseSampler>, OctavePerlinNoiseSampler> getBasaltDeltasNoise() {
        List<OctavePerlinNoiseSampler> valleyNoise = getValleyNoise();
        List<OctavePerlinNoiseSampler> patchNoise = getPatchNoise();
        return new Triplet<>(Arrays.asList(valleyNoise.get(0), valleyNoise.get(1)), Collections.singletonList(valleyNoise.get(2)), patchNoise.get(1));
    }

    public Triplet<List<OctavePerlinNoiseSampler>, List<OctavePerlinNoiseSampler>, OctavePerlinNoiseSampler> getSoulSandValleyNoise() {
        List<OctavePerlinNoiseSampler> valleyNoise = getValleyNoise();
        List<OctavePerlinNoiseSampler> patchNoise = getPatchNoise();
        return new Triplet<>(Arrays.asList(valleyNoise.get(0), valleyNoise.get(1)), Arrays.asList(valleyNoise.get(2), valleyNoise.get(3)), patchNoise.get(0));
    }
}
