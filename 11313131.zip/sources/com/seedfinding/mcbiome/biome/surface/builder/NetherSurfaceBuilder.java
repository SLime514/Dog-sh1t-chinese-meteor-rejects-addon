package com.seedfinding.mcbiome.biome.surface.builder;

import com.seedfinding.mcbiome.biome.Biome;
import com.seedfinding.mcbiome.biome.surface.SurfaceConfig;
import com.seedfinding.mcbiome.source.BiomeSource;
import com.seedfinding.mccore.block.Block;
import com.seedfinding.mccore.block.Blocks;
import com.seedfinding.mccore.rand.ChunkRand;

public class NetherSurfaceBuilder extends SurfaceBuilder {
    public NetherSurfaceBuilder(SurfaceConfig surfaceConfig) {
        super(surfaceConfig);
    }

    @Override
    public Block[] applyToColumn(BiomeSource source, ChunkRand rand, Block[] column, Biome biome, int x, int z, int maxY, int minY, double noise, int seaLevel, Block defaultBlock, Block defaultFluid) {
        boolean shouldExpose = (source.getStaticNoiseSource().getNetherForestsNoise().sample(((double) x) * 0.03125d, ((double) z) * 0.03125d, 0.0d) * 75.0d) + rand.nextDouble() > 0.0d;
        boolean shouldUnderwater = (source.getStaticNoiseSource().getNetherForestsNoise().sample(((double) x) * 0.03125d, 109.0d, ((double) z) * 0.03125d) * 75.0d) + rand.nextDouble() > 0.0d;
        int elevation = (int) ((noise / 3.0d) + 3.0d + (rand.nextDouble() * 0.25d));
        int state = -1;
        Block topBlock = getSurfaceConfig().getTopBlock();
        Block underBlock = getSurfaceConfig().getUnderBlock();
        int y = Math.max(127, maxY);
        while (y >= minY) {
            Block block = column[y];
            if (Block.IS_AIR.test(source.getVersion(), block)) {
                state = -1;
            } else if (block == defaultBlock) {
                if (state == -1) {
                    boolean isBelow = false;
                    if (elevation <= 0) {
                        isBelow = true;
                        underBlock = getSurfaceConfig().getUnderBlock();
                    } else if (y >= seaLevel - 4 && y <= seaLevel + 1) {
                        topBlock = getSurfaceConfig().getTopBlock();
                        underBlock = getSurfaceConfig().getUnderBlock();
                        if (shouldUnderwater) {
                            topBlock = Blocks.GRAVEL;
                            underBlock = getSurfaceConfig().getUnderwaterBlock();
                        }
                        if (shouldExpose) {
                            topBlock = Blocks.SOUL_SAND;
                            underBlock = Blocks.SOUL_SAND;
                        }
                    }
                    if (y < seaLevel && isBelow) {
                        topBlock = defaultFluid;
                    }
                    state = elevation;
                    block = y >= seaLevel - 1 ? topBlock : underBlock;
                } else if (state > 0) {
                    state--;
                    block = underBlock;
                }
            }
            column[y] = block;
            y--;
        }
        return column;
    }
}
