package com.seedfinding.mcbiome.biome.surface.builder;

import com.seedfinding.mcbiome.biome.Biome;
import com.seedfinding.mcbiome.biome.surface.SurfaceConfig;
import com.seedfinding.mcbiome.source.BiomeSource;
import com.seedfinding.mccore.block.Block;
import com.seedfinding.mccore.rand.ChunkRand;

public class NetherForestsSurfaceBuilder extends SurfaceBuilder {
    public NetherForestsSurfaceBuilder(SurfaceConfig surfaceConfig) {
        super(surfaceConfig);
    }

    @Override
    public Block[] applyToColumn(BiomeSource source, ChunkRand rand, Block[] column, Biome biome, int x, int z, int maxY, int minY, double noise, int seaLevel, Block defaultBlock, Block defaultFluid) {
        double seaHeight = source.getStaticNoiseSource().getNetherForestsNoise().sample(x * 0.1d, seaLevel, z * 0.1d);
        boolean shouldExpose = seaHeight > 0.15d + (rand.nextDouble() * 0.35d);
        double topHeight = source.getStaticNoiseSource().getNetherForestsNoise().sample(x * 0.1d, 109.0d, z * 0.1d);
        boolean shouldUnderwater = topHeight > 0.25d + (rand.nextDouble() * 0.9d);
        int elevation = (int) ((noise / 3.0d) + 3.0d + (rand.nextDouble() * 0.25d));
        int state = -1;
        Block underBlock = getSurfaceConfig().getUnderBlock();
        int y = Math.max(127, maxY);
        while (y >= minY) {
            Block topBlock = getSurfaceConfig().getTopBlock();
            Block block = column[y];
            if (Block.IS_AIR.test(source.getVersion(), block)) {
                state = -1;
            } else if (block == defaultBlock) {
                if (state == -1) {
                    boolean flag2 = false;
                    if (elevation <= 0) {
                        flag2 = true;
                        underBlock = getSurfaceConfig().getUnderBlock();
                    }
                    if (shouldExpose) {
                        topBlock = getSurfaceConfig().getUnderBlock();
                    } else if (shouldUnderwater) {
                        topBlock = getSurfaceConfig().getUnderwaterBlock();
                    }
                    if (y < seaLevel && flag2) {
                        topBlock = defaultFluid;
                    }
                    state = elevation;
                    block = y >= seaLevel - 1 ? topBlock : underBlock;
                } else if (state > 0) {
                    state--;
                    block = underBlock;
                }
            }
            column[y] = block;
            y--;
        }
        return column;
    }
}
