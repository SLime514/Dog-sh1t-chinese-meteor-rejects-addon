package com.seedfinding.mcbiome.biome.surface.builder;

import com.seedfinding.mcbiome.biome.Biome;
import com.seedfinding.mcbiome.biome.surface.SurfaceConfig;
import com.seedfinding.mcbiome.source.BiomeSource;
import com.seedfinding.mccore.block.Block;
import com.seedfinding.mccore.block.Blocks;
import com.seedfinding.mccore.rand.ChunkRand;
import com.seedfinding.mccore.util.data.Pair;
import com.seedfinding.mccore.util.data.Quad;
import com.seedfinding.mcnoise.simplex.OctaveSimplexNoiseSampler;
import com.seedfinding.mcseed.rand.JRand;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class BadlandsSurfaceBuilder extends SurfaceBuilder {
    public BadlandsSurfaceBuilder(SurfaceConfig surfaceConfig) {
        super(surfaceConfig);
    }

    @Override
    public Block[] applyToColumn(BiomeSource source, ChunkRand rand, Block[] column, Biome biome, int x, int z, int maxY, int minY, double noise, int seaLevel, Block defaultBlock, Block defaultFluid) {
        Quad<Block[], OctaveSimplexNoiseSampler, OctaveSimplexNoiseSampler, OctaveSimplexNoiseSampler> badlandsSurface = source.getStaticNoiseSource().getBadlandsSurface();
        Block trackedTopBlock = Blocks.WHITE_TERRACOTTA;
        SurfaceConfig config = getSurfaceConfig();
        Block underBlock = config.getUnderBlock();
        Block topBlock = config.getTopBlock();
        Block trackedUnderBlock = underBlock;
        int elevation = (int) ((noise / 3.0d) + 3.0d + (rand.nextDouble() * 0.25d));
        boolean shouldBeSimple = Math.cos((noise / 3.0d) * 3.141592653589793d) > 0.0d;
        int trackedY = -1;
        boolean isOrangeTerracotta = false;
        int topLayers = 0;
        for (int y = maxY; y >= minY; y--) {
            Block block = getBaseBlock(y, column, source, defaultBlock);
            if (topLayers < 15 || shouldBypass()) {
                if (Block.IS_AIR.test(source.getVersion(), block)) {
                    trackedY = -1;
                } else if (block == defaultBlock) {
                    if (trackedY == -1) {
                        isOrangeTerracotta = false;
                        if (elevation <= 0) {
                            trackedTopBlock = Blocks.AIR;
                            trackedUnderBlock = defaultBlock;
                        } else if (y >= seaLevel - 4 && y <= seaLevel + 1) {
                            trackedTopBlock = Blocks.WHITE_TERRACOTTA;
                            trackedUnderBlock = underBlock;
                        }
                        if (y < seaLevel && (trackedTopBlock == null || Block.IS_AIR.test(source.getVersion(), trackedTopBlock))) {
                            trackedTopBlock = defaultFluid;
                        }
                        trackedY = elevation + Math.max(0, y - seaLevel);
                        if (y >= seaLevel - 1) {
                            if (highContion(y, elevation)) {
                                if (shouldBeSimple) {
                                    block = Blocks.COARSE_DIRT;
                                } else {
                                    block = Blocks.GRASS_BLOCK;
                                }
                            } else if (y <= seaLevel + 3 + elevation) {
                                block = topBlock;
                                isOrangeTerracotta = true;
                            } else if (y >= 64 && y <= 127) {
                                if (shouldBeSimple) {
                                    block = Blocks.TERRACOTTA;
                                } else {
                                    block = badlandsSurface.getFirst()[getBandY(x, y, z, badlandsSurface.getFourth())];
                                }
                            } else {
                                block = Blocks.ORANGE_TERRACOTTA;
                            }
                        } else {
                            block = trackedUnderBlock;
                            if (orangeTerracottaCondition(block)) {
                                block = Blocks.ORANGE_TERRACOTTA;
                            }
                        }
                    } else if (trackedY > 0) {
                        trackedY--;
                        if (isOrangeTerracotta) {
                            block = Blocks.ORANGE_TERRACOTTA;
                        } else {
                            block = badlandsSurface.getFirst()[getBandY(x, y, z, badlandsSurface.getFourth())];
                        }
                    }
                    topLayers++;
                }
            }
            column[y] = block;
        }
        return column;
    }

    protected Block getBaseBlock(int y, Block[] column, BiomeSource source, Block defaultBlock) {
        return column[y];
    }

    protected boolean highContion(int y, int elevation) {
        return false;
    }

    protected boolean shouldBypass() {
        return false;
    }

    protected boolean orangeTerracottaCondition(Block block) {
        return block == Blocks.WHITE_TERRACOTTA || block == Blocks.ORANGE_TERRACOTTA || block == Blocks.MAGENTA_TERRACOTTA || block == Blocks.LIGHT_BLUE_TERRACOTTA || block == Blocks.YELLOW_TERRACOTTA || block == Blocks.LIME_TERRACOTTA || block == Blocks.PINK_TERRACOTTA || block == Blocks.GRAY_TERRACOTTA || block == Blocks.LIGHT_GRAY_TERRACOTTA || block == Blocks.CYAN_TERRACOTTA || block == Blocks.PURPLE_TERRACOTTA || block == Blocks.BLUE_TERRACOTTA || block == Blocks.BROWN_TERRACOTTA || block == Blocks.GREEN_TERRACOTTA || block == Blocks.RED_TERRACOTTA || block == Blocks.BLACK_TERRACOTTA;
    }

    protected int getBandY(int x, int y, int z, OctaveSimplexNoiseSampler clayBandsOffsetNoise) {
        int offset = (int) Math.round(clayBandsOffsetNoise.sample(x / 512.0d, z / 512.0d, false) * 2.0d);
        return ((y + offset) + 64) % 64;
    }

    public static Pair<Block[], OctaveSimplexNoiseSampler> generateBands(long worldSeed) {
        JRand rand = new JRand(worldSeed);
        Block[] clayBands = new Block[64];
        Arrays.fill(clayBands, Blocks.TERRACOTTA);
        OctaveSimplexNoiseSampler clayBandsOffsetNoise = new OctaveSimplexNoiseSampler(rand, (List<Integer>) Collections.singletonList(0));
        int y = 0;
        while (y < 64) {
            int y2 = y + rand.nextInt(5) + 1;
            if (y2 < 64) {
                clayBands[y2] = Blocks.ORANGE_TERRACOTTA;
            }
            y = y2 + 1;
        }
        int attempts = rand.nextInt(4) + 2;
        for (int attempt = 0; attempt < attempts; attempt++) {
            int bound = rand.nextInt(3) + 1;
            int offset = rand.nextInt(64);
            for (int y3 = 0; offset + y3 < 64 && y3 < bound; y3++) {
                clayBands[offset + y3] = Blocks.YELLOW_TERRACOTTA;
            }
        }
        int attempts2 = rand.nextInt(4) + 2;
        for (int attempt2 = 0; attempt2 < attempts2; attempt2++) {
            int bound2 = rand.nextInt(3) + 2;
            int offset2 = rand.nextInt(64);
            for (int y4 = 0; offset2 + y4 < 64 && y4 < bound2; y4++) {
                clayBands[offset2 + y4] = Blocks.BROWN_TERRACOTTA;
            }
        }
        int attempts3 = rand.nextInt(4) + 2;
        for (int attempt3 = 0; attempt3 < attempts3; attempt3++) {
            int bound3 = rand.nextInt(3) + 1;
            int offset3 = rand.nextInt(64);
            for (int y5 = 0; offset3 + y5 < 64 && y5 < bound3; y5++) {
                clayBands[offset3 + y5] = Blocks.RED_TERRACOTTA;
            }
        }
        int attempts4 = rand.nextInt(3) + 3;
        int offset4 = 0;
        for (int attempt4 = 0; attempt4 < attempts4; attempt4++) {
            offset4 += rand.nextInt(16) + 4;
            for (int y6 = 0; offset4 + y6 < 64 && y6 < 1; y6++) {
                clayBands[offset4 + y6] = Blocks.WHITE_TERRACOTTA;
                if (offset4 + y6 > 1 && rand.nextBoolean()) {
                    clayBands[(offset4 + y6) - 1] = Blocks.LIGHT_GRAY_TERRACOTTA;
                }
                if (offset4 + y6 < 63 && rand.nextBoolean()) {
                    clayBands[offset4 + y6 + 1] = Blocks.LIGHT_GRAY_TERRACOTTA;
                }
            }
        }
        return new Pair<>(clayBands, clayBandsOffsetNoise);
    }
}
