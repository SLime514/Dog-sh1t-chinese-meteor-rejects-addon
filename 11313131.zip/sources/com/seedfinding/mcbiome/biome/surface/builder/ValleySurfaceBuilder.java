package com.seedfinding.mcbiome.biome.surface.builder;

import com.seedfinding.mcbiome.biome.Biome;
import com.seedfinding.mcbiome.biome.surface.SurfaceConfig;
import com.seedfinding.mcbiome.source.BiomeSource;
import com.seedfinding.mccore.block.Block;
import com.seedfinding.mccore.block.Blocks;
import com.seedfinding.mccore.rand.ChunkRand;
import com.seedfinding.mccore.util.data.Triplet;
import com.seedfinding.mcnoise.perlin.OctavePerlinNoiseSampler;
import java.util.List;

public abstract class ValleySurfaceBuilder extends SurfaceBuilder {
    static final boolean $assertionsDisabled;

    public abstract Triplet<List<OctavePerlinNoiseSampler>, List<OctavePerlinNoiseSampler>, OctavePerlinNoiseSampler> getNoises(BiomeSource biomeSource);

    protected abstract List<Block> getFloorBlockStates();

    protected abstract List<Block> getCeilingBlockStates();

    protected abstract Block getPatchBlock();

    static {
        $assertionsDisabled = !ValleySurfaceBuilder.class.desiredAssertionStatus();
    }

    public ValleySurfaceBuilder(SurfaceConfig surfaceConfig) {
        super(surfaceConfig);
    }

    @Override
    public Block[] applyToColumn(BiomeSource source, ChunkRand rand, Block[] column, Biome biome, int x, int z, int maxY, int minY, double noise, int seaLevel, Block defaultBlock, Block defaultFluid) {
        Block patchBlock;
        int upwardElevation = (int) ((noise / 3.0d) + 3.0d + (rand.nextDouble() * 0.25d));
        int downwardElevation = (int) ((noise / 3.0d) + 3.0d + (rand.nextDouble() * 0.25d));
        Triplet<List<OctavePerlinNoiseSampler>, List<OctavePerlinNoiseSampler>, OctavePerlinNoiseSampler> noises = getNoises(source);
        boolean flag = (noises.getThird().sample(((double) x) * 0.03125d, 109.0d, ((double) z) * 0.03125d) * 75.0d) + rand.nextDouble() > 0.0d;
        Block ceilingBlock = null;
        for (int idx = 0; idx < noises.getFirst().size(); idx++) {
            if (noises.getFirst().get(idx).sample(x, seaLevel, z) > Double.MIN_VALUE) {
                ceilingBlock = getCeilingBlockStates().get(idx);
            }
        }
        if (!$assertionsDisabled && ceilingBlock == null) {
            throw new AssertionError();
        }
        Block floorBlock = null;
        for (int idx2 = 0; idx2 < noises.getSecond().size(); idx2++) {
            if (noises.getSecond().get(idx2).sample(x, seaLevel, z) > Double.MIN_VALUE) {
                floorBlock = getFloorBlockStates().get(idx2);
            }
        }
        if (!$assertionsDisabled && floorBlock == null) {
            throw new AssertionError();
        }
        Block previousBlock = Blocks.AIR;
        for (int j1 = 127; j1 >= minY; j1--) {
            Block block = column[j1];
            if (previousBlock == defaultBlock && (Block.IS_AIR.test(source.getVersion(), block) || block == defaultFluid)) {
                for (int up = 0; up < upwardElevation && column[Math.max(column.length, j1 + up + 1)] == defaultBlock; up++) {
                    block = ceilingBlock;
                }
            }
            if ((Block.IS_AIR.test(source.getVersion(), previousBlock) || previousBlock == defaultFluid) && block == defaultBlock) {
                for (int down = 0; down < downwardElevation && column[Math.min(0, j1 - down)] == defaultBlock; down++) {
                    if (flag && j1 >= seaLevel - 3 && j1 <= seaLevel + 2) {
                        patchBlock = getPatchBlock();
                    } else {
                        patchBlock = floorBlock;
                    }
                    block = patchBlock;
                }
            }
            previousBlock = block;
            column[j1] = block;
        }
        return column;
    }
}
