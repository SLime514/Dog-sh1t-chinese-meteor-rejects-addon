package com.seedfinding.mcbiome.biome.surface.builder;

import com.seedfinding.mcbiome.biome.Biome;
import com.seedfinding.mcbiome.biome.surface.SurfaceConfig;
import com.seedfinding.mcbiome.source.BiomeSource;
import com.seedfinding.mccore.block.Block;
import com.seedfinding.mccore.block.Blocks;
import com.seedfinding.mccore.rand.ChunkRand;
import com.seedfinding.mccore.util.data.Pair;
import com.seedfinding.mcnoise.simplex.OctaveSimplexNoiseSampler;

public class FrozenOceanSurfaceBuilder extends DefaultSurfaceBuilder {

    private double f15d0;

    private double f16d1;

    public FrozenOceanSurfaceBuilder(SurfaceConfig surfaceConfig) {
        super(surfaceConfig);
    }

    @Override
    public Block[] applyToColumn(BiomeSource source, ChunkRand rand, Block[] column, Biome biome, int x, int z, int maxY, int minY, double noise, int seaLevel, Block defaultBlock, Block defaultFluid) {
        this.f15d0 = 0.0d;
        this.f16d1 = 0.0d;
        float f = biome.getTemperatureAt(x, 63, z);
        Pair<OctaveSimplexNoiseSampler, OctaveSimplexNoiseSampler> noises = source.getStaticNoiseSource().getFrozenOceanSurface();
        double icebergHeight = Math.min(Math.abs(noise), noises.getFirst().sample(x * 0.1d, z * 0.1d, false) * 15.0d);
        if (icebergHeight > 1.8d) {
            double icebergCeiling = Math.abs(noises.getSecond().sample(x * 0.09765625d, z * 0.09765625d, false));
            this.f15d0 = icebergHeight * icebergHeight * 1.2d;
            double d5 = Math.ceil(icebergCeiling * 40.0d) + 14.0d;
            if (this.f15d0 > d5) {
                this.f15d0 = d5;
            }
            if (f > 0.1f) {
                this.f15d0 -= 2.0d;
            }
            if (this.f15d0 > 2.0d) {
                this.f16d1 = (seaLevel - this.f15d0) - 7.0d;
                this.f15d0 += seaLevel;
            } else {
                this.f15d0 = 0.0d;
            }
        }
        return super.applyToColumn(source, rand, column, biome, x, z, Math.max(maxY, ((int) this.f15d0) + 1), minY, noise, seaLevel, defaultBlock, defaultFluid);
    }

    @Override
    public Block applyExtraConditions(int y, Block block, Object[] extras) {
        if (block == Blocks.PACKED_ICE && ((Integer) extras[0]).intValue() <= ((Integer) extras[1]).intValue() && y > ((Integer) extras[2]).intValue()) {
            block = Blocks.SNOW_BLOCK;
            extras[0] = Integer.valueOf(((Integer) extras[0]).intValue() + 1);
        }
        return block;
    }

    @Override
    public Object[] generateExtras(ChunkRand rand, int seaLevel) {
        int snowLayerMax = 2 + rand.nextInt(4);
        int minHeightSnow = seaLevel + 18 + rand.nextInt(10);
        return new Object[]{0, Integer.valueOf(snowLayerMax), Integer.valueOf(minHeightSnow)};
    }

    @Override
    public Block getBaseBlock(BiomeSource source, int y, Block[] column, ChunkRand rand, int seaLevel) {
        Block block = column[y];
        if (Block.IS_AIR.test(source.getVersion(), block) && y < ((int) this.f15d0) && rand.nextDouble() > 0.01d) {
            block = Blocks.PACKED_ICE;
        } else if (block == Blocks.WATER && y > ((int) this.f16d1) && y < seaLevel && this.f16d1 != 0.0d && rand.nextDouble() > 0.15d) {
            block = Blocks.PACKED_ICE;
        }
        return block;
    }
}
