package com.seedfinding.mcbiome.device;

public class MushroomCondition {
    static final long SHROOM_LAYER_SEED = -7479281634960481323L;
    static final long EPSILON = 4294967296L;
    static final long MASK = 4294967295L;
    static final int ARG = 299999;
    static final int TARGET = 0;
    private final long upperSeedMultiplier;
    private final long upperSeedAddend;
    private final long numValidSeeds;
    private final long lower32Bits;

    private final int f17x;

    private final int f18z;

    public MushroomCondition(long lower32Bits, int x, int z) {
        this.f17x = x;
        this.f18z = z;
        this.lower32Bits = lower32Bits & MASK;
        long mushAddend = getShroomSeed(lower32Bits, x, z);
        long mushMultiplier = getShroomSeed(this.lower32Bits + EPSILON, x, z) - mushAddend;
        int argNoEven = ARG >> Long.numberOfTrailingZeros(299999L);
        this.upperSeedMultiplier = argNoEven * inverse32Bit(mushMultiplier >>> 32);
        long inverse = modInverse(256L, argNoEven);
        long needed = ((0 - (((mushAddend & MASK) >>> 24) % argNoEven)) + argNoEven) % argNoEven;
        long lowestValidMushSeed = (((inverse * needed) % argNoEven) * EPSILON) + (mushAddend & MASK);
        this.upperSeedAddend = (((lowestValidMushSeed - mushAddend) >>> 32) * inverse32Bit(mushMultiplier >>> 32)) & MASK;
        this.numValidSeeds = (EPSILON - (lowestValidMushSeed >>> 32)) / argNoEven;
    }

    private long inverse32Bit(long a) {
        if (a % 2 == 0) {
            System.err.println("a is not invertible");
        }
        long x = (((a << 2) ^ (a << 1)) & 8) ^ a;
        long x2 = x + (x - ((a * x) * x));
        long x3 = x2 + (x2 - ((a * x2) * x2));
        return (x3 + (x3 - ((a * x3) * x3))) & MASK;
    }

    private long modInverse(long a, long m) {
        long y = 0;
        long x = 1;
        if (m == 1) {
            return 0L;
        }
        while (a > 1) {
            long q = a / m;
            long t = m;
            m = a % m;
            a = t;
            long t2 = y;
            y = x - (q * y);
            x = t2;
        }
        if (x < 0) {
            x += m;
        }
        return x;
    }

    static long getShroomSeed(long ws, int x, int z) {
        long ws2 = (ws * ((ws * 6364136223846793005L) + 1442695040888963407L)) + SHROOM_LAYER_SEED;
        long ws3 = (ws2 * ((ws2 * 6364136223846793005L) + 1442695040888963407L)) + SHROOM_LAYER_SEED;
        long ws4 = (ws3 * ((ws3 * 6364136223846793005L) + 1442695040888963407L)) + SHROOM_LAYER_SEED;
        long ss = (ws4 * ((ws4 * 6364136223846793005L) + 1442695040888963407L)) + x;
        long ss2 = (ss * ((ss * 6364136223846793005L) + 1442695040888963407L)) + z;
        long ss3 = (ss2 * ((ss2 * 6364136223846793005L) + 1442695040888963407L)) + x;
        return (ss3 * ((ss3 * 6364136223846793005L) + 1442695040888963407L)) + z;
    }

    public int getX() {
        return this.f17x;
    }

    public int getZ() {
        return this.f18z;
    }

    public long getNumValidSeeds() {
        return this.numValidSeeds;
    }

    public long getUpperSeedMultiplier() {
        return this.upperSeedMultiplier;
    }

    public long getUpperSeedAddend() {
        return this.upperSeedAddend;
    }

    public long getLower32Bits() {
        return this.lower32Bits;
    }

    public static void main(String[] args) {
        MushroomCondition c = new MushroomCondition(10L, 0, 0);
        System.out.println(c.getUpperSeedAddend());
        System.out.println(c.getUpperSeedMultiplier());
        System.out.println(c.getNumValidSeeds());
        long j = 0;
        while (true) {
            long lowerBits = j;
            if (lowerBits < EPSILON) {
                MushroomCondition c2 = new MushroomCondition(lowerBits, 0, 0);
                long j2 = 0;
                while (true) {
                    long i = j2;
                    if (i < c2.getNumValidSeeds()) {
                        getShroomSeed(((c2.getUpperSeedAddend() + (i * c2.getUpperSeedMultiplier())) << 32) + 10, 0, 0);
                        j2 = i + 1;
                    }
                }
                j = lowerBits + 1;
            } else {
                return;
            }
        }
    }
}
