package com.seedfinding.mcbiome.device;

import com.seedfinding.mcbiome.biome.Biomes;
import com.seedfinding.mcbiome.device.Restriction;
import com.seedfinding.mcbiome.layer.IntBiomeLayer;
import com.seedfinding.mcbiome.layer.land.BambooJungleLayer;
import com.seedfinding.mcbiome.layer.land.BaseBiomesLayer;
import com.seedfinding.mcbiome.layer.land.ContinentLayer;
import com.seedfinding.mcbiome.layer.land.HillsLayer;
import com.seedfinding.mcbiome.layer.land.IslandLayer;
import com.seedfinding.mcbiome.layer.land.MushroomLayer;
import com.seedfinding.mcbiome.layer.land.SunflowerPlainsLayer;
import com.seedfinding.mcbiome.layer.noise.NoiseLayer;
import com.seedfinding.mcbiome.layer.temperature.ClimateLayer;
import com.seedfinding.mcbiome.source.LayeredBiomeSource;

public class Restrictions {
    public static final Restriction.Factory<BoundRestriction> CONTINENT = (version, x, z) -> {
        return new BoundRestriction("CONTINENT", x, z, Restriction.getSalt(version, ContinentLayer.class), 10L, 0L) {

            private final int f21ID;

            {
                this.f21ID = getLayerId(version, ContinentLayer.class);
            }

            @Override
            public boolean testSource(LayeredBiomeSource<IntBiomeLayer> source) {
                return ((IntBiomeLayer) source.getLayer(this.f21ID)).get(getX(), 0, getZ()) == Biomes.PLAINS.getId();
            }
        };
    };
    public static final Restriction.Factory<BoundRestriction> ISLAND = (version, x, z) -> {
        return new BoundRestriction("ISLAND", x, z, Restriction.getSalt(version, IslandLayer.class), 2L, 0L) {

            private final int f26ID;

            {
                this.f26ID = getLayerId(version, IslandLayer.class);
            }

            @Override
            public boolean testSource(LayeredBiomeSource<IntBiomeLayer> source) {
                return ((IntBiomeLayer) source.getLayer(this.f26ID)).get(getX(), 0, getZ()) == Biomes.PLAINS.getId();
            }
        };
    };
    public static final Restriction.Factory<BoundRestriction> COLD_FOREST = (version, x, z) -> {
        return new BoundRestriction("COLD_FOREST", x, z, Restriction.getSalt(version, ClimateLayer.Cold.class), 6L, 0L) {

            private final int f27ID;

            {
                this.f27ID = getLayerId(version, ClimateLayer.Cold.class);
            }

            @Override
            public boolean testSource(LayeredBiomeSource<IntBiomeLayer> source) {
                return ((IntBiomeLayer) source.getLayer(this.f27ID)).get(getX(), 0, getZ()) == Biomes.FOREST.getId();
            }
        };
    };
    public static final Restriction.Factory<BoundRestriction> HILLS_PLATEAU = (version, x, z) -> {
        return new BoundRestriction("PLATEAU", x, z, Restriction.getSalt(version, HillsLayer.class), 3L, 0L) {
            @Override
            public boolean testSource(LayeredBiomeSource<IntBiomeLayer> source) {
                return true;
            }
        };
    };
    public static final Restriction.Factory<BoundRestriction> COLD_MOUNTAIN = (version, x, z) -> {
        return new BoundRestriction("COLD_MOUNTAIN", x, z, Restriction.getSalt(version, ClimateLayer.Cold.class), 6L, 1L) {

            private final int f28ID;

            {
                this.f28ID = getLayerId(version, ClimateLayer.Cold.class);
            }

            @Override
            public boolean testSource(LayeredBiomeSource<IntBiomeLayer> source) {
                return ((IntBiomeLayer) source.getLayer(this.f28ID)).get(getX(), 0, getZ()) == Biomes.MOUNTAINS.getId();
            }
        };
    };
    public static final Restriction.Factory<ModRestriction> MUTATED = (version, x, z) -> {
        return new ModRestriction("NOISE LAYER", x, z, Restriction.getSalt(version, NoiseLayer.class), 299999L, 1L, 29L) {

            private final int f29ID;

            {
                this.f29ID = getLayerId(version, NoiseLayer.class);
            }

            @Override
            public boolean testSource(LayeredBiomeSource<IntBiomeLayer> source) {
                int id = ((IntBiomeLayer) source.getLayer(this.f29ID)).get(getX(), 0, getZ());
                return (id >> 7) == 1;
            }
        };
    };
    public static final Restriction.Factory<ModRestriction> MUTATED_SECOND = (version, x, z) -> {
        return new ModRestriction("NOISE LAYER", x, z, Restriction.getSalt(version, NoiseLayer.class), 299999L, 0L, 29L) {

            private final int f30ID;

            {
                this.f30ID = getLayerId(version, NoiseLayer.class);
            }

            @Override
            public boolean testSource(LayeredBiomeSource<IntBiomeLayer> source) {
                int id = ((IntBiomeLayer) source.getLayer(this.f30ID)).get(getX(), 0, getZ());
                return (id >> 7) == 1;
            }
        };
    };
    public static final Restriction.Factory<BoundRestriction> SAVANNAH_BIOME = (version, x, z) -> {
        return new BoundRestriction("SAVANNAH_BIOME", x, z, Restriction.getSalt(version, BaseBiomesLayer.class), 6L, 3L, 4L) {

            private final int f31ID;

            {
                this.f31ID = getLayerId(version, BaseBiomesLayer.class);
            }

            @Override
            public boolean testSource(LayeredBiomeSource<IntBiomeLayer> source) {
                int id = ((IntBiomeLayer) source.getLayer(this.f31ID)).get(getX(), 0, getZ());
                return id == Biomes.SAVANNA.getId();
            }
        };
    };
    public static final Restriction.Factory<BoundRestriction> COLD_PLAINS = (version, x, z) -> {
        return new BoundRestriction("COLD_PLAINS", x, z, Restriction.getSalt(version, ClimateLayer.Cold.class), 6L, 2L, 5L) {

            private final int f32ID;

            {
                this.f32ID = getLayerId(version, ClimateLayer.Cold.class);
            }

            @Override
            public boolean testSource(LayeredBiomeSource<IntBiomeLayer> source) {
                return ((IntBiomeLayer) source.getLayer(this.f32ID)).get(getX(), 0, getZ()) == Biomes.PLAINS.getId();
            }
        };
    };
    public static final Restriction.Factory<BoundRestriction> SPECIAL = (version, x, z) -> {
        return new BoundRestriction("SPECIAL", x, z, Restriction.getSalt(version, ClimateLayer.Special.class), 13L, 0L) {

            private final int f22ID;

            {
                this.f22ID = getLayerId(version, ClimateLayer.Special.class);
            }

            @Override
            public boolean testSource(LayeredBiomeSource<IntBiomeLayer> source) {
                return (((IntBiomeLayer) source.getLayer(this.f22ID)).get(getX(), 0, getZ()) >> 8) != 0;
            }
        };
    };
    public static final Restriction.Factory<BoundRestriction> MUSHROOM = (version, x, z) -> {
        return new BoundRestriction("MUSHROOM", x, z, Restriction.getSalt(version, MushroomLayer.class), 100L, 0L) {

            private final int f23ID;

            {
                this.f23ID = getLayerId(version, MushroomLayer.class);
            }

            @Override
            public boolean testSource(LayeredBiomeSource<IntBiomeLayer> source) {
                return ((IntBiomeLayer) source.getLayer(this.f23ID)).get(getX(), 0, getZ()) == Biomes.MUSHROOM_FIELDS.getId();
            }
        };
    };
    public static final Restriction.Factory<BoundRestriction> SUNFLOWER_PLAINS = (version, x, z) -> {
        return new BoundRestriction("SUNFLOWER_PLAINS", x, z, Restriction.getSalt(version, SunflowerPlainsLayer.class), 57L, 0L) {

            private final int f24ID;

            {
                this.f24ID = getLayerId(version, SunflowerPlainsLayer.class);
            }

            @Override
            public boolean testSource(LayeredBiomeSource<IntBiomeLayer> source) {
                return ((IntBiomeLayer) source.getLayer(this.f24ID)).get(getX(), 0, getZ()) == Biomes.SUNFLOWER_PLAINS.getId();
            }
        };
    };
    public static final Restriction.Factory<BoundRestriction> BAMBOO_JUNGLE = (version, x, z) -> {
        return new BoundRestriction("BAMBOO_JUNGLE", x, z, Restriction.getSalt(version, BambooJungleLayer.class), 10L, 0L) {

            private final int f25ID;

            {
                this.f25ID = getLayerId(version, BambooJungleLayer.class);
            }

            @Override
            public boolean testSource(LayeredBiomeSource<IntBiomeLayer> source) {
                return ((IntBiomeLayer) source.getLayer(this.f25ID)).get(getX(), 0, getZ()) == Biomes.BAMBOO_JUNGLE.getId();
            }
        };
    };
}
