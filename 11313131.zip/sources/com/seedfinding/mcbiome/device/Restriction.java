package com.seedfinding.mcbiome.device;

import com.seedfinding.mcbiome.layer.IntBiomeLayer;
import com.seedfinding.mcbiome.source.LayeredBiomeSource;
import com.seedfinding.mcbiome.source.OverworldBiomeSource;
import com.seedfinding.mccore.version.MCVersion;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

public abstract class Restriction {
    private final String name;

    private final int f19x;

    private final int f20z;

    @FunctionalInterface
    public interface Factory<T extends Restriction> {
        T create(MCVersion mCVersion, int i, int i2);
    }

    public abstract boolean testSeed(long j, long j2);

    public abstract boolean testSource(LayeredBiomeSource<IntBiomeLayer> layeredBiomeSource);

    public Restriction(String name, int x, int z) {
        this.name = name;
        this.f19x = x;
        this.f20z = z;
    }

    public String getName() {
        return this.name;
    }

    public int getX() {
        return this.f19x;
    }

    public int getZ() {
        return this.f20z;
    }

    public List<Integer> getBitPoints() {
        return Collections.singletonList(64);
    }

    protected static IntBiomeLayer getLayer(MCVersion version, Class<? extends IntBiomeLayer> layerClass) {
        OverworldBiomeSource source = new OverworldBiomeSource(version, 0L);
        for (int i = 0; i < source.getLayers().size(); i++) {
            if (source.getLayer(i).getClass().equals(layerClass)) {
                return source.getLayer(i);
            }
        }
        return null;
    }

    protected static int getLayerId(MCVersion version, Class<? extends IntBiomeLayer> layerClass) {
        return ((IntBiomeLayer) Objects.requireNonNull(getLayer(version, layerClass))).getLayerId();
    }

    protected static long getSalt(MCVersion version, Class<? extends IntBiomeLayer> layerClass) {
        return ((IntBiomeLayer) Objects.requireNonNull(getLayer(version, layerClass))).salt;
    }

    public String toString() {
        return getName() + " at (" + getX() + ", " + getZ() + ")";
    }
}
