package com.seedfinding.mcbiome.layer;

import com.seedfinding.mcbiome.layer.cache.BoolLayerCache;
import com.seedfinding.mccore.version.MCVersion;

public abstract class BoolBiomeLayer extends BiomeLayer {
    private final BoolLayerCache layerCache;

    public abstract boolean sample(int i, int i2, int i3);

    public BoolBiomeLayer(MCVersion version, BiomeLayer... parents) {
        super(version, parents);
        this.layerCache = new BoolLayerCache(1024);
    }

    public BoolBiomeLayer(MCVersion version) {
        super(version);
        this.layerCache = new BoolLayerCache(1024);
    }

    public BoolBiomeLayer(MCVersion version, long worldSeed, long salt, BiomeLayer... parents) {
        super(version, worldSeed, salt, parents);
        this.layerCache = new BoolLayerCache(1024);
    }

    public BoolBiomeLayer(MCVersion version, long worldSeed, long salt) {
        super(version, worldSeed, salt);
        this.layerCache = new BoolLayerCache(1024);
    }

    public boolean get(int x, int y, int z) {
        return this.layerCache.get(x, y, z, this::sample);
    }

    public boolean[] sample(int x, int y, int z, int xSize, int ySize, int zSize) {
        throw new UnsupportedOperationException();
    }
}
