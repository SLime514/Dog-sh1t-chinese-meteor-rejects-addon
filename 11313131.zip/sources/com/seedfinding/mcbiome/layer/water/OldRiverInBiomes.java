package com.seedfinding.mcbiome.layer.water;

import com.seedfinding.mcbiome.biome.Biomes;
import com.seedfinding.mcbiome.layer.IntBiomeLayer;
import com.seedfinding.mccore.version.MCVersion;

public class OldRiverInBiomes extends IntBiomeLayer {
    public OldRiverInBiomes(MCVersion version, long worldSeed, long salt, IntBiomeLayer parent) {
        super(version, worldSeed, salt, parent);
    }

    @Override
    public int sample(int x, int y, int z) {
        setSeed(x, z);
        int center = ((IntBiomeLayer) getParent(IntBiomeLayer.class)).get(x, y, z);
        if ((center != Biomes.SWAMP.getId() || nextInt(6) != 0) && ((center != Biomes.JUNGLE.getId() && center != Biomes.JUNGLE_HILLS.getId()) || nextInt(8) != 0)) {
            return center;
        }
        return Biomes.RIVER.getId();
    }
}
