package com.seedfinding.mcbiome.layer.water;

import com.seedfinding.mcbiome.biome.Biome;
import com.seedfinding.mcbiome.biome.Biomes;
import com.seedfinding.mcbiome.layer.IntBiomeLayer;
import com.seedfinding.mcbiome.layer.composite.CrossLayer;
import com.seedfinding.mccore.version.MCVersion;

public class NoiseToRiverLayer extends CrossLayer {
    public NoiseToRiverLayer(MCVersion version, long worldSeed, long salt, IntBiomeLayer parent) {
        super(version, worldSeed, salt, parent);
    }

    @Override
    public int sample(int n, int e, int s, int w, int center) {
        if (getVersion().isOlderOrEqualTo(MCVersion.v1_6_4)) {
            if (center == 0 || !Biome.applyAll(v -> {
                return Boolean.valueOf(center == v.intValue());
            }, w, n, e, s)) {
                return Biomes.RIVER.getId();
            }
            return -1;
        }
        int validCenter = isValidForRiver(center);
        if (Biome.applyAll(v2 -> {
            return Boolean.valueOf(validCenter == isValidForRiver(v2.intValue()));
        }, w, n, e, s)) {
            return -1;
        }
        return Biomes.RIVER.getId();
    }

    private static int isValidForRiver(int value) {
        return value >= 2 ? 2 + (value & 1) : value;
    }
}
