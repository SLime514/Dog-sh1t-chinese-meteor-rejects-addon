package com.seedfinding.mcbiome.layer.water;

import com.seedfinding.mcbiome.biome.Biome;
import com.seedfinding.mcbiome.biome.Biomes;
import com.seedfinding.mcbiome.layer.IntBiomeLayer;
import com.seedfinding.mcbiome.layer.composite.CrossLayer;
import com.seedfinding.mccore.version.MCVersion;

public class DeepOceanLayer extends CrossLayer {
    public DeepOceanLayer(MCVersion version, long worldSeed, long salt, IntBiomeLayer parent) {
        super(version, worldSeed, salt, parent);
    }

    @Override
    public int sample(int n, int e, int s, int w, int center) {
        if (!Biome.isShallowOcean(center, getVersion())) {
            return center;
        }
        int i = 0;
        if (Biome.isShallowOcean(n, getVersion())) {
            i = 0 + 1;
        }
        if (Biome.isShallowOcean(e, getVersion())) {
            i++;
        }
        if (Biome.isShallowOcean(w, getVersion())) {
            i++;
        }
        if (Biome.isShallowOcean(s, getVersion())) {
            i++;
        }
        if (i > 3) {
            return center == Biomes.WARM_OCEAN.getId() ? Biomes.DEEP_WARM_OCEAN.getId() : center == Biomes.LUKEWARM_OCEAN.getId() ? Biomes.DEEP_LUKEWARM_OCEAN.getId() : center == Biomes.OCEAN.getId() ? Biomes.DEEP_OCEAN.getId() : center == Biomes.COLD_OCEAN.getId() ? Biomes.DEEP_COLD_OCEAN.getId() : center == Biomes.FROZEN_OCEAN.getId() ? Biomes.DEEP_FROZEN_OCEAN.getId() : Biomes.DEEP_OCEAN.getId();
        }
        return center;
    }
}
