package com.seedfinding.mcbiome.layer;

import com.seedfinding.mcbiome.layer.cache.FloatLayerCache;
import com.seedfinding.mccore.version.MCVersion;

public abstract class FloatBiomeLayer extends BiomeLayer {
    private final FloatLayerCache layerCache;

    public abstract float sample(int i, int i2, int i3);

    public FloatBiomeLayer(MCVersion version, BiomeLayer... parents) {
        super(version, parents);
        this.layerCache = new FloatLayerCache(1024);
    }

    public FloatBiomeLayer(MCVersion version) {
        super(version);
        this.layerCache = new FloatLayerCache(1024);
    }

    public FloatBiomeLayer(MCVersion version, long worldSeed, long salt, BiomeLayer... parents) {
        super(version, worldSeed, salt, parents);
        this.layerCache = new FloatLayerCache(1024);
    }

    public FloatBiomeLayer(MCVersion version, long worldSeed, long salt) {
        super(version, worldSeed, salt);
        this.layerCache = new FloatLayerCache(1024);
    }

    public float get(int x, int y, int z) {
        return this.layerCache.get(x, y, z, this::sample);
    }

    public float[] sample(int x, int y, int z, int xSize, int ySize, int zSize) {
        throw new UnsupportedOperationException();
    }
}
