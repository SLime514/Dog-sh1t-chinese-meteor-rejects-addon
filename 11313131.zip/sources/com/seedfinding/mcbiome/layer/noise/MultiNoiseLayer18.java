package com.seedfinding.mcbiome.layer.noise;

import com.seedfinding.mcbiome.biome.Biome;
import com.seedfinding.mcbiome.biome.Biomes;
import com.seedfinding.mcbiome.layer.IntBiomeLayer;
import com.seedfinding.mccore.rand.ChunkRand;
import com.seedfinding.mccore.util.data.Pair;
import com.seedfinding.mccore.version.MCVersion;
import com.seedfinding.mcnoise.noise.DoublePerlinNoiseSampler;
import java.util.Arrays;
import java.util.List;

public class MultiNoiseLayer18 extends IntBiomeLayer {
    private final TargetPoint[] biomePoints;
    private final boolean is3D;
    private DoublePerlinNoiseSampler temperature;
    private DoublePerlinNoiseSampler humidity;
    private DoublePerlinNoiseSampler altitude;
    private DoublePerlinNoiseSampler erosion;
    private DoublePerlinNoiseSampler weirdness;
    private DoublePerlinNoiseSampler offset;
    public static final TerrainShaper shaper = new TerrainShaper();

    public MultiNoiseLayer18(MCVersion version, long worldSeed, boolean is3D, TargetPoint[] biomePoints) {
        super(version, (IntBiomeLayer) null);
        this.is3D = is3D;
        if (biomePoints != null) {
            this.temperature = new DoublePerlinNoiseSampler(new ChunkRand(worldSeed), (Pair<Integer, List<Double>>) new Pair(-9, Arrays.asList(Double.valueOf(1.0d), Double.valueOf(1.0d), Double.valueOf(0.0d), Double.valueOf(1.0d), Double.valueOf(1.0d), Double.valueOf(0.0d))));
            this.humidity = new DoublePerlinNoiseSampler(new ChunkRand(worldSeed + 1), (Pair<Integer, List<Double>>) new Pair(-7, Arrays.asList(Double.valueOf(1.0d), Double.valueOf(0.0d), Double.valueOf(1.0d), Double.valueOf(0.0d), Double.valueOf(1.0d), Double.valueOf(0.0d))));
            this.altitude = new DoublePerlinNoiseSampler(new ChunkRand(worldSeed + 2), (Pair<Integer, List<Double>>) new Pair(-9, Arrays.asList(Double.valueOf(1.0d), Double.valueOf(1.0d), Double.valueOf(2.0d), Double.valueOf(2.0d), Double.valueOf(2.0d), Double.valueOf(1.0d), Double.valueOf(1.0d), Double.valueOf(1.0d), Double.valueOf(1.0d))));
            this.erosion = new DoublePerlinNoiseSampler(new ChunkRand(worldSeed + 3), (Pair<Integer, List<Double>>) new Pair(-9, Arrays.asList(Double.valueOf(1.0d), Double.valueOf(1.0d), Double.valueOf(0.0d), Double.valueOf(1.0d), Double.valueOf(1.0d))));
            this.weirdness = new DoublePerlinNoiseSampler(new ChunkRand(worldSeed + 4), (Pair<Integer, List<Double>>) new Pair(-7, Arrays.asList(Double.valueOf(1.0d), Double.valueOf(2.0d), Double.valueOf(1.0d), Double.valueOf(0.0d), Double.valueOf(0.0d), Double.valueOf(0.0d))));
            this.offset = new DoublePerlinNoiseSampler(new ChunkRand(worldSeed + 5), (Pair<Integer, List<Double>>) new Pair(-3, Arrays.asList(Double.valueOf(1.0d), Double.valueOf(1.0d), Double.valueOf(1.0d), Double.valueOf(0.0d))));
        }
        this.biomePoints = biomePoints;
    }

    public MultiNoiseLayer18(MCVersion version, long worldSeed, boolean is3D, TargetPoint[] biomePoints, NoiseSettings noiseSettings) {
        super(version, (IntBiomeLayer) null);
        this.is3D = is3D;
        if (biomePoints != null) {
            this.temperature = new DoublePerlinNoiseSampler(new ChunkRand(worldSeed), noiseSettings.temperatureNoise);
            this.humidity = new DoublePerlinNoiseSampler(new ChunkRand(worldSeed + 1), noiseSettings.humidityNoise);
            this.altitude = new DoublePerlinNoiseSampler(new ChunkRand(worldSeed + 2), noiseSettings.altitudeNoise);
            this.erosion = new DoublePerlinNoiseSampler(new ChunkRand(worldSeed + 3), noiseSettings.erosionNoise);
            this.altitude = new DoublePerlinNoiseSampler(new ChunkRand(worldSeed + 4), noiseSettings.altitudeNoise);
            this.offset = new DoublePerlinNoiseSampler(new ChunkRand(worldSeed + 5), noiseSettings.offsetNoise);
        }
        this.biomePoints = biomePoints;
    }

    @Override
    public int sample(int x, int y, int z) {
        if (this.biomePoints == null) {
            return Biomes.THE_VOID.getId();
        }
        double X = x + (this.offset.sample(x, 0.0d, z) * 4.0d);
        double Y = y + (this.offset.sample(y, z, x) * 4.0d);
        double Z = z + (this.offset.sample(z, x, 0.0d) * 4.0d);
        float altitude = (float) this.altitude.sample(X, 0.0d, Z);
        float erosion = (float) this.erosion.sample(X, 0.0d, Z);
        float weirdness = (float) this.weirdness.sample(X, 0.0d, Z);
        double shape = shaper.compute(altitude, erosion, weirdness);
        float depth = (float) (computeDimensionDensity(1.0d, -0.51875d, y * 4) + shape);
        float temperature = (float) this.temperature.sample(X, Y, Z);
        float humidity = (float) this.humidity.sample(X, Y, Z);
        TargetPoint target = new TargetPoint(temperature, humidity, altitude, erosion, depth, weirdness);
        return bruteforceFinder(target, Arrays.asList(new BiomePoint[0])).getId();
    }

    private Biome bruteforceFinder(TargetPoint target, List<BiomePoint> biomes) {
        float current = Float.MAX_VALUE;
        Biome biome = Biomes.THE_VOID;
        for (BiomePoint biomePoint : biomes) {
            float fitness = biomePoint.fitness(target);
            if (fitness < current) {
                current = fitness;
                biome = biomePoint.getBiome();
            }
        }
        return biome;
    }

    public static class BiomePoint {
        public final Biome biome;
        public final Pair<Float, Float> temperature;
        public final Pair<Float, Float> humidity;
        public final Pair<Float, Float> altitude;
        public final Pair<Float, Float> erosion;
        public final Pair<Float, Float> depth;
        public final Pair<Float, Float> weirdness;
        public final float offset;

        public BiomePoint(Biome biome, Pair<Float, Float> temperature, Pair<Float, Float> humidity, Pair<Float, Float> altitude, Pair<Float, Float> erosion, Pair<Float, Float> depth, Pair<Float, Float> weirdness, float offset) {
            this.biome = biome;
            this.temperature = temperature;
            this.humidity = humidity;
            this.altitude = altitude;
            this.erosion = erosion;
            this.depth = depth;
            this.weirdness = weirdness;
            this.offset = offset;
        }

        public Biome getBiome() {
            return this.biome;
        }

        float fitness(TargetPoint targetPoint) {
            return square(distance(this.temperature, targetPoint.temperature)) + square(distance(this.humidity, targetPoint.humidity)) + square(distance(this.altitude, targetPoint.altitude)) + square(distance(this.erosion, targetPoint.erosion)) + square(distance(this.depth, targetPoint.depth)) + square(distance(this.weirdness, targetPoint.weirdness)) + square(this.offset);
        }

        public static float distance(Pair<Float, Float> minMax, float f) {
            float f2 = f - minMax.getSecond().floatValue();
            float f3 = minMax.getFirst().floatValue() - f;
            if (f2 > 0.0f) {
                return f2;
            }
            return Math.max(f3, 0.0f);
        }

        public static float square(float f) {
            return f * f;
        }
    }

    public static class TargetPoint {
        public final float temperature;
        public final float humidity;
        public final float altitude;
        public final float erosion;
        public final float depth;
        public final float weirdness;

        public TargetPoint(float temperature, float humidity, float altitude, float erosion, float depth, float weirdness) {
            this.temperature = temperature;
            this.humidity = humidity;
            this.altitude = altitude;
            this.erosion = erosion;
            this.depth = depth;
            this.weirdness = weirdness;
        }
    }

    public static double computeDimensionDensity(double x, double y, double z) {
        return computeDimensionDensity(x, y, z, 0.0d);
    }

    public static double computeDimensionDensity(double x, double y, double z, double offset) {
        double d5 = (1.0d - (z / 128.0d)) + offset;
        return (d5 * x) + y;
    }

    public static class TerrainShaper {
        public double compute(float x, float y, float z) {
            peaksAndValleys(z);
            return 0.014999999664723873d;
        }

        public static float peaksAndValleys(float f) {
            return (-(Math.abs(Math.abs(f) - 0.6666667f) - 0.33333334f)) * 3.0f;
        }
    }

    public static class NoiseSettings {
        public Pair<Integer, List<Double>> temperatureNoise;
        public Pair<Integer, List<Double>> humidityNoise;
        public Pair<Integer, List<Double>> altitudeNoise;
        public Pair<Integer, List<Double>> erosionNoise;
        public Pair<Integer, List<Double>> weirdnessNoise;
        public Pair<Integer, List<Double>> offsetNoise;

        public NoiseSettings() {
            setTemperature(-9, Arrays.asList(Double.valueOf(1.0d), Double.valueOf(1.0d), Double.valueOf(0.0d), Double.valueOf(1.0d), Double.valueOf(1.0d), Double.valueOf(0.0d))).setHumidity(-7, Arrays.asList(Double.valueOf(1.0d), Double.valueOf(0.0d), Double.valueOf(1.0d), Double.valueOf(0.0d), Double.valueOf(1.0d), Double.valueOf(0.0d))).setAltitude(-9, Arrays.asList(Double.valueOf(1.0d), Double.valueOf(1.0d), Double.valueOf(2.0d), Double.valueOf(2.0d), Double.valueOf(2.0d), Double.valueOf(1.0d), Double.valueOf(1.0d), Double.valueOf(1.0d), Double.valueOf(1.0d))).setErosion(-9, Arrays.asList(Double.valueOf(1.0d), Double.valueOf(1.0d), Double.valueOf(0.0d), Double.valueOf(1.0d), Double.valueOf(1.0d))).setWeirdness(-7, Arrays.asList(Double.valueOf(1.0d), Double.valueOf(2.0d), Double.valueOf(1.0d), Double.valueOf(0.0d), Double.valueOf(0.0d), Double.valueOf(0.0d))).setOffset(-3, Arrays.asList(Double.valueOf(1.0d), Double.valueOf(1.0d), Double.valueOf(1.0d), Double.valueOf(0.0d)));
        }

        public NoiseSettings setTemperature(int firstOctaves, List<Double> amplitudes) {
            this.temperatureNoise = new Pair<>(Integer.valueOf(firstOctaves), amplitudes);
            return this;
        }

        public NoiseSettings setHumidity(int firstOctaves, List<Double> amplitudes) {
            this.humidityNoise = new Pair<>(Integer.valueOf(firstOctaves), amplitudes);
            return this;
        }

        public NoiseSettings setAltitude(int firstOctaves, List<Double> amplitudes) {
            this.altitudeNoise = new Pair<>(Integer.valueOf(firstOctaves), amplitudes);
            return this;
        }

        public NoiseSettings setErosion(int firstOctaves, List<Double> amplitudes) {
            this.erosionNoise = new Pair<>(Integer.valueOf(firstOctaves), amplitudes);
            return this;
        }

        public NoiseSettings setWeirdness(int firstOctaves, List<Double> amplitudes) {
            this.weirdnessNoise = new Pair<>(Integer.valueOf(firstOctaves), amplitudes);
            return this;
        }

        public NoiseSettings setOffset(int firstOctaves, List<Double> amplitudes) {
            this.offsetNoise = new Pair<>(Integer.valueOf(firstOctaves), amplitudes);
            return this;
        }
    }
}
