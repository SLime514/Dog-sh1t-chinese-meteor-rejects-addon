package com.seedfinding.mcbiome.layer.noise;

import com.seedfinding.mcbiome.biome.Biome;
import com.seedfinding.mcbiome.layer.IntBiomeLayer;
import com.seedfinding.mccore.version.MCVersion;

public class NoiseLayer extends IntBiomeLayer {
    public NoiseLayer(MCVersion version, long worldSeed, long salt, IntBiomeLayer parent) {
        super(version, worldSeed, salt, parent);
    }

    @Override
    public int sample(int x, int y, int z) {
        setSeed(x, z);
        int i = ((IntBiomeLayer) getParent(IntBiomeLayer.class)).get(x, y, z);
        if (Biome.isShallowOcean(i, getVersion())) {
            return i;
        }
        return nextInt(getVersion().isOlderOrEqualTo(MCVersion.v1_6_4) ? 2 : 299999) + 2;
    }
}
