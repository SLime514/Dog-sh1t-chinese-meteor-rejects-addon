package com.seedfinding.mcbiome.layer.noise;

import com.seedfinding.mcbiome.biome.Biome;
import com.seedfinding.mcbiome.biome.BiomePoint;
import com.seedfinding.mcbiome.biome.Biomes;
import com.seedfinding.mcbiome.layer.IntBiomeLayer;
import com.seedfinding.mccore.rand.ChunkRand;
import com.seedfinding.mccore.util.data.Pair;
import com.seedfinding.mccore.version.MCVersion;
import com.seedfinding.mcnoise.noise.DoublePerlinNoiseSampler;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class MultiNoiseLayer17 extends IntBiomeLayer {
    private final BiomePoint[] biomePoints;
    private final boolean is3D;
    private DoublePerlinNoiseSampler temperature;
    private DoublePerlinNoiseSampler humidity;
    private DoublePerlinNoiseSampler altitude;
    private DoublePerlinNoiseSampler weirdness;

    public MultiNoiseLayer17(MCVersion version, long worldSeed, boolean is3D, BiomePoint[] biomePoints) {
        super(version, (IntBiomeLayer) null);
        this.is3D = is3D;
        if (biomePoints != null) {
            this.temperature = new DoublePerlinNoiseSampler(new ChunkRand(worldSeed), IntStream.rangeClosed(-7, -6));
            this.humidity = new DoublePerlinNoiseSampler(new ChunkRand(worldSeed + 1), IntStream.rangeClosed(-7, -6));
            this.altitude = new DoublePerlinNoiseSampler(new ChunkRand(worldSeed + 2), IntStream.rangeClosed(-7, -6));
            this.weirdness = new DoublePerlinNoiseSampler(new ChunkRand(worldSeed + 3), IntStream.rangeClosed(-7, -6));
        }
        this.biomePoints = biomePoints;
    }

    public MultiNoiseLayer17(MCVersion version, long worldSeed, boolean is3D, BiomePoint[] biomePoints, NoiseSettings noiseSettings) {
        super(version, (IntBiomeLayer) null);
        this.is3D = is3D;
        if (biomePoints != null) {
            this.temperature = new DoublePerlinNoiseSampler(new ChunkRand(worldSeed), noiseSettings.temperatureNoise);
            this.humidity = new DoublePerlinNoiseSampler(new ChunkRand(worldSeed + 1), noiseSettings.humidityNoise);
            this.altitude = new DoublePerlinNoiseSampler(new ChunkRand(worldSeed + 2), noiseSettings.altitudeNoise);
            this.weirdness = new DoublePerlinNoiseSampler(new ChunkRand(worldSeed + 3), noiseSettings.weirdnessNoise);
        }
        this.biomePoints = biomePoints;
    }

    @Override
    public int sample(int x, int y, int z) {
        if (this.biomePoints == null) {
            return Biomes.THE_VOID.getId();
        }
        int y2 = this.is3D ? y : 0;
        BiomePoint point = new BiomePoint(null, (float) this.temperature.sample(x, y2, z), (float) this.humidity.sample(x, y2, z), (float) this.altitude.sample(x, y2, z), (float) this.weirdness.sample(x, y2, z), 0.0f);
        return ((Biome) Stream.of((Object[]) this.biomePoints).min(Comparator.comparing(m -> {
            return Float.valueOf(m.distanceTo(point));
        })).map((v0) -> {
            return v0.getBiome();
        }).orElse(Biomes.THE_VOID)).getId();
    }

    public static class NoiseSettings {
        public Pair<Integer, List<Double>> temperatureNoise;
        public Pair<Integer, List<Double>> humidityNoise;
        public Pair<Integer, List<Double>> altitudeNoise;
        public Pair<Integer, List<Double>> weirdnessNoise;

        public NoiseSettings() {
            setTemperature(-7, Arrays.asList(Double.valueOf(1.0d), Double.valueOf(1.0d))).setHumidity(-7, Arrays.asList(Double.valueOf(1.0d), Double.valueOf(1.0d))).setAltitude(-7, Arrays.asList(Double.valueOf(1.0d), Double.valueOf(1.0d))).setWeirdness(-7, Arrays.asList(Double.valueOf(1.0d), Double.valueOf(1.0d)));
        }

        public NoiseSettings setTemperature(int firstOctaves, List<Double> amplitudes) {
            this.temperatureNoise = new Pair<>(Integer.valueOf(firstOctaves), amplitudes);
            return this;
        }

        public NoiseSettings setHumidity(int firstOctaves, List<Double> amplitudes) {
            this.humidityNoise = new Pair<>(Integer.valueOf(firstOctaves), amplitudes);
            return this;
        }

        public NoiseSettings setAltitude(int firstOctaves, List<Double> amplitudes) {
            this.altitudeNoise = new Pair<>(Integer.valueOf(firstOctaves), amplitudes);
            return this;
        }

        public NoiseSettings setWeirdness(int firstOctaves, List<Double> amplitudes) {
            this.weirdnessNoise = new Pair<>(Integer.valueOf(firstOctaves), amplitudes);
            return this;
        }
    }
}
