package com.seedfinding.mcbiome.layer;

import com.seedfinding.mcbiome.layer.cache.IntLayerCache;
import com.seedfinding.mcbiome.layer.composite.VoronoiLayer;
import com.seedfinding.mcbiome.layer.scale.ScaleLayer;
import com.seedfinding.mccore.version.MCVersion;

public abstract class IntBiomeLayer extends BiomeLayer {
    private final IntLayerCache layerCache;

    public abstract int sample(int i, int i2, int i3);

    public IntBiomeLayer(MCVersion version, BiomeLayer... parents) {
        super(version, parents);
        this.layerCache = new IntLayerCache(1024);
    }

    public IntBiomeLayer(MCVersion version) {
        super(version);
        this.layerCache = new IntLayerCache(1024);
    }

    public IntBiomeLayer(MCVersion version, long worldSeed, long salt, BiomeLayer... parents) {
        super(version, worldSeed, salt, parents);
        this.layerCache = new IntLayerCache(1024);
    }

    public IntBiomeLayer(MCVersion version, long worldSeed, long salt) {
        super(version, worldSeed, salt);
        this.layerCache = new IntLayerCache(1024);
    }

    public int get(int x, int y, int z) {
        return this.layerCache.get(x, y, z, this::sample);
    }

    public void _sample(int x, int z, int xSize, int zSize) throws UnsupportedOperationException {
        if (getParents() == null) {
            throw new UnsupportedOperationException("Error, in our model, this should not happen (we use a null parent array)");
        }
        BiomeLayer[] parents = getParents();
        if (0 < parents.length) {
            BiomeLayer biomeLayer = parents[0];
            int shift = 0;
            if (this instanceof ScaleLayer) {
                shift = 1;
            } else if (this instanceof VoronoiLayer) {
                shift = 2;
            }
            if (biomeLayer == null) {
                for (int offX = 0; offX < xSize; offX++) {
                    for (int offZ = 0; offZ < zSize; offZ++) {
                        this.layerCache.forceStoreAndGet(x + offX, 0, z + offZ, this::sample);
                    }
                }
                return;
            }
            ((IntBiomeLayer) biomeLayer)._sample((x >> shift) - 1, (z >> shift) - 1, xSize + 2, zSize + 2);
            for (int offX2 = 0; offX2 < xSize; offX2++) {
                for (int offZ2 = 0; offZ2 < zSize; offZ2++) {
                    this.layerCache.get(x + offX2, 0, z + offZ2, this::sample);
                }
            }
        }
    }

    public int[] sample(int x, int y, int z, int xSize, int ySize, int zSize) {
        try {
            _sample(x, z, xSize, zSize);
        } catch (UnsupportedOperationException e) {
            e.printStackTrace();
        }
        int[] ids = new int[xSize * zSize];
        for (int offX = 0; offX < xSize; offX++) {
            for (int offZ = 0; offZ < zSize; offZ++) {
                ids[(offX * zSize) + offZ] = this.layerCache.get(x + offX, 0, z + offZ, this::sample);
            }
        }
        return ids;
    }
}
