package com.seedfinding.mcbiome.layer.cache;

import com.seedfinding.mcmath.util.Mth;
import java.util.Arrays;

public class IntLayerCache {
    private final long[] keys;
    private final int[] values;
    private final int mask;

    @FunctionalInterface
    public interface Sampler {
        int sample(int i, int i2, int i3);
    }

    public IntLayerCache(int capacity) {
        if (capacity < 1 || !Mth.isPowerOf2(capacity)) {
            throw new UnsupportedOperationException("capacity must be a power of 2");
        }
        this.keys = new long[capacity];
        Arrays.fill(this.keys, -1L);
        this.values = new int[capacity];
        this.mask = (int) Mth.getMask(Long.numberOfTrailingZeros(capacity));
    }

    public int get(int x, int y, int z, Sampler sampler) {
        long key = uniqueHash(x, y, z);
        int id = murmur64(key) & this.mask;
        if (this.keys[id] == key) {
            return this.values[id];
        }
        int value = sampler.sample(x, y, z);
        this.keys[id] = key;
        this.values[id] = value;
        return value;
    }

    public int getWithoutStore(int x, int y, int z, Sampler sampler) {
        long key = uniqueHash(x, y, z);
        int id = murmur64(key) & this.mask;
        if (this.keys[id] == key) {
            return this.values[id];
        }
        return sampler.sample(x, y, z);
    }

    public int forceStoreAndGet(int x, int y, int z, Sampler sampler) {
        long key = uniqueHash(x, y, z);
        int id = murmur64(key) & this.mask;
        int value = sampler.sample(x, y, z);
        this.keys[id] = key;
        this.values[id] = value;
        return value;
    }

    public long uniqueHash(int x, int y, int z) {
        long hash = x & Mth.getMask(26);
        return hash | ((z & Mth.getMask(26)) << 26) | ((y & Mth.getMask(8)) << 52);
    }

    public int murmur64(long value) {
        long value2 = (value ^ (value >>> 33)) * (-49064778989728563L);
        long value3 = (value2 ^ (value2 >>> 33)) * (-4265267296055464877L);
        return (int) (value3 ^ (value3 >>> 33));
    }
}
