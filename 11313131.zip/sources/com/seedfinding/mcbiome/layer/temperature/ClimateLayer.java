package com.seedfinding.mcbiome.layer.temperature;

import com.seedfinding.mcbiome.biome.Biome;
import com.seedfinding.mcbiome.biome.Biomes;
import com.seedfinding.mcbiome.layer.IntBiomeLayer;
import com.seedfinding.mcbiome.layer.composite.CrossLayer;
import com.seedfinding.mccore.version.MCVersion;

public class ClimateLayer {

    public static class Cold extends IntBiomeLayer {
        public Cold(MCVersion version, long worldSeed, long salt, IntBiomeLayer parent) {
            super(version, worldSeed, salt, parent);
        }

        @Override
        public int sample(int x, int y, int z) {
            int value = ((IntBiomeLayer) getParent(IntBiomeLayer.class)).get(x, y, z);
            if (Biome.isShallowOcean(value, getVersion())) {
                return value;
            }
            setSeed(x, z);
            if (getVersion().isOlderOrEqualTo(MCVersion.v1_6_4)) {
                return nextInt(5) == 0 ? Biomes.SNOWY_TUNDRA.getId() : Biomes.PLAINS.getId();
            }
            int i = nextInt(6);
            return i == 0 ? Biomes.FOREST.getId() : i == 1 ? Biomes.MOUNTAINS.getId() : Biomes.PLAINS.getId();
        }
    }

    public static class Temperate extends CrossLayer {
        public Temperate(MCVersion version, long worldSeed, long salt, IntBiomeLayer parent) {
            super(version, worldSeed, salt, parent);
        }

        @Override
        public int sample(int n, int e, int s, int w, int center) {
            return (center == Biomes.PLAINS.getId() && (n == Biomes.MOUNTAINS.getId() || e == Biomes.MOUNTAINS.getId() || w == Biomes.MOUNTAINS.getId() || s == Biomes.MOUNTAINS.getId() || n == Biomes.FOREST.getId() || e == Biomes.FOREST.getId() || w == Biomes.FOREST.getId() || s == Biomes.FOREST.getId())) ? Biomes.DESERT.getId() : center;
        }
    }

    public static class Cool extends CrossLayer {
        public Cool(MCVersion version, long worldSeed, long salt, IntBiomeLayer parent) {
            super(version, worldSeed, salt, parent);
        }

        @Override
        public int sample(int n, int e, int s, int w, int center) {
            return (center == Biomes.FOREST.getId() && (n == Biomes.PLAINS.getId() || e == Biomes.PLAINS.getId() || w == Biomes.PLAINS.getId() || s == Biomes.PLAINS.getId() || n == Biomes.DESERT.getId() || e == Biomes.DESERT.getId() || w == Biomes.DESERT.getId() || s == Biomes.DESERT.getId())) ? Biomes.MOUNTAINS.getId() : center;
        }
    }

    public static class Special extends IntBiomeLayer {
        public Special(MCVersion version, long worldSeed, long salt, IntBiomeLayer parent) {
            super(version, worldSeed, salt, parent);
        }

        @Override
        public int sample(int x, int y, int z) {
            int i = ((IntBiomeLayer) getParent(IntBiomeLayer.class)).get(x, y, z);
            if (Biome.isShallowOcean(i, getVersion())) {
                return i;
            }
            setSeed(x, z);
            if (nextInt(13) == 0) {
                i |= (1 + nextInt(15)) << 8;
            }
            return i;
        }
    }
}
