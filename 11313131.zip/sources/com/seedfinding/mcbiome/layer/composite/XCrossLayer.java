package com.seedfinding.mcbiome.layer.composite;

import com.seedfinding.mcbiome.layer.IntBiomeLayer;
import com.seedfinding.mccore.version.MCVersion;

public abstract class XCrossLayer extends IntBiomeLayer {
    public abstract int sample(int i, int i2, int i3, int i4, int i5);

    public XCrossLayer(MCVersion version, long worldSeed, long salt, IntBiomeLayer parent) {
        super(version, worldSeed, salt, parent);
    }

    @Override
    public int sample(int x, int y, int z) {
        setSeed(x, z);
        return sample(((IntBiomeLayer) getParent(IntBiomeLayer.class)).get(x - 1, y, z + 1), ((IntBiomeLayer) getParent(IntBiomeLayer.class)).get(x + 1, y, z + 1), ((IntBiomeLayer) getParent(IntBiomeLayer.class)).get(x + 1, y, z - 1), ((IntBiomeLayer) getParent(IntBiomeLayer.class)).get(x - 1, y, z - 1), ((IntBiomeLayer) getParent(IntBiomeLayer.class)).get(x, y, z));
    }
}
