package com.seedfinding.mcbiome.layer.end;

import com.seedfinding.mcbiome.biome.Biomes;
import com.seedfinding.mcbiome.layer.FloatBiomeLayer;
import com.seedfinding.mcbiome.layer.IntBiomeLayer;
import com.seedfinding.mccore.version.MCVersion;

public class EndBiomeLayer extends IntBiomeLayer {
    public EndBiomeLayer(MCVersion version, FloatBiomeLayer parent) {
        super(version, parent);
    }

    @Override
    public int sample(int x, int y, int z) {
        int x2 = x >> 2;
        int z2 = z >> 2;
        if ((x2 * x2) + (z2 * z2) <= 4096) {
            return Biomes.THE_END.getId();
        }
        float height = ((FloatBiomeLayer) getParent(FloatBiomeLayer.class)).get((x2 * 2) + 1, 0, (z2 * 2) + 1);
        if (height > 40.0f) {
            return Biomes.END_HIGHLANDS.getId();
        }
        if (height >= 0.0f) {
            return Biomes.END_MIDLANDS.getId();
        }
        if (height >= -20.0f) {
            return Biomes.END_BARRENS.getId();
        }
        return Biomes.SMALL_END_ISLANDS.getId();
    }
}
