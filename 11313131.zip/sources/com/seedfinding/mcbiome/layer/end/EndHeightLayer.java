package com.seedfinding.mcbiome.layer.end;

import com.seedfinding.mcbiome.layer.BoolBiomeLayer;
import com.seedfinding.mcbiome.layer.FloatBiomeLayer;
import com.seedfinding.mccore.version.MCVersion;

public class EndHeightLayer extends FloatBiomeLayer {
    public EndHeightLayer(MCVersion version, BoolBiomeLayer parent) {
        super(version, parent);
    }

    @Override
    public float sample(int x, int y, int z) {
        return getNoiseValueAt(x, z);
    }

    public float getNoiseValueAt(int x, int z) {
        float height;
        int scaledX = x / 2;
        int scaledZ = z / 2;
        int oddX = x % 2;
        int oddZ = z % 2;
        if (getVersion().isNewerOrEqualTo(MCVersion.v1_14)) {
            height = 100.0f - (((float) Math.sqrt((x * x) + (z * z))) * 8.0f);
        } else {
            height = 100.0f - (((float) Math.sqrt((x * x) + (z * z))) * 8.0f);
        }
        float height2 = clamp(height);
        for (int rx = -12; rx <= 12; rx++) {
            for (int rz = -12; rz <= 12; rz++) {
                long shiftedX = scaledX + rx;
                long shiftedZ = scaledZ + rz;
                if ((shiftedX * shiftedX) + (shiftedZ * shiftedZ) > 4096 && ((BoolBiomeLayer) getParent(BoolBiomeLayer.class)).get((int) shiftedX, 0, (int) shiftedZ)) {
                    float elevation = (((Math.abs(shiftedX) * 3439.0f) + (Math.abs(shiftedZ) * 147.0f)) % 13.0f) + 9.0f;
                    float smoothX = oddX - (rx * 2);
                    float smoothZ = oddZ - (rz * 2);
                    float noise = 100.0f - (((float) Math.sqrt((smoothX * smoothX) + (smoothZ * smoothZ))) * elevation);
                    height2 = Math.max(height2, clamp(noise));
                }
            }
        }
        return height2;
    }

    protected static float clamp(float value) {
        if (value < -100.0f) {
            return -100.0f;
        }
        return Math.min(value, 80.0f);
    }
}
