package com.seedfinding.mcbiome.layer.land;

import com.seedfinding.mcbiome.biome.Biome;
import com.seedfinding.mcbiome.biome.Biomes;
import com.seedfinding.mcbiome.layer.IntBiomeLayer;
import com.seedfinding.mccore.version.MCVersion;

public class BaseBiomesLayer extends IntBiomeLayer {
    public boolean useDefault1_1;
    public static final Biome[] DRY_BIOMES = {Biomes.DESERT, Biomes.DESERT, Biomes.DESERT, Biomes.SAVANNA, Biomes.SAVANNA, Biomes.PLAINS};
    public static final Biome[] TEMPERATE_BIOMES = {Biomes.FOREST, Biomes.DARK_FOREST, Biomes.MOUNTAINS, Biomes.PLAINS, Biomes.BIRCH_FOREST, Biomes.SWAMP};
    public static final Biome[] COOL_BIOMES = {Biomes.FOREST, Biomes.MOUNTAINS, Biomes.TAIGA, Biomes.PLAINS};
    public static final Biome[] SNOWY_BIOMES = {Biomes.SNOWY_TUNDRA, Biomes.SNOWY_TUNDRA, Biomes.SNOWY_TUNDRA, Biomes.SNOWY_TAIGA};
    public static final Biome[] OLD_BIOMES = {Biomes.DESERT, Biomes.FOREST, Biomes.MOUNTAINS, Biomes.SWAMP, Biomes.PLAINS, Biomes.TAIGA, Biomes.JUNGLE};
    public static final Biome[] OLD_BIOMES_DEFAULT_1_1 = {Biomes.DESERT, Biomes.FOREST, Biomes.MOUNTAINS, Biomes.SWAMP, Biomes.PLAINS, Biomes.TAIGA};

    public BaseBiomesLayer(MCVersion version, long worldSeed, long salt, IntBiomeLayer parent) {
        super(version, worldSeed, salt, parent);
        this.useDefault1_1 = false;
    }

    public BaseBiomesLayer setDefault1_1(boolean useDefault1_1) {
        this.useDefault1_1 = useDefault1_1;
        return this;
    }

    @Override
    public int sample(int x, int y, int z) {
        setSeed(x, z);
        int center = ((IntBiomeLayer) getParent(IntBiomeLayer.class)).get(x, y, z);
        int specialBits = (center >> 8) & 15;
        int center2 = center & (-3841);
        if (getVersion().isOlderOrEqualTo(MCVersion.v1_6_4)) {
            return sampleOld(center2);
        }
        if (Biome.isOcean(center2) || center2 == Biomes.MUSHROOM_FIELDS.getId()) {
            return center2;
        }
        if (center2 == Biomes.PLAINS.getId()) {
            if (specialBits > 0) {
                return nextInt(3) == 0 ? Biomes.BADLANDS_PLATEAU.getId() : Biomes.WOODED_BADLANDS_PLATEAU.getId();
            }
            if (this.useDefault1_1) {
                return OLD_BIOMES_DEFAULT_1_1[nextInt(OLD_BIOMES_DEFAULT_1_1.length)].getId();
            }
            return DRY_BIOMES[nextInt(DRY_BIOMES.length)].getId();
        }
        if (center2 == Biomes.DESERT.getId()) {
            if (specialBits > 0) {
                return Biomes.JUNGLE.getId();
            }
            return TEMPERATE_BIOMES[nextInt(TEMPERATE_BIOMES.length)].getId();
        }
        if (center2 == Biomes.MOUNTAINS.getId()) {
            if (specialBits > 0) {
                return Biomes.GIANT_TREE_TAIGA.getId();
            }
            return COOL_BIOMES[nextInt(COOL_BIOMES.length)].getId();
        }
        if (center2 == Biomes.FOREST.getId()) {
            return SNOWY_BIOMES[nextInt(SNOWY_BIOMES.length)].getId();
        }
        return Biomes.MUSHROOM_FIELDS.getId();
    }

    private int sampleOld(int center) {
        if (Biome.isShallowOcean(center, getVersion())) {
            return Biomes.OCEAN.getId();
        }
        if (center == Biomes.MUSHROOM_FIELDS.getId()) {
            return Biomes.MUSHROOM_FIELDS.getId();
        }
        Biome[] biomeList = getVersion().isOlderOrEqualTo(MCVersion.v1_1) ? OLD_BIOMES_DEFAULT_1_1 : OLD_BIOMES;
        Biome oldBiome = biomeList[nextInt(biomeList.length)];
        if (getVersion().isOlderOrEqualTo(MCVersion.vb1_8_1)) {
            return oldBiome.getId();
        }
        if (center == Biomes.PLAINS.getId()) {
            return oldBiome.getId();
        }
        if (getVersion().isOlderOrEqualTo(MCVersion.v1_2_5)) {
            return Biomes.SNOWY_TUNDRA.getId();
        }
        if (oldBiome == Biomes.TAIGA) {
            return Biomes.TAIGA.getId();
        }
        return Biomes.SNOWY_TUNDRA.getId();
    }
}
