package com.seedfinding.mcbiome.layer.land;

import com.seedfinding.mcbiome.biome.Biome;
import com.seedfinding.mcbiome.biome.Biomes;
import com.seedfinding.mcbiome.layer.IntBiomeLayer;
import com.seedfinding.mcbiome.layer.composite.XCrossLayer;
import com.seedfinding.mccore.version.MCVersion;

public class LandLayer extends XCrossLayer {
    public LandLayer(MCVersion version, long worldSeed, long salt, IntBiomeLayer parent) {
        super(version, worldSeed, salt, parent);
    }

    @Override
    public int sample(int sw, int se, int ne, int nw, int center) {
        if (getVersion().isOlderOrEqualTo(MCVersion.vb1_8_1)) {
            return sample_beta(sw, se, ne, nw, center);
        }
        if (!Biome.isShallowOcean(center, getVersion()) || Biome.applyAll(v -> {
            return Boolean.valueOf(Biome.isShallowOcean(v.intValue(), getVersion()));
        }, sw, se, ne, nw)) {
            if (Biome.isShallowOcean(center, getVersion()) || Biome.applyAll(v2 -> {
                return Boolean.valueOf(!Biome.isShallowOcean(v2.intValue(), getVersion()));
            }, sw, se, ne, nw) || nextInt(5) != 0) {
                return center;
            }
            if (getVersion().isOlderOrEqualTo(MCVersion.v1_6_4)) {
                return center == Biomes.SNOWY_TUNDRA.getId() ? Biomes.FROZEN_OCEAN.getId() : Biomes.OCEAN.getId();
            }
            if (Biome.isShallowOcean(nw, getVersion())) {
                return Biome.equalsOrDefault(center, Biomes.FOREST.getId(), nw);
            }
            if (Biome.isShallowOcean(sw, getVersion())) {
                return Biome.equalsOrDefault(center, Biomes.FOREST.getId(), sw);
            }
            if (Biome.isShallowOcean(ne, getVersion())) {
                return Biome.equalsOrDefault(center, Biomes.FOREST.getId(), ne);
            }
            if (Biome.isShallowOcean(se, getVersion())) {
                return Biome.equalsOrDefault(center, Biomes.FOREST.getId(), se);
            }
            return center;
        }
        int i = 1;
        int j = 1;
        if (!Biome.isShallowOcean(nw, getVersion())) {
            i = 1 + 1;
            if (nextInt(1) == 0) {
                j = nw;
            }
        }
        if (!Biome.isShallowOcean(ne, getVersion())) {
            int i2 = i;
            i++;
            if (nextInt(i2) == 0) {
                j = ne;
            }
        }
        if (!Biome.isShallowOcean(sw, getVersion())) {
            int i3 = i;
            i++;
            if (nextInt(i3) == 0) {
                j = sw;
            }
        }
        if (!Biome.isShallowOcean(se, getVersion()) && nextInt(i) == 0) {
            j = se;
        }
        if (nextInt(3) == 0) {
            return j;
        }
        return getVersion().isOlderOrEqualTo(MCVersion.v1_6_4) ? j == Biomes.SNOWY_TUNDRA.getId() ? Biomes.FROZEN_OCEAN.getId() : Biomes.OCEAN.getId() : j == Biomes.FOREST.getId() ? Biomes.FOREST.getId() : center;
    }

    public int sample_beta(int sw, int se, int ne, int nw, int center) {
        if (Biome.isShallowOcean(center, getVersion()) && !Biome.applyAll(v -> {
            return Boolean.valueOf(Biome.isShallowOcean(v.intValue(), getVersion()));
        }, sw, se, ne, nw)) {
            return nextInt(3) == 2 ? Biomes.PLAINS.getId() : Biomes.OCEAN.getId();
        }
        if (center != Biomes.PLAINS.getId() || Biome.applyAll(v2 -> {
            return Boolean.valueOf(v2.intValue() == Biomes.PLAINS.getId());
        }, sw, se, ne, nw)) {
            return center;
        }
        return nextInt(5) == 4 ? Biomes.OCEAN.getId() : Biomes.PLAINS.getId();
    }
}
