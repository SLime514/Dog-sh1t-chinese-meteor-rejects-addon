package com.seedfinding.mcbiome.layer.land;

import com.seedfinding.mcbiome.biome.Biomes;
import com.seedfinding.mcbiome.layer.IntBiomeLayer;
import com.seedfinding.mccore.version.MCVersion;

public class ContinentLayer extends IntBiomeLayer {
    public ContinentLayer(MCVersion version, long worldSeed, long salt) {
        super(version, worldSeed, salt);
    }

    @Override
    public int sample(int x, int y, int z) {
        setSeed(x, z);
        return ((x == 0 && z == 0) || nextInt(10) == 0) ? Biomes.PLAINS.getId() : Biomes.OCEAN.getId();
    }
}
