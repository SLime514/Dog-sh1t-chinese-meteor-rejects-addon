package com.seedfinding.mcbiome.layer.land;

import com.seedfinding.mcbiome.biome.Biomes;
import com.seedfinding.mcbiome.layer.IntBiomeLayer;
import com.seedfinding.mccore.version.MCVersion;

public class SunflowerPlainsLayer extends IntBiomeLayer {
    public SunflowerPlainsLayer(MCVersion version, long worldSeed, long salt, IntBiomeLayer parent) {
        super(version, worldSeed, salt, parent);
    }

    @Override
    public int sample(int x, int y, int z) {
        setSeed(x, z);
        int value = ((IntBiomeLayer) getParent(IntBiomeLayer.class)).get(x, y, z);
        return (value == Biomes.PLAINS.getId() && nextInt(57) == 0) ? Biomes.SUNFLOWER_PLAINS.getId() : value;
    }
}
