package com.seedfinding.mcbiome.layer.shore;

import com.seedfinding.mcbiome.biome.Biome;
import com.seedfinding.mcbiome.biome.Biomes;
import com.seedfinding.mcbiome.layer.IntBiomeLayer;
import com.seedfinding.mcbiome.layer.composite.CrossLayer;
import com.seedfinding.mccore.version.MCVersion;

public class EdgeBiomesLayer extends CrossLayer {
    public EdgeBiomesLayer(MCVersion version, long worldSeed, long salt, IntBiomeLayer parent) {
        super(version, worldSeed, salt, parent);
    }

    @Override
    public int sample(int n, int e, int s, int w, int center) {
        Biome biome = Biomes.REGISTRY.get(Integer.valueOf(center));
        if (center == Biomes.MUSHROOM_FIELDS.getId()) {
            if (Biome.applyAll(v -> {
                return Boolean.valueOf(!Biome.isShallowOcean(v.intValue(), getVersion()));
            }, n, e, s, w)) {
                return center;
            }
            return Biomes.MUSHROOM_FIELD_SHORE.getId();
        }
        if (getVersion().isOlderOrEqualTo(MCVersion.v1_0)) {
            return center;
        }
        if (getVersion().isOlderOrEqualTo(MCVersion.v1_6_4)) {
            return sampleOld(n, e, s, w, center);
        }
        if (biome != null && biome.getCategory() == Biome.Category.JUNGLE) {
            if (!Biome.applyAll((v0) -> {
                return isWooded(v0);
            }, n, e, s, w)) {
                return Biomes.JUNGLE_EDGE.getId();
            }
            if (Biome.applyAll(v2 -> {
                return Boolean.valueOf(!Biome.isOcean(v2.intValue()));
            }, n, e, s, w)) {
                return center;
            }
            return Biomes.BEACH.getId();
        }
        if (center != Biomes.MOUNTAINS.getId() && center != Biomes.WOODED_MOUNTAINS.getId() && center != Biomes.MOUNTAIN_EDGE.getId()) {
            if (biome != null && biome.getPrecipitation() == Biome.Precipitation.SNOW) {
                if (!Biome.isOcean(center) && !Biome.applyAll(v3 -> {
                    return Boolean.valueOf(!Biome.isOcean(v3.intValue()));
                }, n, e, s, w)) {
                    return Biomes.SNOWY_BEACH.getId();
                }
            } else if (center == Biomes.BADLANDS.getId() || center == Biomes.WOODED_BADLANDS_PLATEAU.getId()) {
                if (Biome.applyAll(v4 -> {
                    return Boolean.valueOf(!Biome.isOcean(v4.intValue()));
                }, n, e, s, w) && !Biome.applyAll((v0) -> {
                    return isBadlands(v0);
                }, n, e, s, w)) {
                    return Biomes.DESERT.getId();
                }
            } else if (!Biome.isOcean(center) && center != Biomes.RIVER.getId() && center != Biomes.SWAMP.getId() && !Biome.applyAll(v5 -> {
                return Boolean.valueOf(!Biome.isOcean(v5.intValue()));
            }, n, e, s, w)) {
                return Biomes.BEACH.getId();
            }
        } else if (!Biome.isOcean(center) && !Biome.applyAll(v6 -> {
            return Boolean.valueOf(!Biome.isOcean(v6.intValue()));
        }, n, e, s, w)) {
            return Biomes.STONE_SHORE.getId();
        }
        return center;
    }

    private static boolean isWooded(int id) {
        Biome b = Biomes.REGISTRY.get(Integer.valueOf(id));
        return (b != null && b.getCategory() == Biome.Category.JUNGLE) || id == Biomes.JUNGLE_EDGE.getId() || id == Biomes.JUNGLE.getId() || id == Biomes.JUNGLE_HILLS.getId() || id == Biomes.FOREST.getId() || id == Biomes.TAIGA.getId() || Biome.isOcean(id);
    }

    private static boolean isBadlands(int id) {
        return id == Biomes.BADLANDS.getId() || id == Biomes.WOODED_BADLANDS_PLATEAU.getId() || id == Biomes.BADLANDS_PLATEAU.getId() || id == Biomes.ERODED_BADLANDS.getId() || id == Biomes.MODIFIED_WOODED_BADLANDS_PLATEAU.getId() || id == Biomes.MODIFIED_BADLANDS_PLATEAU.getId();
    }

    private int sampleOld(int n, int e, int s, int w, int center) {
        if (center != Biomes.OCEAN.getId() && center != Biomes.RIVER.getId() && center != Biomes.SWAMP.getId() && center != Biomes.MOUNTAINS.getId()) {
            if (Biome.applyAll(v -> {
                return Boolean.valueOf(!Biome.isShallowOcean(v.intValue(), getVersion()));
            }, n, e, s, w)) {
                return center;
            }
            return Biomes.BEACH.getId();
        }
        if (center != Biomes.MOUNTAINS.getId()) {
            return center;
        }
        if (Biome.applyAll(v2 -> {
            return Boolean.valueOf(v2.intValue() == Biomes.MOUNTAINS.getId());
        }, n, e, s, w)) {
            return center;
        }
        return Biomes.MOUNTAIN_EDGE.getId();
    }
}
